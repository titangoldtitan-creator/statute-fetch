| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0070-0030-0120-0120 | 200 | 10173 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0120/0070-0030-0120-0120.html |    7-3-1212. Treatment of existing officers, MCA  |  |
| MTS_0070-0030-0120-0130 | 200 | 9528 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0130/0070-0030-0120-0130.html |    7-3-1213. Power to effectuate transition, MCA  |  |
| MTS_0070-0030-0120-0140 | 200 | 10021 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0140/0070-0030-0120-0140.html |    7-3-1214. Consolidated municipality commission, MCA  |  |
| MTS_0070-0030-0120-0150 | 200 | 9642 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0150/0070-0030-0120-0150.html |    7-3-1215. Qualifications for commission, MCA  |  |
| MTS_0070-0030-0120-0160 | 200 | 9955 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0160/0070-0030-0120-0160.html |    7-3-1216. Term of office of commission members, MCA  |  |
| MTS_0070-0030-0120-0170 | 200 | 9663 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0170/0070-0030-0120-0170.html |    7-3-1217. Vacancies, MCA  |  |
| MTS_0070-0030-0120-0180 | 200 | 10922 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0180/0070-0030-0120-0180.html |    7-3-1218. Meetings of commission, MCA  |  |
| MTS_0070-0030-0120-0190 | 200 | 10941 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0190/0070-0030-0120-0190.html |    7-3-1219. Organization and officers of commission, MCA  |  |
| MTS_0070-0030-0120-0200 | 200 | 10396 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0200/0070-0030-0120-0200.html |    7-3-1220. Conduct of commission business, MCA  |  |
| MTS_0070-0030-0120-0210 | 200 | 9996 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0210/0070-0030-0120-0210.html |    7-3-1221. Compensation of commission members, MCA  |  |
| MTS_0070-0030-0120-0220 | 200 | 12776 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0220/0070-0030-0120-0220.html |    7-3-1222. Procedure to enact ordinances and resolutions, MCA  |  |
| MTS_0070-0030-0120-0230 | 200 | 10503 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0230/0070-0030-0120-0230.html |    7-3-1223. Effective date of ordinances, MCA  |  |
| MTS_0070-0030-0120-0240 | 200 | 9458 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0240/0070-0030-0120-0240.html |    7-3-1224. Emergency measures, MCA  |  |
| MTS_0070-0030-0120-0250 | 200 | 9664 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0250/0070-0030-0120-0250.html |    7-3-1225. Vote required on certain measures, MCA  |  |
| MTS_0070-0030-0120-0260 | 200 | 10092 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0260/0070-0030-0120-0260.html |    7-3-1226. Codification of ordinances, MCA  |  |
| MTS_0070-0030-0120-0270 | 200 | 10167 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0270/0070-0030-0120-0270.html |    7-3-1227. Petition for initiative, MCA  |  |
| MTS_0070-0030-0120-0280 | 200 | 10167 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0280/0070-0030-0120-0280.html |    7-3-1228. Action on initiative petition, MCA  |  |
| MTS_0070-0030-0120-0290 | 200 | 10740 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0290/0070-0030-0120-0290.html |    7-3-1229. Submission of initiative measure to electors, MCA  |  |
| MTS_0070-0030-0120-0300 | 200 | 10237 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0300/0070-0030-0120-0300.html |    7-3-1230. Petition for referendum, MCA  |  |
| MTS_0070-0030-0120-0310 | 200 | 10303 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0310/0070-0030-0120-0310.html |    7-3-1231. Action on referendum petition, MCA  |  |
| MTS_0070-0030-0120-0320 | 200 | 9758 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0320/0070-0030-0120-0320.html |    7-3-1232. Preliminary acts authorized prior to submission of certain ordinanc |  |
| MTS_0070-0030-0120-0330 | 200 | 9223 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0330/0070-0030-0120-0330.html |    7-3-1233. Repealed, MCA  |  |
| MTS_0070-0030-0120-0340 | 200 | 9090 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0340/0070-0030-0120-0340.html |    7-3-1234. Repealed, MCA  |  |
| MTS_0070-0030-0120-0350 | 200 | 8886 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0350/0070-0030-0120-0350.html |    7-3-1235. through 7-3-1240 reserved, MCA  |  |
| MTS_0070-0030-0120-0410 | 200 | 10665 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0410/0070-0030-0120-0410.html |    7-3-1241. Appointment and removal of manager of consolidated municipality, MC |  |
| MTS_0070-0030-0120-0420 | 200 | 9764 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0420/0070-0030-0120-0420.html |    7-3-1242. Role of manager, MCA  |  |
| MTS_0070-0030-0120-0430 | 200 | 9517 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0430/0070-0030-0120-0430.html |    7-3-1243. Appointments by manager, MCA  |  |
| MTS_0070-0030-0120-0440 | 200 | 10778 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0440/0070-0030-0120-0440.html |    7-3-1244. Removal of appointees, MCA  |  |
| MTS_0070-0030-0120-0450 | 200 | 10384 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0450/0070-0030-0120-0450.html |    7-3-1245. Relationship of commission and manager regarding appointments and a |  |
| MTS_0070-0030-0120-0460 | 200 | 9906 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0460/0070-0030-0120-0460.html |    7-3-1246. General duties of manager, MCA  |  |
| MTS_0070-0030-0120-0470 | 200 | 9903 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0470/0070-0030-0120-0470.html |    7-3-1247. Attendance and participation of manager, directors, and other offic |  |
| MTS_0070-0030-0120-0480 | 200 | 10843 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0480/0070-0030-0120-0480.html |    7-3-1248. Departments of consolidated municipality, MCA  |  |
| MTS_0070-0030-0120-0490 | 200 | 11137 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0490/0070-0030-0120-0490.html |    7-3-1249. Employees and employment list, MCA  |  |
| MTS_0070-0030-0120-0500 | 200 | 10024 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0500/0070-0030-0120-0500.html |    7-3-1250. Compensation of officers and employees, MCA  |  |
| MTS_0070-0030-0120-0510 | 200 | 9642 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0510/0070-0030-0120-0510.html |    7-3-1251. Advisory boards, MCA  |  |
| MTS_0070-0030-0120-0520 | 200 | 10035 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0520/0070-0030-0120-0520.html |    7-3-1252. Investigatory powers of commission and manager, MCA  |  |
| MTS_0070-0030-0120-0530 | 200 | 9953 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0530/0070-0030-0120-0530.html |    7-3-1253. Disposition of money received by officers in official capacity, MCA |  |
| MTS_0070-0030-0120-0540 | 200 | 11751 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0540/0070-0030-0120-0540.html |    7-3-1254. Nonpartisan nature of government, MCA  |  |
| MTS_0070-0030-0120-0550 | 200 | 9618 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0550/0070-0030-0120-0550.html |    7-3-1255. Commissioners not to hold or seek other office, MCA  |  |
| MTS_0070-0030-0120-0560 | 200 | 9465 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0560/0070-0030-0120-0560.html |    7-3-1256. Appointive officers not to seek other office, MCA  |  |
| MTS_0070-0030-0120-0570 | 200 | 9882 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0570/0070-0030-0120-0570.html |    7-3-1257. Control of conflict of interest, MCA  |  |
| MTS_0070-0030-0120-0580 | 200 | 10060 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0580/0070-0030-0120-0580.html |    7-3-1258. Official bonds, MCA  |  |
| MTS_0070-0030-0120-0590 | 200 | 9365 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0590/0070-0030-0120-0590.html |    7-3-1259. Oath of office, MCA  |  |
| MTS_0070-0030-0120-0600 | 200 | 8868 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0600/0070-0030-0120-0600.html |    7-3-1260. through 7-3-1270 reserved, MCA  |  |
| MTS_0070-0030-0120-0710 | 200 | 9939 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0710/0070-0030-0120-0710.html |    7-3-1271. General provisions related to elections, MCA  |  |
| MTS_0070-0030-0120-0720 | 200 | 9110 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0720/0070-0030-0120-0720.html |    7-3-1272. Repealed, MCA  |  |
| MTS_0070-0030-0120-0730 | 200 | 9103 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0730/0070-0030-0120-0730.html |    7-3-1273. Repealed, MCA  |  |
| MTS_0070-0030-0120-0740 | 200 | 9073 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0740/0070-0030-0120-0740.html |    7-3-1274. Repealed, MCA  |  |
| MTS_0070-0030-0120-0750 | 200 | 9079 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0750/0070-0030-0120-0750.html |    7-3-1275. Repealed, MCA  |  |
| MTS_0070-0030-0120-0760 | 200 | 9317 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0760/0070-0030-0120-0760.html |    7-3-1276. Repealed, MCA  |  |
| MTS_0070-0030-0120-0770 | 200 | 9079 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0770/0070-0030-0120-0770.html |    7-3-1277. Repealed, MCA  |  |
| MTS_0070-0030-0120-0780 | 200 | 9073 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0780/0070-0030-0120-0780.html |    7-3-1278. Repealed, MCA  |  |
| MTS_0070-0030-0120-0790 | 200 | 9079 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0790/0070-0030-0120-0790.html |    7-3-1279. Repealed, MCA  |  |
| MTS_0070-0030-0120-0800 | 200 | 8879 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0120/section_0800/0070-0030-0120-0800.html |    7-3-1280. Repealed, MCA  |  |
| MTS_0070-0030-0130-0010 | 200 | 9871 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0010/0070-0030-0130-0010.html |    7-3-1301. Department of finance, MCA  |  |
| MTS_0070-0030-0130-0020 | 200 | 9191 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0020/0070-0030-0130-0020.html |    7-3-1302. Fiscal year, MCA  |  |
| MTS_0070-0030-0130-0030 | 200 | 9497 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0030/0070-0030-0130-0030.html |    7-3-1303. Monthly financial statements, MCA  |  |
| MTS_0070-0030-0130-0040 | 200 | 9729 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0040/0070-0030-0130-0040.html |    7-3-1304. Division of audit and accounts, MCA  |  |
| MTS_0070-0030-0130-0050 | 200 | 10150 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0050/0070-0030-0130-0050.html |    7-3-1305. Conduct of audits, MCA  |  |
| MTS_0070-0030-0130-0060 | 200 | 9984 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0060/0070-0030-0130-0060.html |    7-3-1306. Division of treasury, MCA  |  |
| MTS_0070-0030-0130-0070 | 200 | 9826 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0070/0070-0030-0130-0070.html |    7-3-1307. Division of purchases and supplies, MCA  |  |
| MTS_0070-0030-0130-0080 | 200 | 10028 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0080/0070-0030-0130-0080.html |    7-3-1308. Procedure for purchase, sale, and supply, MCA  |  |
| MTS_0070-0030-0130-0090 | 200 | 9853 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0090/0070-0030-0130-0090.html |    7-3-1309. Division of assessment, MCA  |  |
| MTS_0070-0030-0130-0100 | 200 | 10049 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0100/0070-0030-0130-0100.html |    7-3-1310. Limitation on tax levy, MCA  |  |
| MTS_0070-0030-0130-0110 | 200 | 10831 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0110/0070-0030-0130-0110.html |    7-3-1311. Authority for special taxes and special service districts, MCA  |  |
| MTS_0070-0030-0130-0120 | 200 | 9399 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0120/0070-0030-0130-0120.html |    7-3-1312. Collection of taxes, MCA  |  |
| MTS_0070-0030-0130-0130 | 200 | 11443 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0130/0070-0030-0130-0130.html |    7-3-1313. Special taxing districts for indebtedness existing prior to consoli |  |
| MTS_0070-0030-0130-0140 | 200 | 11407 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0140/0070-0030-0130-0140.html |    7-3-1314. Payment and investigation of claims -- use of warrants, MCA  |  |
| MTS_0070-0030-0130-0150 | 200 | 10728 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0150/0070-0030-0130-0150.html |    7-3-1315. Certification of certain obligations by finance director, MCA  |  |
| MTS_0070-0030-0130-0160 | 200 | 9520 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0160/0070-0030-0130-0160.html |    7-3-1316. Designation of depository banks, MCA  |  |
| MTS_0070-0030-0130-0170 | 200 | 11918 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0170/0070-0030-0130-0170.html |    7-3-1317. Deposit security, MCA  |  |
| MTS_0070-0030-0130-0180 | 200 | 9790 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0180/0070-0030-0130-0180.html |    7-3-1318. Additional or new deposit security, MCA  |  |
| MTS_0070-0030-0130-0190 | 200 | 11008 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0190/0070-0030-0130-0190.html |    7-3-1319. Deposit of funds with depository banks, MCA  |  |
| MTS_0070-0030-0130-0200 | 200 | 10038 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0200/0070-0030-0130-0200.html |    7-3-1320. Liability for deposited funds, MCA  |  |
| MTS_0070-0030-0130-0210 | 200 | 10327 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0210/0070-0030-0130-0210.html |    7-3-1321. Authorization to incur indebtedness -- limitation, MCA  |  |
| MTS_0070-0030-0130-0220 | 200 | 10579 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0220/0070-0030-0130-0220.html |    7-3-1322. Investment of sinking funds, MCA  |  |
| MTS_0070-0030-0130-0230 | 200 | 10235 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0230/0070-0030-0130-0230.html |    7-3-1323. Competitive, advertised bidding required for certain contracts, MCA |  |
| MTS_0070-0030-0130-0240 | 200 | 9723 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0240/0070-0030-0130-0240.html |    7-3-1324. Alteration of contracts, MCA  |  |
| MTS_0070-0030-0130-0250 | 200 | 9413 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0250/0070-0030-0130-0250.html |    7-3-1325. Energy performance contracts exempt, MCA  |  |
| MTS_0070-0030-0130-0260 | 200 | 8906 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0260/0070-0030-0130-0260.html |    7-3-1326. through 7-3-1330 reserved, MCA  |  |
| MTS_0070-0030-0130-0310 | 200 | 11947 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0310/0070-0030-0130-0310.html |    7-3-1331. Department of public works, MCA  |  |
| MTS_0070-0030-0130-0320 | 200 | 11256 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0320/0070-0030-0130-0320.html |    7-3-1332. Public works and improvements, MCA  |  |
| MTS_0070-0030-0130-0330 | 200 | 8891 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0330/0070-0030-0130-0330.html |    7-3-1333. through 7-3-1340 reserved, MCA  |  |
| MTS_0070-0030-0130-0410 | 200 | 10327 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0410/0070-0030-0130-0410.html |    7-3-1341. Department of law, MCA  |  |
| MTS_0070-0030-0130-0420 | 200 | 10267 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0420/0070-0030-0130-0420.html |    7-3-1342. City court, MCA  |  |
| MTS_0070-0030-0130-0430 | 200 | 10395 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0430/0070-0030-0130-0430.html |    7-3-1343. Police department, MCA  |  |
| MTS_0070-0030-0130-0440 | 200 | 11287 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0440/0070-0030-0130-0440.html |    7-3-1344. Prior rights of law enforcement officers, MCA  |  |
| MTS_0070-0030-0130-0450 | 200 | 10631 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0450/0070-0030-0130-0450.html |    7-3-1345. Fire department, MCA  |  |
| MTS_0070-0030-0130-0460 | 200 | 9639 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0460/0070-0030-0130-0460.html |    7-3-1346. Department of health, MCA  |  |
| MTS_0070-0030-0130-0470 | 200 | 9955 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0470/0070-0030-0130-0470.html |    7-3-1347. County board of health, MCA  |  |
| MTS_0070-0030-0130-0480 | 200 | 9561 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0130/section_0480/0070-0030-0130-0480.html |    7-3-1348. Superintendent of schools, MCA  |  |
| MTS_0070-0030-0210-0010 | 200 | 8860 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0010/0070-0030-0210-0010.html |    7-3-2101. Repealed, MCA  |  |
| MTS_0070-0030-0210-0020 | 200 | 9063 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0020/0070-0030-0210-0020.html |    7-3-2102. Repealed, MCA  |  |
| MTS_0070-0030-0210-0030 | 200 | 9069 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0030/0070-0030-0210-0030.html |    7-3-2103. Repealed, MCA  |  |
| MTS_0070-0030-0210-0040 | 200 | 9098 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0040/0070-0030-0210-0040.html |    7-3-2104. Repealed, MCA  |  |
| MTS_0070-0030-0210-0050 | 200 | 9063 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0050/0070-0030-0210-0050.html |    7-3-2105. Repealed, MCA  |  |
| MTS_0070-0030-0210-0060 | 200 | 9063 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0060/0070-0030-0210-0060.html |    7-3-2106. Repealed, MCA  |  |
| MTS_0070-0030-0210-0070 | 200 | 9063 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0070/0070-0030-0210-0070.html |    7-3-2107. Repealed, MCA  |  |
| MTS_0070-0030-0210-0080 | 200 | 9063 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0080/0070-0030-0210-0080.html |    7-3-2108. Repealed, MCA  |  |
| MTS_0070-0030-0210-0090 | 200 | 9095 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0090/0070-0030-0210-0090.html |    7-3-2109. Repealed, MCA  |  |
| MTS_0070-0030-0210-0100 | 200 | 9064 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0100/0070-0030-0210-0100.html |    7-3-2110. Repealed, MCA  |  |
| MTS_0070-0030-0210-0110 | 200 | 9064 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0110/0070-0030-0210-0110.html |    7-3-2111. Repealed, MCA  |  |
| MTS_0070-0030-0210-0120 | 200 | 9070 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0120/0070-0030-0210-0120.html |    7-3-2112. Repealed, MCA  |  |
| MTS_0070-0030-0210-0130 | 200 | 9070 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0130/0070-0030-0210-0130.html |    7-3-2113. Repealed, MCA  |  |
| MTS_0070-0030-0210-0140 | 200 | 9064 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0140/0070-0030-0210-0140.html |    7-3-2114. Repealed, MCA  |  |
| MTS_0070-0030-0210-0150 | 200 | 9064 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0150/0070-0030-0210-0150.html |    7-3-2115. Repealed, MCA  |  |
| MTS_0070-0030-0210-0160 | 200 | 9064 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0160/0070-0030-0210-0160.html |    7-3-2116. Repealed, MCA  |  |
| MTS_0070-0030-0210-0170 | 200 | 9081 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0170/0070-0030-0210-0170.html |    7-3-2117. Repealed, MCA  |  |
| MTS_0070-0030-0210-0180 | 200 | 8858 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0180/0070-0030-0210-0180.html |    7-3-2118. through 7-3-2130 reserved, MCA  |  |
| MTS_0070-0030-0210-0310 | 200 | 9081 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0310/0070-0030-0210-0310.html |    7-3-2131. Repealed, MCA  |  |
| MTS_0070-0030-0210-0320 | 200 | 9064 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0320/0070-0030-0210-0320.html |    7-3-2132. Repealed, MCA  |  |
| MTS_0070-0030-0210-0330 | 200 | 9064 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0330/0070-0030-0210-0330.html |    7-3-2133. Repealed, MCA  |  |
| MTS_0070-0030-0210-0340 | 200 | 8864 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0210/section_0340/0070-0030-0210-0340.html |    7-3-2134. Repealed, MCA  |  |
| MTS_0070-0030-0410-0010 | 200 | 11363 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0410/section_0010/0070-0030-0410-0010.html |    7-3-4101. Strong mayor form of municipal government, MCA  |  |
| MTS_0070-0030-0410-0020 | 200 | 9456 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0410/section_0020/0070-0030-0410-0020.html |    7-3-4102. Relationship of administrative assistants and budget and finance di |  |
| MTS_0070-0030-0420-0010 | 200 | 10160 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0010/0070-0030-0420-0010.html |    7-3-4201. Definitions, MCA  |  |
| MTS_0070-0030-0420-0020 | 200 | 9423 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0020/0070-0030-0420-0020.html |    7-3-4202. Authorization for commission form of municipal government, MCA  |  |
| MTS_0070-0030-0420-0030 | 200 | 9635 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0030/0070-0030-0420-0030.html |    7-3-4203. Effect of part on other local government laws, MCA  |  |
| MTS_0070-0030-0420-0040 | 200 | 9552 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0040/0070-0030-0420-0040.html |    7-3-4204. Laws governing city, MCA  |  |
| MTS_0070-0030-0420-0050 | 200 | 9527 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0050/0070-0030-0420-0050.html |    7-3-4205. City to be governed by mayor and council members, MCA  |  |
| MTS_0070-0030-0420-0060 | 200 | 9659 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0060/0070-0030-0420-0060.html |    7-3-4206. Territorial limits and property, MCA  |  |
| MTS_0070-0030-0420-0070 | 200 | 9769 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0070/0070-0030-0420-0070.html |    7-3-4207. Requirements of petitions, MCA  |  |
| MTS_0070-0030-0420-0080 | 200 | 10211 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0080/0070-0030-0420-0080.html |    7-3-4208. Petition to organize under commission form -- election required, MC |  |
| MTS_0070-0030-0420-0090 | 200 | 9141 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0090/0070-0030-0420-0090.html |    7-3-4209. Repealed, MCA  |  |
| MTS_0070-0030-0420-0100 | 200 | 9771 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0100/0070-0030-0420-0100.html |    7-3-4210. Form of ballot, MCA  |  |
| MTS_0070-0030-0420-0110 | 200 | 9243 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0110/0070-0030-0420-0110.html |    7-3-4211. Conduct of election, MCA  |  |
| MTS_0070-0030-0420-0120 | 200 | 9633 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0120/0070-0030-0420-0120.html |    7-3-4212. Effect of vote on question, MCA  |  |
| MTS_0070-0030-0420-0130 | 200 | 10610 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0130/0070-0030-0420-0130.html |    7-3-4213. Election for first city officers, MCA  |  |
| MTS_0070-0030-0420-0140 | 200 | 11492 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0140/0070-0030-0420-0140.html |    7-3-4214. First term of office, MCA  |  |
| MTS_0070-0030-0420-0150 | 200 | 9802 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0150/0070-0030-0420-0150.html |    7-3-4215. Council members and mayor to be elected, MCA  |  |
| MTS_0070-0030-0420-0160 | 200 | 9274 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0160/0070-0030-0420-0160.html |    7-3-4216. General term of office, MCA  |  |
| MTS_0070-0030-0420-0170 | 200 | 9779 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0170/0070-0030-0420-0170.html |    7-3-4217. Oath of office and official bond, MCA  |  |
| MTS_0070-0030-0420-0180 | 200 | 9752 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0180/0070-0030-0420-0180.html |    7-3-4218. Vacancies, MCA  |  |
| MTS_0070-0030-0420-0190 | 200 | 9206 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0190/0070-0030-0420-0190.html |    7-3-4219. Council offices, MCA  |  |
| MTS_0070-0030-0420-0200 | 200 | 9646 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0200/0070-0030-0420-0200.html |    7-3-4220. Council meetings, MCA  |  |
| MTS_0070-0030-0420-0210 | 200 | 11265 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0210/0070-0030-0420-0210.html |    7-3-4221. Conduct of business, MCA  |  |
| MTS_0070-0030-0420-0220 | 200 | 11042 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0220/0070-0030-0420-0220.html |    7-3-4222. Adoption of ordinances -- petition to protest -- election, MCA  |  |
| MTS_0070-0030-0420-0230 | 200 | 9879 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0230/0070-0030-0420-0230.html |    7-3-4223. Granting of franchises -- election required, MCA  |  |
| MTS_0070-0030-0420-0240 | 200 | 9123 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0240/0070-0030-0420-0240.html |    7-3-4224. Repealed, MCA  |  |
| MTS_0070-0030-0420-0250 | 200 | 9088 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0250/0070-0030-0420-0250.html |    7-3-4225. Repealed, MCA  |  |
| MTS_0070-0030-0420-0260 | 200 | 9110 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0260/0070-0030-0420-0260.html |    7-3-4226. Repealed, MCA  |  |
| MTS_0070-0030-0420-0270 | 200 | 11189 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0270/0070-0030-0420-0270.html |    7-3-4227. Abandonment of commission form, MCA  |  |
| MTS_0070-0030-0420-0280 | 200 | 8866 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0280/0070-0030-0420-0280.html |    7-3-4228. through 7-3-4230 reserved, MCA  |  |
| MTS_0070-0030-0420-0310 | 200 | 10083 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0310/0070-0030-0420-0310.html |    7-3-4231. General provisions related to elections, MCA  |  |
| MTS_0070-0030-0420-0320 | 200 | 9147 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0320/0070-0030-0420-0320.html |    7-3-4232. Repealed, MCA  |  |
| MTS_0070-0030-0420-0330 | 200 | 9125 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0330/0070-0030-0420-0330.html |    7-3-4233. Repealed, MCA  |  |
| MTS_0070-0030-0420-0340 | 200 | 9053 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0340/0070-0030-0420-0340.html |    7-3-4234. Repealed, MCA  |  |
| MTS_0070-0030-0420-0350 | 200 | 9119 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0350/0070-0030-0420-0350.html |    7-3-4235. Repealed, MCA  |  |
| MTS_0070-0030-0420-0360 | 200 | 9119 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0360/0070-0030-0420-0360.html |    7-3-4236. Repealed, MCA  |  |
| MTS_0070-0030-0420-0370 | 200 | 9119 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0370/0070-0030-0420-0370.html |    7-3-4237. Repealed, MCA  |  |
| MTS_0070-0030-0420-0380 | 200 | 9116 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0380/0070-0030-0420-0380.html |    7-3-4238. Repealed, MCA  |  |
| MTS_0070-0030-0420-0390 | 200 | 9052 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0390/0070-0030-0420-0390.html |    7-3-4239. Repealed, MCA  |  |
| MTS_0070-0030-0420-0400 | 200 | 9082 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0400/0070-0030-0420-0400.html |    7-3-4240. Repealed, MCA  |  |
| MTS_0070-0030-0420-0410 | 200 | 9130 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0410/0070-0030-0420-0410.html |    7-3-4241. Repealed, MCA  |  |
| MTS_0070-0030-0420-0420 | 200 | 8820 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0420/0070-0030-0420-0420.html |    7-3-4242. through 7-3-4250 reserved, MCA  |  |
| MTS_0070-0030-0420-0510 | 200 | 9456 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0510/0070-0030-0420-0510.html |    7-3-4251. Powers of mayor, MCA  |  |
| MTS_0070-0030-0420-0520 | 200 | 9586 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0520/0070-0030-0420-0520.html |    7-3-4252. Powers of council, MCA  |  |
| MTS_0070-0030-0420-0530 | 200 | 11160 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0530/0070-0030-0420-0530.html |    7-3-4253. Department structure and operation, MCA  |  |
| MTS_0070-0030-0420-0540 | 200 | 12285 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0540/0070-0030-0420-0540.html |    7-3-4254. Selection and supervision of officers and employees, MCA  |  |
| MTS_0070-0030-0420-0550 | 200 | 11397 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0550/0070-0030-0420-0550.html |    7-3-4255. Compensation of mayor, council members, and employees, MCA  |  |
| MTS_0070-0030-0420-0560 | 200 | 11487 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0560/0070-0030-0420-0560.html |    7-3-4256. Control of conflict of interest, MCA  |  |
| MTS_0070-0030-0420-0570 | 200 | 11216 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0570/0070-0030-0420-0570.html |    7-3-4257. Appointment of civil service commission, MCA  |  |
| MTS_0070-0030-0420-0580 | 200 | 10242 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0580/0070-0030-0420-0580.html |    7-3-4258. Civil service examinations, MCA  |  |
| MTS_0070-0030-0420-0590 | 200 | 10043 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0590/0070-0030-0420-0590.html |    7-3-4259. Discharge of employees, MCA  |  |
| MTS_0070-0030-0420-0600 | 200 | 9498 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0600/0070-0030-0420-0600.html |    7-3-4260. Investigatory powers of council, MCA  |  |
| MTS_0070-0030-0420-0610 | 200 | 9700 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0610/0070-0030-0420-0610.html |    7-3-4261. Conduct of civil service commission business, MCA  |  |
| MTS_0070-0030-0420-0620 | 200 | 9437 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0620/0070-0030-0420-0620.html |    7-3-4262. Nonpartisan appointments and elections, MCA  |  |
| MTS_0070-0030-0420-0630 | 200 | 9151 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0630/0070-0030-0420-0630.html |    7-3-4263. Repealed, MCA  |  |
| MTS_0070-0030-0420-0640 | 200 | 10067 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0640/0070-0030-0420-0640.html |    7-3-4264. Applicability of civil service provisions, MCA  |  |
| MTS_0070-0030-0420-0650 | 200 | 10337 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0650/0070-0030-0420-0650.html |    7-3-4265. Violations of civil service provisions, MCA  |  |
| MTS_0070-0030-0420-0660 | 200 | 9708 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0660/0070-0030-0420-0660.html |    7-3-4266. Report of proceedings and financial statement, MCA  |  |
| MTS_0070-0030-0420-0670 | 200 | 9415 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0420/section_0670/0070-0030-0420-0670.html |    7-3-4267. Revision of appropriations made by former council, MCA  |  |
| MTS_0070-0030-0430-0010 | 200 | 9764 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0010/0070-0030-0430-0010.html |    7-3-4301. Authorization for commission-manager form of municipal government,  |  |
| MTS_0070-0030-0430-0020 | 200 | 10085 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0020/0070-0030-0430-0020.html |    7-3-4302. Construction, MCA  |  |
| MTS_0070-0030-0430-0030 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0030/0070-0030-0430-0030.html |    7-3-4303. Laws governing municipality, MCA  |  |
| MTS_0070-0030-0430-0040 | 200 | 9737 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0040/0070-0030-0430-0040.html |    7-3-4304. Territorial limits and property, MCA  |  |
| MTS_0070-0030-0430-0050 | 200 | 10422 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0050/0070-0030-0430-0050.html |    7-3-4305. Petition to organize under commission-manager form -- election requ |  |
| MTS_0070-0030-0430-0060 | 200 | 9174 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0060/0070-0030-0430-0060.html |    7-3-4306. Repealed, MCA  |  |
| MTS_0070-0030-0430-0070 | 200 | 9934 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0070/0070-0030-0430-0070.html |    7-3-4307. Form of ballot, MCA  |  |
| MTS_0070-0030-0430-0080 | 200 | 9151 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0080/0070-0030-0430-0080.html |    7-3-4308. Repealed, MCA  |  |
| MTS_0070-0030-0430-0090 | 200 | 9739 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0090/0070-0030-0430-0090.html |    7-3-4309. Effect of vote on question of organization, MCA  |  |
| MTS_0070-0030-0430-0100 | 200 | 11513 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0100/0070-0030-0430-0100.html |    7-3-4310. Election for municipal officers after reorganization, MCA  |  |
| MTS_0070-0030-0430-0110 | 200 | 12181 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0110/0070-0030-0430-0110.html |    7-3-4311. Procedure for multimunicipality organization -- petition -- electio |  |
| MTS_0070-0030-0430-0120 | 200 | 12310 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0120/0070-0030-0430-0120.html |    7-3-4312. Effect of organization of communities into single municipal distric |  |
| MTS_0070-0030-0430-0130 | 200 | 12196 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0130/0070-0030-0430-0130.html |    7-3-4313. Powers of municipalities under commission-manager plan, MCA  |  |
| MTS_0070-0030-0430-0140 | 200 | 9863 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0140/0070-0030-0430-0140.html |    7-3-4314. Composition and general authority of commission, MCA  |  |
| MTS_0070-0030-0430-0150 | 200 | 9389 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0150/0070-0030-0430-0150.html |    7-3-4315. Qualifications of commissioners, MCA  |  |
| MTS_0070-0030-0430-0160 | 200 | 10412 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0160/0070-0030-0430-0160.html |    7-3-4316. Term of office for commissioners, MCA  |  |
| MTS_0070-0030-0430-0170 | 200 | 9348 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0170/0070-0030-0430-0170.html |    7-3-4317. Vacancies, MCA  |  |
| MTS_0070-0030-0430-0180 | 200 | 9370 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0180/0070-0030-0430-0180.html |    7-3-4318. Repealed, MCA  |  |
| MTS_0070-0030-0430-0190 | 200 | 10510 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0190/0070-0030-0430-0190.html |    7-3-4319. Designation of mayor, MCA  |  |
| MTS_0070-0030-0430-0200 | 200 | 9723 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0200/0070-0030-0430-0200.html |    7-3-4320. Role of mayor, MCA  |  |
| MTS_0070-0030-0430-0210 | 200 | 9588 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0210/0070-0030-0430-0210.html |    7-3-4321. Salary of commissioners and mayor, MCA  |  |
| MTS_0070-0030-0430-0220 | 200 | 10468 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0220/0070-0030-0430-0220.html |    7-3-4322. Meetings of commission, MCA  |  |
| MTS_0070-0030-0430-0230 | 200 | 11065 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0230/0070-0030-0430-0230.html |    7-3-4323. Conduct of commission business, MCA  |  |
| MTS_0070-0030-0430-0240 | 200 | 11487 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0240/0070-0030-0430-0240.html |    7-3-4324. Procedure to enact ordinance or resolution, MCA  |  |
| MTS_0070-0030-0430-0250 | 200 | 9835 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0250/0070-0030-0430-0250.html |    7-3-4325. Effective date of ordinance or resolution, MCA  |  |
| MTS_0070-0030-0430-0260 | 200 | 10654 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0260/0070-0030-0430-0260.html |    7-3-4326. Emergency measures, MCA  |  |
| MTS_0070-0030-0430-0270 | 200 | 11123 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0270/0070-0030-0430-0270.html |    7-3-4327. Petition for initiative, MCA  |  |
| MTS_0070-0030-0430-0280 | 200 | 9128 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0280/0070-0030-0430-0280.html |    7-3-4328. Repealed, MCA  |  |
| MTS_0070-0030-0430-0290 | 200 | 9113 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0290/0070-0030-0430-0290.html |    7-3-4329. Repealed, MCA  |  |
| MTS_0070-0030-0430-0300 | 200 | 9407 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0300/0070-0030-0430-0300.html |    7-3-4330. Repealed, MCA  |  |
| MTS_0070-0030-0430-0310 | 200 | 9113 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0310/0070-0030-0430-0310.html |    7-3-4331. Repealed, MCA  |  |
| MTS_0070-0030-0430-0320 | 200 | 9671 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0320/0070-0030-0430-0320.html |    7-3-4332. Repealed, MCA  |  |
| MTS_0070-0030-0430-0330 | 200 | 9137 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0330/0070-0030-0430-0330.html |    7-3-4333. Repealed, MCA  |  |
| MTS_0070-0030-0430-0340 | 200 | 9156 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0340/0070-0030-0430-0340.html |    7-3-4334. Repealed, MCA  |  |
| MTS_0070-0030-0430-0350 | 200 | 8837 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0350/0070-0030-0430-0350.html |    7-3-4335. through 7-3-4340 reserved, MCA  |  |
| MTS_0070-0030-0430-0410 | 200 | 9189 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0410/0070-0030-0430-0410.html |    7-3-4341. Repealed, MCA  |  |
| MTS_0070-0030-0430-0420 | 200 | 9107 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0420/0070-0030-0430-0420.html |    7-3-4342. Repealed, MCA  |  |
| MTS_0070-0030-0430-0430 | 200 | 9144 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0430/0070-0030-0430-0430.html |    7-3-4343. Repealed, MCA  |  |
| MTS_0070-0030-0430-0440 | 200 | 9107 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0440/0070-0030-0430-0440.html |    7-3-4344. Repealed, MCA  |  |
| MTS_0070-0030-0430-0450 | 200 | 9200 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0450/0070-0030-0430-0450.html |    7-3-4345. Repealed, MCA  |  |
| MTS_0070-0030-0430-0460 | 200 | 9205 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0460/0070-0030-0430-0460.html |    7-3-4346. Repealed, MCA  |  |
| MTS_0070-0030-0430-0470 | 200 | 9403 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0470/0070-0030-0430-0470.html |    7-3-4347. Repealed, MCA  |  |
| MTS_0070-0030-0430-0480 | 200 | 9143 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0480/0070-0030-0430-0480.html |    7-3-4348. Repealed, MCA  |  |
| MTS_0070-0030-0430-0490 | 200 | 9395 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0490/0070-0030-0430-0490.html |    7-3-4349. Repealed, MCA  |  |
| MTS_0070-0030-0430-0500 | 200 | 9045 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0500/0070-0030-0430-0500.html |    7-3-4350. Repealed, MCA  |  |
| MTS_0070-0030-0430-0510 | 200 | 9137 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0510/0070-0030-0430-0510.html |    7-3-4351. Repealed, MCA  |  |
| MTS_0070-0030-0430-0520 | 200 | 9348 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0520/0070-0030-0430-0520.html |    7-3-4352. Repealed, MCA  |  |
| MTS_0070-0030-0430-0530 | 200 | 8856 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0530/0070-0030-0430-0530.html |    7-3-4353. through 7-3-4360 reserved, MCA  |  |
| MTS_0070-0030-0430-0610 | 200 | 9436 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0610/0070-0030-0430-0610.html |    7-3-4361. Appointment of city manager, MCA  |  |
| MTS_0070-0030-0430-0620 | 200 | 9304 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0620/0070-0030-0430-0620.html |    7-3-4362. Role of city manager, MCA  |  |
| MTS_0070-0030-0430-0630 | 200 | 10845 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0630/0070-0030-0430-0630.html |    7-3-4363. Powers and duties of city manager, MCA  |  |
| MTS_0070-0030-0430-0640 | 200 | 9349 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0640/0070-0030-0430-0640.html |    7-3-4364. Salary of city manager, MCA  |  |
| MTS_0070-0030-0430-0650 | 200 | 10327 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0650/0070-0030-0430-0650.html |    7-3-4365. Investigations by commission, MCA  |  |
| MTS_0070-0030-0430-0660 | 200 | 9674 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0660/0070-0030-0430-0660.html |    7-3-4366. Investigatory powers of city manager, MCA  |  |
| MTS_0070-0030-0430-0670 | 200 | 10597 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0670/0070-0030-0430-0670.html |    7-3-4367. Control of conflict of interest, MCA  |  |
| MTS_0070-0030-0430-0680 | 200 | 9559 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0680/0070-0030-0430-0680.html |    7-3-4368. Execution of conveyances of real property, MCA  |  |
| MTS_0070-0030-0430-0690 | 200 | 9852 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0690/0070-0030-0430-0690.html |    7-3-4369. Appropriation of property for public or municipal purposes, MCA  |  |
| MTS_0070-0030-0430-0700 | 200 | 10010 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0700/0070-0030-0430-0700.html |    7-3-4370. Use of county buildings, MCA  |  |
| MTS_0070-0030-0430-0710 | 200 | 9251 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0710/0070-0030-0430-0710.html |    7-3-4371. Repealed, MCA  |  |
| MTS_0070-0030-0430-0720 | 200 | 9362 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0720/0070-0030-0430-0720.html |    7-3-4372. Repealed, MCA  |  |
| MTS_0070-0030-0430-0730 | 200 | 9516 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0730/0070-0030-0430-0730.html |    7-3-4373. Repealed, MCA  |  |
| MTS_0070-0030-0430-0740 | 200 | 9601 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0430/section_0740/0070-0030-0430-0740.html |    7-3-4374. Details of public advertising or publication, MCA  |  |
| MTS_0070-0030-0440-0010 | 200 | 9802 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0010/0070-0030-0440-0010.html |    7-3-4401. Administrative departments, MCA  |  |
| MTS_0070-0030-0440-0020 | 200 | 9531 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0020/0070-0030-0440-0020.html |    7-3-4402. Appointment of department directors, MCA  |  |
| MTS_0070-0030-0440-0030 | 200 | 9722 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0030/0070-0030-0440-0030.html |    7-3-4403. Role of department director, MCA  |  |
| MTS_0070-0030-0440-0040 | 200 | 9510 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0040/0070-0030-0440-0040.html |    7-3-4404. Appointment of boards, MCA  |  |
| MTS_0070-0030-0440-0050 | 200 | 11101 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0050/0070-0030-0440-0050.html |    7-3-4405. Establishment of civil service board, MCA  |  |
| MTS_0070-0030-0440-0060 | 200 | 9516 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0060/0070-0030-0440-0060.html |    7-3-4406. Organization of board, MCA  |  |
| MTS_0070-0030-0440-0070 | 200 | 11159 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0070/0070-0030-0440-0070.html |    7-3-4407. Classification of civil service, MCA  |  |
| MTS_0070-0030-0440-0080 | 200 | 10048 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0080/0070-0030-0440-0080.html |    7-3-4408. Role of civil service board, MCA  |  |
| MTS_0070-0030-0440-0090 | 200 | 9856 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0090/0070-0030-0440-0090.html |    7-3-4409. Role of chief examiner, MCA  |  |
| MTS_0070-0030-0440-0100 | 200 | 9542 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0100/0070-0030-0440-0100.html |    7-3-4410. Probationary period, MCA  |  |
| MTS_0070-0030-0440-0110 | 200 | 10388 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0110/0070-0030-0440-0110.html |    7-3-4411. Procedure for discharge, demotion, or suspension of employee, MCA  |  |
| MTS_0070-0030-0440-0120 | 200 | 9642 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0120/0070-0030-0440-0120.html |    7-3-4412. Retention of existing positions, MCA  |  |
| MTS_0070-0030-0440-0130 | 200 | 9765 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0130/0070-0030-0440-0130.html |    7-3-4413. Certification required to receive salary, MCA  |  |
| MTS_0070-0030-0440-0140 | 200 | 9552 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0140/0070-0030-0440-0140.html |    7-3-4414. Investigatory powers of civil service board, MCA  |  |
| MTS_0070-0030-0440-0150 | 200 | 9609 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0150/0070-0030-0440-0150.html |    7-3-4415. Prohibition on discrimination in employment, MCA  |  |
| MTS_0070-0030-0440-0160 | 200 | 9420 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0160/0070-0030-0440-0160.html |    7-3-4416. Violation of civil service provisions, MCA  |  |
| MTS_0070-0030-0440-0170 | 200 | 10056 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0170/0070-0030-0440-0170.html |    7-3-4417. Fixing compensation, MCA  |  |
| MTS_0070-0030-0440-0180 | 200 | 9430 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0180/0070-0030-0440-0180.html |    7-3-4418. Power to establish eight-hour day, MCA  |  |
| MTS_0070-0030-0440-0190 | 200 | 8905 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0190/0070-0030-0440-0190.html |    7-3-4419. through 7-3-4430 reserved, MCA  |  |
| MTS_0070-0030-0440-0310 | 200 | 12317 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0310/0070-0030-0440-0310.html |    7-3-4431. Department of finance, MCA  |  |
| MTS_0070-0030-0440-0320 | 200 | 10162 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0320/0070-0030-0440-0320.html |    7-3-4432. Accounting procedures, MCA  |  |
| MTS_0070-0030-0440-0330 | 200 | 10548 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0330/0070-0030-0440-0330.html |    7-3-4433. Claims and issuance of warrants, MCA  |  |
| MTS_0070-0030-0440-0340 | 200 | 12705 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0340/0070-0030-0440-0340.html |    7-3-4434. Purchase and sale of supplies and property, MCA  |  |
| MTS_0070-0030-0440-0350 | 200 | 9432 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0350/0070-0030-0440-0350.html |    7-3-4435. Approval required for certain contracts, MCA  |  |
| MTS_0070-0030-0440-0360 | 200 | 9634 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0360/0070-0030-0440-0360.html |    7-3-4436. Sinking fund trustees, MCA  |  |
| MTS_0070-0030-0440-0370 | 200 | 8900 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0370/0070-0030-0440-0370.html |    7-3-4437. through 7-3-4440 reserved, MCA  |  |
| MTS_0070-0030-0440-0410 | 200 | 11107 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0410/0070-0030-0440-0410.html |    7-3-4441. Department of public service, MCA  |  |
| MTS_0070-0030-0440-0420 | 200 | 10100 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0420/0070-0030-0440-0420.html |    7-3-4442. Local improvements, MCA  |  |
| MTS_0070-0030-0440-0430 | 200 | 11049 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0430/0070-0030-0440-0430.html |    7-3-4443. Utility connections, MCA  |  |
| MTS_0070-0030-0440-0440 | 200 | 10294 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0440/0070-0030-0440-0440.html |    7-3-4444. Supervision of plats, MCA  |  |
| MTS_0070-0030-0440-0450 | 200 | 9294 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0450/0070-0030-0440-0450.html |    7-3-4445. Subdivided lands, MCA  |  |
| MTS_0070-0030-0440-0460 | 200 | 10365 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0460/0070-0030-0440-0460.html |    7-3-4446. Acceptance of streets or alleys, MCA  |  |
| MTS_0070-0030-0440-0470 | 200 | 9922 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0470/0070-0030-0440-0470.html |    7-3-4447. Supervision of public places, MCA  |  |
| MTS_0070-0030-0440-0480 | 200 | 10883 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0480/0070-0030-0440-0480.html |    7-3-4448. Vacating or changing name of street, MCA  |  |
| MTS_0070-0030-0440-0490 | 200 | 9900 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0490/0070-0030-0440-0490.html |    7-3-4449. Grant of right to use or occupy public places, MCA  |  |
| MTS_0070-0030-0440-0500 | 200 | 9383 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0500/0070-0030-0440-0500.html |    7-3-4450. Renewal of franchises, MCA  |  |
| MTS_0070-0030-0440-0510 | 200 | 9433 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0510/0070-0030-0440-0510.html |    7-3-4451. Prohibition on exclusive grant or franchise, MCA  |  |
| MTS_0070-0030-0440-0520 | 200 | 11062 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0520/0070-0030-0440-0520.html |    7-3-4452. Grant to operate public utility, MCA  |  |
| MTS_0070-0030-0440-0530 | 200 | 9648 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0530/0070-0030-0440-0530.html |    7-3-4453. Assessments for snow, ice, weed, and rubbish removal, MCA  |  |
| MTS_0070-0030-0440-0540 | 200 | 8920 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0540/0070-0030-0440-0540.html |    7-3-4454. through 7-3-4460 reserved, MCA  |  |
| MTS_0070-0030-0440-0610 | 200 | 10070 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0610/0070-0030-0440-0610.html |    7-3-4461. Department of law, MCA  |  |
| MTS_0070-0030-0440-0620 | 200 | 10205 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0620/0070-0030-0440-0620.html |    7-3-4462. Office of city judge, MCA  |  |
| MTS_0070-0030-0440-0630 | 200 | 11525 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0630/0070-0030-0440-0630.html |    7-3-4463. Department of public welfare, MCA  |  |
| MTS_0070-0030-0440-0640 | 200 | 10240 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0640/0070-0030-0440-0640.html |    7-3-4464. Department of public safety, MCA  |  |
| MTS_0070-0030-0440-0650 | 200 | 10655 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0650/0070-0030-0440-0650.html |    7-3-4465. Police department, MCA  |  |
| MTS_0070-0030-0440-0660 | 200 | 9905 | https://leg.mt.gov/bills/mca/title_0070/chapter_0030/part_0440/section_0660/0070-0030-0440-0660.html |    7-3-4466. Fire department, MCA  |  |
| MTS_0070-0040-0010-0010 | 200 | 9589 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0010/section_0010/0070-0040-0010-0010.html |    7-4-101. Filing of oath of office, MCA  |  |
| MTS_0070-0040-0010-0020 | 200 | 9840 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0010/section_0020/0070-0040-0010-0020.html |    7-4-102. Office hours, MCA  |  |
| MTS_0070-0040-0050-0010 | 200 | 9722 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0050/section_0010/0070-0040-0050-0010.html |    7-4-501. Establishment of program -- award value limited, MCA  |  |
| MTS_0070-0040-0050-0020 | 200 | 9564 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0050/section_0020/0070-0040-0050-0020.html |    7-4-502. Definitions, MCA  |  |
| MTS_0070-0040-0050-0030 | 200 | 10181 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0050/section_0030/0070-0040-0050-0030.html |    7-4-503. Powers and duties of governing body, MCA  |  |
| MTS_0070-0040-0050-0040 | 200 | 9967 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0050/section_0040/0070-0040-0050-0040.html |    7-4-504. Appointment and functions of advisory council -- governing body as a |  |
| MTS_0070-0040-0050-0050 | 200 | 10791 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0050/section_0050/0070-0040-0050-0050.html |    7-4-505. Eligibility for award, MCA  |  |
| MTS_0070-0040-0050-0060 | 200 | 9437 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0050/section_0060/0070-0040-0050-0060.html |    7-4-506. Agency head to grant award, MCA  |  |
| MTS_0070-0040-0210-0010 | 200 | 9303 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0010/0070-0040-0210-0010.html |    7-4-2101. Composition of board of county commissioners, MCA  |  |
| MTS_0070-0040-0210-0020 | 200 | 10382 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0020/0070-0040-0210-0020.html |    7-4-2102. Division of county into commissioner districts, MCA  |  |
| MTS_0070-0040-0210-0030 | 200 | 9494 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0030/0070-0040-0210-0030.html |    7-4-2103. Filing of certificate designating districts, MCA  |  |
| MTS_0070-0040-0210-0040 | 200 | 10120 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0040/0070-0040-0210-0040.html |    7-4-2104. Commissioners to be elected by district, MCA  |  |
| MTS_0070-0040-0210-0050 | 200 | 10050 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0050/0070-0040-0210-0050.html |    7-4-2105. Term of office, MCA  |  |
| MTS_0070-0040-0210-0060 | 200 | 17524 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0060/0070-0040-0210-0060.html |    7-4-2106. Vacancy on board of county commissioners -- resigning member not to |  |
| MTS_0070-0040-0210-0070 | 200 | 10775 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0070/0070-0040-0210-0070.html |    7-4-2107. Compensation of county commissioners, MCA  |  |
| MTS_0070-0040-0210-0080 | 200 | 12049 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0080/0070-0040-0210-0080.html |    7-4-2108. Mileage allowance for county commissioners -- expenses, MCA  |  |
| MTS_0070-0040-0210-0090 | 200 | 9521 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0090/0070-0040-0210-0090.html |    7-4-2109. Presiding officer of board, MCA  |  |
| MTS_0070-0040-0210-0100 | 200 | 11639 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0100/0070-0040-0210-0100.html |    7-4-2110. Supervision of county and other officers, MCA  |  |
| MTS_0070-0040-0210-0110 | 200 | 10170 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0110/0070-0040-0210-0110.html |    7-4-2111. Indemnity insurance for county officers, MCA  |  |
| MTS_0070-0040-0210-0120 | 200 | 9298 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0120/0070-0040-0210-0120.html |    7-4-2112. County seal, MCA  |  |
| MTS_0070-0040-0210-0130 | 200 | 9653 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0210/section_0130/0070-0040-0210-0130.html |    7-4-2113. Liability on official bond of commissioner, MCA  |  |
| MTS_0070-0040-0220-0010 | 200 | 9789 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0010/0070-0040-0220-0010.html |    7-4-2201. General qualifications for county office, MCA  |  |
| MTS_0070-0040-0220-0020 | 200 | 9871 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0020/0070-0040-0220-0020.html |    7-4-2202. General qualifications for district or township offices, MCA  |  |
| MTS_0070-0040-0220-0030 | 200 | 11201 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0030/0070-0040-0220-0030.html |    7-4-2203. County officers, MCA  |  |
| MTS_0070-0040-0220-0040 | 200 | 9258 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0040/0070-0040-0220-0040.html |    7-4-2204. Township officers, MCA  |  |
| MTS_0070-0040-0220-0050 | 200 | 10270 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0050/0070-0040-0220-0050.html |    7-4-2205. Term of office -- oath, MCA  |  |
| MTS_0070-0040-0220-0060 | 200 | 13007 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0060/0070-0040-0220-0060.html |    7-4-2206. Vacancies -- appointment of interim officer, MCA  |  |
| MTS_0070-0040-0220-0070 | 200 | 9844 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0070/0070-0040-0220-0070.html |    7-4-2207. Duty of officers to complete official business, MCA  |  |
| MTS_0070-0040-0220-0080 | 200 | 10052 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0080/0070-0040-0220-0080.html |    7-4-2208. Absence of county officers from state, MCA  |  |
| MTS_0070-0040-0220-0090 | 200 | 9388 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0090/0070-0040-0220-0090.html |    7-4-2209. Authority to administer oaths, MCA  |  |
| MTS_0070-0040-0220-0100 | 200 | 10370 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0100/0070-0040-0220-0100.html |    7-4-2210. Restriction on practice of law by certain officers, MCA  |  |
| MTS_0070-0040-0220-0110 | 200 | 10761 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0110/0070-0040-0220-0110.html |    7-4-2211. County offices, MCA  |  |
| MTS_0070-0040-0220-0120 | 200 | 9754 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0120/0070-0040-0220-0120.html |    7-4-2212. Official bonds of county officers, MCA  |  |
| MTS_0070-0040-0220-0130 | 200 | 10609 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0130/0070-0040-0220-0130.html |    7-4-2213. Inspection of official bonds, MCA  |  |
| MTS_0070-0040-0220-0140 | 200 | 8827 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0140/0070-0040-0220-0140.html |    7-4-2214. through 7-4-2220 reserved, MCA  |  |
| MTS_0070-0040-0220-0210 | 200 | 10115 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0210/0070-0040-0220-0210.html |    7-4-2221. Manner of keeping records and storing documents, MCA  |  |
| MTS_0070-0040-0220-0220 | 200 | 10389 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0220/0070-0040-0220-0220.html |    7-4-2222. Substitution of reproduction for original document, MCA  |  |
| MTS_0070-0040-0220-0230 | 200 | 9583 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0220/section_0230/0070-0040-0220-0230.html |    7-4-2223. Duplicate records -- safe storage of one copy, MCA  |  |
| MTS_0070-0040-0230-0010 | 200 | 9796 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0010/0070-0040-0230-0010.html |    7-4-2301. Authorization to consolidate county offices, MCA  |  |
| MTS_0070-0040-0230-0020 | 200 | 9788 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0020/0070-0040-0230-0020.html |    7-4-2302. Petition for consolidation of county offices, MCA  |  |
| MTS_0070-0040-0230-0030 | 200 | 9719 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0030/0070-0040-0230-0030.html |    7-4-2303. Petition for intercounty consolidation of offices, MCA  |  |
| MTS_0070-0040-0230-0040 | 200 | 10052 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0040/0070-0040-0230-0040.html |    7-4-2304. Petition details, MCA  |  |
| MTS_0070-0040-0230-0050 | 200 | 10046 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0050/0070-0040-0230-0050.html |    7-4-2305. Initiation of consolidation by county commissioners, MCA  |  |
| MTS_0070-0040-0230-0060 | 200 | 10204 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0060/0070-0040-0230-0060.html |    7-4-2306. Processing of petition -- resolution of intent and hearing, MCA  |  |
| MTS_0070-0040-0230-0070 | 200 | 9445 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0070/0070-0040-0230-0070.html |    7-4-2307. Notice of hearing, MCA  |  |
| MTS_0070-0040-0230-0080 | 200 | 9418 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0080/0070-0040-0230-0080.html |    7-4-2308. Joint hearings, MCA  |  |
| MTS_0070-0040-0230-0090 | 200 | 9957 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0090/0070-0040-0230-0090.html |    7-4-2309. Conduct of hearing -- decision, MCA  |  |
| MTS_0070-0040-0230-0100 | 200 | 10510 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0100/0070-0040-0230-0100.html |    7-4-2310. Order for consolidation of offices, MCA  |  |
| MTS_0070-0040-0230-0110 | 200 | 10785 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0110/0070-0040-0230-0110.html |    7-4-2311. Implementation of consolidation order, MCA  |  |
| MTS_0070-0040-0230-0120 | 200 | 10686 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0120/0070-0040-0230-0120.html |    7-4-2312. Salary and bond of officer following consolidation, MCA  |  |
| MTS_0070-0040-0230-0130 | 200 | 9484 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0230/section_0130/0070-0040-0230-0130.html |    7-4-2313. Deputies and personnel for consolidated offices, MCA  |  |
| MTS_0070-0040-0240-0010 | 200 | 9766 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0240/section_0010/0070-0040-0240-0010.html |    7-4-2401. Deputy officers, MCA  |  |
| MTS_0070-0040-0240-0020 | 200 | 10114 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0240/section_0020/0070-0040-0240-0020.html |    7-4-2402. Authorization to exceed limitation on number of deputy officers, MC |  |
| MTS_0070-0040-0240-0030 | 200 | 9549 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0240/section_0030/0070-0040-0240-0030.html |    7-4-2403. Official mention of principal officer includes deputies, MCA  |  |
| MTS_0070-0040-0240-0040 | 200 | 9577 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0240/section_0040/0070-0040-0240-0040.html |    7-4-2404. Limitation on county officer acting as deputy officer, MCA  |  |
| MTS_0070-0040-0240-0050 | 200 | 9677 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0240/section_0050/0070-0040-0240-0050.html |    7-4-2405. Appointment of deputies in certain counties, MCA  |  |
| MTS_0070-0040-0250-0010 | 200 | 9589 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0010/0070-0040-0250-0010.html |    7-4-2501. Compensation of county officers, MCA  |  |
| MTS_0070-0040-0250-0020 | 200 | 14330 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0020/0070-0040-0250-0020.html |    7-4-2502. Payment of salaries of county officials and assistants -- state sha |  |
| MTS_0070-0040-0250-0030 | 200 | 20533 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0030/0070-0040-0250-0030.html |    7-4-2503. Salary schedule for certain county officers -- county compensation  |  |
| MTS_0070-0040-0250-0040 | 200 | 10647 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0040/0070-0040-0250-0040.html |    7-4-2504. Salaries to be fixed by resolution -- cost-of-living increments, MC |  |
| MTS_0070-0040-0250-0050 | 200 | 11346 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0050/0070-0040-0250-0050.html |    7-4-2505. Amount of compensation for deputies and assistants, MCA  |  |
| MTS_0070-0040-0250-0060 | 200 | 9224 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0060/0070-0040-0250-0060.html |    7-4-2506. Repealed, MCA  |  |
| MTS_0070-0040-0250-0070 | 200 | 10036 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0070/0070-0040-0250-0070.html |    7-4-2507. Deputy sheriff, undersheriff, and detention officer employed under  |  |
| MTS_0070-0040-0250-0080 | 200 | 11945 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0080/0070-0040-0250-0080.html |    7-4-2508. Compensation of undersheriff and deputy sheriff -- definitions, MCA |  |
| MTS_0070-0040-0250-0090 | 200 | 10311 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0090/0070-0040-0250-0090.html |    7-4-2509. Sheriff's office -- work period in lieu of workweek -- overtime com |  |
| MTS_0070-0040-0250-0100 | 200 | 9927 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0100/0070-0040-0250-0100.html |    7-4-2510. Sheriff's office -- longevity payments, MCA  |  |
| MTS_0070-0040-0250-0110 | 200 | 10627 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0110/0070-0040-0250-0110.html |    7-4-2511. Collection and disposal of fees, MCA  |  |
| MTS_0070-0040-0250-0120 | 200 | 11237 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0120/0070-0040-0250-0120.html |    7-4-2512. Statement and affidavit of fees collected, MCA  |  |
| MTS_0070-0040-0250-0130 | 200 | 9736 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0130/0070-0040-0250-0130.html |    7-4-2513. Filing of statements and affidavits, MCA  |  |
| MTS_0070-0040-0250-0140 | 200 | 9511 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0140/0070-0040-0250-0140.html |    7-4-2514. Filing required to receive salary, MCA  |  |
| MTS_0070-0040-0250-0150 | 200 | 10605 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0150/0070-0040-0250-0150.html |    7-4-2515. Fees to be paid in advance, MCA  |  |
| MTS_0070-0040-0250-0160 | 200 | 9627 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0160/0070-0040-0250-0160.html |    7-4-2516. Fees not required in certain cases, MCA  |  |
| MTS_0070-0040-0250-0170 | 200 | 9602 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0170/0070-0040-0250-0170.html |    7-4-2517. Itemized receipt for fees, MCA  |  |
| MTS_0070-0040-0250-0180 | 200 | 9552 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0180/0070-0040-0250-0180.html |    7-4-2518. Statement of fees to be posted, MCA  |  |
| MTS_0070-0040-0250-0190 | 200 | 9633 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0190/0070-0040-0250-0190.html |    7-4-2519. Prohibition upon receiving other fees, MCA  |  |
| MTS_0070-0040-0250-0200 | 200 | 9706 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0200/0070-0040-0250-0200.html |    7-4-2520. Misconduct concerning official fees to result in vacancy of office, |  |
| MTS_0070-0040-0250-0210 | 200 | 9957 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0210/0070-0040-0250-0210.html |    7-4-2521. Designation of person to receive decedent's warrants or paychecks - |  |
| MTS_0070-0040-0250-0220 | 200 | 8884 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0220/0070-0040-0250-0220.html |    7-4-2522. through 7-4-2524 reserved, MCA  |  |
| MTS_0070-0040-0250-0250 | 200 | 9918 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0250/section_0250/0070-0040-0250-0250.html |    7-4-2525. Fees of sheriff to be fixed by resolution, MCA  |  |
| MTS_0070-0040-0260-0010 | 200 | 9808 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0010/0070-0040-0260-0010.html |    7-4-2601. Limitation on number of deputy county clerks, MCA  |  |
| MTS_0070-0040-0260-0020 | 200 | 9316 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0020/0070-0040-0260-0020.html |    7-4-2602. Designation of chief deputy by county clerk, MCA  |  |
| MTS_0070-0040-0260-0030 | 200 | 8841 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0030/0070-0040-0260-0030.html |    7-4-2603. through 7-4-2610 reserved, MCA  |  |
| MTS_0070-0040-0260-0110 | 200 | 14214 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0110/0070-0040-0260-0110.html |    7-4-2611. Role and duties of county clerk and election administrator, MCA  |  |
| MTS_0070-0040-0260-0120 | 200 | 9472 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0120/0070-0040-0260-0120.html |    7-4-2612. Books for recording documents, MCA  |  |
| MTS_0070-0040-0260-0130 | 200 | 14377 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0130/0070-0040-0260-0130.html |    7-4-2613. Documents subject to recording, MCA  |  |
| MTS_0070-0040-0260-0140 | 200 | 12599 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0140/0070-0040-0260-0140.html |    7-4-2614. Records of discharge from military service, MCA  |  |
| MTS_0070-0040-0260-0150 | 200 | 9831 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0150/0070-0040-0260-0150.html |    7-4-2615. Records of water users' associations, MCA  |  |
| MTS_0070-0040-0260-0160 | 200 | 9284 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0160/0070-0040-0260-0160.html |    7-4-2616. Map book, MCA  |  |
| MTS_0070-0040-0260-0170 | 200 | 11131 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0170/0070-0040-0260-0170.html |    7-4-2617. Procedure to record documents, MCA  |  |
| MTS_0070-0040-0260-0180 | 200 | 9677 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0180/0070-0040-0260-0180.html |    7-4-2618. Addresses required to record certain documents, MCA  |  |
| MTS_0070-0040-0260-0190 | 200 | 18297 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0190/0070-0040-0260-0190.html |    7-4-2619. Indexes to recorded documents, MCA  |  |
| MTS_0070-0040-0260-0200 | 200 | 10079 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0200/0070-0040-0260-0200.html |    7-4-2620. Details relating to indexes, MCA  |  |
| MTS_0070-0040-0260-0210 | 200 | 9710 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0210/0070-0040-0260-0210.html |    7-4-2621. Search of records, MCA  |  |
| MTS_0070-0040-0260-0220 | 200 | 9531 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0220/0070-0040-0260-0220.html |    7-4-2622. Availability of records, MCA  |  |
| MTS_0070-0040-0260-0230 | 200 | 10232 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0230/0070-0040-0260-0230.html |    7-4-2623. Liability of clerk relating to duties as recorder, MCA  |  |
| MTS_0070-0040-0260-0240 | 200 | 8809 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0240/0070-0040-0260-0240.html |    7-4-2624. through 7-4-2630 reserved, MCA  |  |
| MTS_0070-0040-0260-0310 | 200 | 16693 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0310/0070-0040-0260-0310.html |    7-4-2631. Fees of county clerk, MCA  |  |
| MTS_0070-0040-0260-0320 | 200 | 10007 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0320/0070-0040-0260-0320.html |    7-4-2632. Fee when recording done by mechanical means, MCA  |  |
| MTS_0070-0040-0260-0330 | 200 | 9406 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0330/0070-0040-0260-0330.html |    7-4-2633. Repealed, MCA  |  |
| MTS_0070-0040-0260-0340 | 200 | 9851 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0340/0070-0040-0260-0340.html |    7-4-2634. Fees to be noted on recorded documents, MCA  |  |
| MTS_0070-0040-0260-0350 | 200 | 9870 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0350/0070-0040-0260-0350.html |    7-4-2635. Records preservation fund authorized, MCA  |  |
| MTS_0070-0040-0260-0360 | 200 | 12652 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0360/0070-0040-0260-0360.html |    7-4-2636. Standards for recorded documents -- exemptions, MCA  |  |
| MTS_0070-0040-0260-0370 | 200 | 12800 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0260/section_0370/0070-0040-0260-0370.html |    7-4-2637. Fees for recording documents -- rulemaking, MCA  |  |
| MTS_0070-0040-0270-0010 | 200 | 10154 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0010/0070-0040-0270-0010.html |    7-4-2701. Qualifications for county attorney in certain counties, MCA  |  |
| MTS_0070-0040-0270-0020 | 200 | 9634 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0020/0070-0040-0270-0020.html |    7-4-2702. Procedure to fill vacancy in office of county attorney, MCA  |  |
| MTS_0070-0040-0270-0030 | 200 | 9659 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0030/0070-0040-0270-0030.html |    7-4-2703. Limitation on number of deputies, MCA  |  |
| MTS_0070-0040-0270-0040 | 200 | 11569 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0040/0070-0040-0270-0040.html |    7-4-2704. Limitations on activities of county attorneys and deputy county att |  |
| MTS_0070-0040-0270-0050 | 200 | 9497 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0050/0070-0040-0270-0050.html |    7-4-2705. Employment of special counsel, MCA  |  |
| MTS_0070-0040-0270-0060 | 200 | 9887 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0060/0070-0040-0270-0060.html |    7-4-2706. County attorney to be full or part time -- resolution, MCA  |  |
| MTS_0070-0040-0270-0070 | 200 | 9699 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0070/0070-0040-0270-0070.html |    7-4-2707. Contract for services of county attorney from another county, MCA  |  |
| MTS_0070-0040-0270-0080 | 200 | 9317 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0080/0070-0040-0270-0080.html |    7-4-2708. Contract for services of any other attorney, MCA  |  |
| MTS_0070-0040-0270-0090 | 200 | 8840 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0090/0070-0040-0270-0090.html |    7-4-2709. and 7-4-2710 reserved, MCA  |  |
| MTS_0070-0040-0270-0110 | 200 | 11631 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0110/0070-0040-0270-0110.html |    7-4-2711. County attorney to be legal adviser of county and other subdivision |  |
| MTS_0070-0040-0270-0120 | 200 | 9967 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0120/0070-0040-0270-0120.html |    7-4-2712. Prosecutorial duties, MCA  |  |
| MTS_0070-0040-0270-0130 | 200 | 9466 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0130/0070-0040-0270-0130.html |    7-4-2713. Actions to recover money, MCA  |  |
| MTS_0070-0040-0270-0140 | 200 | 10104 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0140/0070-0040-0270-0140.html |    7-4-2714. Recovery of illegally paid money, MCA  |  |
| MTS_0070-0040-0270-0150 | 200 | 9881 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0150/0070-0040-0270-0150.html |    7-4-2715. Records and reports, MCA  |  |
| MTS_0070-0040-0270-0160 | 200 | 10072 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0160/0070-0040-0270-0160.html |    7-4-2716. Duties related to state matters, MCA  |  |
| MTS_0070-0040-0270-0170 | 200 | 9129 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0170/0070-0040-0270-0170.html |    7-4-2717. Other duties, MCA  |  |
| MTS_0070-0040-0270-0180 | 200 | 9523 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0270/section_0180/0070-0040-0270-0180.html |    7-4-2718. Referral of complaint, MCA  |  |
| MTS_0070-0040-0280-0010 | 200 | 10153 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0280/section_0010/0070-0040-0280-0010.html |    7-4-2801. Qualifications for county surveyor and deputies, MCA  |  |
| MTS_0070-0040-0280-0020 | 200 | 9479 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0280/section_0020/0070-0040-0280-0020.html |    7-4-2802. Employment of assistants to surveyor, MCA  |  |
| MTS_0070-0040-0280-0030 | 200 | 10299 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0280/section_0030/0070-0040-0280-0030.html |    7-4-2803. Situations involving use of other surveyors, MCA  |  |
| MTS_0070-0040-0280-0040 | 200 | 8819 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0280/section_0040/0070-0040-0280-0040.html |    7-4-2804. through 7-4-2810 reserved, MCA  |  |
| MTS_0070-0040-0280-0110 | 200 | 10189 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0280/section_0110/0070-0040-0280-0110.html |    7-4-2811. Function of county surveyor, MCA  |  |
| MTS_0070-0040-0280-0120 | 200 | 11709 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0280/section_0120/0070-0040-0280-0120.html |    7-4-2812. Duties related to roads and bridges, MCA  |  |
| MTS_0070-0040-0280-0130 | 200 | 9839 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0280/section_0130/0070-0040-0280-0130.html |    7-4-2813. Maintenance of records, MCA  |  |
| MTS_0070-0040-0280-0140 | 200 | 10998 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0280/section_0140/0070-0040-0280-0140.html |    7-4-2814. Preparation of surveys, MCA  |  |
| MTS_0070-0040-0280-0150 | 200 | 10057 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0280/section_0150/0070-0040-0280-0150.html |    7-4-2815. Surveys involving land in two counties, MCA  |  |
| MTS_0070-0040-0280-0160 | 200 | 8810 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0280/section_0160/0070-0040-0280-0160.html |    7-4-2816. through 7-4-2820 reserved, MCA  |  |
| MTS_0070-0040-0280-0210 | 200 | 9035 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0280/section_0210/0070-0040-0280-0210.html |    7-4-2821. Fees of county surveyor, MCA  |  |
| MTS_0070-0040-0290-0010 | 200 | 10062 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0010/0070-0040-0290-0010.html |    7-4-2901. Appointment of deputy coroners, MCA  |  |
| MTS_0070-0040-0290-0020 | 200 | 11246 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0020/0070-0040-0290-0020.html |    7-4-2902. Vacancy in office of county coroner or disqualification of coroner, |  |
| MTS_0070-0040-0290-0030 | 200 | 9750 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0030/0070-0040-0290-0030.html |    7-4-2903. Stenographer for coroner in certain counties, MCA  |  |
| MTS_0070-0040-0290-0040 | 200 | 11251 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0040/0070-0040-0290-0040.html |    7-4-2904. Qualifications for office of county coroner, MCA  |  |
| MTS_0070-0040-0290-0050 | 200 | 10763 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0050/0070-0040-0290-0050.html |    7-4-2905. Coroner education and continuing education, MCA  |  |
| MTS_0070-0040-0290-0060 | 200 | 8812 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0060/0070-0040-0290-0060.html |    7-4-2906. through 7-4-2910 reserved, MCA  |  |
| MTS_0070-0040-0290-0110 | 200 | 12313 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0110/0070-0040-0290-0110.html |    7-4-2911. Duties of county coroner, MCA  |  |
| MTS_0070-0040-0290-0120 | 200 | 9128 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0120/0070-0040-0290-0120.html |    7-4-2912. Repealed, MCA  |  |
| MTS_0070-0040-0290-0130 | 200 | 9777 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0130/0070-0040-0290-0130.html |    7-4-2913. Payment of costs of inquest, MCA  |  |
| MTS_0070-0040-0290-0140 | 200 | 9894 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0140/0070-0040-0290-0140.html |    7-4-2914. Statement required before allowing accounts of coroner, MCA  |  |
| MTS_0070-0040-0290-0150 | 200 | 11249 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0150/0070-0040-0290-0150.html |    7-4-2915. Custody and disposition of bodies held pending investigation, MCA  |  |
| MTS_0070-0040-0290-0160 | 200 | 9041 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0160/0070-0040-0290-0160.html |    7-4-2916. Repealed, MCA  |  |
| MTS_0070-0040-0290-0170 | 200 | 10234 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0170/0070-0040-0290-0170.html |    7-4-2917. Disposition of property of deceased -- suicide note, MCA  |  |
| MTS_0070-0040-0290-0180 | 200 | 8805 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0180/0070-0040-0290-0180.html |    7-4-2918. through 7-4-2920 reserved, MCA  |  |
| MTS_0070-0040-0290-0210 | 200 | 9203 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0210/0070-0040-0290-0210.html |    7-4-2921. Repealed, MCA  |  |
| MTS_0070-0040-0290-0220 | 200 | 9218 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0220/0070-0040-0290-0220.html |    7-4-2922. Repealed, MCA  |  |
| MTS_0070-0040-0290-0230 | 200 | 9459 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0230/0070-0040-0290-0230.html |    7-4-2923. Computation of mileage for reimbursement, MCA  |  |
| MTS_0070-0040-0290-0240 | 200 | 10792 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0290/section_0240/0070-0040-0290-0240.html |    7-4-2924. Indigent funeral assistance, MCA  |  |
| MTS_0070-0040-0300-0010 | 200 | 8839 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0300/section_0010/0070-0040-0300-0010.html |    7-4-3001. Office of sheriff, MCA  |  |
| MTS_0070-0040-0300-0020 | 200 | 9056 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0300/section_0020/0070-0040-0300-0020.html |    7-4-3002. Office of county treasurer, MCA  |  |
| MTS_0070-0040-0300-0030 | 200 | 9059 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0300/section_0030/0070-0040-0300-0030.html |    7-4-3003. Office of county auditor, MCA  |  |
| MTS_0070-0040-0300-0040 | 200 | 9346 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0300/section_0040/0070-0040-0300-0040.html |    7-4-3004. Office of public administrator, MCA  |  |
| MTS_0070-0040-0300-0050 | 200 | 9191 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0300/section_0050/0070-0040-0300-0050.html |    7-4-3005. Office of county superintendent of schools, MCA  |  |
| MTS_0070-0040-0300-0060 | 200 | 10263 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0300/section_0060/0070-0040-0300-0060.html |    7-4-3006. Limitation on number of deputy district court clerks, MCA  |  |
| MTS_0070-0040-0300-0070 | 200 | 11084 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0300/section_0070/0070-0040-0300-0070.html |    7-4-3007. Qualifications for office of county assessor -- forfeiture of offic |  |
| MTS_0070-0040-0410-0010 | 200 | 10970 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0010/0070-0040-0410-0010.html |    7-4-4101. Officers of city of first class, MCA  |  |
| MTS_0070-0040-0410-0020 | 200 | 11549 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0020/0070-0040-0410-0020.html |    7-4-4102. Officers of city of second or third class, MCA  |  |
| MTS_0070-0040-0410-0030 | 200 | 11255 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0030/0070-0040-0410-0030.html |    7-4-4103. Officers of towns, MCA  |  |
| MTS_0070-0040-0410-0040 | 200 | 9748 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0040/0070-0040-0410-0040.html |    7-4-4104. General qualifications for municipal office, MCA  |  |
| MTS_0070-0040-0410-0050 | 200 | 9589 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0050/0070-0040-0410-0050.html |    7-4-4105. Authority to abolish appointive municipal offices, MCA  |  |
| MTS_0070-0040-0410-0060 | 200 | 9591 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0060/0070-0040-0410-0060.html |    7-4-4106. Authority to consolidate municipal offices, MCA  |  |
| MTS_0070-0040-0410-0070 | 200 | 9581 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0070/0070-0040-0410-0070.html |    7-4-4107. Commencement of term of office, MCA  |  |
| MTS_0070-0040-0410-0080 | 200 | 9325 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0080/0070-0040-0410-0080.html |    7-4-4108. Repealed, MCA  |  |
| MTS_0070-0040-0410-0090 | 200 | 9454 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0090/0070-0040-0410-0090.html |    7-4-4109. Official bond, MCA  |  |
| MTS_0070-0040-0410-0100 | 200 | 9834 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0100/0070-0040-0410-0100.html |    7-4-4110. Duties of officers not otherwise provided for, MCA  |  |
| MTS_0070-0040-0410-0110 | 200 | 11516 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0110/0070-0040-0410-0110.html |    7-4-4111. Determination of vacancy in municipal office, MCA  |  |
| MTS_0070-0040-0410-0120 | 200 | 10278 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0120/0070-0040-0410-0120.html |    7-4-4112. Filling of vacancy, MCA  |  |
| MTS_0070-0040-0410-0130 | 200 | 9351 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0130/0070-0040-0410-0130.html |    7-4-4113. Removal of appointed officer, MCA  |  |
| MTS_0070-0040-0410-0140 | 200 | 9714 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0410/section_0140/0070-0040-0410-0140.html |    7-4-4114. Municipal executive officers, MCA  |  |
| MTS_0070-0040-0420-0010 | 200 | 11012 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0420/section_0010/0070-0040-0420-0010.html |    7-4-4201. Salary of officers, MCA  |  |
| MTS_0070-0040-0420-0020 | 200 | 9596 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0420/section_0020/0070-0040-0420-0020.html |    7-4-4202. Repealed, MCA  |  |
| MTS_0070-0040-0420-0030 | 200 | 8905 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0420/section_0030/0070-0040-0420-0030.html |    7-4-4203. through 7-4-4210 reserved, MCA  |  |
| MTS_0070-0040-0420-0110 | 200 | 9814 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0420/section_0110/0070-0040-0420-0110.html |    7-4-4211. Designation of person to receive decedent's warrants or paychecks - |  |
| MTS_0070-0040-0430-0010 | 200 | 9773 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0430/section_0010/0070-0040-0430-0010.html |    7-4-4301. Qualifications for mayor, MCA  |  |
| MTS_0070-0040-0430-0020 | 200 | 9327 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0430/section_0020/0070-0040-0430-0020.html |    7-4-4302. Term of office, MCA  |  |
| MTS_0070-0040-0430-0030 | 200 | 10552 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0430/section_0030/0070-0040-0430-0030.html |    7-4-4303. Powers of mayor related to municipal officers, personnel, and citiz |  |
| MTS_0070-0040-0430-0040 | 200 | 9243 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0430/section_0040/0070-0040-0430-0040.html |    7-4-4304. Repealed, MCA  |  |
| MTS_0070-0040-0430-0050 | 200 | 9459 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0430/section_0050/0070-0040-0430-0050.html |    7-4-4305. Power to grant pardons, MCA  |  |
| MTS_0070-0040-0430-0060 | 200 | 9523 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0430/section_0060/0070-0040-0430-0060.html |    7-4-4306. Extraterritorial powers, MCA  |  |
| MTS_0070-0040-0440-0010 | 200 | 9419 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0440/section_0010/0070-0040-0440-0010.html |    7-4-4401. Qualifications for city council member, MCA  |  |
| MTS_0070-0040-0440-0020 | 200 | 10193 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0440/section_0020/0070-0040-0440-0020.html |    7-4-4402. Term of office, MCA  |  |
| MTS_0070-0040-0440-0030 | 200 | 9203 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0440/section_0030/0070-0040-0440-0030.html |    7-4-4403. Officers of city or town council, MCA  |  |
| MTS_0070-0040-0450-0010 | 200 | 10187 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0450/section_0010/0070-0040-0450-0010.html |    7-4-4501. Duties of city clerk related to administration, MCA  |  |
| MTS_0070-0040-0450-0020 | 200 | 10066 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0450/section_0020/0070-0040-0450-0020.html |    7-4-4502. Duties of city clerk related to city records and papers, MCA  |  |
| MTS_0070-0040-0450-0030 | 200 | 9294 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0450/section_0030/0070-0040-0450-0030.html |    7-4-4503. City ordinance book, MCA  |  |
| MTS_0070-0040-0450-0040 | 200 | 8814 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0450/section_0040/0070-0040-0450-0040.html |    7-4-4504. through 7-4-4510 reserved, MCA  |  |
| MTS_0070-0040-0450-0110 | 200 | 10024 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0450/section_0110/0070-0040-0450-0110.html |    7-4-4511. Duties of town clerk related to administration, MCA  |  |
| MTS_0070-0040-0450-0120 | 200 | 9407 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0450/section_0120/0070-0040-0450-0120.html |    7-4-4512. Duties of town clerk related to town records and papers, MCA  |  |
| MTS_0070-0040-0450-0130 | 200 | 8974 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0450/section_0130/0070-0040-0450-0130.html |    7-4-4513. Town ordinance book, MCA  |  |
| MTS_0070-0040-0460-0010 | 200 | 9137 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0460/section_0010/0070-0040-0460-0010.html |    7-4-4601. Qualifications for city attorney, MCA  |  |
| MTS_0070-0040-0460-0020 | 200 | 9551 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0460/section_0020/0070-0040-0460-0020.html |    7-4-4602. Appointment -- term of office, MCA  |  |
| MTS_0070-0040-0460-0030 | 200 | 9346 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0460/section_0030/0070-0040-0460-0030.html |    7-4-4603. Removal or suspension, MCA  |  |
| MTS_0070-0040-0460-0040 | 200 | 10207 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0460/section_0040/0070-0040-0460-0040.html |    7-4-4604. Duties, MCA  |  |
| MTS_0070-0040-0460-0050 | 200 | 9796 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0460/section_0050/0070-0040-0460-0050.html |    7-4-4605. Employment of special or additional counsel, MCA  |  |
| MTS_0070-0040-0460-0060 | 200 | 9298 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0460/section_0060/0070-0040-0460-0060.html |    7-4-4606. Legal services for city of third class, MCA  |  |
| MTS_0070-0040-0470-0010 | 200 | 9026 | https://leg.mt.gov/bills/mca/title_0070/chapter_0040/part_0470/section_0010/0070-0040-0470-0010.html |    7-4-4701. Term of office for city treasurer, MCA  |  |
| MTS_0070-0050-0010-0010 | 200 | 9405 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0010/0070-0050-0010-0010.html |    7-5-101. Definition, MCA  |  |
| MTS_0070-0050-0010-0020 | 200 | 9561 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0020/0070-0050-0010-0020.html |    7-5-102. Construction of certain sections, MCA  |  |
| MTS_0070-0050-0010-0030 | 200 | 13284 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0030/0070-0050-0010-0030.html |    7-5-103. Ordinance requirements, MCA  |  |
| MTS_0070-0050-0010-0040 | 200 | 9551 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0040/0070-0050-0010-0040.html |    7-5-104. Emergency ordinance, MCA  |  |
| MTS_0070-0050-0010-0050 | 200 | 9486 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0050/0070-0050-0010-0050.html |    7-5-105. Effective date of ordinance, MCA  |  |
| MTS_0070-0050-0010-0060 | 200 | 9661 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0060/0070-0050-0010-0060.html |    7-5-106. Ordinance veto procedure, MCA  |  |
| MTS_0070-0050-0010-0070 | 200 | 9918 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0070/0070-0050-0010-0070.html |    7-5-107. Register of ordinances and codification, MCA  |  |
| MTS_0070-0050-0010-0080 | 200 | 11948 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0080/0070-0050-0010-0080.html |    7-5-108. Adoption and amendment of codes by reference, MCA  |  |
| MTS_0070-0050-0010-0090 | 200 | 10060 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0090/0070-0050-0010-0090.html |    7-5-109. Penalty for violation of ordinance, MCA  |  |
| MTS_0070-0050-0010-0100 | 200 | 8973 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0100/0070-0050-0010-0100.html |    7-5-110. through 7-5-120 reserved, MCA  |  |
| MTS_0070-0050-0010-0210 | 200 | 12170 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0210/0070-0050-0010-0210.html |    7-5-121. Resolution requirements, MCA  |  |
| MTS_0070-0050-0010-0220 | 200 | 9625 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0220/0070-0050-0010-0220.html |    7-5-122. Resolution veto procedure, MCA  |  |
| MTS_0070-0050-0010-0230 | 200 | 9324 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0230/0070-0050-0010-0230.html |    7-5-123. Effective date of resolutions, MCA  |  |
| MTS_0070-0050-0010-0240 | 200 | 8979 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0240/0070-0050-0010-0240.html |    7-5-124. through 7-5-130 reserved, MCA  |  |
| MTS_0070-0050-0010-0310 | 200 | 11064 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0310/0070-0050-0010-0310.html |    7-5-131. Right of initiative and referendum, MCA  |  |
| MTS_0070-0050-0010-0320 | 200 | 9348 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0320/0070-0050-0010-0320.html |    7-5-132. Repealed, MCA  |  |
| MTS_0070-0050-0010-0330 | 200 | 9196 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0330/0070-0050-0010-0330.html |    7-5-133. Repealed, MCA  |  |
| MTS_0070-0050-0010-0340 | 200 | 9234 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0340/0070-0050-0010-0340.html |    7-5-134. Repealed, MCA  |  |
| MTS_0070-0050-0010-0350 | 200 | 9227 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0350/0070-0050-0010-0350.html |    7-5-135. Repealed, MCA  |  |
| MTS_0070-0050-0010-0360 | 200 | 9320 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0360/0070-0050-0010-0360.html |    7-5-136. Repealed, MCA  |  |
| MTS_0070-0050-0010-0370 | 200 | 10040 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0370/0070-0050-0010-0370.html |    7-5-137. Effect of repeal or enactment of ordinance by initiative or referend |  |
| MTS_0070-0050-0010-0380 | 200 | 9600 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0380/0070-0050-0010-0380.html |    7-5-138. Sanctuary jurisdiction prohibited, MCA  |  |
| MTS_0070-0050-0010-0390 | 200 | 8852 | https://leg.mt.gov/bills/mca/title_0070/chapter_0050/part_0010/section_0390/0070-0050-0010-0390.html |    7-5-139. reserved, MCA  |  |
