| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0050-0050-0040-0160 | 200 | 10700 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0160/0050-0050-0040-0160.html |    5-5-416. Senate to be sworn, MCA  |  |
| MTS_0050-0050-0040-0170 | 200 | 10690 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0170/0050-0050-0040-0170.html |    5-5-417. Proceedings on failure to appear, MCA  |  |
| MTS_0050-0050-0040-0180 | 200 | 10707 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0180/0050-0050-0040-0180.html |    5-5-418. Counsel may be appointed, MCA  |  |
| MTS_0050-0050-0040-0190 | 200 | 10590 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0190/0050-0050-0040-0190.html |    5-5-419. Defendant's objection or answer, MCA  |  |
| MTS_0050-0050-0040-0200 | 200 | 10798 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0200/0050-0050-0040-0200.html |    5-5-420. Overrule of objection -- defendant's plea, MCA  |  |
| MTS_0050-0050-0040-0210 | 200 | 10587 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0210/0050-0050-0040-0210.html |    5-5-421. Two-thirds vote necessary to conviction, MCA  |  |
| MTS_0050-0050-0040-0220 | 200 | 10474 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0220/0050-0050-0040-0220.html |    5-5-422. Judgment on conviction -- how pronounced, MCA  |  |
| MTS_0050-0050-0040-0230 | 200 | 10465 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0230/0050-0050-0040-0230.html |    5-5-423. Judgment on conviction -- how finalized, MCA  |  |
| MTS_0050-0050-0040-0240 | 200 | 9806 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0240/0050-0050-0040-0240.html |    5-5-424. through 5-5-430 reserved, MCA  |  |
| MTS_0050-0050-0040-0310 | 200 | 10416 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0310/0050-0050-0040-0310.html |    5-5-431. Nature of judgment, MCA  |  |
| MTS_0050-0050-0040-0320 | 200 | 10412 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0320/0050-0050-0040-0320.html |    5-5-432. Effect of judgment of suspension, MCA  |  |
| MTS_0050-0050-0040-0330 | 200 | 10211 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0330/0050-0050-0040-0330.html |    5-5-433. Criminal prosecution not barred, MCA  |  |
| MTS_0050-0050-0050-0010 | 200 | 9604 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0050/section_0010/0050-0050-0050-0010.html |    5-5-501. reserved, MCA  |  |
| MTS_0050-0050-0050-0020 | 200 | 11113 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0050/section_0020/0050-0050-0050-0020.html |    5-5-502. Sole constitutional authority by legislature on rules governing its  |  |
| MTS_0050-0060-0010-0010 | 200 | 9876 | https://leg.mt.gov/bills/mca/title_0050/chapter_0060/part_0010/section_0010/0050-0060-0010-0010.html |    5-6-101. Repealed, MCA  |  |
| MTS_0050-0060-0010-0020 | 200 | 10202 | https://leg.mt.gov/bills/mca/title_0050/chapter_0060/part_0010/section_0020/0050-0060-0010-0020.html |    5-6-102. Repealed, MCA  |  |
| MTS_0050-0060-0010-0030 | 200 | 10109 | https://leg.mt.gov/bills/mca/title_0050/chapter_0060/part_0010/section_0030/0050-0060-0010-0030.html |    5-6-103. Repealed, MCA  |  |
| MTS_0050-0060-0010-0040 | 200 | 10078 | https://leg.mt.gov/bills/mca/title_0050/chapter_0060/part_0010/section_0040/0050-0060-0010-0040.html |    5-6-104. Repealed, MCA  |  |
| MTS_0050-0060-0010-0050 | 200 | 10078 | https://leg.mt.gov/bills/mca/title_0050/chapter_0060/part_0010/section_0050/0050-0060-0010-0050.html |    5-6-105. Repealed, MCA  |  |
| MTS_0050-0060-0010-0060 | 200 | 10171 | https://leg.mt.gov/bills/mca/title_0050/chapter_0060/part_0010/section_0060/0050-0060-0010-0060.html |    5-6-106. Repealed, MCA  |  |
| MTS_0050-0060-0010-0070 | 200 | 10078 | https://leg.mt.gov/bills/mca/title_0050/chapter_0060/part_0010/section_0070/0050-0060-0010-0070.html |    5-6-107. Repealed, MCA  |  |
| MTS_0050-0060-0010-0080 | 200 | 10078 | https://leg.mt.gov/bills/mca/title_0050/chapter_0060/part_0010/section_0080/0050-0060-0010-0080.html |    5-6-108. Repealed, MCA  |  |
| MTS_0050-0060-0010-0090 | 200 | 10110 | https://leg.mt.gov/bills/mca/title_0050/chapter_0060/part_0010/section_0090/0050-0060-0010-0090.html |    5-6-109. Repealed, MCA  |  |
| MTS_0050-0060-0010-0100 | 200 | 10079 | https://leg.mt.gov/bills/mca/title_0050/chapter_0060/part_0010/section_0100/0050-0060-0010-0100.html |    5-6-110. Repealed, MCA  |  |
| MTS_0050-0060-0010-0110 | 200 | 9880 | https://leg.mt.gov/bills/mca/title_0050/chapter_0060/part_0010/section_0110/0050-0060-0010-0110.html |    5-6-111. Repealed, MCA  |  |
| MTS_0050-0070-0010-0010 | 200 | 10634 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0010/0050-0070-0010-0010.html |    5-7-101. Purposes of chapter -- applicability, MCA  |  |
| MTS_0050-0070-0010-0020 | 200 | 19829 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0020/0050-0070-0010-0020.html |    5-7-102. Definitions, MCA  |  |
| MTS_0050-0070-0010-0030 | 200 | 12955 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0030/0050-0070-0010-0030.html |    5-7-103. Licenses -- fees -- eligibility -- waiver, MCA  |  |
| MTS_0050-0070-0010-0040 | 200 | 10135 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0040/0050-0070-0010-0040.html |    5-7-104. Repealed, MCA  |  |
| MTS_0050-0070-0010-0050 | 200 | 10529 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0050/0050-0070-0010-0050.html |    5-7-105. Suspension of lobbying privileges, MCA  |  |
| MTS_0050-0070-0010-0060 | 200 | 13935 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0060/0050-0070-0010-0060.html |    5-7-106. Disclosure of local government lobbying contract -- exemption for lo |  |
| MTS_0050-0070-0010-0070 | 200 | 9843 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0070/0050-0070-0010-0070.html |    5-7-107. reserved, MCA  |  |
| MTS_0050-0070-0010-0080 | 200 | 11528 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0080/0050-0070-0010-0080.html |    5-7-108. Inspection of applications and reports -- order of noncompliance --  |  |
| MTS_0050-0070-0010-0090 | 200 | 9864 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0090/0050-0070-0010-0090.html |    5-7-109. and 5-7-110 reserved, MCA  |  |
| MTS_0050-0070-0010-0110 | 200 | 10730 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0110/0050-0070-0010-0110.html |    5-7-111. Commissioner to make rules, MCA  |  |
| MTS_0050-0070-0010-0120 | 200 | 11058 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0120/0050-0070-0010-0120.html |    5-7-112. Payment threshold -- inflation adjustment, MCA  |  |
| MTS_0050-0070-0010-0130 | 200 | 9877 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0130/0050-0070-0010-0130.html |    5-7-113. through 5-7-119 reserved, MCA  |  |
| MTS_0050-0070-0010-0200 | 200 | 11607 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0010/section_0200/0050-0070-0010-0200.html |    5-7-120. Full disclosure of public expenditures on federal lobbying, MCA  |  |
| MTS_0050-0070-0020-0010 | 200 | 10506 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0010/0050-0070-0020-0010.html |    5-7-201. Docket -- contents, MCA  |  |
| MTS_0050-0070-0020-0020 | 200 | 10264 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0020/0050-0070-0020-0020.html |    5-7-202. Docket -- public record, MCA  |  |
| MTS_0050-0070-0020-0030 | 200 | 10518 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0030/0050-0070-0020-0030.html |    5-7-203. Principal -- name of lobbyist on docket, MCA  |  |
| MTS_0050-0070-0020-0040 | 200 | 10466 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0040/0050-0070-0020-0040.html |    5-7-204. Updating docket, MCA  |  |
| MTS_0050-0070-0020-0050 | 200 | 10003 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0050/0050-0070-0020-0050.html |    5-7-205. Repealed, MCA  |  |
| MTS_0050-0070-0020-0060 | 200 | 10041 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0060/0050-0070-0020-0060.html |    5-7-206. Repealed, MCA  |  |
| MTS_0050-0070-0020-0070 | 200 | 10642 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0070/0050-0070-0020-0070.html |    5-7-207. Report to legislature, MCA  |  |
| MTS_0050-0070-0020-0080 | 200 | 15433 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0080/0050-0070-0020-0080.html |    5-7-208. Principals to file report, MCA  |  |
| MTS_0050-0070-0020-0090 | 200 | 11111 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0090/0050-0070-0020-0090.html |    5-7-209. Payments prohibited unless reported -- penalty for late filing, fail |  |
| MTS_0050-0070-0020-0100 | 200 | 10548 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0100/0050-0070-0020-0100.html |    5-7-210. Reimbursement, MCA  |  |
| MTS_0050-0070-0020-0110 | 200 | 10307 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0110/0050-0070-0020-0110.html |    5-7-211. Governmental responses not lobbying payments, MCA  |  |
| MTS_0050-0070-0020-0120 | 200 | 11585 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0120/0050-0070-0020-0120.html |    5-7-212. Audit of lobbying reports, MCA  |  |
| MTS_0050-0070-0020-0130 | 200 | 9596 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0020/section_0130/0050-0070-0020-0130.html |    5-7-213. Renumbered 2-2-106, MCA  |  |
| MTS_0050-0070-0030-0010 | 200 | 10716 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0030/section_0010/0050-0070-0030-0010.html |    5-7-301. Prohibition of practice without license and registration, MCA  |  |
| MTS_0050-0070-0030-0020 | 200 | 10273 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0030/section_0020/0050-0070-0030-0020.html |    5-7-302. Unprofessional conduct, MCA  |  |
| MTS_0050-0070-0030-0030 | 200 | 10051 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0030/section_0030/0050-0070-0030-0030.html |    5-7-303. Repealed, MCA  |  |
| MTS_0050-0070-0030-0040 | 200 | 10019 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0030/section_0040/0050-0070-0030-0040.html |    5-7-304. Repealed, MCA  |  |
| MTS_0050-0070-0030-0050 | 200 | 14183 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0030/section_0050/0050-0070-0030-0050.html |    5-7-305. Penalties and enforcement, MCA  |  |
| MTS_0050-0070-0030-0060 | 200 | 11973 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0030/section_0060/0050-0070-0030-0060.html |    5-7-306. Civil penalties for delays in filing -- option for hearing -- suspen |  |
| MTS_0050-0070-0030-0070 | 200 | 9906 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0030/section_0070/0050-0070-0030-0070.html |    5-7-307. through 5-7-309 reserved, MCA  |  |
| MTS_0050-0070-0030-0100 | 200 | 10739 | https://leg.mt.gov/bills/mca/title_0050/chapter_0070/part_0030/section_0100/0050-0070-0030-0100.html |    5-7-310. Prohibition of lobbying by former government personnel, MCA  |  |
| MTS_0050-0110-0010-0010 | 200 | 11480 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0010/0050-0110-0010-0010.html |    5-11-101. Appointment and composition of council, MCA  |  |
| MTS_0050-0110-0010-0020 | 200 | 10805 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0020/0050-0110-0010-0020.html |    5-11-102. Term, MCA  |  |
| MTS_0050-0110-0010-0030 | 200 | 10326 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0030/0050-0110-0010-0030.html |    5-11-103. Vacancies, MCA  |  |
| MTS_0050-0110-0010-0040 | 200 | 11003 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0040/0050-0110-0010-0040.html |    5-11-104. Officers -- rules of procedure -- records, MCA  |  |
| MTS_0050-0110-0010-0050 | 200 | 13626 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0050/0050-0110-0010-0050.html |    5-11-105. Powers and duties of council, MCA  |  |
| MTS_0050-0110-0010-0060 | 200 | 10688 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0060/0050-0110-0010-0060.html |    5-11-106. Authority to investigate and examine, MCA  |  |
| MTS_0050-0110-0010-0070 | 200 | 11977 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0070/0050-0110-0010-0070.html |    5-11-107. Powers relating to hearings, MCA  |  |
| MTS_0050-0110-0010-0080 | 200 | 15258 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0080/0050-0110-0010-0080.html |    5-11-108. Legislative declaration, MCA  |  |
| MTS_0050-0110-0010-0090 | 200 | 12252 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0090/0050-0110-0010-0090.html |    5-11-109. Review of presidential executive orders -- restriction, MCA  |  |
| MTS_0050-0110-0010-0100 | 200 | 9875 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0100/0050-0110-0010-0100.html |    5-11-110. reserved, MCA  |  |
| MTS_0050-0110-0010-0110 | 200 | 10985 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0110/0050-0110-0010-0110.html |    5-11-111. Legislative services division, MCA  |  |
| MTS_0050-0110-0010-0120 | 200 | 14932 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0120/0050-0110-0010-0120.html |    5-11-112. Functional organization and responsibilities, MCA  |  |
| MTS_0050-0110-0010-0130 | 200 | 11793 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0130/0050-0110-0010-0130.html |    5-11-113. State-tribal relations training, MCA  |  |
| MTS_0050-0110-0010-0140 | 200 | 9842 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0140/0050-0110-0010-0140.html |    5-11-114. reserved, MCA  |  |
| MTS_0050-0110-0010-0150 | 200 | 9937 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0150/0050-0110-0010-0150.html |    5-11-115. Renumbered 2-17-805, MCA  |  |
| MTS_0050-0110-0010-0160 | 200 | 9954 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0160/0050-0110-0010-0160.html |    5-11-116. Renumbered 2-17-825, MCA  |  |
| MTS_0050-0110-0010-0170 | 200 | 9983 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0170/0050-0110-0010-0170.html |    5-11-117. through 5-11-119 reserved, MCA  |  |
| MTS_0050-0110-0010-0200 | 200 | 11635 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0010/section_0200/0050-0110-0010-0200.html |    5-11-120. Legislative branch retirement termination reserve account, MCA  |  |
| MTS_0050-0110-0020-0010 | 200 | 10512 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0010/0050-0110-0020-0010.html |    5-11-201. Journals -- how authenticated -- filing, MCA  |  |
| MTS_0050-0110-0020-0020 | 200 | 10841 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0020/0050-0110-0020-0020.html |    5-11-202. Printing of session laws, MCA  |  |
| MTS_0050-0110-0020-0030 | 200 | 13795 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0030/0050-0110-0020-0030.html |    5-11-203. Distribution of session laws -- examination of journals, MCA  |  |
| MTS_0050-0110-0020-0040 | 200 | 11048 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0040/0050-0110-0020-0040.html |    5-11-204. Secretary of state to assign chapter numbers to new laws, MCA  |  |
| MTS_0050-0110-0020-0050 | 200 | 12046 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0050/0050-0110-0020-0050.html |    5-11-205. Publication of laws -- format, MCA  |  |
| MTS_0050-0110-0020-0060 | 200 | 11340 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0060/0050-0110-0020-0060.html |    5-11-206. Index -- list, MCA  |  |
| MTS_0050-0110-0020-0070 | 200 | 10866 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0070/0050-0110-0020-0070.html |    5-11-207. Description of county boundaries included in session laws, MCA  |  |
| MTS_0050-0110-0020-0080 | 200 | 11015 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0080/0050-0110-0020-0080.html |    5-11-208. Expenses, MCA  |  |
| MTS_0050-0110-0020-0090 | 200 | 12463 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0090/0050-0110-0020-0090.html |    5-11-209. Codes -- availability to legislators -- reserved for use by legisla |  |
| MTS_0050-0110-0020-0100 | 200 | 13206 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0100/0050-0110-0020-0100.html |    5-11-210. Clearinghouse for reports to legislature, MCA  |  |
| MTS_0050-0110-0020-0110 | 200 | 11184 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0110/0050-0110-0020-0110.html |    5-11-211. Definitions, MCA  |  |
| MTS_0050-0110-0020-0120 | 200 | 11583 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0120/0050-0110-0020-0120.html |    5-11-212. Fees for proceedings -- electronic version requirement, MCA  |  |
| MTS_0050-0110-0020-0130 | 200 | 10652 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0130/0050-0110-0020-0130.html |    5-11-213. Exclusions, MCA  |  |
| MTS_0050-0110-0020-0140 | 200 | 10371 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0140/0050-0110-0020-0140.html |    5-11-214. Exemptions from fees, MCA  |  |
| MTS_0050-0110-0020-0150 | 200 | 9911 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0150/0050-0110-0020-0150.html |    5-11-215. through 5-11-220 reserved, MCA  |  |
| MTS_0050-0110-0020-0210 | 200 | 10111 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0210/0050-0110-0020-0210.html |    5-11-221. Repealed, MCA  |  |
| MTS_0050-0110-0020-0220 | 200 | 97425 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0020/section_0220/0050-0110-0020-0220.html |    5-11-222. Reports to legislature, MCA  |  |
| MTS_0050-0110-0030-0010 | 200 | 10123 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0030/section_0010/0050-0110-0030-0010.html |    5-11-301. Repealed, MCA  |  |
| MTS_0050-0110-0030-0020 | 200 | 10175 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0030/section_0020/0050-0110-0030-0020.html |    5-11-302. Repealed, MCA  |  |
| MTS_0050-0110-0030-0030 | 200 | 11208 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0030/section_0030/0050-0110-0030-0030.html |    5-11-303. Definitions, MCA  |  |
| MTS_0050-0110-0030-0040 | 200 | 11476 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0030/section_0040/0050-0110-0030-0040.html |    5-11-304. Legislative council's role in interstate, international, and interg |  |
| MTS_0050-0110-0030-0050 | 200 | 12749 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0030/section_0050/0050-0110-0030-0050.html |    5-11-305. Legislative council appointments to interstate, international, and  |  |
| MTS_0050-0110-0040-0010 | 200 | 10475 | https://leg.mt.gov/bills/mca/title_0050/chapter_0110/part_0040/section_0010/0050-0110-0040-0010.html |    5-11-401. Purpose, MCA  |  |
