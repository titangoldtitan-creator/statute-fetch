| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0720-0300-0020-0120 | 200 | 10708 | https://leg.mt.gov/bills/mca/title_0720/chapter_0300/part_0020/section_0120/0720-0300-0020-0120.html |    72-30-212. Application to existing institutional funds, MCA  |  |
| MTS_0720-0300-0020-0130 | 200 | 10729 | https://leg.mt.gov/bills/mca/title_0720/chapter_0300/part_0020/section_0130/0720-0300-0020-0130.html |    72-30-213. Relation to Electronic Signatures in Global and National Commerce  |  |
| MTS_0720-0300-0030-0010 | 200 | 10441 | https://leg.mt.gov/bills/mca/title_0720/chapter_0300/part_0030/section_0010/0720-0300-0030-0010.html |    72-30-301. Short title -- purpose, MCA  |  |
| MTS_0720-0300-0030-0020 | 200 | 13276 | https://leg.mt.gov/bills/mca/title_0720/chapter_0300/part_0030/section_0020/0720-0300-0030-0020.html |    72-30-302. Definitions, MCA  |  |
| MTS_0720-0300-0030-0030 | 200 | 13054 | https://leg.mt.gov/bills/mca/title_0720/chapter_0300/part_0030/section_0030/0720-0300-0030-0030.html |    72-30-303. Protections afforded, MCA  |  |
| MTS_0720-0310-0010-0010 | 200 | 10867 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0010/section_0010/0720-0310-0010-0010.html |    72-31-101. Oath in behalf of corporation acting as fiduciary, MCA  |  |
| MTS_0720-0310-0010-0020 | 200 | 11183 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0010/section_0020/0720-0310-0010-0020.html |    72-31-102. Investment by fiduciaries in home owners' loan corporation bonds a |  |
| MTS_0720-0310-0010-0030 | 200 | 11387 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0010/section_0030/0720-0310-0010-0030.html |    72-31-103. Validation of fiduciary sales, MCA  |  |
| MTS_0720-0310-0020-0010 | 200 | 10352 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0010/0720-0310-0020-0010.html |    72-31-201. Repealed, MCA  |  |
| MTS_0720-0310-0020-0020 | 200 | 10284 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0020/0720-0310-0020-0020.html |    72-31-202. Renumbered 72-31-224, MCA  |  |
| MTS_0720-0310-0020-0030 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0030/0720-0310-0020-0030.html |    72-31-203. Renumbered 72-31-225, MCA  |  |
| MTS_0720-0310-0020-0040 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0040/0720-0310-0020-0040.html |    72-31-204. Renumbered 72-31-226, MCA  |  |
| MTS_0720-0310-0020-0050 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0050/0720-0310-0020-0050.html |    72-31-205. Renumbered 72-31-228, MCA  |  |
| MTS_0720-0310-0020-0060 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0060/0720-0310-0020-0060.html |    72-31-206. Renumbered 72-31-229, MCA  |  |
| MTS_0720-0310-0020-0070 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0070/0720-0310-0020-0070.html |    72-31-207. Renumbered 72-31-230, MCA  |  |
| MTS_0720-0310-0020-0080 | 200 | 10284 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0080/0720-0310-0020-0080.html |    72-31-208. Renumbered 72-31-231, MCA  |  |
| MTS_0720-0310-0020-0090 | 200 | 10462 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0090/0720-0310-0020-0090.html |    72-31-209. Repealed, MCA  |  |
| MTS_0720-0310-0020-0100 | 200 | 10463 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0100/0720-0310-0020-0100.html |    72-31-210. Repealed, MCA  |  |
| MTS_0720-0310-0020-0110 | 200 | 10284 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0110/0720-0310-0020-0110.html |    72-31-211. Renumbered 72-31-232, MCA  |  |
| MTS_0720-0310-0020-0120 | 200 | 10284 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0120/0720-0310-0020-0120.html |    72-31-212. Renumbered 72-31-233, MCA  |  |
| MTS_0720-0310-0020-0130 | 200 | 10463 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0130/0720-0310-0020-0130.html |    72-31-213. Repealed, MCA  |  |
| MTS_0720-0310-0020-0140 | 200 | 10451 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0140/0720-0310-0020-0140.html |    72-31-214. Repealed, MCA  |  |
| MTS_0720-0310-0020-0150 | 200 | 10451 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0150/0720-0310-0020-0150.html |    72-31-215. Repealed, MCA  |  |
| MTS_0720-0310-0020-0160 | 200 | 10469 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0160/0720-0310-0020-0160.html |    72-31-216. Repealed, MCA  |  |
| MTS_0720-0310-0020-0170 | 200 | 10282 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0170/0720-0310-0020-0170.html |    72-31-217. through 72-31-221 reserved, MCA  |  |
| MTS_0720-0310-0020-0220 | 200 | 10302 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0220/0720-0310-0020-0220.html |    72-31-222. Renumbered 72-31-304, MCA  |  |
| MTS_0720-0310-0020-0230 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0230/0720-0310-0020-0230.html |    72-31-223. Renumbered 72-31-338, MCA  |  |
| MTS_0720-0310-0020-0240 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0240/0720-0310-0020-0240.html |    72-31-224. Renumbered 72-31-339, MCA  |  |
| MTS_0720-0310-0020-0250 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0250/0720-0310-0020-0250.html |    72-31-225. Renumbered 72-31-340, MCA  |  |
| MTS_0720-0310-0020-0260 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0260/0720-0310-0020-0260.html |    72-31-226. Renumbered 72-31-341, MCA  |  |
| MTS_0720-0310-0020-0270 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0270/0720-0310-0020-0270.html |    72-31-227. Renumbered 72-31-342, MCA  |  |
| MTS_0720-0310-0020-0280 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0280/0720-0310-0020-0280.html |    72-31-228. Renumbered 72-31-343, MCA  |  |
| MTS_0720-0310-0020-0290 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0290/0720-0310-0020-0290.html |    72-31-229. Renumbered 72-31-344, MCA  |  |
| MTS_0720-0310-0020-0300 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0300/0720-0310-0020-0300.html |    72-31-230. Renumbered 72-31-345, MCA  |  |
| MTS_0720-0310-0020-0310 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0310/0720-0310-0020-0310.html |    72-31-231. Renumbered 72-31-346, MCA  |  |
| MTS_0720-0310-0020-0320 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0320/0720-0310-0020-0320.html |    72-31-232. Renumbered 72-31-347, MCA  |  |
| MTS_0720-0310-0020-0330 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0330/0720-0310-0020-0330.html |    72-31-233. Renumbered 72-31-348, MCA  |  |
| MTS_0720-0310-0020-0340 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0340/0720-0310-0020-0340.html |    72-31-234. Renumbered 72-31-349, MCA  |  |
| MTS_0720-0310-0020-0350 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0350/0720-0310-0020-0350.html |    72-31-235. Renumbered 72-31-350, MCA  |  |
| MTS_0720-0310-0020-0360 | 200 | 10284 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0360/0720-0310-0020-0360.html |    72-31-236. Renumbered 72-31-351, MCA  |  |
| MTS_0720-0310-0020-0370 | 200 | 10475 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0370/0720-0310-0020-0370.html |    72-31-237. Repealed, MCA  |  |
| MTS_0720-0310-0020-0380 | 200 | 10071 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0020/section_0380/0720-0310-0020-0380.html |    72-31-238. Renumbered 72-31-365, MCA  |  |
| MTS_0720-0310-0030-0010 | 200 | 10159 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0010/0720-0310-0030-0010.html |    72-31-301. Short title, MCA  |  |
| MTS_0720-0310-0030-0020 | 200 | 15054 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0020/0720-0310-0030-0020.html |    72-31-302. Definitions, MCA  |  |
| MTS_0720-0310-0030-0030 | 200 | 11139 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0030/0720-0310-0030-0030.html |    72-31-303. Applicability, MCA  |  |
| MTS_0720-0310-0030-0040 | 200 | 10716 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0040/0720-0310-0030-0040.html |    72-31-304. Power of attorney is durable, MCA  |  |
| MTS_0720-0310-0030-0050 | 200 | 10820 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0050/0720-0310-0030-0050.html |    72-31-305. Execution of power of attorney, MCA  |  |
| MTS_0720-0310-0030-0060 | 200 | 11798 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0060/0720-0310-0030-0060.html |    72-31-306. Validity of power of attorney, MCA  |  |
| MTS_0720-0310-0030-0070 | 200 | 10793 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0070/0720-0310-0030-0070.html |    72-31-307. Meaning and effect of power of attorney, MCA  |  |
| MTS_0720-0310-0030-0080 | 200 | 11663 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0080/0720-0310-0030-0080.html |    72-31-308. Nomination of conservator or guardian -- relation of agent to cour |  |
| MTS_0720-0310-0030-0090 | 200 | 12563 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0090/0720-0310-0030-0090.html |    72-31-309. When power of attorney effective, MCA  |  |
| MTS_0720-0310-0030-0100 | 200 | 13651 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0100/0720-0310-0030-0100.html |    72-31-310. Termination of power of attorney or agent's authority, MCA  |  |
| MTS_0720-0310-0030-0110 | 200 | 10236 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0110/0720-0310-0030-0110.html |    72-31-311. through 72-31-315 reserved, MCA  |  |
| MTS_0720-0310-0030-0160 | 200 | 12314 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0160/0720-0310-0030-0160.html |    72-31-316. Coagents or successor agents, MCA  |  |
| MTS_0720-0310-0030-0170 | 200 | 10678 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0170/0720-0310-0030-0170.html |    72-31-317. Reimbursement and compensation of agent, MCA  |  |
| MTS_0720-0310-0030-0180 | 200 | 10609 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0180/0720-0310-0030-0180.html |    72-31-318. Agent's acceptance, MCA  |  |
| MTS_0720-0310-0030-0190 | 200 | 15292 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0190/0720-0310-0030-0190.html |    72-31-319. Agent's duties, MCA  |  |
| MTS_0720-0310-0030-0200 | 200 | 11008 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0200/0720-0310-0030-0200.html |    72-31-320. Exoneration of agent, MCA  |  |
| MTS_0720-0310-0030-0210 | 200 | 12184 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0210/0720-0310-0030-0210.html |    72-31-321. Judicial relief, MCA  |  |
| MTS_0720-0310-0030-0220 | 200 | 10867 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0220/0720-0310-0030-0220.html |    72-31-322. Agent's liability, MCA  |  |
| MTS_0720-0310-0030-0230 | 200 | 11378 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0230/0720-0310-0030-0230.html |    72-31-323. Agent's resignation -- notice, MCA  |  |
| MTS_0720-0310-0030-0240 | 200 | 13495 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0240/0720-0310-0030-0240.html |    72-31-324. Acceptance of and reliance upon acknowledged power of attorney, MC |  |
| MTS_0720-0310-0030-0250 | 200 | 14103 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0250/0720-0310-0030-0250.html |    72-31-325. Liability for refusal to accept acknowledged power of attorney, MC |  |
| MTS_0720-0310-0030-0260 | 200 | 10584 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0260/0720-0310-0030-0260.html |    72-31-326. Principles of law and equity, MCA  |  |
| MTS_0720-0310-0030-0270 | 200 | 10707 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0270/0720-0310-0030-0270.html |    72-31-327. Laws applicable to financial institutions and entities, MCA  |  |
| MTS_0720-0310-0030-0280 | 200 | 10564 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0280/0720-0310-0030-0280.html |    72-31-328. Remedies under other law, MCA  |  |
| MTS_0720-0310-0030-0290 | 200 | 10247 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0290/0720-0310-0030-0290.html |    72-31-329. through 72-31-335 reserved, MCA  |  |
| MTS_0720-0310-0030-0360 | 200 | 14216 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0360/0720-0310-0030-0360.html |    72-31-336. Authority that requires specific grant -- grant of general authori |  |
| MTS_0720-0310-0030-0370 | 200 | 12015 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0370/0720-0310-0030-0370.html |    72-31-337. Incorporation of authority, MCA  |  |
| MTS_0720-0310-0030-0380 | 200 | 13749 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0380/0720-0310-0030-0380.html |    72-31-338. Construction of authority generally, MCA  |  |
| MTS_0720-0310-0030-0390 | 200 | 14561 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0390/0720-0310-0030-0390.html |    72-31-339. Real property, MCA  |  |
| MTS_0720-0310-0030-0400 | 200 | 13409 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0400/0720-0310-0030-0400.html |    72-31-340. Tangible personal property, MCA  |  |
| MTS_0720-0310-0030-0410 | 200 | 11705 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0410/0720-0310-0030-0410.html |    72-31-341. Stocks and bonds, MCA  |  |
| MTS_0720-0310-0030-0420 | 200 | 11111 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0420/0720-0310-0030-0420.html |    72-31-342. Commodities and options, MCA  |  |
| MTS_0720-0310-0030-0430 | 200 | 13757 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0430/0720-0310-0030-0430.html |    72-31-343. Banks and other financial institutions, MCA  |  |
| MTS_0720-0310-0030-0440 | 200 | 15456 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0440/0720-0310-0030-0440.html |    72-31-344. Operation of entity or business, MCA  |  |
| MTS_0720-0310-0030-0450 | 200 | 13524 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0450/0720-0310-0030-0450.html |    72-31-345. Insurance and annuities, MCA  |  |
| MTS_0720-0310-0030-0460 | 200 | 13087 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0460/0720-0310-0030-0460.html |    72-31-346. Estates, trusts, and other beneficial interests, MCA  |  |
| MTS_0720-0310-0030-0470 | 200 | 13698 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0470/0720-0310-0030-0470.html |    72-31-347. Claims and litigation, MCA  |  |
| MTS_0720-0310-0030-0480 | 200 | 14473 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0480/0720-0310-0030-0480.html |    72-31-348. Personal and family maintenance, MCA  |  |
| MTS_0720-0310-0030-0490 | 200 | 13179 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0490/0720-0310-0030-0490.html |    72-31-349. Benefits from governmental programs or civil or military service,  |  |
| MTS_0720-0310-0030-0500 | 200 | 13276 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0500/0720-0310-0030-0500.html |    72-31-350. Retirement plans, MCA  |  |
| MTS_0720-0310-0030-0510 | 200 | 11919 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0510/0720-0310-0030-0510.html |    72-31-351. Taxes, MCA  |  |
| MTS_0720-0310-0030-0520 | 200 | 12960 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0520/0720-0310-0030-0520.html |    72-31-352. Gifts, MCA  |  |
| MTS_0720-0310-0030-0530 | 200 | 25999 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0530/0720-0310-0030-0530.html |    72-31-353. Statutory form power of attorney, MCA  |  |
| MTS_0720-0310-0030-0540 | 200 | 13890 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0540/0720-0310-0030-0540.html |    72-31-354. Agent's certification, MCA  |  |
| MTS_0720-0310-0030-0550 | 200 | 10218 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0550/0720-0310-0030-0550.html |    72-31-355. through 72-31-364 reserved, MCA  |  |
| MTS_0720-0310-0030-0650 | 200 | 10881 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0650/0720-0310-0030-0650.html |    72-31-365. Uniformity of application and construction, MCA  |  |
| MTS_0720-0310-0030-0660 | 200 | 10993 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0660/0720-0310-0030-0660.html |    72-31-366. Relation to Electronic Signatures in Global and National Commerce  |  |
| MTS_0720-0310-0030-0670 | 200 | 11377 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0030/section_0670/0720-0310-0030-0670.html |    72-31-367. Effect on existing powers of attorney, MCA  |  |
| MTS_0720-0310-0040-0010 | 200 | 10259 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0010/0720-0310-0040-0010.html |    72-31-401. Short title, MCA  |  |
| MTS_0720-0310-0040-0020 | 200 | 16780 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0020/0720-0310-0040-0020.html |    72-31-402. Definitions, MCA  |  |
| MTS_0720-0310-0040-0030 | 200 | 11752 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0030/0720-0310-0040-0030.html |    72-31-403. User direction for disclosure of digital assets, MCA  |  |
| MTS_0720-0310-0040-0040 | 200 | 11325 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0040/0720-0310-0040-0040.html |    72-31-404. Terms-of-service agreement, MCA  |  |
| MTS_0720-0310-0040-0050 | 200 | 12762 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0050/0720-0310-0040-0050.html |    72-31-405. Procedure for disclosing digital assets, MCA  |  |
| MTS_0720-0310-0040-0060 | 200 | 13188 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0060/0720-0310-0040-0060.html |    72-31-406. Disclosure of content of electronic communications of deceased use |  |
| MTS_0720-0310-0040-0070 | 200 | 12633 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0070/0720-0310-0040-0070.html |    72-31-407. Disclosure of other digital assets of deceased user, MCA  |  |
| MTS_0720-0310-0040-0080 | 200 | 11986 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0080/0720-0310-0040-0080.html |    72-31-408. Disclosure of content of electronic communications of principal, M |  |
| MTS_0720-0310-0040-0090 | 200 | 12098 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0090/0720-0310-0040-0090.html |    72-31-409. Disclosure of other digital assets of principal, MCA  |  |
| MTS_0720-0310-0040-0100 | 200 | 11106 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0100/0720-0310-0040-0100.html |    72-31-410. Disclosure of digital assets held in trust when trustee is origina |  |
| MTS_0720-0310-0040-0110 | 200 | 12493 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0110/0720-0310-0040-0110.html |    72-31-411. Disclosure of contents of electronic communications held in trust  |  |
| MTS_0720-0310-0040-0120 | 200 | 12419 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0120/0720-0310-0040-0120.html |    72-31-412. Disclosure of other digital assets held in trust when trustee not  |  |
| MTS_0720-0310-0040-0130 | 200 | 12673 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0130/0720-0310-0040-0130.html |    72-31-413. Disclosure of digital assets to conservator of protected person, M |  |
| MTS_0720-0310-0040-0140 | 200 | 14911 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0140/0720-0310-0040-0140.html |    72-31-414. Fiduciary duty and authority, MCA  |  |
| MTS_0720-0310-0040-0150 | 200 | 13017 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0150/0720-0310-0040-0150.html |    72-31-415. Custodian compliance and immunity, MCA  |  |
| MTS_0720-0310-0040-0160 | 200 | 10795 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0160/0720-0310-0040-0160.html |    72-31-416. Uniformity of application and construction, MCA  |  |
| MTS_0720-0310-0040-0170 | 200 | 10829 | https://leg.mt.gov/bills/mca/title_0720/chapter_0310/part_0040/section_0170/0720-0310-0040-0170.html |    72-31-417. Relation to Electronic Signatures in Global and National Commerce  |  |
| MTS_0720-0330-0010-0010 | 200 | 10131 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0010/section_0010/0720-0330-0010-0010.html |    72-33-101. Repealed, MCA  |  |
| MTS_0720-0330-0010-0020 | 200 | 10335 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0010/section_0020/0720-0330-0010-0020.html |    72-33-102. Repealed, MCA  |  |
| MTS_0720-0330-0010-0030 | 200 | 10335 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0010/section_0030/0720-0330-0010-0030.html |    72-33-103. Repealed, MCA  |  |
| MTS_0720-0330-0010-0040 | 200 | 10335 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0010/section_0040/0720-0330-0010-0040.html |    72-33-104. Repealed, MCA  |  |
| MTS_0720-0330-0010-0050 | 200 | 10335 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0010/section_0050/0720-0330-0010-0050.html |    72-33-105. Repealed, MCA  |  |
| MTS_0720-0330-0010-0060 | 200 | 10335 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0010/section_0060/0720-0330-0010-0060.html |    72-33-106. Repealed, MCA  |  |
| MTS_0720-0330-0010-0070 | 200 | 10335 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0010/section_0070/0720-0330-0010-0070.html |    72-33-107. Repealed, MCA  |  |
| MTS_0720-0330-0010-0080 | 200 | 10196 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0010/section_0080/0720-0330-0010-0080.html |    72-33-108. Repealed, MCA  |  |
| MTS_0720-0330-0020-0010 | 200 | 10272 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0010/0720-0330-0020-0010.html |    72-33-201. Repealed, MCA  |  |
| MTS_0720-0330-0020-0020 | 200 | 10477 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0020/0720-0330-0020-0020.html |    72-33-202. Repealed, MCA  |  |
| MTS_0720-0330-0020-0030 | 200 | 10477 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0030/0720-0330-0020-0030.html |    72-33-203. Repealed, MCA  |  |
| MTS_0720-0330-0020-0040 | 200 | 10477 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0040/0720-0330-0020-0040.html |    72-33-204. Repealed, MCA  |  |
| MTS_0720-0330-0020-0050 | 200 | 10477 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0050/0720-0330-0020-0050.html |    72-33-205. Repealed, MCA  |  |
| MTS_0720-0330-0020-0060 | 200 | 10477 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0060/0720-0330-0020-0060.html |    72-33-206. Repealed, MCA  |  |
| MTS_0720-0330-0020-0070 | 200 | 10477 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0070/0720-0330-0020-0070.html |    72-33-207. Repealed, MCA  |  |
| MTS_0720-0330-0020-0080 | 200 | 10477 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0080/0720-0330-0020-0080.html |    72-33-208. Repealed, MCA  |  |
| MTS_0720-0330-0020-0090 | 200 | 10477 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0090/0720-0330-0020-0090.html |    72-33-209. Repealed, MCA  |  |
| MTS_0720-0330-0020-0100 | 200 | 10477 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0100/0720-0330-0020-0100.html |    72-33-210. Repealed, MCA  |  |
| MTS_0720-0330-0020-0110 | 200 | 10495 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0110/0720-0330-0020-0110.html |    72-33-211. Repealed, MCA  |  |
| MTS_0720-0330-0020-0120 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0120/0720-0330-0020-0120.html |    72-33-212. through 72-33-215 reserved, MCA  |  |
| MTS_0720-0330-0020-0160 | 200 | 10528 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0160/0720-0330-0020-0160.html |    72-33-216. Repealed, MCA  |  |
| MTS_0720-0330-0020-0170 | 200 | 10510 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0170/0720-0330-0020-0170.html |    72-33-217. Repealed, MCA  |  |
| MTS_0720-0330-0020-0180 | 200 | 10477 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0180/0720-0330-0020-0180.html |    72-33-218. Repealed, MCA  |  |
| MTS_0720-0330-0020-0190 | 200 | 10510 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0190/0720-0330-0020-0190.html |    72-33-219. Repealed, MCA  |  |
| MTS_0720-0330-0020-0200 | 200 | 10276 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0020/section_0200/0720-0330-0020-0200.html |    72-33-220. Repealed, MCA  |  |
| MTS_0720-0330-0030-0010 | 200 | 10231 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0030/section_0010/0720-0330-0030-0010.html |    72-33-301. Repealed, MCA  |  |
| MTS_0720-0330-0030-0020 | 200 | 10435 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0030/section_0020/0720-0330-0030-0020.html |    72-33-302. Repealed, MCA  |  |
| MTS_0720-0330-0030-0030 | 200 | 10435 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0030/section_0030/0720-0330-0030-0030.html |    72-33-303. Repealed, MCA  |  |
| MTS_0720-0330-0030-0040 | 200 | 10435 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0030/section_0040/0720-0330-0030-0040.html |    72-33-304. Repealed, MCA  |  |
| MTS_0720-0330-0030-0050 | 200 | 10435 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0030/section_0050/0720-0330-0030-0050.html |    72-33-305. Repealed, MCA  |  |
| MTS_0720-0330-0030-0060 | 200 | 10267 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0030/section_0060/0720-0330-0030-0060.html |    72-33-306. Repealed, MCA  |  |
| MTS_0720-0330-0040-0010 | 200 | 10192 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0010/0720-0330-0040-0010.html |    72-33-401. Repealed, MCA  |  |
| MTS_0720-0330-0040-0020 | 200 | 10396 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0020/0720-0330-0040-0020.html |    72-33-402. Repealed, MCA  |  |
| MTS_0720-0330-0040-0030 | 200 | 10410 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0030/0720-0330-0040-0030.html |    72-33-403. Repealed, MCA  |  |
| MTS_0720-0330-0040-0040 | 200 | 10195 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0040/0720-0330-0040-0040.html |    72-33-404. and 72-33-405 reserved, MCA  |  |
| MTS_0720-0330-0040-0060 | 200 | 10410 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0060/0720-0330-0040-0060.html |    72-33-406. Repealed, MCA  |  |
| MTS_0720-0330-0040-0070 | 200 | 10396 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0070/0720-0330-0040-0070.html |    72-33-407. Repealed, MCA  |  |
| MTS_0720-0330-0040-0080 | 200 | 10396 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0080/0720-0330-0040-0080.html |    72-33-408. Repealed, MCA  |  |
| MTS_0720-0330-0040-0090 | 200 | 10396 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0090/0720-0330-0040-0090.html |    72-33-409. Repealed, MCA  |  |
| MTS_0720-0330-0040-0100 | 200 | 10095 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0100/0720-0330-0040-0100.html |    72-33-410. reserved, MCA  |  |
| MTS_0720-0330-0040-0110 | 200 | 10396 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0110/0720-0330-0040-0110.html |    72-33-411. Repealed, MCA  |  |
| MTS_0720-0330-0040-0120 | 200 | 10396 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0120/0720-0330-0040-0120.html |    72-33-412. Repealed, MCA  |  |
| MTS_0720-0330-0040-0130 | 200 | 10396 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0130/0720-0330-0040-0130.html |    72-33-413. Repealed, MCA  |  |
| MTS_0720-0330-0040-0140 | 200 | 10396 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0140/0720-0330-0040-0140.html |    72-33-414. Repealed, MCA  |  |
| MTS_0720-0330-0040-0150 | 200 | 10396 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0150/0720-0330-0040-0150.html |    72-33-415. Repealed, MCA  |  |
| MTS_0720-0330-0040-0160 | 200 | 10195 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0040/section_0160/0720-0330-0040-0160.html |    72-33-416. Repealed, MCA  |  |
| MTS_0720-0330-0050-0010 | 200 | 10129 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0050/section_0010/0720-0330-0050-0010.html |    72-33-501. Repealed, MCA  |  |
| MTS_0720-0330-0050-0020 | 200 | 10333 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0050/section_0020/0720-0330-0050-0020.html |    72-33-502. Repealed, MCA  |  |
| MTS_0720-0330-0050-0030 | 200 | 10366 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0050/section_0030/0720-0330-0050-0030.html |    72-33-503. Repealed, MCA  |  |
| MTS_0720-0330-0050-0040 | 200 | 10132 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0050/section_0040/0720-0330-0050-0040.html |    72-33-504. Repealed, MCA  |  |
| MTS_0720-0330-0060-0010 | 200 | 10102 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0010/0720-0330-0060-0010.html |    72-33-601. Repealed, MCA  |  |
| MTS_0720-0330-0060-0020 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0020/0720-0330-0060-0020.html |    72-33-602. Repealed, MCA  |  |
| MTS_0720-0330-0060-0030 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0030/0720-0330-0060-0030.html |    72-33-603. Repealed, MCA  |  |
| MTS_0720-0330-0060-0040 | 200 | 10324 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0040/0720-0330-0060-0040.html |    72-33-604. Repealed, MCA  |  |
| MTS_0720-0330-0060-0050 | 200 | 10125 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0050/0720-0330-0060-0050.html |    72-33-605. through 72-33-610 reserved, MCA  |  |
| MTS_0720-0330-0060-0110 | 200 | 10324 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0110/0720-0330-0060-0110.html |    72-33-611. Repealed, MCA  |  |
| MTS_0720-0330-0060-0120 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0120/0720-0330-0060-0120.html |    72-33-612. Repealed, MCA  |  |
| MTS_0720-0330-0060-0130 | 200 | 10320 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0130/0720-0330-0060-0130.html |    72-33-613. Repealed, MCA  |  |
| MTS_0720-0330-0060-0140 | 200 | 10105 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0140/0720-0330-0060-0140.html |    72-33-614. and 72-33-615 reserved, MCA  |  |
| MTS_0720-0330-0060-0160 | 200 | 10320 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0160/0720-0330-0060-0160.html |    72-33-616. Repealed, MCA  |  |
| MTS_0720-0330-0060-0170 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0170/0720-0330-0060-0170.html |    72-33-617. Repealed, MCA  |  |
| MTS_0720-0330-0060-0180 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0180/0720-0330-0060-0180.html |    72-33-618. Repealed, MCA  |  |
| MTS_0720-0330-0060-0190 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0190/0720-0330-0060-0190.html |    72-33-619. Repealed, MCA  |  |
| MTS_0720-0330-0060-0200 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0200/0720-0330-0060-0200.html |    72-33-620. Repealed, MCA  |  |
| MTS_0720-0330-0060-0210 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0210/0720-0330-0060-0210.html |    72-33-621. Repealed, MCA  |  |
| MTS_0720-0330-0060-0220 | 200 | 10324 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0220/0720-0330-0060-0220.html |    72-33-622. Repealed, MCA  |  |
| MTS_0720-0330-0060-0230 | 200 | 10125 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0230/0720-0330-0060-0230.html |    72-33-623. through 72-33-625 reserved, MCA  |  |
| MTS_0720-0330-0060-0260 | 200 | 10324 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0260/0720-0330-0060-0260.html |    72-33-626. Repealed, MCA  |  |
| MTS_0720-0330-0060-0270 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0270/0720-0330-0060-0270.html |    72-33-627. Repealed, MCA  |  |
| MTS_0720-0330-0060-0280 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0280/0720-0330-0060-0280.html |    72-33-628. Repealed, MCA  |  |
| MTS_0720-0330-0060-0290 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0290/0720-0330-0060-0290.html |    72-33-629. Repealed, MCA  |  |
| MTS_0720-0330-0060-0300 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0300/0720-0330-0060-0300.html |    72-33-630. Repealed, MCA  |  |
| MTS_0720-0330-0060-0310 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0310/0720-0330-0060-0310.html |    72-33-631. Repealed, MCA  |  |
| MTS_0720-0330-0060-0320 | 200 | 10105 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0060/section_0320/0720-0330-0060-0320.html |    72-33-632. Repealed, MCA  |  |
| MTS_0720-0330-0070-0010 | 200 | 10149 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0070/section_0010/0720-0330-0070-0010.html |    72-33-701. Repealed, MCA  |  |
| MTS_0720-0330-0070-0020 | 200 | 10321 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0070/section_0020/0720-0330-0070-0020.html |    72-33-702. Repealed, MCA  |  |
| MTS_0720-0330-0070-0030 | 200 | 10321 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0070/section_0030/0720-0330-0070-0030.html |    72-33-703. Repealed, MCA  |  |
| MTS_0720-0330-0070-0040 | 200 | 10321 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0070/section_0040/0720-0330-0070-0040.html |    72-33-704. Repealed, MCA  |  |
| MTS_0720-0330-0070-0050 | 200 | 10120 | https://leg.mt.gov/bills/mca/title_0720/chapter_0330/part_0070/section_0050/0720-0330-0070-0050.html |    72-33-705. Repealed, MCA  |  |
| MTS_0720-0340-0010-0010 | 200 | 10137 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0010/0720-0340-0010-0010.html |    72-34-101. Repealed, MCA  |  |
| MTS_0720-0340-0010-0020 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0020/0720-0340-0010-0020.html |    72-34-102. Repealed, MCA  |  |
| MTS_0720-0340-0010-0030 | 200 | 10353 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0030/0720-0340-0010-0030.html |    72-34-103. Repealed, MCA  |  |
| MTS_0720-0340-0010-0040 | 200 | 10164 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0040/0720-0340-0010-0040.html |    72-34-104. Renumbered 72-34-604, MCA  |  |
| MTS_0720-0340-0010-0050 | 200 | 10353 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0050/0720-0340-0010-0050.html |    72-34-105. Repealed, MCA  |  |
| MTS_0720-0340-0010-0060 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0060/0720-0340-0010-0060.html |    72-34-106. Repealed, MCA  |  |
| MTS_0720-0340-0010-0070 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0070/0720-0340-0010-0070.html |    72-34-107. Repealed, MCA  |  |
| MTS_0720-0340-0010-0080 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0080/0720-0340-0010-0080.html |    72-34-108. Repealed, MCA  |  |
| MTS_0720-0340-0010-0090 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0090/0720-0340-0010-0090.html |    72-34-109. Repealed, MCA  |  |
| MTS_0720-0340-0010-0100 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0100/0720-0340-0010-0100.html |    72-34-110. Repealed, MCA  |  |
| MTS_0720-0340-0010-0110 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0110/0720-0340-0010-0110.html |    72-34-111. Repealed, MCA  |  |
| MTS_0720-0340-0010-0120 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0120/0720-0340-0010-0120.html |    72-34-112. Repealed, MCA  |  |
| MTS_0720-0340-0010-0130 | 200 | 10404 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0130/0720-0340-0010-0130.html |    72-34-113. Repealed, MCA  |  |
| MTS_0720-0340-0010-0140 | 200 | 10404 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0140/0720-0340-0010-0140.html |    72-34-114. Repealed, MCA  |  |
| MTS_0720-0340-0010-0150 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0150/0720-0340-0010-0150.html |    72-34-115. Repealed, MCA  |  |
| MTS_0720-0340-0010-0160 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0160/0720-0340-0010-0160.html |    72-34-116. Repealed, MCA  |  |
| MTS_0720-0340-0010-0170 | 200 | 10372 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0170/0720-0340-0010-0170.html |    72-34-117. Repealed, MCA  |  |
| MTS_0720-0340-0010-0180 | 200 | 10355 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0180/0720-0340-0010-0180.html |    72-34-118. Repealed, MCA  |  |
| MTS_0720-0340-0010-0190 | 200 | 10140 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0190/0720-0340-0010-0190.html |    72-34-119. and 72-34-120 reserved, MCA  |  |
| MTS_0720-0340-0010-0210 | 200 | 10368 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0210/0720-0340-0010-0210.html |    72-34-121. Repealed, MCA  |  |
| MTS_0720-0340-0010-0220 | 200 | 10140 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0220/0720-0340-0010-0220.html |    72-34-122. and 72-34-123 reserved, MCA  |  |
| MTS_0720-0340-0010-0240 | 200 | 10355 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0240/0720-0340-0010-0240.html |    72-34-124. Repealed, MCA  |  |
| MTS_0720-0340-0010-0250 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0250/0720-0340-0010-0250.html |    72-34-125. Repealed, MCA  |  |
| MTS_0720-0340-0010-0260 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0260/0720-0340-0010-0260.html |    72-34-126. Repealed, MCA  |  |
| MTS_0720-0340-0010-0270 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0270/0720-0340-0010-0270.html |    72-34-127. Repealed, MCA  |  |
| MTS_0720-0340-0010-0280 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0280/0720-0340-0010-0280.html |    72-34-128. Repealed, MCA  |  |
| MTS_0720-0340-0010-0290 | 200 | 10341 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0290/0720-0340-0010-0290.html |    72-34-129. Repealed, MCA  |  |
| MTS_0720-0340-0010-0300 | 200 | 10173 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0010/section_0300/0720-0340-0010-0300.html |    72-34-130. Repealed, MCA  |  |
| MTS_0720-0340-0020-0010 | 200 | 10299 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0020/section_0010/0720-0340-0020-0010.html |    72-34-201. Repealed, MCA  |  |
| MTS_0720-0340-0020-0020 | 200 | 10504 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0020/section_0020/0720-0340-0020-0020.html |    72-34-202. Repealed, MCA  |  |
| MTS_0720-0340-0020-0030 | 200 | 10504 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0020/section_0030/0720-0340-0020-0030.html |    72-34-203. Repealed, MCA  |  |
| MTS_0720-0340-0020-0040 | 200 | 10504 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0020/section_0040/0720-0340-0020-0040.html |    72-34-204. Repealed, MCA  |  |
| MTS_0720-0340-0020-0050 | 200 | 10535 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0020/section_0050/0720-0340-0020-0050.html |    72-34-205. Repealed, MCA  |  |
| MTS_0720-0340-0020-0060 | 200 | 10504 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0020/section_0060/0720-0340-0020-0060.html |    72-34-206. Repealed, MCA  |  |
| MTS_0720-0340-0020-0070 | 200 | 10302 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0020/section_0070/0720-0340-0020-0070.html |    72-34-207. Repealed, MCA  |  |
| MTS_0720-0340-0030-0010 | 200 | 10093 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0010/0720-0340-0030-0010.html |    72-34-301. Repealed, MCA  |  |
| MTS_0720-0340-0030-0020 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0020/0720-0340-0030-0020.html |    72-34-302. Repealed, MCA  |  |
| MTS_0720-0340-0030-0030 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0030/0720-0340-0030-0030.html |    72-34-303. Repealed, MCA  |  |
| MTS_0720-0340-0030-0040 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0040/0720-0340-0030-0040.html |    72-34-304. Repealed, MCA  |  |
| MTS_0720-0340-0030-0050 | 200 | 9995 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0050/0720-0340-0030-0050.html |    72-34-305. reserved, MCA  |  |
| MTS_0720-0340-0030-0060 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0060/0720-0340-0030-0060.html |    72-34-306. Repealed, MCA  |  |
| MTS_0720-0340-0030-0070 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0070/0720-0340-0030-0070.html |    72-34-307. Repealed, MCA  |  |
| MTS_0720-0340-0030-0080 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0080/0720-0340-0030-0080.html |    72-34-308. Repealed, MCA  |  |
| MTS_0720-0340-0030-0090 | 200 | 10328 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0090/0720-0340-0030-0090.html |    72-34-309. Repealed, MCA  |  |
| MTS_0720-0340-0030-0100 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0100/0720-0340-0030-0100.html |    72-34-310. Repealed, MCA  |  |
| MTS_0720-0340-0030-0110 | 200 | 10315 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0110/0720-0340-0030-0110.html |    72-34-311. Repealed, MCA  |  |
| MTS_0720-0340-0030-0120 | 200 | 10115 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0120/0720-0340-0030-0120.html |    72-34-312. through 72-34-315 reserved, MCA  |  |
| MTS_0720-0340-0030-0160 | 200 | 10315 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0160/0720-0340-0030-0160.html |    72-34-316. Repealed, MCA  |  |
| MTS_0720-0340-0030-0170 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0170/0720-0340-0030-0170.html |    72-34-317. Repealed, MCA  |  |
| MTS_0720-0340-0030-0180 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0180/0720-0340-0030-0180.html |    72-34-318. Repealed, MCA  |  |
| MTS_0720-0340-0030-0190 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0190/0720-0340-0030-0190.html |    72-34-319. Repealed, MCA  |  |
| MTS_0720-0340-0030-0200 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0200/0720-0340-0030-0200.html |    72-34-320. Repealed, MCA  |  |
| MTS_0720-0340-0030-0210 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0210/0720-0340-0030-0210.html |    72-34-321. Repealed, MCA  |  |
| MTS_0720-0340-0030-0220 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0220/0720-0340-0030-0220.html |    72-34-322. Repealed, MCA  |  |
| MTS_0720-0340-0030-0230 | 200 | 10311 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0230/0720-0340-0030-0230.html |    72-34-323. Repealed, MCA  |  |
| MTS_0720-0340-0030-0240 | 200 | 10095 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0240/0720-0340-0030-0240.html |    72-34-324. and 72-34-325 reserved, MCA  |  |
| MTS_0720-0340-0030-0260 | 200 | 10311 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0260/0720-0340-0030-0260.html |    72-34-326. Repealed, MCA  |  |
| MTS_0720-0340-0030-0270 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0270/0720-0340-0030-0270.html |    72-34-327. Repealed, MCA  |  |
| MTS_0720-0340-0030-0280 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0280/0720-0340-0030-0280.html |    72-34-328. Repealed, MCA  |  |
| MTS_0720-0340-0030-0290 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0290/0720-0340-0030-0290.html |    72-34-329. Repealed, MCA  |  |
| MTS_0720-0340-0030-0300 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0300/0720-0340-0030-0300.html |    72-34-330. Repealed, MCA  |  |
| MTS_0720-0340-0030-0310 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0310/0720-0340-0030-0310.html |    72-34-331. Repealed, MCA  |  |
| MTS_0720-0340-0030-0320 | 200 | 10315 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0320/0720-0340-0030-0320.html |    72-34-332. Repealed, MCA  |  |
| MTS_0720-0340-0030-0330 | 200 | 10115 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0330/0720-0340-0030-0330.html |    72-34-333. through 72-34-335 reserved, MCA  |  |
| MTS_0720-0340-0030-0360 | 200 | 10315 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0360/0720-0340-0030-0360.html |    72-34-336. Repealed, MCA  |  |
| MTS_0720-0340-0030-0370 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0370/0720-0340-0030-0370.html |    72-34-337. Repealed, MCA  |  |
| MTS_0720-0340-0030-0380 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0380/0720-0340-0030-0380.html |    72-34-338. Repealed, MCA  |  |
| MTS_0720-0340-0030-0390 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0390/0720-0340-0030-0390.html |    72-34-339. Repealed, MCA  |  |
| MTS_0720-0340-0030-0400 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0400/0720-0340-0030-0400.html |    72-34-340. Repealed, MCA  |  |
| MTS_0720-0340-0030-0410 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0410/0720-0340-0030-0410.html |    72-34-341. Repealed, MCA  |  |
| MTS_0720-0340-0030-0420 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0420/0720-0340-0030-0420.html |    72-34-342. Repealed, MCA  |  |
| MTS_0720-0340-0030-0430 | 200 | 10096 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0030/section_0430/0720-0340-0030-0430.html |    72-34-343. Repealed, MCA  |  |
| MTS_0720-0340-0040-0010 | 200 | 10125 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0010/0720-0340-0040-0010.html |    72-34-401. Repealed, MCA  |  |
| MTS_0720-0340-0040-0020 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0020/0720-0340-0040-0020.html |    72-34-402. Repealed, MCA  |  |
| MTS_0720-0340-0040-0030 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0030/0720-0340-0040-0030.html |    72-34-403. Repealed, MCA  |  |
| MTS_0720-0340-0040-0040 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0040/0720-0340-0040-0040.html |    72-34-404. Repealed, MCA  |  |
| MTS_0720-0340-0040-0050 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0050/0720-0340-0040-0050.html |    72-34-405. Repealed, MCA  |  |
| MTS_0720-0340-0040-0060 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0060/0720-0340-0040-0060.html |    72-34-406. Repealed, MCA  |  |
| MTS_0720-0340-0040-0070 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0070/0720-0340-0040-0070.html |    72-34-407. Repealed, MCA  |  |
| MTS_0720-0340-0040-0080 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0080/0720-0340-0040-0080.html |    72-34-408. Repealed, MCA  |  |
| MTS_0720-0340-0040-0090 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0090/0720-0340-0040-0090.html |    72-34-409. Repealed, MCA  |  |
| MTS_0720-0340-0040-0100 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0100/0720-0340-0040-0100.html |    72-34-410. Repealed, MCA  |  |
| MTS_0720-0340-0040-0110 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0110/0720-0340-0040-0110.html |    72-34-411. Repealed, MCA  |  |
| MTS_0720-0340-0040-0120 | 200 | 10347 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0120/0720-0340-0040-0120.html |    72-34-412. Repealed, MCA  |  |
| MTS_0720-0340-0040-0130 | 200 | 10148 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0130/0720-0340-0040-0130.html |    72-34-413. through 72-34-415 reserved, MCA  |  |
| MTS_0720-0340-0040-0160 | 200 | 10365 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0160/0720-0340-0040-0160.html |    72-34-416. Repealed, MCA  |  |
| MTS_0720-0340-0040-0170 | 200 | 10151 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0170/0720-0340-0040-0170.html |    72-34-417. through 72-34-420 reserved, MCA  |  |
| MTS_0720-0340-0040-0210 | 200 | 10369 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0210/0720-0340-0040-0210.html |    72-34-421. Short title, MCA  |  |
| MTS_0720-0340-0040-0220 | 200 | 12376 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0220/0720-0340-0040-0220.html |    72-34-422. Definitions, MCA  |  |
| MTS_0720-0340-0040-0230 | 200 | 12798 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0230/0720-0340-0040-0230.html |    72-34-423. Allocation between principal and income -- impartial exercise of d |  |
| MTS_0720-0340-0040-0240 | 200 | 18147 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0240/0720-0340-0040-0240.html |    72-34-424. Adjustments between principal and income, MCA  |  |
| MTS_0720-0340-0040-0250 | 200 | 14388 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0250/0720-0340-0040-0250.html |    72-34-425. Notice of proposed action -- objections by beneficiary -- liabilit |  |
| MTS_0720-0340-0040-0260 | 200 | 10835 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0260/0720-0340-0040-0260.html |    72-34-426. Proceedings relating to adjustments -- remedy, MCA  |  |
| MTS_0720-0340-0040-0270 | 200 | 10585 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0270/0720-0340-0040-0270.html |    72-34-427. Application of part, MCA  |  |
| MTS_0720-0340-0040-0280 | 200 | 14479 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0280/0720-0340-0040-0280.html |    72-34-428. Rules applicable after decedent's death or termination of income i |  |
| MTS_0720-0340-0040-0290 | 200 | 11809 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0290/0720-0340-0040-0290.html |    72-34-429. Beneficiary's portion of net income -- maintenance of records -- d |  |
| MTS_0720-0340-0040-0300 | 200 | 12778 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0300/0720-0340-0040-0300.html |    72-34-430. Beneficiary's entitlement to net income -- assets subject to trust |  |
| MTS_0720-0340-0040-0310 | 200 | 12425 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0310/0720-0340-0040-0310.html |    72-34-431. Allocation of income receipt or disbursement, MCA  |  |
| MTS_0720-0340-0040-0320 | 200 | 11983 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0320/0720-0340-0040-0320.html |    72-34-432. Undistributed income -- definition -- payment to beneficiary, MCA  |  |
| MTS_0720-0340-0040-0330 | 200 | 13900 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0330/0720-0340-0040-0330.html |    72-34-433. Allocation of receipts to income or principal -- entity defined, M |  |
| MTS_0720-0340-0040-0340 | 200 | 10983 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0340/0720-0340-0040-0340.html |    72-34-434. Allocation of amounts received from specified trusts or estates, M |  |
| MTS_0720-0340-0040-0350 | 200 | 12888 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0350/0720-0340-0040-0350.html |    72-34-435. Separate accounting records for business or other activity, MCA  |  |
| MTS_0720-0340-0040-0360 | 200 | 12454 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0360/0720-0340-0040-0360.html |    72-34-436. Amounts allocated to principal, MCA  |  |
| MTS_0720-0340-0040-0370 | 200 | 11210 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0370/0720-0340-0040-0370.html |    72-34-437. Amounts received from rental property allocation, MCA  |  |
| MTS_0720-0340-0040-0380 | 200 | 12224 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0380/0720-0340-0040-0380.html |    72-34-438. Interest on obligation to pay money -- allocation, MCA  |  |
| MTS_0720-0340-0040-0390 | 200 | 11973 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0390/0720-0340-0040-0390.html |    72-34-439. Life insurance policy proceeds -- proceeds of contracts insuring a |  |
| MTS_0720-0340-0040-0400 | 200 | 12955 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0400/0720-0340-0040-0400.html |    72-34-440. Insubstantial allocation -- allocation of entire amount to princip |  |
| MTS_0720-0340-0040-0410 | 200 | 16187 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0410/0720-0340-0040-0410.html |    72-34-441. Payments characterized as interest or dividend -- allocation to in |  |
| MTS_0720-0340-0040-0420 | 200 | 12058 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0420/0720-0340-0040-0420.html |    72-34-442. Receipts from liquidating assets -- allocation, MCA  |  |
| MTS_0720-0340-0040-0430 | 200 | 12480 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0430/0720-0340-0040-0430.html |    72-34-443. Receipts from mineral interests and other natural resources -- all |  |
| MTS_0720-0340-0040-0440 | 200 | 12374 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0440/0720-0340-0040-0440.html |    72-34-444. Receipts from sale of timber and related products -- allocation, M |  |
| MTS_0720-0340-0040-0450 | 200 | 11871 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0450/0720-0340-0040-0450.html |    72-34-445. Increasing income in order to maintain marital deduction, MCA  |  |
| MTS_0720-0340-0040-0460 | 200 | 12709 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0460/0720-0340-0040-0460.html |    72-34-446. Transactions in derivatives -- allocations of receipts and disburs |  |
| MTS_0720-0340-0040-0470 | 200 | 12550 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0470/0720-0340-0040-0470.html |    72-34-447. Payments from collateral financial assets and payments in exchange |  |
| MTS_0720-0340-0040-0480 | 200 | 11830 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0480/0720-0340-0040-0480.html |    72-34-448. Disbursements from income, MCA  |  |
| MTS_0720-0340-0040-0490 | 200 | 12897 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0490/0720-0340-0040-0490.html |    72-34-449. Disbursements from principal, MCA  |  |
| MTS_0720-0340-0040-0500 | 200 | 12192 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0500/0720-0340-0040-0500.html |    72-34-450. Assets subject to depreciation -- transfer from income to principa |  |
| MTS_0720-0340-0040-0510 | 200 | 12643 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0510/0720-0340-0040-0510.html |    72-34-451. Transfer from income to principal in anticipation of principal dis |  |
| MTS_0720-0340-0040-0520 | 200 | 11963 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0520/0720-0340-0040-0520.html |    72-34-452. Payment of taxes, MCA  |  |
| MTS_0720-0340-0040-0530 | 200 | 12344 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0040/section_0530/0720-0340-0040-0530.html |    72-34-453. Adjustments between principal and income in certain cases, MCA  |  |
| MTS_0720-0340-0050-0010 | 200 | 10153 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0010/0720-0340-0050-0010.html |    72-34-501. Repealed, MCA  |  |
| MTS_0720-0340-0050-0020 | 200 | 10357 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0020/0720-0340-0050-0020.html |    72-34-502. Repealed, MCA  |  |
| MTS_0720-0340-0050-0030 | 200 | 10357 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0030/0720-0340-0050-0030.html |    72-34-503. Repealed, MCA  |  |
| MTS_0720-0340-0050-0040 | 200 | 10357 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0040/0720-0340-0050-0040.html |    72-34-504. Repealed, MCA  |  |
| MTS_0720-0340-0050-0050 | 200 | 10055 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0050/0720-0340-0050-0050.html |    72-34-505. reserved, MCA  |  |
| MTS_0720-0340-0050-0060 | 200 | 10357 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0060/0720-0340-0050-0060.html |    72-34-506. Repealed, MCA  |  |
| MTS_0720-0340-0050-0070 | 200 | 10357 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0070/0720-0340-0050-0070.html |    72-34-507. Repealed, MCA  |  |
| MTS_0720-0340-0050-0080 | 200 | 10357 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0080/0720-0340-0050-0080.html |    72-34-508. Repealed, MCA  |  |
| MTS_0720-0340-0050-0090 | 200 | 10357 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0090/0720-0340-0050-0090.html |    72-34-509. Repealed, MCA  |  |
| MTS_0720-0340-0050-0100 | 200 | 10055 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0100/0720-0340-0050-0100.html |    72-34-510. reserved, MCA  |  |
| MTS_0720-0340-0050-0110 | 200 | 10357 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0110/0720-0340-0050-0110.html |    72-34-511. Repealed, MCA  |  |
| MTS_0720-0340-0050-0120 | 200 | 10357 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0120/0720-0340-0050-0120.html |    72-34-512. Repealed, MCA  |  |
| MTS_0720-0340-0050-0130 | 200 | 10389 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0130/0720-0340-0050-0130.html |    72-34-513. Repealed, MCA  |  |
| MTS_0720-0340-0050-0140 | 200 | 10390 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0140/0720-0340-0050-0140.html |    72-34-514. Repealed, MCA  |  |
| MTS_0720-0340-0050-0150 | 200 | 10390 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0150/0720-0340-0050-0150.html |    72-34-515. Repealed, MCA  |  |
| MTS_0720-0340-0050-0160 | 200 | 10390 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0160/0720-0340-0050-0160.html |    72-34-516. Repealed, MCA  |  |
| MTS_0720-0340-0050-0170 | 200 | 10155 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0050/section_0170/0720-0340-0050-0170.html |    72-34-517. Repealed, MCA  |  |
| MTS_0720-0340-0060-0010 | 200 | 10145 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0060/section_0010/0720-0340-0060-0010.html |    72-34-601. Repealed, MCA  |  |
| MTS_0720-0340-0060-0020 | 200 | 10349 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0060/section_0020/0720-0340-0060-0020.html |    72-34-602. Repealed, MCA  |  |
| MTS_0720-0340-0060-0030 | 200 | 10349 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0060/section_0030/0720-0340-0060-0030.html |    72-34-603. Repealed, MCA  |  |
| MTS_0720-0340-0060-0040 | 200 | 10483 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0060/section_0040/0720-0340-0060-0040.html |    72-34-604. Repealed, MCA  |  |
| MTS_0720-0340-0060-0050 | 200 | 10349 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0060/section_0050/0720-0340-0060-0050.html |    72-34-605. Repealed, MCA  |  |
| MTS_0720-0340-0060-0060 | 200 | 10349 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0060/section_0060/0720-0340-0060-0060.html |    72-34-606. Repealed, MCA  |  |
| MTS_0720-0340-0060-0070 | 200 | 10349 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0060/section_0070/0720-0340-0060-0070.html |    72-34-607. Repealed, MCA  |  |
| MTS_0720-0340-0060-0080 | 200 | 10349 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0060/section_0080/0720-0340-0060-0080.html |    72-34-608. Repealed, MCA  |  |
| MTS_0720-0340-0060-0090 | 200 | 10349 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0060/section_0090/0720-0340-0060-0090.html |    72-34-609. Repealed, MCA  |  |
| MTS_0720-0340-0060-0100 | 200 | 10148 | https://leg.mt.gov/bills/mca/title_0720/chapter_0340/part_0060/section_0100/0720-0340-0060-0100.html |    72-34-610. Repealed, MCA  |  |
| MTS_0720-0350-0010-0010 | 200 | 10191 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0010/section_0010/0720-0350-0010-0010.html |    72-35-101. Repealed, MCA  |  |
| MTS_0720-0350-0010-0020 | 200 | 10395 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0010/section_0020/0720-0350-0010-0020.html |    72-35-102. Repealed, MCA  |  |
| MTS_0720-0350-0010-0030 | 200 | 10395 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0010/section_0030/0720-0350-0010-0030.html |    72-35-103. Repealed, MCA  |  |
| MTS_0720-0350-0010-0040 | 200 | 10395 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0010/section_0040/0720-0350-0010-0040.html |    72-35-104. Repealed, MCA  |  |
| MTS_0720-0350-0010-0050 | 200 | 10395 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0010/section_0050/0720-0350-0010-0050.html |    72-35-105. Repealed, MCA  |  |
| MTS_0720-0350-0010-0060 | 200 | 10395 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0010/section_0060/0720-0350-0010-0060.html |    72-35-106. Repealed, MCA  |  |
| MTS_0720-0350-0010-0070 | 200 | 10194 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0010/section_0070/0720-0350-0010-0070.html |    72-35-107. Repealed, MCA  |  |
| MTS_0720-0350-0020-0010 | 200 | 10143 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0020/section_0010/0720-0350-0020-0010.html |    72-35-201. Repealed, MCA  |  |
| MTS_0720-0350-0020-0020 | 200 | 10347 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0020/section_0020/0720-0350-0020-0020.html |    72-35-202. Repealed, MCA  |  |
| MTS_0720-0350-0020-0030 | 200 | 10361 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0020/section_0030/0720-0350-0020-0030.html |    72-35-203. Repealed, MCA  |  |
| MTS_0720-0350-0020-0040 | 200 | 10145 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0020/section_0040/0720-0350-0020-0040.html |    72-35-204. and 72-35-205 reserved, MCA  |  |
| MTS_0720-0350-0020-0060 | 200 | 10361 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0020/section_0060/0720-0350-0020-0060.html |    72-35-206. Repealed, MCA  |  |
| MTS_0720-0350-0020-0070 | 200 | 10347 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0020/section_0070/0720-0350-0020-0070.html |    72-35-207. Repealed, MCA  |  |
| MTS_0720-0350-0020-0080 | 200 | 10347 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0020/section_0080/0720-0350-0020-0080.html |    72-35-208. Repealed, MCA  |  |
| MTS_0720-0350-0020-0090 | 200 | 10146 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0020/section_0090/0720-0350-0020-0090.html |    72-35-209. Repealed, MCA  |  |
| MTS_0720-0350-0030-0010 | 200 | 10212 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0010/0720-0350-0030-0010.html |    72-35-301. Repealed, MCA  |  |
| MTS_0720-0350-0030-0020 | 200 | 10416 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0020/0720-0350-0030-0020.html |    72-35-302. Repealed, MCA  |  |
| MTS_0720-0350-0030-0030 | 200 | 10430 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0030/0720-0350-0030-0030.html |    72-35-303. Repealed, MCA  |  |
| MTS_0720-0350-0030-0040 | 200 | 10214 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0040/0720-0350-0030-0040.html |    72-35-304. and 72-35-305 reserved, MCA  |  |
| MTS_0720-0350-0030-0060 | 200 | 10462 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0060/0720-0350-0030-0060.html |    72-35-306. Repealed, MCA  |  |
| MTS_0720-0350-0030-0070 | 200 | 10416 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0070/0720-0350-0030-0070.html |    72-35-307. Repealed, MCA  |  |
| MTS_0720-0350-0030-0080 | 200 | 10430 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0080/0720-0350-0030-0080.html |    72-35-308. Repealed, MCA  |  |
| MTS_0720-0350-0030-0090 | 200 | 10214 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0090/0720-0350-0030-0090.html |    72-35-309. and 72-35-310 reserved, MCA  |  |
| MTS_0720-0350-0030-0110 | 200 | 10430 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0110/0720-0350-0030-0110.html |    72-35-311. Repealed, MCA  |  |
| MTS_0720-0350-0030-0120 | 200 | 10416 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0120/0720-0350-0030-0120.html |    72-35-312. Repealed, MCA  |  |
| MTS_0720-0350-0030-0130 | 200 | 10449 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0130/0720-0350-0030-0130.html |    72-35-313. Repealed, MCA  |  |
| MTS_0720-0350-0030-0140 | 200 | 10416 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0140/0720-0350-0030-0140.html |    72-35-314. Repealed, MCA  |  |
| MTS_0720-0350-0030-0150 | 200 | 10215 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0030/section_0150/0720-0350-0030-0150.html |    72-35-315. Repealed, MCA  |  |
| MTS_0720-0350-0040-0010 | 200 | 10248 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0040/section_0010/0720-0350-0040-0010.html |    72-35-401. Repealed, MCA  |  |
| MTS_0720-0350-0040-0020 | 200 | 10452 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0040/section_0020/0720-0350-0040-0020.html |    72-35-402. Repealed, MCA  |  |
| MTS_0720-0350-0040-0030 | 200 | 10452 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0040/section_0030/0720-0350-0040-0030.html |    72-35-403. Repealed, MCA  |  |
| MTS_0720-0350-0040-0040 | 200 | 10452 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0040/section_0040/0720-0350-0040-0040.html |    72-35-404. Repealed, MCA  |  |
| MTS_0720-0350-0040-0050 | 200 | 10452 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0040/section_0050/0720-0350-0040-0050.html |    72-35-405. Repealed, MCA  |  |
| MTS_0720-0350-0040-0060 | 200 | 10251 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0040/section_0060/0720-0350-0040-0060.html |    72-35-406. Repealed, MCA  |  |
| MTS_0720-0350-0050-0010 | 200 | 10254 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0050/section_0010/0720-0350-0050-0010.html |    72-35-501. Repealed, MCA  |  |
| MTS_0720-0350-0050-0020 | 200 | 10458 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0050/section_0020/0720-0350-0050-0020.html |    72-35-502. Repealed, MCA  |  |
| MTS_0720-0350-0050-0030 | 200 | 10458 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0050/section_0030/0720-0350-0050-0030.html |    72-35-503. Repealed, MCA  |  |
| MTS_0720-0350-0050-0040 | 200 | 10458 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0050/section_0040/0720-0350-0050-0040.html |    72-35-504. Repealed, MCA  |  |
| MTS_0720-0350-0050-0050 | 200 | 10458 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0050/section_0050/0720-0350-0050-0050.html |    72-35-505. Repealed, MCA  |  |
| MTS_0720-0350-0050-0060 | 200 | 10458 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0050/section_0060/0720-0350-0050-0060.html |    72-35-506. Repealed, MCA  |  |
| MTS_0720-0350-0050-0070 | 200 | 10458 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0050/section_0070/0720-0350-0050-0070.html |    72-35-507. Repealed, MCA  |  |
| MTS_0720-0350-0050-0080 | 200 | 10257 | https://leg.mt.gov/bills/mca/title_0720/chapter_0350/part_0050/section_0080/0720-0350-0050-0080.html |    72-35-508. Repealed, MCA  |  |
| MTS_0720-0360-0010-0010 | 200 | 10236 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0010/section_0010/0720-0360-0010-0010.html |    72-36-101. Repealed, MCA  |  |
| MTS_0720-0360-0010-0020 | 200 | 10440 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0010/section_0020/0720-0360-0010-0020.html |    72-36-102. Repealed, MCA  |  |
| MTS_0720-0360-0010-0030 | 200 | 10440 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0010/section_0030/0720-0360-0010-0030.html |    72-36-103. Repealed, MCA  |  |
| MTS_0720-0360-0010-0040 | 200 | 10440 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0010/section_0040/0720-0360-0010-0040.html |    72-36-104. Repealed, MCA  |  |
| MTS_0720-0360-0010-0050 | 200 | 10440 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0010/section_0050/0720-0360-0010-0050.html |    72-36-105. Repealed, MCA  |  |
| MTS_0720-0360-0010-0060 | 200 | 10239 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0010/section_0060/0720-0360-0010-0060.html |    72-36-106. Repealed, MCA  |  |
| MTS_0720-0360-0020-0010 | 200 | 10251 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0020/section_0010/0720-0360-0020-0010.html |    72-36-201. Repealed, MCA  |  |
| MTS_0720-0360-0020-0020 | 200 | 10455 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0020/section_0020/0720-0360-0020-0020.html |    72-36-202. Repealed, MCA  |  |
| MTS_0720-0360-0020-0030 | 200 | 10469 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0020/section_0030/0720-0360-0020-0030.html |    72-36-203. Repealed, MCA  |  |
| MTS_0720-0360-0020-0040 | 200 | 10266 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0020/section_0040/0720-0360-0020-0040.html |    72-36-204. and 72-36-205 reserved, MCA  |  |
| MTS_0720-0360-0020-0060 | 200 | 10093 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0020/section_0060/0720-0360-0020-0060.html |    72-36-206. Renumbered 72-38-1111, MCA  |  |
| MTS_0720-0360-0030-0010 | 200 | 10215 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0030/section_0010/0720-0360-0030-0010.html |    72-36-301. Repealed, MCA  |  |
| MTS_0720-0360-0030-0020 | 200 | 10218 | https://leg.mt.gov/bills/mca/title_0720/chapter_0360/part_0030/section_0020/0720-0360-0030-0020.html |    72-36-302. Repealed, MCA  |  |
| MTS_0720-0370-0010-0010 | 200 | 10292 | https://leg.mt.gov/bills/mca/title_0720/chapter_0370/part_0010/section_0010/0720-0370-0010-0010.html |    72-37-101. Repealed, MCA  |  |
| MTS_0720-0370-0010-0020 | 200 | 10496 | https://leg.mt.gov/bills/mca/title_0720/chapter_0370/part_0010/section_0020/0720-0370-0010-0020.html |    72-37-102. Repealed, MCA  |  |
| MTS_0720-0370-0010-0030 | 200 | 10560 | https://leg.mt.gov/bills/mca/title_0720/chapter_0370/part_0010/section_0030/0720-0370-0010-0030.html |    72-37-103. Repealed, MCA  |  |
| MTS_0720-0370-0010-0040 | 200 | 10264 | https://leg.mt.gov/bills/mca/title_0720/chapter_0370/part_0010/section_0040/0720-0370-0010-0040.html |    72-37-104. Repealed, MCA  |  |
| MTS_0720-0380-0010-0010 | 200 | 10344 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0010/0720-0380-0010-0010.html |    72-38-101. Short title, MCA  |  |
| MTS_0720-0380-0010-0020 | 200 | 10971 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0020/0720-0380-0010-0020.html |    72-38-102. Scope, MCA  |  |
| MTS_0720-0380-0010-0030 | 200 | 19710 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0030/0720-0380-0010-0030.html |    72-38-103. Definitions, MCA  |  |
| MTS_0720-0380-0010-0040 | 200 | 11896 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0040/0720-0380-0010-0040.html |    72-38-104. Knowledge, MCA  |  |
| MTS_0720-0380-0010-0050 | 200 | 14289 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0050/0720-0380-0010-0050.html |    72-38-105. Default and mandatory rules, MCA  |  |
| MTS_0720-0380-0010-0060 | 200 | 10833 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0060/0720-0380-0010-0060.html |    72-38-106. Common law of trusts -- principles of equity, MCA  |  |
| MTS_0720-0380-0010-0070 | 200 | 11165 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0070/0720-0380-0010-0070.html |    72-38-107. Governing law, MCA  |  |
| MTS_0720-0380-0010-0080 | 200 | 13629 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0080/0720-0380-0010-0080.html |    72-38-108. Principal place of administration, MCA  |  |
| MTS_0720-0380-0010-0090 | 200 | 12270 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0090/0720-0380-0010-0090.html |    72-38-109. Methods and waiver of notice, MCA  |  |
| MTS_0720-0380-0010-0100 | 200 | 13841 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0100/0720-0380-0010-0100.html |    72-38-110. Others treated as qualified beneficiaries, MCA  |  |
| MTS_0720-0380-0010-0110 | 200 | 12834 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0110/0720-0380-0010-0110.html |    72-38-111. Nonjudicial settlement agreements, MCA  |  |
| MTS_0720-0380-0010-0120 | 200 | 10814 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0120/0720-0380-0010-0120.html |    72-38-112. Rules of construction, MCA  |  |
| MTS_0720-0380-0010-0130 | 200 | 11888 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0130/0720-0380-0010-0130.html |    72-38-113. Insurable interest of trustee, MCA  |  |
| MTS_0720-0380-0010-0140 | 200 | 10414 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0140/0720-0380-0010-0140.html |    72-38-114. through 72-38-119 reserved, MCA  |  |
| MTS_0720-0380-0010-0200 | 200 | 11425 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0200/0720-0380-0010-0200.html |    72-38-120. Resulting trust upon failure of trust, MCA  |  |
| MTS_0720-0380-0010-0210 | 200 | 11100 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0210/0720-0380-0010-0210.html |    72-38-121. Resulting trust upon full performance of trust, MCA  |  |
| MTS_0720-0380-0010-0220 | 200 | 11887 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0220/0720-0380-0010-0220.html |    72-38-122. Purchase money resulting trust, MCA  |  |
| MTS_0720-0380-0010-0230 | 200 | 10838 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0230/0720-0380-0010-0230.html |    72-38-123. Constructive trust, MCA  |  |
| MTS_0720-0380-0010-0240 | 200 | 10981 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0240/0720-0380-0010-0240.html |    72-38-124. Resulting trusts -- constructive trusts -- statute of frauds, MCA  |  |
| MTS_0720-0380-0010-0250 | 200 | 10473 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0250/0720-0380-0010-0250.html |    72-38-125. through 72-38-129 reserved, MCA  |  |
| MTS_0720-0380-0010-0300 | 200 | 12514 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0300/0720-0380-0010-0300.html |    72-38-130. Scope and effect of part -- proposed action or inaction described, |  |
| MTS_0720-0380-0010-0310 | 200 | 13788 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0310/0720-0380-0010-0310.html |    72-38-131. When use of notice authorized, MCA  |  |
| MTS_0720-0380-0010-0320 | 200 | 12444 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0320/0720-0380-0010-0320.html |    72-38-132. Content of notice, MCA  |  |
| MTS_0720-0380-0010-0330 | 200 | 15116 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0330/0720-0380-0010-0330.html |    72-38-133. Objection to proposed action or inaction -- petition -- liability  |  |
| MTS_0720-0380-0010-0340 | 200 | 10756 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0010/section_0340/0720-0380-0010-0340.html |    72-38-134. Procedures not required, MCA  |  |
| MTS_0720-0380-0020-0010 | 200 | 10899 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0010/0720-0380-0020-0010.html |    72-38-201. Subject matter jurisdiction, MCA  |  |
| MTS_0720-0380-0020-0020 | 200 | 10481 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0020/0720-0380-0020-0020.html |    72-38-202. Powers of court, MCA  |  |
| MTS_0720-0380-0020-0030 | 200 | 11396 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0030/0720-0380-0020-0030.html |    72-38-203. Jurisdiction over trustees and beneficiaries, MCA  |  |
| MTS_0720-0380-0020-0040 | 200 | 10731 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0040/0720-0380-0020-0040.html |    72-38-204. Basis of jurisdiction over trust, trust property, and trust partie |  |
| MTS_0720-0380-0020-0050 | 200 | 11298 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0050/0720-0380-0020-0050.html |    72-38-205. Venue, MCA  |  |
| MTS_0720-0380-0020-0060 | 200 | 10877 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0060/0720-0380-0020-0060.html |    72-38-206. Rules of procedure in trust proceedings, MCA  |  |
| MTS_0720-0380-0020-0070 | 200 | 10367 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0070/0720-0380-0020-0070.html |    72-38-207. Jury trial, MCA  |  |
| MTS_0720-0380-0020-0080 | 200 | 10546 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0080/0720-0380-0020-0080.html |    72-38-208. Application, MCA  |  |
| MTS_0720-0380-0020-0090 | 200 | 12530 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0090/0720-0380-0020-0090.html |    72-38-209. Notice -- method and time of giving, MCA  |  |
| MTS_0720-0380-0020-0100 | 200 | 10528 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0100/0720-0380-0020-0100.html |    72-38-210. Waiver of notice, MCA  |  |
| MTS_0720-0380-0020-0110 | 200 | 14957 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0110/0720-0380-0020-0110.html |    72-38-211. Pleadings -- when orders or notice binding one binds another -- re |  |
| MTS_0720-0380-0020-0120 | 200 | 10841 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0120/0720-0380-0020-0120.html |    72-38-212. Additional notice, MCA  |  |
| MTS_0720-0380-0020-0130 | 200 | 14661 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0130/0720-0380-0020-0130.html |    72-38-213. Petitioners -- grounds for petition, MCA  |  |
| MTS_0720-0380-0020-0140 | 200 | 13376 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0140/0720-0380-0020-0140.html |    72-38-214. Commencement of proceedings, MCA  |  |
| MTS_0720-0380-0020-0150 | 200 | 10476 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0150/0720-0380-0020-0150.html |    72-38-215. Dismissal of petition, MCA  |  |
| MTS_0720-0380-0020-0160 | 200 | 11611 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0160/0720-0380-0020-0160.html |    72-38-216. Request for special notice, MCA  |  |
| MTS_0720-0380-0020-0170 | 200 | 10898 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0170/0720-0380-0020-0170.html |    72-38-217. Request for copy of petition, MCA  |  |
| MTS_0720-0380-0020-0180 | 200 | 10702 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0180/0720-0380-0020-0180.html |    72-38-218. Authority to make necessary orders -- temporary trustee, MCA  |  |
| MTS_0720-0380-0020-0190 | 200 | 11184 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0190/0720-0380-0020-0190.html |    72-38-219. Appeal, MCA  |  |
| MTS_0720-0380-0020-0200 | 200 | 10673 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0200/0720-0380-0020-0200.html |    72-38-220. Intermittent judicial intervention in trust administration, MCA  |  |
| MTS_0720-0380-0020-0210 | 200 | 10557 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0020/section_0210/0720-0380-0020-0210.html |    72-38-221. Enforcement of beneficiary's rights under charitable trust by atto |  |
| MTS_0720-0380-0030-0010 | 200 | 11741 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0030/section_0010/0720-0380-0030-0010.html |    72-38-301. Representation -- basic effect, MCA  |  |
| MTS_0720-0380-0030-0020 | 200 | 10892 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0030/section_0020/0720-0380-0030-0020.html |    72-38-302. Representation by holder of general testamentary power of appointm |  |
| MTS_0720-0380-0030-0030 | 200 | 12519 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0030/section_0030/0720-0380-0030-0030.html |    72-38-303. Representation by fiduciaries and parents, MCA  |  |
| MTS_0720-0380-0030-0040 | 200 | 10934 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0030/section_0040/0720-0380-0030-0040.html |    72-38-304. Representation by person having substantially identical interest,  |  |
| MTS_0720-0380-0030-0050 | 200 | 11061 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0030/section_0050/0720-0380-0030-0050.html |    72-38-305. Appointment of representative, MCA  |  |
| MTS_0720-0380-0040-0010 | 200 | 10769 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0010/0720-0380-0040-0010.html |    72-38-401. Methods of creating trust, MCA  |  |
| MTS_0720-0380-0040-0020 | 200 | 12538 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0020/0720-0380-0040-0020.html |    72-38-402. Requirements for creation, MCA  |  |
| MTS_0720-0380-0040-0030 | 200 | 11082 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0030/0720-0380-0040-0030.html |    72-38-403. Trusts created in other jurisdictions, MCA  |  |
| MTS_0720-0380-0040-0040 | 200 | 10602 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0040/0720-0380-0040-0040.html |    72-38-404. Trust purposes, MCA  |  |
| MTS_0720-0380-0040-0050 | 200 | 11386 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0050/0720-0380-0040-0050.html |    72-38-405. Charitable purposes -- enforcement, MCA  |  |
| MTS_0720-0380-0040-0060 | 200 | 10724 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0060/0720-0380-0040-0060.html |    72-38-406. Creation of trust induced by fraud, duress, or undue influence, MC |  |
| MTS_0720-0380-0040-0070 | 200 | 10969 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0070/0720-0380-0040-0070.html |    72-38-407. Statute of frauds, MCA  |  |
| MTS_0720-0380-0040-0080 | 200 | 11661 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0080/0720-0380-0040-0080.html |    72-38-408. Trust for care of animal, MCA  |  |
| MTS_0720-0380-0040-0090 | 200 | 11872 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0090/0720-0380-0040-0090.html |    72-38-409. Noncharitable trust without ascertainable beneficiary, MCA  |  |
| MTS_0720-0380-0040-0100 | 200 | 12209 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0100/0720-0380-0040-0100.html |    72-38-410. Modification or termination of trust -- proceedings for approval o |  |
| MTS_0720-0380-0040-0110 | 200 | 13843 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0110/0720-0380-0040-0110.html |    72-38-411. Modification or termination of irrevocable trust by consent, MCA  |  |
| MTS_0720-0380-0040-0120 | 200 | 11707 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0120/0720-0380-0040-0120.html |    72-38-412. Modification or termination because of unanticipated circumstances |  |
| MTS_0720-0380-0040-0130 | 200 | 11847 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0130/0720-0380-0040-0130.html |    72-38-413. Cy pres, MCA  |  |
| MTS_0720-0380-0040-0140 | 200 | 11327 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0140/0720-0380-0040-0140.html |    72-38-414. Modification or termination of uneconomic trust, MCA  |  |
| MTS_0720-0380-0040-0150 | 200 | 10826 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0150/0720-0380-0040-0150.html |    72-38-415. Reformation to correct mistakes, MCA  |  |
| MTS_0720-0380-0040-0160 | 200 | 10796 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0160/0720-0380-0040-0160.html |    72-38-416. Modification to achieve settlor's tax objectives, MCA  |  |
| MTS_0720-0380-0040-0170 | 200 | 10570 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0040/section_0170/0720-0380-0040-0170.html |    72-38-417. Combination and division of trusts, MCA  |  |
| MTS_0720-0380-0050-0010 | 200 | 10691 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0050/section_0010/0720-0380-0050-0010.html |    72-38-501. Rights of beneficiary's creditor or assignee, MCA  |  |
| MTS_0720-0380-0050-0020 | 200 | 11216 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0050/section_0020/0720-0380-0050-0020.html |    72-38-502. Spendthrift provision, MCA  |  |
| MTS_0720-0380-0050-0030 | 200 | 10138 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0050/section_0030/0720-0380-0050-0030.html |    72-38-503. reserved, MCA  |  |
| MTS_0720-0380-0050-0040 | 200 | 11641 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0050/section_0040/0720-0380-0050-0040.html |    72-38-504. Discretionary trusts -- effect of standard, MCA  |  |
| MTS_0720-0380-0050-0050 | 200 | 13104 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0050/section_0050/0720-0380-0050-0050.html |    72-38-505. Creditor's claim against settlor, MCA  |  |
| MTS_0720-0380-0050-0060 | 200 | 11582 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0050/section_0060/0720-0380-0050-0060.html |    72-38-506. Overdue distribution, MCA  |  |
| MTS_0720-0380-0050-0070 | 200 | 10370 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0050/section_0070/0720-0380-0050-0070.html |    72-38-507. Personal obligations of trustee, MCA  |  |
| MTS_0720-0380-0060-0010 | 200 | 10371 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0060/section_0010/0720-0380-0060-0010.html |    72-38-601. Capacity of settlor of revocable trust, MCA  |  |
| MTS_0720-0380-0060-0020 | 200 | 13675 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0060/section_0020/0720-0380-0060-0020.html |    72-38-602. Revocation or amendment of revocable trust, MCA  |  |
| MTS_0720-0380-0060-0030 | 200 | 11478 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0060/section_0030/0720-0380-0060-0030.html |    72-38-603. Settlor's powers -- powers of withdrawal, MCA  |  |
| MTS_0720-0380-0060-0040 | 200 | 12178 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0060/section_0040/0720-0380-0060-0040.html |    72-38-604. Limitation on action contesting validity of revocable trust -- dis |  |
| MTS_0720-0380-0060-0050 | 200 | 11264 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0060/section_0050/0720-0380-0060-0050.html |    72-38-605. Fees and expenses -- by whom paid, MCA  |  |
| MTS_0720-0380-0060-0060 | 200 | 11453 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0060/section_0060/0720-0380-0060-0060.html |    72-38-606. Separate writing identifying disposition of tangible personal prop |  |
| MTS_0720-0380-0070-0010 | 200 | 11729 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0070/section_0010/0720-0380-0070-0010.html |    72-38-701. Accepting or declining trusteeship, MCA  |  |
| MTS_0720-0380-0070-0020 | 200 | 10972 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0070/section_0020/0720-0380-0070-0020.html |    72-38-702. Trustee's bond, MCA  |  |
| MTS_0720-0380-0070-0030 | 200 | 12808 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0070/section_0030/0720-0380-0070-0030.html |    72-38-703. Cotrustees, MCA  |  |
| MTS_0720-0380-0070-0040 | 200 | 12611 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0070/section_0040/0720-0380-0070-0040.html |    72-38-704. Vacancy in trusteeship -- appointment of successor, MCA  |  |
| MTS_0720-0380-0070-0050 | 200 | 11099 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0070/section_0050/0720-0380-0070-0050.html |    72-38-705. Resignation of trustee, MCA  |  |
| MTS_0720-0380-0070-0060 | 200 | 11988 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0070/section_0060/0720-0380-0070-0060.html |    72-38-706. Removal of trustee, MCA  |  |
| MTS_0720-0380-0070-0070 | 200 | 11522 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0070/section_0070/0720-0380-0070-0070.html |    72-38-707. Delivery of property by former trustee, MCA  |  |
| MTS_0720-0380-0070-0080 | 200 | 11064 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0070/section_0080/0720-0380-0070-0080.html |    72-38-708. Compensation of trustee, MCA  |  |
| MTS_0720-0380-0070-0090 | 200 | 10808 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0070/section_0090/0720-0380-0070-0090.html |    72-38-709. Reimbursement of expenses, MCA  |  |
| MTS_0720-0380-0080-0010 | 200 | 10344 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0010/0720-0380-0080-0010.html |    72-38-801. Duty to administer trust, MCA  |  |
| MTS_0720-0380-0080-0020 | 200 | 16783 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0020/0720-0380-0080-0020.html |    72-38-802. Duty of loyalty, MCA  |  |
| MTS_0720-0380-0080-0030 | 200 | 10476 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0030/0720-0380-0080-0030.html |    72-38-803. Impartiality, MCA  |  |
| MTS_0720-0380-0080-0040 | 200 | 10585 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0040/0720-0380-0080-0040.html |    72-38-804. Prudent administration, MCA  |  |
| MTS_0720-0380-0080-0050 | 200 | 10505 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0050/0720-0380-0080-0050.html |    72-38-805. Costs of administration, MCA  |  |
| MTS_0720-0380-0080-0060 | 200 | 10510 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0060/0720-0380-0080-0060.html |    72-38-806. Trustee's skills, MCA  |  |
| MTS_0720-0380-0080-0070 | 200 | 11698 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0070/0720-0380-0080-0070.html |    72-38-807. Delegation by trustee, MCA  |  |
| MTS_0720-0380-0080-0080 | 200 | 10349 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0080/0720-0380-0080-0080.html |    72-38-808. Repealed, MCA  |  |
| MTS_0720-0380-0080-0090 | 200 | 10527 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0090/0720-0380-0080-0090.html |    72-38-809. Control and protection of trust property, MCA  |  |
| MTS_0720-0380-0080-0100 | 200 | 11260 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0100/0720-0380-0080-0100.html |    72-38-810. Recordkeeping and identification of trust property, MCA  |  |
| MTS_0720-0380-0080-0110 | 200 | 10514 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0110/0720-0380-0080-0110.html |    72-38-811. Enforcement and defense claims, MCA  |  |
| MTS_0720-0380-0080-0120 | 200 | 10580 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0120/0720-0380-0080-0120.html |    72-38-812. Collecting trust property, MCA  |  |
| MTS_0720-0380-0080-0130 | 200 | 14665 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0130/0720-0380-0080-0130.html |    72-38-813. Duty to inform and report, MCA  |  |
| MTS_0720-0380-0080-0140 | 200 | 12795 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0140/0720-0380-0080-0140.html |    72-38-814. Discretionary powers -- tax savings, MCA  |  |
| MTS_0720-0380-0080-0150 | 200 | 11508 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0150/0720-0380-0080-0150.html |    72-38-815. General powers of trustee, MCA  |  |
| MTS_0720-0380-0080-0160 | 200 | 20232 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0160/0720-0380-0080-0160.html |    72-38-816. Specific powers of trustee, MCA  |  |
| MTS_0720-0380-0080-0170 | 200 | 11676 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0170/0720-0380-0080-0170.html |    72-38-817. Distribution upon termination, MCA  |  |
| MTS_0720-0380-0080-0180 | 200 | 10128 | https://leg.mt.gov/bills/mca/title_0720/chapter_0380/part_0080/section_0180/0720-0380-0080-0180.html |    72-38-818. and 72-38-819 reserved, MCA  |  |
