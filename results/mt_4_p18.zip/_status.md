| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0150-0300-0210-0910 | 200 | 9484 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0210/section_0910/0150-0300-0210-0910.html |    15-30-2191. Terminated, MCA  |  |
| MTS_0150-0300-0230-0010 | 200 | 9659 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0010/0150-0300-0230-0010.html |    15-30-2301. Repealed, MCA  |  |
| MTS_0150-0300-0230-0020 | 200 | 13006 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0020/0150-0300-0230-0020.html |    15-30-2302. Credit allowed resident taxpayers for income taxes imposed by for |  |
| MTS_0150-0300-0230-0030 | 200 | 18143 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0030/0150-0300-0230-0030.html |    15-30-2303. Tax credits subject to review by interim committee, MCA  |  |
| MTS_0150-0300-0230-0040 | 200 | 9525 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0040/0150-0300-0230-0040.html |    15-30-2304. through 15-30-2317 reserved, MCA  |  |
| MTS_0150-0300-0230-0180 | 200 | 11832 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0180/0150-0300-0230-0180.html |    15-30-2318. Earned income tax credit, MCA  |  |
| MTS_0150-0300-0230-0190 | 200 | 9790 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0190/0150-0300-0230-0190.html |    15-30-2319. Repealed, MCA  |  |
| MTS_0150-0300-0230-0200 | 200 | 9799 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0200/0150-0300-0230-0200.html |    15-30-2320. Repealed, MCA  |  |
| MTS_0150-0300-0230-0210 | 200 | 12166 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0210/0150-0300-0230-0210.html |    15-30-2321. Adoption tax credit -- rulemaking, MCA  |  |
| MTS_0150-0300-0230-0220 | 200 | 9492 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0220/0150-0300-0230-0220.html |    15-30-2322. through 15-30-2325 reserved, MCA  |  |
| MTS_0150-0300-0230-0260 | 200 | 9898 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0260/0150-0300-0230-0260.html |    15-30-2326. Repealed, MCA  |  |
| MTS_0150-0300-0230-0270 | 200 | 17467 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0270/0150-0300-0230-0270.html |    15-30-2327. Qualified endowments credit -- definitions -- rules, MCA  |  |
| MTS_0150-0300-0230-0280 | 200 | 12191 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0280/0150-0300-0230-0280.html |    15-30-2328. Credit for contributions to qualified endowment -- recapture of c |  |
| MTS_0150-0300-0230-0290 | 200 | 11093 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0290/0150-0300-0230-0290.html |    15-30-2329. Beneficiaries of estates -- credit for contribution to qualified  |  |
| MTS_0150-0300-0230-0300 | 200 | 9618 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0300/0150-0300-0230-0300.html |    15-30-2330. through 15-30-2333 reserved, MCA  |  |
| MTS_0150-0300-0230-0340 | 200 | 10502 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0340/0150-0300-0230-0340.html |    15-30-2334. Credit for providing supplemental funding to public schools -- in |  |
| MTS_0150-0300-0230-0350 | 200 | 10529 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0350/0150-0300-0230-0350.html |    15-30-2335. Qualified education individual income tax credit for contribution |  |
| MTS_0150-0300-0230-0360 | 200 | 9952 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0360/0150-0300-0230-0360.html |    15-30-2336. Repealed, MCA  |  |
| MTS_0150-0300-0230-0370 | 200 | 14694 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0370/0150-0300-0230-0370.html |    15-30-2337. Residential property tax credit for elderly -- definitions, MCA  |  |
| MTS_0150-0300-0230-0380 | 200 | 12243 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0380/0150-0300-0230-0380.html |    15-30-2338. Residential property tax credit for elderly -- eligibility -- dis |  |
| MTS_0150-0300-0230-0390 | 200 | 12063 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0390/0150-0300-0230-0390.html |    15-30-2339. Residential property tax credit for elderly -- filing date, MCA  |  |
| MTS_0150-0300-0230-0400 | 200 | 19376 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0400/0150-0300-0230-0400.html |    15-30-2340. Residential property tax credit for elderly -- computation of rel |  |
| MTS_0150-0300-0230-0410 | 200 | 12045 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0410/0150-0300-0230-0410.html |    15-30-2341. Residential property tax credit for elderly -- limitations -- den |  |
| MTS_0150-0300-0230-0420 | 200 | 10395 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0420/0150-0300-0230-0420.html |    15-30-2342. Credit for preservation of historic buildings, MCA  |  |
| MTS_0150-0300-0230-0430 | 200 | 9504 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0430/0150-0300-0230-0430.html |    15-30-2343. through 15-30-2355 reserved, MCA  |  |
| MTS_0150-0300-0230-0560 | 200 | 9850 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0560/0150-0300-0230-0560.html |    15-30-2356. Repealed, MCA  |  |
| MTS_0150-0300-0230-0570 | 200 | 12672 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0570/0150-0300-0230-0570.html |    15-30-2357. Tax credit for hiring registered apprentice or veteran apprentice |  |
| MTS_0150-0300-0230-0580 | 200 | 9866 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0580/0150-0300-0230-0580.html |    15-30-2358. Repealed, MCA  |  |
| MTS_0150-0300-0230-0590 | 200 | 21087 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0590/0150-0300-0230-0590.html |    15-30-2359. Tax credit for trades education and training, MCA  |  |
| MTS_0150-0300-0230-0600 | 200 | 9429 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0600/0150-0300-0230-0600.html |    15-30-2360. reserved, MCA  |  |
| MTS_0150-0300-0230-0610 | 200 | 14220 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0610/0150-0300-0230-0610.html |    15-30-2361. Grow Montana jobs -- annual job growth incentive tax credit, MCA  |  |
| MTS_0150-0300-0230-0620 | 200 | 9498 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0620/0150-0300-0230-0620.html |    15-30-2362. and 15-30-2363 reserved, MCA  |  |
| MTS_0150-0300-0230-0640 | 200 | 9789 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0640/0150-0300-0230-0640.html |    15-30-2364. Repealed, MCA  |  |
| MTS_0150-0300-0230-0650 | 200 | 9773 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0650/0150-0300-0230-0650.html |    15-30-2365. Repealed, MCA  |  |
| MTS_0150-0300-0230-0660 | 200 | 9837 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0660/0150-0300-0230-0660.html |    15-30-2366. Repealed, MCA  |  |
| MTS_0150-0300-0230-0670 | 200 | 9806 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0670/0150-0300-0230-0670.html |    15-30-2367. Repealed, MCA  |  |
| MTS_0150-0300-0230-0680 | 200 | 9806 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0680/0150-0300-0230-0680.html |    15-30-2368. Repealed, MCA  |  |
| MTS_0150-0300-0230-0690 | 200 | 9780 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0690/0150-0300-0230-0690.html |    15-30-2369. Repealed, MCA  |  |
| MTS_0150-0300-0230-0700 | 200 | 9811 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0700/0150-0300-0230-0700.html |    15-30-2370. Repealed, MCA  |  |
| MTS_0150-0300-0230-0710 | 200 | 9780 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0710/0150-0300-0230-0710.html |    15-30-2371. Repealed, MCA  |  |
| MTS_0150-0300-0230-0720 | 200 | 9780 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0720/0150-0300-0230-0720.html |    15-30-2372. Repealed, MCA  |  |
| MTS_0150-0300-0230-0730 | 200 | 9824 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0730/0150-0300-0230-0730.html |    15-30-2373. Repealed, MCA  |  |
| MTS_0150-0300-0230-0740 | 200 | 9515 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0740/0150-0300-0230-0740.html |    15-30-2374. through 15-30-2379 reserved, MCA  |  |
| MTS_0150-0300-0230-0800 | 200 | 12534 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0800/0150-0300-0230-0800.html |    15-30-2380. Credit for unlocking public lands program -- definitions, MCA  |  |
| MTS_0150-0300-0230-0810 | 200 | 9872 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0810/0150-0300-0230-0810.html |    15-30-2381. Repealed, MCA  |  |
| MTS_0150-0300-0230-0820 | 200 | 9513 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0820/0150-0300-0230-0820.html |    15-30-2382. through 15-30-2385 reserved, MCA  |  |
| MTS_0150-0300-0230-0860 | 200 | 10774 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0860/0150-0300-0230-0860.html |    15-30-2386. Funding for administration of special revenue accounts, MCA  |  |
| MTS_0150-0300-0230-0870 | 200 | 11812 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0870/0150-0300-0230-0870.html |    15-30-2387. Voluntary checkoff for nongame wildlife programs, MCA  |  |
| MTS_0150-0300-0230-0880 | 200 | 11274 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0880/0150-0300-0230-0880.html |    15-30-2388. Agriculture literacy in Montana schools program account -- admini |  |
| MTS_0150-0300-0230-0890 | 200 | 11982 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0890/0150-0300-0230-0890.html |    15-30-2389. Voluntary checkoff for agriculture literacy in Montana schools pr |  |
| MTS_0150-0300-0230-0900 | 200 | 11957 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0900/0150-0300-0230-0900.html |    15-30-2390. Voluntary checkoff for child abuse and neglect prevention program |  |
| MTS_0150-0300-0230-0910 | 200 | 9442 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0910/0150-0300-0230-0910.html |    15-30-2391. reserved, MCA  |  |
| MTS_0150-0300-0230-0920 | 200 | 11860 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0920/0150-0300-0230-0920.html |    15-30-2392. Voluntary checkoff for Montana military relief fund, MCA  |  |
| MTS_0150-0300-0230-0930 | 200 | 10543 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0230/section_0930/0150-0300-0230-0930.html |    15-30-2393. Election to deposit refund to education savings or ABLE account,  |  |
| MTS_0150-0300-0250-0010 | 200 | 14357 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0010/0150-0300-0250-0010.html |    15-30-2501. Definitions, MCA  |  |
| MTS_0150-0300-0250-0020 | 200 | 10695 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0020/0150-0300-0250-0020.html |    15-30-2502. Withholding of tax from wages, MCA  |  |
| MTS_0150-0300-0250-0030 | 200 | 16276 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0030/0150-0300-0250-0030.html |    15-30-2503. Employer liable for withholding taxes and statements, MCA  |  |
| MTS_0150-0300-0250-0040 | 200 | 14127 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0040/0150-0300-0250-0040.html |    15-30-2504. Schedules for remitting income withholding taxes -- records, MCA  |  |
| MTS_0150-0300-0250-0050 | 200 | 10706 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0050/0150-0300-0250-0050.html |    15-30-2505. Amount withheld considered as tax collected, MCA  |  |
| MTS_0150-0300-0250-0060 | 200 | 10722 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0060/0150-0300-0250-0060.html |    15-30-2506. Annual withholding statement, MCA  |  |
| MTS_0150-0300-0250-0070 | 200 | 11221 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0070/0150-0300-0250-0070.html |    15-30-2507. Annual statement by employer, MCA  |  |
| MTS_0150-0300-0250-0080 | 200 | 10439 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0080/0150-0300-0250-0080.html |    15-30-2508. Withheld taxes held in trust for state, MCA  |  |
| MTS_0150-0300-0250-0090 | 200 | 13016 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0090/0150-0300-0250-0090.html |    15-30-2509. Violations by employer -- penalties, interest, remedies, and waiv |  |
| MTS_0150-0300-0250-0100 | 200 | 10855 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0100/0150-0300-0250-0100.html |    15-30-2510. Remitting withholding taxes electronically -- employer option --  |  |
| MTS_0150-0300-0250-0110 | 200 | 10701 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0110/0150-0300-0250-0110.html |    15-30-2511. Voluntary state withholding from federal annuity -- agreement wit |  |
| MTS_0150-0300-0250-0120 | 200 | 24649 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0120/0150-0300-0250-0120.html |    15-30-2512. Estimated tax -- payment -- exceptions -- interest, MCA  |  |
| MTS_0150-0300-0250-0130 | 200 | 12973 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0130/0150-0300-0250-0130.html |    15-30-2513. Withholding from compensation -- exception, MCA  |  |
| MTS_0150-0300-0250-0140 | 200 | 9484 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0140/0150-0300-0250-0140.html |    15-30-2514. through 15-30-2520 reserved, MCA  |  |
| MTS_0150-0300-0250-0210 | 200 | 10559 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0210/0150-0300-0250-0210.html |    15-30-2521. Policy and purpose, MCA  |  |
| MTS_0150-0300-0250-0220 | 200 | 11133 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0220/0150-0300-0250-0220.html |    15-30-2522. Withholding of lottery winnings, MCA  |  |
| MTS_0150-0300-0250-0230 | 200 | 10396 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0230/0150-0300-0250-0230.html |    15-30-2523. Determination of employer status, MCA  |  |
| MTS_0150-0300-0250-0240 | 200 | 9500 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0240/0150-0300-0250-0240.html |    15-30-2524. through 15-30-2530 reserved, MCA  |  |
| MTS_0150-0300-0250-0310 | 200 | 12299 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0310/0150-0300-0250-0310.html |    15-30-2531. Credits and refunds -- period of limitations, MCA  |  |
| MTS_0150-0300-0250-0320 | 200 | 9479 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0320/0150-0300-0250-0320.html |    15-30-2532. through 15-30-2535 reserved, MCA  |  |
| MTS_0150-0300-0250-0360 | 200 | 10018 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0360/0150-0300-0250-0360.html |    15-30-2536. Short title, MCA  |  |
| MTS_0150-0300-0250-0370 | 200 | 10911 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0370/0150-0300-0250-0370.html |    15-30-2537. Definitions, MCA  |  |
| MTS_0150-0300-0250-0380 | 200 | 10282 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0380/0150-0300-0250-0380.html |    15-30-2538. Withholding required on mineral royalty payments, MCA  |  |
| MTS_0150-0300-0250-0390 | 200 | 14911 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0390/0150-0300-0250-0390.html |    15-30-2539. Withholding -- no application under certain conditions, MCA  |  |
| MTS_0150-0300-0250-0400 | 200 | 17404 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0400/0150-0300-0250-0400.html |    15-30-2540. Remitter liable for withholding taxes and statements -- liability |  |
| MTS_0150-0300-0250-0410 | 200 | 13180 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0410/0150-0300-0250-0410.html |    15-30-2541. Royalty withholding tax remittance schedule -- alternative schedu |  |
| MTS_0150-0300-0250-0420 | 200 | 11254 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0420/0150-0300-0250-0420.html |    15-30-2542. Amount of royalty payment withheld considered taxes collected, MC |  |
| MTS_0150-0300-0250-0430 | 200 | 10390 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0430/0150-0300-0250-0430.html |    15-30-2543. Annual withholding statement to royalty owner, MCA  |  |
| MTS_0150-0300-0250-0440 | 200 | 11314 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0440/0150-0300-0250-0440.html |    15-30-2544. Remitter to furnish annual statement to department, MCA  |  |
| MTS_0150-0300-0250-0450 | 200 | 10272 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0450/0150-0300-0250-0450.html |    15-30-2545. Withheld taxes held in trust for state, MCA  |  |
| MTS_0150-0300-0250-0460 | 200 | 12563 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0460/0150-0300-0250-0460.html |    15-30-2546. Violations by remitter -- penalties -- interest -- remedies -- wa |  |
| MTS_0150-0300-0250-0470 | 200 | 9945 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0250/section_0470/0150-0300-0250-0470.html |    15-30-2547. Rulemaking authority, MCA  |  |
| MTS_0150-0300-0260-0010 | 200 | 9868 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0010/0150-0300-0260-0010.html |    15-30-2601. Tax as personal debt, MCA  |  |
| MTS_0150-0300-0260-0020 | 200 | 14176 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0020/0150-0300-0260-0020.html |    15-30-2602. Returns and payment of tax -- penalty and interest -- refunds --  |  |
| MTS_0150-0300-0260-0030 | 200 | 10289 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0030/0150-0300-0260-0030.html |    15-30-2603. Return of fiduciary, MCA  |  |
| MTS_0150-0300-0260-0040 | 200 | 12948 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0040/0150-0300-0260-0040.html |    15-30-2604. Time for filing -- extensions of time, MCA  |  |
| MTS_0150-0300-0260-0050 | 200 | 13242 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0050/0150-0300-0260-0050.html |    15-30-2605. Revision of return by department -- statute of limitations -- exa |  |
| MTS_0150-0300-0260-0060 | 200 | 12359 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0060/0150-0300-0260-0060.html |    15-30-2606. Tolling of statute of limitations -- consent to extend time to as |  |
| MTS_0150-0300-0260-0070 | 200 | 10793 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0070/0150-0300-0260-0070.html |    15-30-2607. Application for revision -- appeal, MCA  |  |
| MTS_0150-0300-0260-0080 | 200 | 10757 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0080/0150-0300-0260-0080.html |    15-30-2608. Judicial review, MCA  |  |
| MTS_0150-0300-0260-0090 | 200 | 15552 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0090/0150-0300-0260-0090.html |    15-30-2609. Credits and refunds -- period of limitations, MCA  |  |
| MTS_0150-0300-0260-0100 | 200 | 9494 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0100/0150-0300-0260-0100.html |    15-30-2610. through 15-30-2615 reserved, MCA  |  |
| MTS_0150-0300-0260-0160 | 200 | 11822 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0160/0150-0300-0260-0160.html |    15-30-2616. Information agents' duties, MCA  |  |
| MTS_0150-0300-0260-0170 | 200 | 10380 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0170/0150-0300-0260-0170.html |    15-30-2617. Oaths administered by director of revenue and designated employee |  |
| MTS_0150-0300-0260-0180 | 200 | 21844 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0180/0150-0300-0260-0180.html |    15-30-2618. Confidentiality of tax records, MCA  |  |
| MTS_0150-0300-0260-0190 | 200 | 12122 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0190/0150-0300-0260-0190.html |    15-30-2619. Furnishing copy of federal return -- copy of share of income, cre |  |
| MTS_0150-0300-0260-0200 | 200 | 10604 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0200/0150-0300-0260-0200.html |    15-30-2620. Department rules -- conformance with Internal Revenue Code, MCA  |  |
| MTS_0150-0300-0260-0210 | 200 | 10495 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0210/0150-0300-0260-0210.html |    15-30-2621. Agreements with contiguous states, MCA  |  |
| MTS_0150-0300-0260-0220 | 200 | 10842 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0220/0150-0300-0260-0220.html |    15-30-2622. Closing agreements, MCA  |  |
| MTS_0150-0300-0260-0230 | 200 | 9487 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0230/0150-0300-0260-0230.html |    15-30-2623. through 15-30-2628 reserved, MCA  |  |
| MTS_0150-0300-0260-0290 | 200 | 11428 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0290/0150-0300-0260-0290.html |    15-30-2629. Authority to collect tax -- offset -- hearing, MCA  |  |
| MTS_0150-0300-0260-0300 | 200 | 10185 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0300/0150-0300-0260-0300.html |    15-30-2630. Warrant for distraint, MCA  |  |
| MTS_0150-0300-0260-0310 | 200 | 10841 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0310/0150-0300-0260-0310.html |    15-30-2631. Jeopardy assessments, MCA  |  |
| MTS_0150-0300-0260-0320 | 200 | 11899 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0320/0150-0300-0260-0320.html |    15-30-2632. Deferment of taxes for person in military service -- filing of re |  |
| MTS_0150-0300-0260-0330 | 200 | 11977 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0330/0150-0300-0260-0330.html |    15-30-2633. Stay of enforcement against military personnel, MCA  |  |
| MTS_0150-0300-0260-0340 | 200 | 13168 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0340/0150-0300-0260-0340.html |    15-30-2634. Failure to file return or report -- order to show cause -- action |  |
| MTS_0150-0300-0260-0350 | 200 | 9511 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0350/0150-0300-0260-0350.html |    15-30-2635. through 15-30-2640 reserved, MCA  |  |
| MTS_0150-0300-0260-0410 | 200 | 10165 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0410/0150-0300-0260-0410.html |    15-30-2641. Repealed, MCA  |  |
| MTS_0150-0300-0260-0420 | 200 | 11713 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0420/0150-0300-0260-0420.html |    15-30-2642. Notice of additional assessment -- penalty and interest for defic |  |
| MTS_0150-0300-0260-0430 | 200 | 10161 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0430/0150-0300-0260-0430.html |    15-30-2643. Time limitations for prosecution, MCA  |  |
| MTS_0150-0300-0260-0440 | 200 | 9515 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0440/0150-0300-0260-0440.html |    15-30-2644. and 15-30-2645 reserved, MCA  |  |
| MTS_0150-0300-0260-0460 | 200 | 12205 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0460/0150-0300-0260-0460.html |    15-30-2646. Relief from joint and several liability on joint return -- limita |  |
| MTS_0150-0300-0260-0470 | 200 | 9553 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0470/0150-0300-0260-0470.html |    15-30-2647. through 15-30-2650 reserved, MCA  |  |
| MTS_0150-0300-0260-0510 | 200 | 10940 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0510/0150-0300-0260-0510.html |    15-30-2651. Certified copies of tax returns to taxpayer -- fee, MCA  |  |
| MTS_0150-0300-0260-0520 | 200 | 9497 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0520/0150-0300-0260-0520.html |    15-30-2652. through 15-30-2659 reserved, MCA  |  |
| MTS_0150-0300-0260-0600 | 200 | 17140 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0260/section_0600/0150-0300-0260-0600.html |    15-30-2660. Taxpayer integrity fees, MCA  |  |
| MTS_0150-0300-0300-0010 | 200 | 9731 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0300/section_0010/0150-0300-0300-0010.html |    15-30-3001. Short title, MCA  |  |
| MTS_0150-0300-0300-0020 | 200 | 11515 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0300/section_0020/0150-0300-0300-0020.html |    15-30-3002. Definitions, MCA  |  |
| MTS_0150-0300-0300-0030 | 200 | 11586 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0300/section_0030/0150-0300-0300-0030.html |    15-30-3003. Montana farm and ranch risk management account -- deposits -- exc |  |
| MTS_0150-0300-0300-0040 | 200 | 11515 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0300/section_0040/0150-0300-0300-0040.html |    15-30-3004. Montana farm and ranch risk management account -- creation -- adm |  |
| MTS_0150-0300-0300-0050 | 200 | 12310 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0300/section_0050/0150-0300-0300-0050.html |    15-30-3005. Montana farm and ranch risk management account -- distributions,  |  |
| MTS_0150-0300-0310-0010 | 200 | 9900 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0310/section_0010/0150-0300-0310-0010.html |    15-30-3101. Purpose, MCA  |  |
| MTS_0150-0300-0310-0020 | 200 | 16133 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0310/section_0020/0150-0300-0310-0020.html |    15-30-3102. Definitions, MCA  |  |
| MTS_0150-0300-0310-0030 | 200 | 15962 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0310/section_0030/0150-0300-0310-0030.html |    15-30-3103. Requirements for student scholarship organizations, MCA  |  |
| MTS_0150-0300-0310-0040 | 200 | 10851 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0310/section_0040/0150-0300-0310-0040.html |    15-30-3104. Tuition payment limitation, MCA  |  |
| MTS_0150-0300-0310-0050 | 200 | 12497 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0310/section_0050/0150-0300-0310-0050.html |    15-30-3105. Reporting requirements for student scholarship organizations, MCA |  |
| MTS_0150-0300-0310-0060 | 200 | 11308 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0310/section_0060/0150-0300-0310-0060.html |    15-30-3106. Student scholarship organizations -- listing on website, MCA  |  |
| MTS_0150-0300-0310-0070 | 200 | 9629 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0310/section_0070/0150-0300-0310-0070.html |    15-30-3107. through 15-30-3109 reserved, MCA  |  |
| MTS_0150-0300-0310-0100 | 200 | 16461 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0310/section_0100/0150-0300-0310-0100.html |    15-30-3110. Credit for providing supplemental funding to public schools -- in |  |
| MTS_0150-0300-0310-0110 | 200 | 14627 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0310/section_0110/0150-0300-0310-0110.html |    15-30-3111. Qualified education tax credit for donations to student scholarsh |  |
| MTS_0150-0300-0310-0120 | 200 | 10827 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0310/section_0120/0150-0300-0310-0120.html |    15-30-3112. Report to revenue interim committee -- student scholarship organi |  |
| MTS_0150-0300-0310-0130 | 200 | 13841 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0310/section_0130/0150-0300-0310-0130.html |    15-30-3113. Review determination -- termination -- confidentiality, MCA  |  |
| MTS_0150-0300-0310-0140 | 200 | 9731 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0310/section_0140/0150-0300-0310-0140.html |    15-30-3114. Rulemaking, MCA  |  |
| MTS_0150-0300-0330-0010 | 200 | 11586 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0010/0150-0300-0330-0010.html |    15-30-3301. Definition of small business corporation, MCA  |  |
| MTS_0150-0300-0330-0020 | 200 | 19161 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0020/0150-0300-0330-0020.html |    15-30-3302. Income or license tax involving pass-through entities -- informat |  |
| MTS_0150-0300-0330-0030 | 200 | 9599 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0030/0150-0300-0330-0030.html |    15-30-3303. through 15-30-3310 reserved, MCA  |  |
| MTS_0150-0300-0330-0110 | 200 | 11686 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0110/0150-0300-0330-0110.html |    15-30-3311. Taxation of partners, shareholders, managers, and members, MCA  |  |
| MTS_0150-0300-0330-0120 | 200 | 15524 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0120/0150-0300-0330-0120.html |    15-30-3312. Composite returns and tax, MCA  |  |
| MTS_0150-0300-0330-0130 | 200 | 22801 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0130/0150-0300-0330-0130.html |    15-30-3313. Consent or withholding -- rulemaking, MCA  |  |
| MTS_0150-0300-0330-0140 | 200 | 10481 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0140/0150-0300-0330-0140.html |    15-30-3314. Review of pass-through entity taxation by department, MCA  |  |
| MTS_0150-0300-0330-0150 | 200 | 11602 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0150/0150-0300-0330-0150.html |    15-30-3315. Electronic partnership return required -- waiver -- rulemaking, M |  |
| MTS_0150-0300-0330-0160 | 200 | 9580 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0160/0150-0300-0330-0160.html |    15-30-3316. through 15-30-3320 reserved, MCA  |  |
| MTS_0150-0300-0330-0210 | 200 | 10508 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0210/0150-0300-0330-0210.html |    15-30-3321. Small business option unavailable on dissolution -- exception, MC |  |
| MTS_0150-0300-0330-0220 | 200 | 9529 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0220/0150-0300-0330-0220.html |    15-30-3322. through 15-30-3324 reserved, MCA  |  |
| MTS_0150-0300-0330-0250 | 200 | 10975 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0250/0150-0300-0330-0250.html |    15-30-3325. Definitions, MCA  |  |
| MTS_0150-0300-0330-0260 | 200 | 13379 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0260/0150-0300-0330-0260.html |    15-30-3326. Pass-through entity tax, MCA  |  |
| MTS_0150-0300-0330-0270 | 200 | 12005 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0270/0150-0300-0330-0270.html |    15-30-3327. Making pass-through entity tax election, MCA  |  |
| MTS_0150-0300-0330-0280 | 200 | 11492 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0330/section_0280/0150-0300-0330-0280.html |    15-30-3328. Pass-through entity tax -- refundable credit -- credit for taxes  |  |
| MTS_0150-0300-0340-0010 | 200 | 15353 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0340/section_0010/0150-0300-0340-0010.html |    15-30-3401. Definitions, MCA  |  |
| MTS_0150-0300-0340-0020 | 200 | 10769 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0340/section_0020/0150-0300-0340-0020.html |    15-30-3402. State partnership representative, MCA  |  |
| MTS_0150-0300-0340-0030 | 200 | 13410 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0340/section_0030/0150-0300-0340-0030.html |    15-30-3403. Reporting and payment requirements for partnerships subject to fi |  |
| MTS_0150-0300-0340-0040 | 200 | 16932 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0340/section_0040/0150-0300-0340-0040.html |    15-30-3404. Election -- partnership pays -- rulemaking, MCA  |  |
| MTS_0150-0300-0340-0050 | 200 | 11028 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0340/section_0050/0150-0300-0340-0050.html |    15-30-3405. Modified reporting and payment method, MCA  |  |
| MTS_0150-0300-0340-0060 | 200 | 11763 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0340/section_0060/0150-0300-0340-0060.html |    15-30-3406. Effect of election by audited partnership or tiered partner and p |  |
| MTS_0150-0300-0340-0070 | 200 | 10097 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0340/section_0070/0150-0300-0340-0070.html |    15-30-3407. De minimis exception -- rulemaking, MCA  |  |
| MTS_0150-0300-0340-0080 | 200 | 10671 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0340/section_0080/0150-0300-0340-0080.html |    15-30-3408. Estimated tax payments during course of federal audit, MCA  |  |
| MTS_0150-0300-0370-0010 | 200 | 9393 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0370/section_0010/0150-0300-0370-0010.html |    15-30-3701. Short title, MCA  |  |
| MTS_0150-0300-0370-0020 | 200 | 11525 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0370/section_0020/0150-0300-0370-0020.html |    15-30-3702. Definitions, MCA  |  |
| MTS_0150-0300-0370-0030 | 200 | 11547 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0370/section_0030/0150-0300-0370-0030.html |    15-30-3703. Taxation of qualifying net capital gains from sale of capital sto |  |
| MTS_0150-0300-0370-0040 | 200 | 9816 | https://leg.mt.gov/bills/mca/title_0150/chapter_0300/part_0370/section_0040/0150-0300-0370-0040.html |    15-30-3704. Tax on qualifying net capital gains, MCA  |  |
| MTS_0150-0310-0010-0010 | 200 | 14534 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0010/0150-0310-0010-0010.html |    15-31-101. Organizations subject to tax -- incorporation of terms that mean c |  |
| MTS_0150-0310-0010-0020 | 200 | 16499 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0020/0150-0310-0010-0020.html |    15-31-102. Organizations exempt from tax -- unrelated business income not exe |  |
| MTS_0150-0310-0010-0030 | 200 | 14026 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0030/0150-0310-0010-0030.html |    15-31-103. Research and development firms exempt from taxation -- application |  |
| MTS_0150-0310-0010-0040 | 200 | 9637 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0040/0150-0310-0010-0040.html |    15-31-104. through 15-31-109 reserved, MCA  |  |
| MTS_0150-0310-0010-0100 | 200 | 12951 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0100/0150-0310-0010-0100.html |    15-31-110. Electronic corporate income tax return required -- waiver -- rulem |  |
| MTS_0150-0310-0010-0110 | 200 | 13458 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0110/0150-0310-0010-0110.html |    15-31-111. Return to be filed -- penalty and interest, MCA  |  |
| MTS_0150-0310-0010-0120 | 200 | 10345 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0120/0150-0310-0010-0120.html |    15-31-112. Taxable period, MCA  |  |
| MTS_0150-0310-0010-0130 | 200 | 16817 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0130/0150-0310-0010-0130.html |    15-31-113. Gross income and net income, MCA  |  |
| MTS_0150-0310-0010-0140 | 200 | 19663 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0140/0150-0310-0010-0140.html |    15-31-114. Deductions allowed in computing income, MCA  |  |
| MTS_0150-0310-0010-0150 | 200 | 10408 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0150/0150-0310-0010-0150.html |    15-31-115. Reaffirmation of bond income inclusion in definition of net income |  |
| MTS_0150-0310-0010-0160 | 200 | 9795 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0160/0150-0310-0010-0160.html |    15-31-116. Repealed, MCA  |  |
| MTS_0150-0310-0010-0170 | 200 | 11100 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0170/0150-0310-0010-0170.html |    15-31-117. Tax deductibility, MCA  |  |
| MTS_0150-0310-0010-0180 | 200 | 10516 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0180/0150-0310-0010-0180.html |    15-31-118. Taxable liability on termination of independent liability fund, MC |  |
| MTS_0150-0310-0010-0190 | 200 | 14775 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0190/0150-0310-0010-0190.html |    15-31-119. Net operating losses -- carryovers and carrybacks -- limit, MCA  |  |
| MTS_0150-0310-0010-0200 | 200 | 9491 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0200/0150-0310-0010-0200.html |    15-31-120. reserved, MCA  |  |
| MTS_0150-0310-0010-0210 | 200 | 11530 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0210/0150-0310-0010-0210.html |    15-31-121. Rate of tax -- minimum tax -- distribution of revenue, MCA  |  |
| MTS_0150-0310-0010-0220 | 200 | 11603 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0220/0150-0310-0010-0220.html |    15-31-122. Alternative gross sales tax, MCA  |  |
| MTS_0150-0310-0010-0230 | 200 | 9897 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0230/0150-0310-0010-0230.html |    15-31-123. Repealed, MCA  |  |
| MTS_0150-0310-0010-0240 | 200 | 9850 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0240/0150-0310-0010-0240.html |    15-31-124. Repealed, MCA  |  |
| MTS_0150-0310-0010-0250 | 200 | 9758 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0250/0150-0310-0010-0250.html |    15-31-125. Repealed, MCA  |  |
| MTS_0150-0310-0010-0260 | 200 | 9726 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0260/0150-0310-0010-0260.html |    15-31-126. Repealed, MCA  |  |
| MTS_0150-0310-0010-0270 | 200 | 9740 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0270/0150-0310-0010-0270.html |    15-31-127. Repealed, MCA  |  |
| MTS_0150-0310-0010-0280 | 200 | 9496 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0280/0150-0310-0010-0280.html |    15-31-128. and 15-31-129 reserved, MCA  |  |
| MTS_0150-0310-0010-0300 | 200 | 9741 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0300/0150-0310-0010-0300.html |    15-31-130. Repealed, MCA  |  |
| MTS_0150-0310-0010-0310 | 200 | 9859 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0310/0150-0310-0010-0310.html |    15-31-131. Repealed, MCA  |  |
| MTS_0150-0310-0010-0320 | 200 | 9725 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0320/0150-0310-0010-0320.html |    15-31-132. Repealed, MCA  |  |
| MTS_0150-0310-0010-0330 | 200 | 9694 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0330/0150-0310-0010-0330.html |    15-31-133. Repealed, MCA  |  |
| MTS_0150-0310-0010-0340 | 200 | 9695 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0340/0150-0310-0010-0340.html |    15-31-134. Repealed, MCA  |  |
| MTS_0150-0310-0010-0350 | 200 | 9726 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0350/0150-0310-0010-0350.html |    15-31-135. Repealed, MCA  |  |
| MTS_0150-0310-0010-0360 | 200 | 9726 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0360/0150-0310-0010-0360.html |    15-31-136. Repealed, MCA  |  |
| MTS_0150-0310-0010-0370 | 200 | 9713 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0370/0150-0310-0010-0370.html |    15-31-137. Repealed, MCA  |  |
| MTS_0150-0310-0010-0380 | 200 | 9581 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0380/0150-0310-0010-0380.html |    15-31-138. through 15-31-140 reserved, MCA  |  |
| MTS_0150-0310-0010-0410 | 200 | 14669 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0410/0150-0310-0010-0410.html |    15-31-141. Consolidated returns -- computation and procedure -- penalty and i |  |
| MTS_0150-0310-0010-0420 | 200 | 11373 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0420/0150-0310-0010-0420.html |    15-31-142. Reports upon merger of corporations, MCA  |  |
| MTS_0150-0310-0010-0430 | 200 | 11128 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0430/0150-0310-0010-0430.html |    15-31-143. Return and payment on corporate dissolution, MCA  |  |
| MTS_0150-0310-0010-0440 | 200 | 9551 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0440/0150-0310-0010-0440.html |    15-31-144. through 15-31-149 reserved, MCA  |  |
| MTS_0150-0310-0010-0500 | 200 | 9874 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0500/0150-0310-0010-0500.html |    15-31-150. Repealed, MCA  |  |
| MTS_0150-0310-0010-0510 | 200 | 11785 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0510/0150-0310-0010-0510.html |    15-31-151. Credit for preservation of historic buildings, MCA  |  |
| MTS_0150-0310-0010-0520 | 200 | 9750 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0520/0150-0310-0010-0520.html |    15-31-152. Repealed, MCA  |  |
| MTS_0150-0310-0010-0530 | 200 | 9625 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0530/0150-0310-0010-0530.html |    15-31-153. through 15-31-157 reserved, MCA  |  |
| MTS_0150-0310-0010-0580 | 200 | 10679 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0580/0150-0310-0010-0580.html |    15-31-158. Credit for providing supplemental funding to public schools -- cor |  |
| MTS_0150-0310-0010-0590 | 200 | 10563 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0590/0150-0310-0010-0590.html |    15-31-159. Qualified education corporate credit for contributions to student  |  |
| MTS_0150-0310-0010-0600 | 200 | 9587 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0600/0150-0310-0010-0600.html |    15-31-160. reserved, MCA  |  |
| MTS_0150-0310-0010-0610 | 200 | 12340 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0610/0150-0310-0010-0610.html |    15-31-161. Credit for contribution by corporations to qualified endowment --  |  |
| MTS_0150-0310-0010-0620 | 200 | 13108 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0620/0150-0310-0010-0620.html |    15-31-162. Small business corporation, partnership, and limited liability com |  |
| MTS_0150-0310-0010-0630 | 200 | 12566 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0630/0150-0310-0010-0630.html |    15-31-163. Capital gain exclusion from sale of mobile home park, MCA  |  |
| MTS_0150-0310-0010-0640 | 200 | 11274 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0640/0150-0310-0010-0640.html |    15-31-164. Notification of mobile home park owners, MCA  |  |
| MTS_0150-0310-0010-0650 | 200 | 11077 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0650/0150-0310-0010-0650.html |    15-31-165. Account for notification of mobile home park owners, MCA  |  |
| MTS_0150-0310-0010-0660 | 200 | 9561 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0660/0150-0310-0010-0660.html |    15-31-166. through 15-31-169 reserved, MCA  |  |
| MTS_0150-0310-0010-0700 | 200 | 9722 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0700/0150-0310-0010-0700.html |    15-31-170. Terminated, MCA  |  |
| MTS_0150-0310-0010-0710 | 200 | 9805 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0710/0150-0310-0010-0710.html |    15-31-171. Repealed, MCA  |  |
| MTS_0150-0310-0010-0720 | 200 | 11607 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0720/0150-0310-0010-0720.html |    15-31-172. Small business corporation -- deduction for donation of computer e |  |
| MTS_0150-0310-0010-0730 | 200 | 11407 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0730/0150-0310-0010-0730.html |    15-31-173. Tax credit for hiring registered apprentices or veteran apprentice |  |
| MTS_0150-0310-0010-0740 | 200 | 11542 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0740/0150-0310-0010-0740.html |    15-31-174. Corporate income tax credit for trades education and training, MCA |  |
| MTS_0150-0310-0010-0750 | 200 | 11239 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0010/section_0750/0150-0310-0010-0750.html |    15-31-175. Grow Montana jobs -- annual job growth incentive tax credit, MCA  |  |
| MTS_0150-0310-0020-0010 | 200 | 9375 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0020/section_0010/0150-0310-0020-0010.html |    15-31-201. Renumbered 15-30-1101, MCA  |  |
| MTS_0150-0310-0020-0020 | 200 | 10084 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0020/section_0020/0150-0310-0020-0020.html |    15-31-202. Repealed, MCA  |  |
| MTS_0150-0310-0020-0030 | 200 | 9579 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0020/section_0030/0150-0310-0020-0030.html |    15-31-203. Renumbered 15-30-1121, MCA  |  |
| MTS_0150-0310-0020-0040 | 200 | 9886 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0020/section_0040/0150-0310-0020-0040.html |    15-31-204. Repealed, MCA  |  |
| MTS_0150-0310-0020-0050 | 200 | 9816 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0020/section_0050/0150-0310-0020-0050.html |    15-31-205. Repealed, MCA  |  |
| MTS_0150-0310-0020-0060 | 200 | 9816 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0020/section_0060/0150-0310-0020-0060.html |    15-31-206. Repealed, MCA  |  |
| MTS_0150-0310-0020-0070 | 200 | 9816 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0020/section_0070/0150-0310-0020-0070.html |    15-31-207. Repealed, MCA  |  |
| MTS_0150-0310-0020-0080 | 200 | 9777 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0020/section_0080/0150-0310-0020-0080.html |    15-31-208. Repealed, MCA  |  |
| MTS_0150-0310-0020-0090 | 200 | 9545 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0020/section_0090/0150-0310-0020-0090.html |    15-31-209. Repealed, MCA  |  |
| MTS_0150-0310-0030-0010 | 200 | 11285 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0010/0150-0310-0030-0010.html |    15-31-301. Corporations subject to allocation and apportionment, MCA  |  |
| MTS_0150-0310-0030-0020 | 200 | 11962 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0020/0150-0310-0030-0020.html |    15-31-302. Definitions, MCA  |  |
| MTS_0150-0310-0030-0030 | 200 | 10285 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0030/0150-0310-0030-0030.html |    15-31-303. When taxable in another state, MCA  |  |
| MTS_0150-0310-0030-0040 | 200 | 10441 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0040/0150-0310-0030-0040.html |    15-31-304. Allocation of nonapportionable income, MCA  |  |
| MTS_0150-0310-0030-0050 | 200 | 10248 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0050/0150-0310-0030-0050.html |    15-31-305. Apportionment of apportionable income, MCA  |  |
| MTS_0150-0310-0030-0060 | 200 | 9968 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0060/0150-0310-0030-0060.html |    15-31-306. Repealed, MCA  |  |
| MTS_0150-0310-0030-0070 | 200 | 9945 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0070/0150-0310-0030-0070.html |    15-31-307. Repealed, MCA  |  |
| MTS_0150-0310-0030-0080 | 200 | 9940 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0080/0150-0310-0030-0080.html |    15-31-308. Repealed, MCA  |  |
| MTS_0150-0310-0030-0090 | 200 | 9961 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0090/0150-0310-0030-0090.html |    15-31-309. Repealed, MCA  |  |
| MTS_0150-0310-0030-0100 | 200 | 10174 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0100/0150-0310-0030-0100.html |    15-31-310. Definition of receipts factor, MCA  |  |
| MTS_0150-0310-0030-0110 | 200 | 10659 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0110/0150-0310-0030-0110.html |    15-31-311. Receipts factor for receipts in this state, MCA  |  |
| MTS_0150-0310-0030-0120 | 200 | 11458 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0120/0150-0310-0030-0120.html |    15-31-312. Apportionment formula -- unitary business provisions, MCA  |  |
| MTS_0150-0310-0030-0130 | 200 | 9998 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0130/0150-0310-0030-0130.html |    15-31-313. Rules, MCA  |  |
| MTS_0150-0310-0030-0140 | 200 | 9522 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0140/0150-0310-0030-0140.html |    15-31-314. through 15-31-320 reserved, MCA  |  |
| MTS_0150-0310-0030-0210 | 200 | 10773 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0210/0150-0310-0030-0210.html |    15-31-321. Definitions, MCA  |  |
| MTS_0150-0310-0030-0220 | 200 | 11681 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0220/0150-0310-0030-0220.html |    15-31-322. Water's-edge election, MCA  |  |
| MTS_0150-0310-0030-0230 | 200 | 10143 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0230/0150-0310-0030-0230.html |    15-31-323. Apportionment factors, MCA  |  |
| MTS_0150-0310-0030-0240 | 200 | 11196 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0240/0150-0310-0030-0240.html |    15-31-324. Water's-edge election period -- consent -- change of election, MCA |  |
| MTS_0150-0310-0030-0250 | 200 | 11908 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0250/0150-0310-0030-0250.html |    15-31-325. Treatment of dividends, MCA  |  |
| MTS_0150-0310-0030-0260 | 200 | 10060 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0030/section_0260/0150-0310-0030-0260.html |    15-31-326. Domestic disclosure spreadsheet, MCA  |  |
| MTS_0150-0310-0040-0010 | 200 | 10719 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0040/section_0010/0150-0310-0040-0010.html |    15-31-401. Application of corporate income tax and alternative corporate inco |  |
| MTS_0150-0310-0040-0020 | 200 | 10111 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0040/section_0020/0150-0310-0040-0020.html |    15-31-402. Short title -- administration of part, MCA  |  |
| MTS_0150-0310-0040-0030 | 200 | 12703 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0040/section_0030/0150-0310-0040-0030.html |    15-31-403. Rate of tax imposed -- income from sources within state defined -- |  |
| MTS_0150-0310-0040-0040 | 200 | 10924 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0040/section_0040/0150-0310-0040-0040.html |    15-31-404. Offset for corporate income taxes -- alternative corporate income  |  |
| MTS_0150-0310-0040-0050 | 200 | 10441 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0040/section_0050/0150-0310-0040-0050.html |    15-31-405. Information return -- period for assessment of tax, MCA  |  |
| MTS_0150-0310-0040-0060 | 200 | 13140 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0040/section_0060/0150-0310-0040-0060.html |    15-31-406. Corporate income tax sections incorporated by reference, MCA  |  |
| MTS_0150-0310-0040-0070 | 200 | 10008 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0040/section_0070/0150-0310-0040-0070.html |    15-31-407. Employment of personnel -- rules, MCA  |  |
| MTS_0150-0310-0040-0080 | 200 | 9527 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0040/section_0080/0150-0310-0040-0080.html |    15-31-408. Repealed, MCA  |  |
| MTS_0150-0310-0050-0010 | 200 | 10388 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0010/0150-0310-0050-0010.html |    15-31-501. Department rules -- conformance with Internal Revenue Code, MCA  |  |
| MTS_0150-0310-0050-0020 | 200 | 15263 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0020/0150-0310-0050-0020.html |    15-31-502. Assessment and payment of tax -- estimated tax payment -- amount o |  |
| MTS_0150-0310-0050-0030 | 200 | 11269 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0030/0150-0310-0050-0030.html |    15-31-503. Deficiency assessment -- notice -- penalty and interest, MCA  |  |
| MTS_0150-0310-0050-0040 | 200 | 10873 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0040/0150-0310-0050-0040.html |    15-31-504. Estimated tax on failure to file, MCA  |  |
| MTS_0150-0310-0050-0050 | 200 | 11297 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0050/0150-0310-0050-0050.html |    15-31-505. Subpoenas -- investigation of income, and shifting, MCA  |  |
| MTS_0150-0310-0050-0060 | 200 | 11351 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0060/0150-0310-0050-0060.html |    15-31-506. Copy of federal return required -- report of amended federal retur |  |
| MTS_0150-0310-0050-0070 | 200 | 9878 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0070/0150-0310-0050-0070.html |    15-31-507. Repealed, MCA  |  |
| MTS_0150-0310-0050-0080 | 200 | 9775 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0080/0150-0310-0050-0080.html |    15-31-508. Repealed, MCA  |  |
| MTS_0150-0310-0050-0090 | 200 | 14876 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0090/0150-0310-0050-0090.html |    15-31-509. Periods of limitation, MCA  |  |
| MTS_0150-0310-0050-0100 | 200 | 15548 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0100/0150-0310-0050-0100.html |    15-31-510. Estimated payments -- tax returns -- penalty and interest, MCA  |  |
| MTS_0150-0310-0050-0110 | 200 | 18029 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0110/0150-0310-0050-0110.html |    15-31-511. Confidentiality of tax records, MCA  |  |
| MTS_0150-0310-0050-0120 | 200 | 9527 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0120/0150-0310-0050-0120.html |    15-31-512. through 15-31-520 reserved, MCA  |  |
| MTS_0150-0310-0050-0210 | 200 | 10779 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0210/0150-0310-0050-0210.html |    15-31-521. Closing agreements, MCA  |  |
| MTS_0150-0310-0050-0220 | 200 | 10664 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0220/0150-0310-0050-0220.html |    15-31-522. When immediate payment demanded, MCA  |  |
| MTS_0150-0310-0050-0230 | 200 | 11762 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0230/0150-0310-0050-0230.html |    15-31-523. Suspension or forfeiture on delinquency, MCA  |  |
| MTS_0150-0310-0050-0240 | 200 | 11628 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0240/0150-0310-0050-0240.html |    15-31-524. Reviver of corporation after suspension or forfeiture, MCA  |  |
| MTS_0150-0310-0050-0250 | 200 | 10272 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0250/0150-0310-0050-0250.html |    15-31-525. Levy upon and sale of property, MCA  |  |
| MTS_0150-0310-0050-0260 | 200 | 10226 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0260/0150-0310-0050-0260.html |    15-31-526. Action by attorney general, MCA  |  |
| MTS_0150-0310-0050-0270 | 200 | 9765 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0270/0150-0310-0050-0270.html |    15-31-527. Repealed, MCA  |  |
| MTS_0150-0310-0050-0280 | 200 | 9536 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0280/0150-0310-0050-0280.html |    15-31-528. through 15-31-530 reserved, MCA  |  |
| MTS_0150-0310-0050-0310 | 200 | 11995 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0310/0150-0310-0050-0310.html |    15-31-531. Credit for overpayment -- interest on overpayment, MCA  |  |
| MTS_0150-0310-0050-0320 | 200 | 10349 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0320/0150-0310-0050-0320.html |    15-31-532. Application for refund -- appeal from denial, MCA  |  |
| MTS_0150-0310-0050-0330 | 200 | 9557 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0330/0150-0310-0050-0330.html |    15-31-533. through 15-31-540 reserved, MCA  |  |
| MTS_0150-0310-0050-0410 | 200 | 10373 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0410/0150-0310-0050-0410.html |    15-31-541. Site of failure to act -- evidence, MCA  |  |
| MTS_0150-0310-0050-0420 | 200 | 9800 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0420/0150-0310-0050-0420.html |    15-31-542. Repealed, MCA  |  |
| MTS_0150-0310-0050-0430 | 200 | 11320 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0430/0150-0310-0050-0430.html |    15-31-543. Forfeiture of right to engage in business -- penalties, MCA  |  |
| MTS_0150-0310-0050-0440 | 200 | 10358 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0440/0150-0310-0050-0440.html |    15-31-544. Action on false or fraudulent return, MCA  |  |
| MTS_0150-0310-0050-0450 | 200 | 9751 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0450/0150-0310-0050-0450.html |    15-31-545. Repealed, MCA  |  |
| MTS_0150-0310-0050-0460 | 200 | 9554 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0460/0150-0310-0050-0460.html |    15-31-546. through 15-31-550 reserved, MCA  |  |
| MTS_0150-0310-0050-0510 | 200 | 10433 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0510/0150-0310-0050-0510.html |    15-31-551. Certified copies of corporate income tax returns to taxpayer -- fe |  |
| MTS_0150-0310-0050-0520 | 200 | 11027 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0520/0150-0310-0050-0520.html |    15-31-552. Corporation dissolution or withdrawal certificates and tax clearan |  |
| MTS_0150-0310-0050-0530 | 200 | 10508 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0530/0150-0310-0050-0530.html |    15-31-553. Fees to reimburse department for costs -- deposit in general fund, |  |
| MTS_0150-0310-0050-0540 | 200 | 9888 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0050/section_0540/0150-0310-0050-0540.html |    15-31-554. Returns to which sections apply, MCA  |  |
| MTS_0150-0310-0060-0010 | 200 | 9500 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0060/section_0010/0150-0310-0060-0010.html |    15-31-601. Repealed, MCA  |  |
| MTS_0150-0310-0060-0020 | 200 | 9712 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0060/section_0020/0150-0310-0060-0020.html |    15-31-602. Repealed, MCA  |  |
| MTS_0150-0310-0060-0030 | 200 | 10791 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0060/section_0030/0150-0310-0060-0030.html |    15-31-603. List of entities furnished by secretary of state, MCA  |  |
| MTS_0150-0310-0060-0040 | 200 | 9712 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0060/section_0040/0150-0310-0060-0040.html |    15-31-604. Repealed, MCA  |  |
| MTS_0150-0310-0060-0050 | 200 | 9704 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0060/section_0050/0150-0310-0060-0050.html |    15-31-605. Repealed, MCA  |  |
| MTS_0150-0310-0060-0060 | 200 | 9672 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0060/section_0060/0150-0310-0060-0060.html |    15-31-606. Repealed, MCA  |  |
| MTS_0150-0310-0060-0070 | 200 | 9471 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0060/section_0070/0150-0310-0060-0070.html |    15-31-607. Repealed, MCA  |  |
| MTS_0150-0310-0070-0010 | 200 | 9567 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0070/section_0010/0150-0310-0070-0010.html |    15-31-701. Repealed, MCA  |  |
| MTS_0150-0310-0070-0020 | 200 | 9960 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0070/section_0020/0150-0310-0070-0020.html |    15-31-702. Repealed, MCA  |  |
| MTS_0150-0310-0070-0030 | 200 | 10088 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0070/section_0030/0150-0310-0070-0030.html |    15-31-703. Moneyed capital and shares of banks exempt, MCA  |  |
| MTS_0150-0310-0080-0010 | 200 | 9537 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0080/section_0010/0150-0310-0080-0010.html |    15-31-801. Repealed, MCA  |  |
| MTS_0150-0310-0080-0020 | 200 | 9741 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0080/section_0020/0150-0310-0080-0020.html |    15-31-802. Repealed, MCA  |  |
| MTS_0150-0310-0080-0030 | 200 | 9778 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0080/section_0030/0150-0310-0080-0030.html |    15-31-803. Repealed, MCA  |  |
| MTS_0150-0310-0080-0040 | 200 | 9741 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0080/section_0040/0150-0310-0080-0040.html |    15-31-804. Repealed, MCA  |  |
| MTS_0150-0310-0080-0050 | 200 | 9741 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0080/section_0050/0150-0310-0080-0050.html |    15-31-805. Repealed, MCA  |  |
| MTS_0150-0310-0080-0060 | 200 | 9741 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0080/section_0060/0150-0310-0080-0060.html |    15-31-806. Repealed, MCA  |  |
| MTS_0150-0310-0080-0070 | 200 | 9741 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0080/section_0070/0150-0310-0080-0070.html |    15-31-807. Repealed, MCA  |  |
| MTS_0150-0310-0080-0080 | 200 | 9540 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0080/section_0080/0150-0310-0080-0080.html |    15-31-808. Repealed, MCA  |  |
| MTS_0150-0310-0090-0010 | 200 | 9676 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0090/section_0010/0150-0310-0090-0010.html |    15-31-901. Terminated, MCA  |  |
| MTS_0150-0310-0090-0020 | 200 | 9882 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0090/section_0020/0150-0310-0090-0020.html |    15-31-902. Terminated, MCA  |  |
| MTS_0150-0310-0090-0030 | 200 | 9882 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0090/section_0030/0150-0310-0090-0030.html |    15-31-903. Terminated, MCA  |  |
| MTS_0150-0310-0090-0040 | 200 | 9882 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0090/section_0040/0150-0310-0090-0040.html |    15-31-904. Terminated, MCA  |  |
| MTS_0150-0310-0090-0050 | 200 | 9882 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0090/section_0050/0150-0310-0090-0050.html |    15-31-905. Terminated, MCA  |  |
| MTS_0150-0310-0090-0060 | 200 | 9943 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0090/section_0060/0150-0310-0090-0060.html |    15-31-906. Terminated, MCA  |  |
| MTS_0150-0310-0090-0070 | 200 | 9943 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0090/section_0070/0150-0310-0090-0070.html |    15-31-907. Terminated, MCA  |  |
| MTS_0150-0310-0090-0080 | 200 | 9941 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0090/section_0080/0150-0310-0090-0080.html |    15-31-908. Terminated, MCA  |  |
| MTS_0150-0310-0090-0090 | 200 | 9845 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0090/section_0090/0150-0310-0090-0090.html |    15-31-909. Repealed, MCA  |  |
| MTS_0150-0310-0090-0100 | 200 | 9881 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0090/section_0100/0150-0310-0090-0100.html |    15-31-910. Terminated, MCA  |  |
| MTS_0150-0310-0090-0110 | 200 | 9741 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0090/section_0110/0150-0310-0090-0110.html |    15-31-911. Terminated, MCA  |  |
| MTS_0150-0310-0100-0010 | 200 | 9509 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0010/0150-0310-0100-0010.html |    15-31-1001. Short title, MCA  |  |
| MTS_0150-0310-0100-0020 | 200 | 10571 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0020/0150-0310-0100-0020.html |    15-31-1002. Purpose, MCA  |  |
| MTS_0150-0310-0100-0030 | 200 | 28936 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0030/0150-0310-0100-0030.html |    15-31-1003. Definitions, MCA  |  |
| MTS_0150-0310-0100-0040 | 200 | 17713 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0040/0150-0310-0100-0040.html |    15-31-1004. Application for state certification, MCA  |  |
| MTS_0150-0310-0100-0050 | 200 | 16915 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0050/0150-0310-0100-0050.html |    15-31-1005. Submission of costs -- fee, MCA  |  |
| MTS_0150-0310-0100-0060 | 200 | 12737 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0060/0150-0310-0100-0060.html |    15-31-1006. Production expenditure verification report, MCA  |  |
| MTS_0150-0310-0100-0070 | 200 | 18826 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0070/0150-0310-0100-0070.html |    15-31-1007. Tax credit for media production, MCA  |  |
| MTS_0150-0310-0100-0080 | 200 | 12950 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0080/0150-0310-0100-0080.html |    15-31-1008. Transfer of tax credit for media production -- transfer fee, MCA  |  |
| MTS_0150-0310-0100-0090 | 200 | 13941 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0090/0150-0310-0100-0090.html |    15-31-1009. Tax credit for postproduction wages, MCA  |  |
| MTS_0150-0310-0100-0100 | 200 | 14927 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0100/0150-0310-0100-0100.html |    15-31-1010. Limitation of tax credits -- allocation -- fee, MCA  |  |
| MTS_0150-0310-0100-0110 | 200 | 12808 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0110/0150-0310-0100-0110.html |    15-31-1011. Report to legislature, MCA  |  |
| MTS_0150-0310-0100-0120 | 200 | 11017 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0120/0150-0310-0100-0120.html |    15-31-1012. Rulemaking, MCA  |  |
| MTS_0150-0310-0100-0130 | 200 | 10304 | https://leg.mt.gov/bills/mca/title_0150/chapter_0310/part_0100/section_0130/0150-0310-0100-0130.html |    15-31-1013. Media manufacturing industry workforce training account, MCA  |  |
| MTS_0150-0320-0010-0010 | 200 | 9841 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0010/section_0010/0150-0320-0010-0010.html |    15-32-101. Purpose, MCA  |  |
| MTS_0150-0320-0010-0020 | 200 | 14823 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0010/section_0020/0150-0320-0010-0020.html |    15-32-102. Definitions, MCA  |  |
| MTS_0150-0320-0010-0030 | 200 | 12774 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0010/section_0030/0150-0320-0010-0030.html |    15-32-103. Deduction for energy-conserving investments, MCA  |  |
| MTS_0150-0320-0010-0040 | 200 | 10239 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0010/section_0040/0150-0320-0010-0040.html |    15-32-104. Limitations on deduction and credit, MCA  |  |
| MTS_0150-0320-0010-0050 | 200 | 11017 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0010/section_0050/0150-0320-0010-0050.html |    15-32-105. Application to new construction -- rules, MCA  |  |
| MTS_0150-0320-0010-0060 | 200 | 10792 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0010/section_0060/0150-0320-0010-0060.html |    15-32-106. Procedure for obtaining benefit of deduction, MCA  |  |
| MTS_0150-0320-0010-0070 | 200 | 9982 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0010/section_0070/0150-0320-0010-0070.html |    15-32-107. Repealed, MCA  |  |
| MTS_0150-0320-0010-0080 | 200 | 9784 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0010/section_0080/0150-0320-0010-0080.html |    15-32-108. Repealed, MCA  |  |
| MTS_0150-0320-0010-0090 | 200 | 9809 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0010/section_0090/0150-0320-0010-0090.html |    15-32-109. Repealed, MCA  |  |
| MTS_0150-0320-0010-0100 | 200 | 9549 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0010/section_0100/0150-0320-0010-0100.html |    15-32-110. through 15-32-114 reserved, MCA  |  |
| MTS_0150-0320-0010-0150 | 200 | 9638 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0010/section_0150/0150-0320-0010-0150.html |    15-32-115. Repealed, MCA  |  |
| MTS_0150-0320-0020-0010 | 200 | 9799 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0020/section_0010/0150-0320-0020-0010.html |    15-32-201. Repealed, MCA  |  |
| MTS_0150-0320-0020-0020 | 200 | 9785 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0020/section_0020/0150-0320-0020-0020.html |    15-32-202. Repealed, MCA  |  |
| MTS_0150-0320-0020-0030 | 200 | 9675 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0020/section_0030/0150-0320-0020-0030.html |    15-32-203. Repealed, MCA  |  |
| MTS_0150-0320-0030-0010 | 200 | 10039 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0030/section_0010/0150-0320-0030-0010.html |    15-32-301. Purpose, MCA  |  |
| MTS_0150-0320-0030-0020 | 200 | 10984 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0030/section_0020/0150-0320-0030-0020.html |    15-32-302. Definitions, MCA  |  |
| MTS_0150-0320-0030-0030 | 200 | 10521 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0030/section_0030/0150-0320-0030-0030.html |    15-32-303. Deduction for purchase of Montana-produced organic or inorganic fe |  |
| MTS_0150-0320-0040-0010 | 200 | 9511 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0040/section_0010/0150-0320-0040-0010.html |    15-32-401. Repealed, MCA  |  |
| MTS_0150-0320-0040-0020 | 200 | 9787 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0040/section_0020/0150-0320-0040-0020.html |    15-32-402. Repealed, MCA  |  |
| MTS_0150-0320-0040-0030 | 200 | 9783 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0040/section_0030/0150-0320-0040-0030.html |    15-32-403. Repealed, MCA  |  |
| MTS_0150-0320-0040-0040 | 200 | 9745 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0040/section_0040/0150-0320-0040-0040.html |    15-32-404. Repealed, MCA  |  |
| MTS_0150-0320-0040-0050 | 200 | 9833 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0040/section_0050/0150-0320-0040-0050.html |    15-32-405. Repealed, MCA  |  |
| MTS_0150-0320-0040-0060 | 200 | 9683 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0040/section_0060/0150-0320-0040-0060.html |    15-32-406. Repealed, MCA  |  |
| MTS_0150-0320-0040-0070 | 200 | 9482 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0040/section_0070/0150-0320-0040-0070.html |    15-32-407. Repealed, MCA  |  |
| MTS_0150-0320-0050-0010 | 200 | 9509 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0050/section_0010/0150-0320-0050-0010.html |    15-32-501. Repealed, MCA  |  |
| MTS_0150-0320-0050-0020 | 200 | 9713 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0050/section_0020/0150-0320-0050-0020.html |    15-32-502. Repealed, MCA  |  |
| MTS_0150-0320-0050-0030 | 200 | 9744 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0050/section_0030/0150-0320-0050-0030.html |    15-32-503. Repealed, MCA  |  |
| MTS_0150-0320-0050-0040 | 200 | 9713 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0050/section_0040/0150-0320-0050-0040.html |    15-32-504. Repealed, MCA  |  |
| MTS_0150-0320-0050-0050 | 200 | 9713 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0050/section_0050/0150-0320-0050-0050.html |    15-32-505. Repealed, MCA  |  |
| MTS_0150-0320-0050-0060 | 200 | 9713 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0050/section_0060/0150-0320-0050-0060.html |    15-32-506. Repealed, MCA  |  |
| MTS_0150-0320-0050-0070 | 200 | 9744 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0050/section_0070/0150-0320-0050-0070.html |    15-32-507. Repealed, MCA  |  |
| MTS_0150-0320-0050-0080 | 200 | 9713 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0050/section_0080/0150-0320-0050-0080.html |    15-32-508. Repealed, MCA  |  |
| MTS_0150-0320-0050-0090 | 200 | 9713 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0050/section_0090/0150-0320-0050-0090.html |    15-32-509. Repealed, MCA  |  |
| MTS_0150-0320-0050-0100 | 200 | 9513 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0050/section_0100/0150-0320-0050-0100.html |    15-32-510. Repealed, MCA  |  |
| MTS_0150-0320-0060-0010 | 200 | 11605 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0060/section_0010/0150-0320-0060-0010.html |    15-32-601. Definitions, MCA  |  |
| MTS_0150-0320-0060-0020 | 200 | 11783 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0060/section_0020/0150-0320-0060-0020.html |    15-32-602. Amount and duration of credit -- how claimed, MCA  |  |
| MTS_0150-0320-0060-0030 | 200 | 14282 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0060/section_0030/0150-0320-0060-0030.html |    15-32-603. Credit for investment in property used to collect or process recla |  |
| MTS_0150-0320-0060-0040 | 200 | 10100 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0060/section_0040/0150-0320-0060-0040.html |    15-32-604. Limitation of credit, MCA  |  |
| MTS_0150-0320-0060-0050 | 200 | 9518 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0060/section_0050/0150-0320-0060-0050.html |    15-32-605. through 15-32-608 reserved, MCA  |  |
| MTS_0150-0320-0060-0090 | 200 | 12562 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0060/section_0090/0150-0320-0060-0090.html |    15-32-609. Recycled material qualifying for deduction -- purpose -- rulemakin |  |
| MTS_0150-0320-0060-0100 | 200 | 10272 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0060/section_0100/0150-0320-0060-0100.html |    15-32-610. Deduction for purchase of recycled material, MCA  |  |
| MTS_0150-0320-0060-0110 | 200 | 9570 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0060/section_0110/0150-0320-0060-0110.html |    15-32-611. Department to make rules, MCA  |  |
| MTS_0150-0320-0070-0010 | 200 | 9483 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0070/section_0010/0150-0320-0070-0010.html |    15-32-701. Repealed, MCA  |  |
| MTS_0150-0320-0070-0020 | 200 | 9687 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0070/section_0020/0150-0320-0070-0020.html |    15-32-702. Repealed, MCA  |  |
| MTS_0150-0320-0070-0030 | 200 | 9572 | https://leg.mt.gov/bills/mca/title_0150/chapter_0320/part_0070/section_0030/0150-0320-0070-0030.html |    15-32-703. Repealed, MCA  |  |
| MTS_0150-0330-0010-0010 | 200 | 9521 | https://leg.mt.gov/bills/mca/title_0150/chapter_0330/part_0010/section_0010/0150-0330-0010-0010.html |    15-33-101. Short title, MCA  |  |
| MTS_0150-0330-0010-0020 | 200 | 10441 | https://leg.mt.gov/bills/mca/title_0150/chapter_0330/part_0010/section_0020/0150-0330-0010-0020.html |    15-33-102. Purpose, MCA  |  |
| MTS_0150-0330-0010-0030 | 200 | 9894 | https://leg.mt.gov/bills/mca/title_0150/chapter_0330/part_0010/section_0030/0150-0330-0010-0030.html |    15-33-103. Definition, MCA  |  |
| MTS_0150-0330-0010-0040 | 200 | 10103 | https://leg.mt.gov/bills/mca/title_0150/chapter_0330/part_0010/section_0040/0150-0330-0010-0040.html |    15-33-104. Reporting -- recordkeeping by the department, MCA  |  |
| MTS_0150-0330-0010-0050 | 200 | 9855 | https://leg.mt.gov/bills/mca/title_0150/chapter_0330/part_0010/section_0050/0150-0330-0010-0050.html |    15-33-105. Rulemaking authority, MCA  |  |
| MTS_0150-0330-0010-0060 | 200 | 9811 | https://leg.mt.gov/bills/mca/title_0150/chapter_0330/part_0010/section_0060/0150-0330-0010-0060.html |    15-33-106. Capital gains -- dividends exempted, MCA  |  |
| MTS_0150-0340-0010-0010 | 200 | 9432 | https://leg.mt.gov/bills/mca/title_0150/chapter_0340/part_0010/section_0010/0150-0340-0010-0010.html |    15-34-101. Repealed, MCA  |  |
| MTS_0150-0340-0010-0020 | 200 | 9636 | https://leg.mt.gov/bills/mca/title_0150/chapter_0340/part_0010/section_0020/0150-0340-0010-0020.html |    15-34-102. Repealed, MCA  |  |
| MTS_0150-0340-0010-0030 | 200 | 9637 | https://leg.mt.gov/bills/mca/title_0150/chapter_0340/part_0010/section_0030/0150-0340-0010-0030.html |    15-34-103. Repealed, MCA  |  |
| MTS_0150-0340-0010-0040 | 200 | 9636 | https://leg.mt.gov/bills/mca/title_0150/chapter_0340/part_0010/section_0040/0150-0340-0010-0040.html |    15-34-104. Repealed, MCA  |  |
| MTS_0150-0340-0010-0050 | 200 | 9655 | https://leg.mt.gov/bills/mca/title_0150/chapter_0340/part_0010/section_0050/0150-0340-0010-0050.html |    15-34-105. Repealed, MCA  |  |
| MTS_0150-0340-0010-0060 | 200 | 9459 | https://leg.mt.gov/bills/mca/title_0150/chapter_0340/part_0010/section_0060/0150-0340-0010-0060.html |    15-34-106. through 15-34-109 reserved, MCA  |  |
| MTS_0150-0340-0010-0100 | 200 | 9655 | https://leg.mt.gov/bills/mca/title_0150/chapter_0340/part_0010/section_0100/0150-0340-0010-0100.html |    15-34-110. Repealed, MCA  |  |
| MTS_0150-0340-0010-0110 | 200 | 9637 | https://leg.mt.gov/bills/mca/title_0150/chapter_0340/part_0010/section_0110/0150-0340-0010-0110.html |    15-34-111. Repealed, MCA  |  |
| MTS_0150-0340-0010-0120 | 200 | 9651 | https://leg.mt.gov/bills/mca/title_0150/chapter_0340/part_0010/section_0120/0150-0340-0010-0120.html |    15-34-112. Repealed, MCA  |  |
| MTS_0150-0340-0010-0130 | 200 | 9439 | https://leg.mt.gov/bills/mca/title_0150/chapter_0340/part_0010/section_0130/0150-0340-0010-0130.html |    15-34-113. and 15-34-114 reserved, MCA  |  |
| MTS_0150-0340-0010-0150 | 200 | 9688 | https://leg.mt.gov/bills/mca/title_0150/chapter_0340/part_0010/section_0150/0150-0340-0010-0150.html |    15-34-115. Repealed, MCA  |  |
| MTS_0150-0340-0010-0160 | 200 | 9436 | https://leg.mt.gov/bills/mca/title_0150/chapter_0340/part_0010/section_0160/0150-0340-0010-0160.html |    15-34-116. Repealed, MCA  |  |
| MTS_0150-0350-0010-0010 | 200 | 13152 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0010/0150-0350-0010-0010.html |    15-35-101. Legislative findings and declarations of purpose, MCA  |  |
| MTS_0150-0350-0010-0020 | 200 | 18219 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0020/0150-0350-0010-0020.html |    15-35-102. Definitions, MCA  |  |
| MTS_0150-0350-0010-0030 | 200 | 13128 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0030/0150-0350-0010-0030.html |    15-35-103. Severance tax -- rates imposed, MCA  |  |
| MTS_0150-0350-0010-0040 | 200 | 10733 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0040/0150-0350-0010-0040.html |    15-35-104. Quarterly statement and payment of tax, MCA  |  |
| MTS_0150-0350-0010-0050 | 200 | 10682 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0050/0150-0350-0010-0050.html |    15-35-105. Penalty and interest for delinquent tax -- waiver, MCA  |  |
| MTS_0150-0350-0010-0060 | 200 | 10226 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0060/0150-0350-0010-0060.html |    15-35-106. Annual testing of samples, MCA  |  |
| MTS_0150-0350-0010-0070 | 200 | 11280 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0070/0150-0350-0010-0070.html |    15-35-107. When value of coal may be imputed -- procedure, MCA  |  |
| MTS_0150-0350-0010-0080 | 200 | 24190 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0080/0150-0350-0010-0080.html |    15-35-108. Disposal of severance taxes, MCA  |  |
| MTS_0150-0350-0010-0090 | 200 | 9629 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0090/0150-0350-0010-0090.html |    15-35-109. Repealed, MCA  |  |
| MTS_0150-0350-0010-0100 | 200 | 9400 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0100/0150-0350-0010-0100.html |    15-35-110. Renumbered 15-35-121, MCA  |  |
| MTS_0150-0350-0010-0110 | 200 | 9447 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0110/0150-0350-0010-0110.html |    15-35-111. Renumbered 15-35-122, MCA  |  |
| MTS_0150-0350-0010-0120 | 200 | 10675 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0120/0150-0350-0010-0120.html |    15-35-112. Deficiency assessment -- review -- penalty and interest, MCA  |  |
| MTS_0150-0350-0010-0130 | 200 | 11750 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0130/0150-0350-0010-0130.html |    15-35-113. Credit for overpayment -- interest on overpayment, MCA  |  |
| MTS_0150-0350-0010-0140 | 200 | 11509 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0140/0150-0350-0010-0140.html |    15-35-114. Statute of limitations, MCA  |  |
| MTS_0150-0350-0010-0150 | 200 | 9432 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0150/0150-0350-0010-0150.html |    15-35-115. through 15-35-120 reserved, MCA  |  |
| MTS_0150-0350-0010-0210 | 200 | 10148 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0210/0150-0350-0010-0210.html |    15-35-121. Penalties for neglect or false statement, MCA  |  |
| MTS_0150-0350-0010-0220 | 200 | 9616 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0010/section_0220/0150-0350-0010-0220.html |    15-35-122. Rulemaking authority, MCA  |  |
| MTS_0150-0350-0020-0010 | 200 | 9471 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0020/section_0010/0150-0350-0020-0010.html |    15-35-201. Repealed, MCA  |  |
| MTS_0150-0350-0020-0020 | 200 | 9736 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0020/section_0020/0150-0350-0020-0020.html |    15-35-202. Repealed, MCA  |  |
| MTS_0150-0350-0020-0030 | 200 | 9706 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0020/section_0030/0150-0350-0020-0030.html |    15-35-203. Repealed, MCA  |  |
| MTS_0150-0350-0020-0040 | 200 | 9675 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0020/section_0040/0150-0350-0020-0040.html |    15-35-204. Repealed, MCA  |  |
| MTS_0150-0350-0020-0050 | 200 | 9474 | https://leg.mt.gov/bills/mca/title_0150/chapter_0350/part_0020/section_0050/0150-0350-0020-0050.html |    15-35-205. Repealed, MCA  |  |
| MTS_0150-0360-0010-0010 | 200 | 10294 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0010/0150-0360-0010-0010.html |    15-36-101. Repealed, MCA  |  |
| MTS_0150-0360-0010-0020 | 200 | 9893 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0020/0150-0360-0010-0020.html |    15-36-102. Repealed, MCA  |  |
| MTS_0150-0360-0010-0030 | 200 | 9792 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0030/0150-0360-0010-0030.html |    15-36-103. Repealed, MCA  |  |
| MTS_0150-0360-0010-0040 | 200 | 9868 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0040/0150-0360-0010-0040.html |    15-36-104. Repealed, MCA  |  |
| MTS_0150-0360-0010-0050 | 200 | 10019 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0050/0150-0360-0010-0050.html |    15-36-105. Repealed, MCA  |  |
| MTS_0150-0360-0010-0060 | 200 | 9728 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0060/0150-0360-0010-0060.html |    15-36-106. Repealed, MCA  |  |
| MTS_0150-0360-0010-0070 | 200 | 9978 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0070/0150-0360-0010-0070.html |    15-36-107. Repealed, MCA  |  |
| MTS_0150-0360-0010-0080 | 200 | 9746 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0080/0150-0360-0010-0080.html |    15-36-108. Repealed, MCA  |  |
| MTS_0150-0360-0010-0090 | 200 | 9731 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0090/0150-0360-0010-0090.html |    15-36-109. Repealed, MCA  |  |
| MTS_0150-0360-0010-0100 | 200 | 9699 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0100/0150-0360-0010-0100.html |    15-36-110. Repealed, MCA  |  |
| MTS_0150-0360-0010-0110 | 200 | 9760 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0110/0150-0360-0010-0110.html |    15-36-111. Repealed, MCA  |  |
| MTS_0150-0360-0010-0120 | 200 | 10035 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0120/0150-0360-0010-0120.html |    15-36-112. Repealed, MCA  |  |
| MTS_0150-0360-0010-0130 | 200 | 9676 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0130/0150-0360-0010-0130.html |    15-36-113. Repealed, MCA  |  |
| MTS_0150-0360-0010-0140 | 200 | 9662 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0140/0150-0360-0010-0140.html |    15-36-114. Repealed, MCA  |  |
| MTS_0150-0360-0010-0150 | 200 | 9435 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0150/0150-0360-0010-0150.html |    15-36-115. through 15-36-119 reserved, MCA  |  |
| MTS_0150-0360-0010-0200 | 200 | 9632 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0200/0150-0360-0010-0200.html |    15-36-120. Repealed, MCA  |  |
| MTS_0150-0360-0010-0210 | 200 | 10013 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0210/0150-0360-0010-0210.html |    15-36-121. Repealed, MCA  |  |
| MTS_0150-0360-0010-0220 | 200 | 9632 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0220/0150-0360-0010-0220.html |    15-36-122. Repealed, MCA  |  |
| MTS_0150-0360-0010-0230 | 200 | 9435 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0230/0150-0360-0010-0230.html |    15-36-123. through 15-36-125 reserved, MCA  |  |
| MTS_0150-0360-0010-0260 | 200 | 9501 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0010/section_0260/0150-0360-0010-0260.html |    15-36-126. Repealed, MCA  |  |
| MTS_0150-0360-0030-0010 | 200 | 9479 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0010/0150-0360-0030-0010.html |    15-36-301. Short title, MCA  |  |
| MTS_0150-0360-0030-0020 | 200 | 11620 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0020/0150-0360-0030-0020.html |    15-36-302. Legislative findings and declaration of purpose, MCA  |  |
| MTS_0150-0360-0030-0030 | 200 | 24610 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0030/0150-0360-0030-0030.html |    15-36-303. Definitions, MCA  |  |
| MTS_0150-0360-0030-0040 | 200 | 31688 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0040/0150-0360-0030-0040.html |    15-36-304. Production tax rates imposed on oil and natural gas -- exemption,  |  |
| MTS_0150-0360-0030-0050 | 200 | 10826 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0050/0150-0360-0030-0050.html |    15-36-305. Determination of gross value of product, MCA  |  |
| MTS_0150-0360-0030-0060 | 200 | 9485 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0060/0150-0360-0030-0060.html |    15-36-306. through 15-36-308 reserved, MCA  |  |
| MTS_0150-0360-0030-0090 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0090/0150-0360-0030-0090.html |    15-36-309. Certain royalties exempt, MCA  |  |
| MTS_0150-0360-0030-0100 | 200 | 10849 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0100/0150-0360-0030-0100.html |    15-36-310. Operator responsible for payment -- deduction of taxes from royalt |  |
| MTS_0150-0360-0030-0110 | 200 | 11944 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0110/0150-0360-0030-0110.html |    15-36-311. Quarterly payment of tax -- statement -- failure to pay penalty, M |  |
| MTS_0150-0360-0030-0120 | 200 | 10769 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0120/0150-0360-0030-0120.html |    15-36-312. Record of product -- carriers to furnish data -- penalty, MCA  |  |
| MTS_0150-0360-0030-0130 | 200 | 11807 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0130/0150-0360-0030-0130.html |    15-36-313. Procedure to compute tax in absence of statement -- estimation of  |  |
| MTS_0150-0360-0030-0140 | 200 | 11016 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0140/0150-0360-0030-0140.html |    15-36-314. Deficiency assessment -- review -- penalty and interest, MCA  |  |
| MTS_0150-0360-0030-0150 | 200 | 12922 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0150/0150-0360-0030-0150.html |    15-36-315. Credit or refund for overpayment -- refund from county -- interest |  |
| MTS_0150-0360-0030-0160 | 200 | 9524 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0160/0150-0360-0030-0160.html |    15-36-316. through 15-36-318 reserved, MCA  |  |
| MTS_0150-0360-0030-0190 | 200 | 9915 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0190/0150-0360-0030-0190.html |    15-36-319. Warrant for distraint, MCA  |  |
| MTS_0150-0360-0030-0200 | 200 | 9645 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0200/0150-0360-0030-0200.html |    15-36-320. Repealed, MCA  |  |
| MTS_0150-0360-0030-0210 | 200 | 11499 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0210/0150-0360-0030-0210.html |    15-36-321. Statute of limitations, MCA  |  |
| MTS_0150-0360-0030-0220 | 200 | 9715 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0220/0150-0360-0030-0220.html |    15-36-322. Rulemaking authority, MCA  |  |
| MTS_0150-0360-0030-0230 | 200 | 9725 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0230/0150-0360-0030-0230.html |    15-36-323. Repealed, MCA  |  |
| MTS_0150-0360-0030-0240 | 200 | 10072 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0240/0150-0360-0030-0240.html |    15-36-324. Repealed, MCA  |  |
| MTS_0150-0360-0030-0250 | 200 | 9776 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0250/0150-0360-0030-0250.html |    15-36-325. Repealed, MCA  |  |
| MTS_0150-0360-0030-0260 | 200 | 10895 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0260/0150-0360-0030-0260.html |    15-36-326. Oil and natural gas accelerated tax fund, MCA  |  |
| MTS_0150-0360-0030-0270 | 200 | 9483 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0270/0150-0360-0030-0270.html |    15-36-327. through 15-36-330 reserved, MCA  |  |
| MTS_0150-0360-0030-0310 | 200 | 25310 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0310/0150-0360-0030-0310.html |    15-36-331. Distribution of taxes, MCA  |  |
| MTS_0150-0360-0030-0320 | 200 | 37507 | https://leg.mt.gov/bills/mca/title_0150/chapter_0360/part_0030/section_0320/0150-0360-0030-0320.html |    15-36-332. Distribution of taxes to taxing units -- appropriation, MCA  |  |
| MTS_0150-0370-0010-0010 | 200 | 11050 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0010/0150-0370-0010-0010.html |    15-37-101. License tax on metal mines, MCA  |  |
| MTS_0150-0370-0010-0020 | 200 | 10901 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0020/0150-0370-0010-0020.html |    15-37-102. Gross value of metal mine yield -- definitions, MCA  |  |
| MTS_0150-0370-0010-0030 | 200 | 13868 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0030/0150-0370-0010-0030.html |    15-37-103. Rate of tax, MCA  |  |
| MTS_0150-0370-0010-0040 | 200 | 12861 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0040/0150-0370-0010-0040.html |    15-37-104. Mine operator's statement of gross value -- reports and sampling,  |  |
| MTS_0150-0370-0010-0050 | 200 | 12152 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0050/0150-0370-0010-0050.html |    15-37-105. Computation and payment of tax, MCA  |  |
| MTS_0150-0370-0010-0060 | 200 | 11204 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0060/0150-0370-0010-0060.html |    15-37-106. Procedure in case of failure to file statements, MCA  |  |
| MTS_0150-0370-0010-0070 | 200 | 10006 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0070/0150-0370-0010-0070.html |    15-37-107. Warrant for distraint, MCA  |  |
| MTS_0150-0370-0010-0080 | 200 | 10784 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0080/0150-0370-0010-0080.html |    15-37-108. Delinquent taxes -- penalty and interest, MCA  |  |
| MTS_0150-0370-0010-0090 | 200 | 14056 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0090/0150-0370-0010-0090.html |    15-37-109. False or erroneous statements -- investigation penalty and interes |  |
| MTS_0150-0370-0010-0100 | 200 | 10501 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0100/0150-0370-0010-0100.html |    15-37-110. Review of determination of gross value of product or amount of tax |  |
| MTS_0150-0370-0010-0110 | 200 | 9910 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0110/0150-0370-0010-0110.html |    15-37-111. License tax supplemental, MCA  |  |
| MTS_0150-0370-0010-0120 | 200 | 10374 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0120/0150-0370-0010-0120.html |    15-37-112. Returns of dissolved corporations, MCA  |  |
| MTS_0150-0370-0010-0130 | 200 | 9772 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0130/0150-0370-0010-0130.html |    15-37-113. Repealed, MCA  |  |
| MTS_0150-0370-0010-0140 | 200 | 10670 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0140/0150-0370-0010-0140.html |    15-37-114. Deficiency assessment -- review -- penalty and interest, MCA  |  |
| MTS_0150-0370-0010-0150 | 200 | 11774 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0150/0150-0370-0010-0150.html |    15-37-115. Credit for overpayment -- interest on overpayment, MCA  |  |
| MTS_0150-0370-0010-0160 | 200 | 11538 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0160/0150-0370-0010-0160.html |    15-37-116. Statute of limitations, MCA  |  |
| MTS_0150-0370-0010-0170 | 200 | 21417 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0170/0150-0370-0010-0170.html |    15-37-117. Disposition of metalliferous mines license taxes, MCA  |  |
| MTS_0150-0370-0010-0180 | 200 | 9435 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0180/0150-0370-0010-0180.html |    15-37-118. through 15-37-125 reserved, MCA  |  |
| MTS_0150-0370-0010-0260 | 200 | 9418 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0010/section_0260/0150-0370-0010-0260.html |    15-37-126. Terminated, MCA  |  |
| MTS_0150-0370-0020-0010 | 200 | 10036 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0010/0150-0370-0020-0010.html |    15-37-201. License tax on micaceous mines, MCA  |  |
| MTS_0150-0370-0020-0020 | 200 | 10061 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0020/0150-0370-0020-0020.html |    15-37-202. Quarterly payment, MCA  |  |
| MTS_0150-0370-0020-0030 | 200 | 9926 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0030/0150-0370-0020-0030.html |    15-37-203. Records, MCA  |  |
| MTS_0150-0370-0020-0040 | 200 | 10899 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0040/0150-0370-0020-0040.html |    15-37-204. Quarterly return, MCA  |  |
| MTS_0150-0370-0020-0050 | 200 | 10888 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0050/0150-0370-0020-0050.html |    15-37-205. Procedure on failure to file statement, MCA  |  |
| MTS_0150-0370-0020-0060 | 200 | 10476 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0060/0150-0370-0020-0060.html |    15-37-206. Collection -- warrant for distraint, MCA  |  |
| MTS_0150-0370-0020-0070 | 200 | 9803 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0070/0150-0370-0020-0070.html |    15-37-207. Disposition of proceeds of tax, MCA  |  |
| MTS_0150-0370-0020-0080 | 200 | 9671 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0080/0150-0370-0020-0080.html |    15-37-208. Repealed, MCA  |  |
| MTS_0150-0370-0020-0090 | 200 | 9454 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0090/0150-0370-0020-0090.html |    15-37-209. Renumbered 15-37-221, MCA  |  |
| MTS_0150-0370-0020-0100 | 200 | 10694 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0100/0150-0370-0020-0100.html |    15-37-210. Deficiency assessment -- review -- penalty and interest, MCA  |  |
| MTS_0150-0370-0020-0110 | 200 | 11733 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0110/0150-0370-0020-0110.html |    15-37-211. Credit for overpayment -- interest on overpayment, MCA  |  |
| MTS_0150-0370-0020-0120 | 200 | 11528 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0120/0150-0370-0020-0120.html |    15-37-212. Statute of limitations, MCA  |  |
| MTS_0150-0370-0020-0130 | 200 | 9433 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0130/0150-0370-0020-0130.html |    15-37-213. through 15-37-220 reserved, MCA  |  |
| MTS_0150-0370-0020-0210 | 200 | 10002 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0210/0150-0370-0020-0210.html |    15-37-221. Penalty for violations, MCA  |  |
| MTS_0150-0370-0020-0220 | 200 | 9421 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0220/0150-0370-0020-0220.html |    15-37-222. through 15-37-225 reserved, MCA  |  |
| MTS_0150-0370-0020-0260 | 200 | 9430 | https://leg.mt.gov/bills/mca/title_0150/chapter_0370/part_0020/section_0260/0150-0370-0020-0260.html |    15-37-226. Terminated, MCA  |  |
| MTS_0150-0380-0010-0010 | 200 | 9571 | https://leg.mt.gov/bills/mca/title_0150/chapter_0380/part_0010/section_0010/0150-0380-0010-0010.html |    15-38-101. Short title, MCA  |  |
| MTS_0150-0380-0010-0020 | 200 | 10716 | https://leg.mt.gov/bills/mca/title_0150/chapter_0380/part_0010/section_0020/0150-0380-0010-0020.html |    15-38-102. Legislative policy, MCA  |  |
| MTS_0150-0380-0010-0030 | 200 | 11017 | https://leg.mt.gov/bills/mca/title_0150/chapter_0380/part_0010/section_0030/0150-0380-0010-0030.html |    15-38-103. Definitions, MCA  |  |
| MTS_0150-0380-0010-0040 | 200 | 13130 | https://leg.mt.gov/bills/mca/title_0150/chapter_0380/part_0010/section_0040/0150-0380-0010-0040.html |    15-38-104. Tax on mineral production, MCA  |  |
