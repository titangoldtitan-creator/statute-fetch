| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| SDC_60-9A | 200 | 109102 | https://sdlegislature.gov/api/Statutes/60-9A.html?all=true |  |  |
| SDC_60-10 | 200 | 124480 | https://sdlegislature.gov/api/Statutes/60-10.html?all=true |  |  |
| SDC_60-11 | 200 | 225796 | https://sdlegislature.gov/api/Statutes/60-11.html?all=true |  |  |
| SDC_60-12 | 200 | 153564 | https://sdlegislature.gov/api/Statutes/60-12.html?all=true |  |  |
| SDC_60-13 | 200 | 17272 | https://sdlegislature.gov/api/Statutes/60-13.html?all=true |  |  |
| SDC_60-14 | 200 | 49250 | https://sdlegislature.gov/api/Statutes/60-14.html?all=true |  |  |
| SDC_60-15 | 200 | 59250 | https://sdlegislature.gov/api/Statutes/60-15.html?all=true |  |  |
| SDC_61-1 | 200 | 553406 | https://sdlegislature.gov/api/Statutes/61-1.html?all=true |  |  |
| SDC_61-2 | 200 | 138304 | https://sdlegislature.gov/api/Statutes/61-2.html?all=true |  |  |
| SDC_61-3 | 200 | 224066 | https://sdlegislature.gov/api/Statutes/61-3.html?all=true |  |  |
| SDC_61-4 | 200 | 114414 | https://sdlegislature.gov/api/Statutes/61-4.html?all=true |  |  |
| SDC_61-5 | 200 | 1142930 | https://sdlegislature.gov/api/Statutes/61-5.html?all=true |  |  |
| SDC_61-5A | 200 | 274924 | https://sdlegislature.gov/api/Statutes/61-5A.html?all=true |  |  |
| SDC_61-6 | 200 | 693876 | https://sdlegislature.gov/api/Statutes/61-6.html?all=true |  |  |
| SDC_61-6A | 200 | 106986 | https://sdlegislature.gov/api/Statutes/61-6A.html?all=true |  |  |
| SDC_61-7 | 200 | 141000 | https://sdlegislature.gov/api/Statutes/61-7.html?all=true |  |  |
| SDC_62-1 | 200 | 270624 | https://sdlegislature.gov/api/Statutes/62-1.html?all=true |  |  |
| SDC_62-2 | 200 | 130992 | https://sdlegislature.gov/api/Statutes/62-2.html?all=true |  |  |
| SDC_62-3 | 200 | 120716 | https://sdlegislature.gov/api/Statutes/62-3.html?all=true |  |  |
| SDC_62-4 | 200 | 536498 | https://sdlegislature.gov/api/Statutes/62-4.html?all=true |  |  |
| SDC_62-5 | 200 | 165108 | https://sdlegislature.gov/api/Statutes/62-5.html?all=true |  |  |
| SDC_62-6 | 200 | 74984 | https://sdlegislature.gov/api/Statutes/62-6.html?all=true |  |  |
| SDC_62-7 | 200 | 276164 | https://sdlegislature.gov/api/Statutes/62-7.html?all=true |  |  |
| SDC_62-8 | 200 | 271822 | https://sdlegislature.gov/api/Statutes/62-8.html?all=true |  |  |
| SDC_62-9 | 200 | 122870 | https://sdlegislature.gov/api/Statutes/62-9.html?all=true |  |  |
