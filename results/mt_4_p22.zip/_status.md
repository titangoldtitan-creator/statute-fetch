| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0170-0060-0030-0230 | 200 | 10011 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0030/section_0230/0170-0060-0030-0230.html |    17-6-323. Repealed, MCA  |  |
| MTS_0170-0060-0030-0240 | 200 | 11421 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0030/section_0240/0170-0060-0030-0240.html |    17-6-324. Rulemaking authority, MCA  |  |
| MTS_0170-0060-0030-0250 | 200 | 10818 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0030/section_0250/0170-0060-0030-0250.html |    17-6-325. Preference of Montana labor, MCA  |  |
| MTS_0170-0060-0030-0260 | 200 | 9881 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0030/section_0260/0170-0060-0030-0260.html |    17-6-326. through 17-6-330 reserved, MCA  |  |
| MTS_0170-0060-0030-0310 | 200 | 10787 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0030/section_0310/0170-0060-0030-0310.html |    17-6-331. Establishment of a Montana economic development fund, MCA  |  |
| MTS_0170-0060-0030-0320 | 200 | 9862 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0030/section_0320/0170-0060-0030-0320.html |    17-6-332. through 17-6-339 reserved, MCA  |  |
| MTS_0170-0060-0030-0400 | 200 | 10104 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0030/section_0400/0170-0060-0030-0400.html |    17-6-340. Repealed, MCA  |  |
| MTS_0170-0060-0030-0410 | 200 | 9840 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0030/section_0410/0170-0060-0030-0410.html |    17-6-341. through 17-6-344 reserved, MCA  |  |
| MTS_0170-0060-0030-0450 | 200 | 11352 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0030/section_0450/0170-0060-0030-0450.html |    17-6-345. Intermediary relending program, MCA  |  |
| MTS_0170-0060-0030-0460 | 200 | 10708 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0030/section_0460/0170-0060-0030-0460.html |    17-6-346. Interest rates and repayment of intermediary loan -- terms, MCA  |  |
| MTS_0170-0060-0030-0470 | 200 | 10104 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0030/section_0470/0170-0060-0030-0470.html |    17-6-347. Purchase of seasoned or mature loans by board, MCA  |  |
| MTS_0170-0060-0040-0010 | 200 | 9839 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0040/section_0010/0170-0060-0040-0010.html |    17-6-401. Short title, MCA  |  |
| MTS_0170-0060-0040-0020 | 200 | 11897 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0040/section_0020/0170-0060-0040-0020.html |    17-6-402. Legislative findings and purpose, MCA  |  |
| MTS_0170-0060-0040-0030 | 200 | 12636 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0040/section_0030/0170-0060-0040-0030.html |    17-6-403. Definitions, MCA  |  |
| MTS_0170-0060-0040-0040 | 200 | 9863 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0040/section_0040/0170-0060-0040-0040.html |    17-6-404. and 17-6-405 reserved, MCA  |  |
| MTS_0170-0060-0040-0060 | 200 | 12874 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0040/section_0060/0170-0060-0040-0060.html |    17-6-406. Microbusiness finance program -- powers and duties of department, M |  |
| MTS_0170-0060-0040-0070 | 200 | 18468 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0040/section_0070/0170-0060-0040-0070.html |    17-6-407. Microbusiness development loan account -- criteria -- limitations,  |  |
| MTS_0170-0060-0040-0080 | 200 | 11722 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0040/section_0080/0170-0060-0040-0080.html |    17-6-408. Certification of microbusiness development corporations, MCA  |  |
| MTS_0170-0060-0040-0090 | 200 | 10743 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0040/section_0090/0170-0060-0040-0090.html |    17-6-409. Authority to accept funds -- funding authorization, MCA  |  |
| MTS_0170-0060-0040-0100 | 200 | 10305 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0040/section_0100/0170-0060-0040-0100.html |    17-6-410. Exemption from environmental review, MCA  |  |
| MTS_0170-0060-0040-0110 | 200 | 9865 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0040/section_0110/0170-0060-0040-0110.html |    17-6-411. Repealed, MCA  |  |
| MTS_0170-0060-0050-0010 | 200 | 9805 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0050/section_0010/0170-0060-0050-0010.html |    17-6-501. Repealed, MCA  |  |
| MTS_0170-0060-0050-0020 | 200 | 10008 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0050/section_0020/0170-0060-0050-0020.html |    17-6-502. Repealed, MCA  |  |
| MTS_0170-0060-0050-0030 | 200 | 10039 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0050/section_0030/0170-0060-0050-0030.html |    17-6-503. Repealed, MCA  |  |
| MTS_0170-0060-0050-0040 | 200 | 10008 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0050/section_0040/0170-0060-0050-0040.html |    17-6-504. Repealed, MCA  |  |
| MTS_0170-0060-0050-0050 | 200 | 10025 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0050/section_0050/0170-0060-0050-0050.html |    17-6-505. Repealed, MCA  |  |
| MTS_0170-0060-0050-0060 | 200 | 9824 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0050/section_0060/0170-0060-0050-0060.html |    17-6-506. through 17-6-508 reserved, MCA  |  |
| MTS_0170-0060-0050-0090 | 200 | 10056 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0050/section_0090/0170-0060-0050-0090.html |    17-6-509. Repealed, MCA  |  |
| MTS_0170-0060-0050-0100 | 200 | 10040 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0050/section_0100/0170-0060-0050-0100.html |    17-6-510. Repealed, MCA  |  |
| MTS_0170-0060-0050-0110 | 200 | 10039 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0050/section_0110/0170-0060-0050-0110.html |    17-6-511. Repealed, MCA  |  |
| MTS_0170-0060-0050-0120 | 200 | 9808 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0050/section_0120/0170-0060-0050-0120.html |    17-6-512. Repealed, MCA  |  |
| MTS_0170-0060-0060-0010 | 200 | 10312 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0060/section_0010/0170-0060-0060-0010.html |    17-6-601. Establishment -- purpose, MCA  |  |
| MTS_0170-0060-0060-0020 | 200 | 12819 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0060/section_0020/0170-0060-0060-0020.html |    17-6-602. Definitions, MCA  |  |
| MTS_0170-0060-0060-0030 | 200 | 11536 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0060/section_0030/0170-0060-0060-0030.html |    17-6-603. Montana tobacco settlement trust fund -- state special revenue fund |  |
| MTS_0170-0060-0060-0040 | 200 | 9933 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0060/section_0040/0170-0060-0060-0040.html |    17-6-604. and 17-6-605 reserved, MCA  |  |
| MTS_0170-0060-0060-0060 | 200 | 14233 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0060/section_0060/0170-0060-0060-0060.html |    17-6-606. Tobacco settlement accounts -- purpose -- uses, MCA  |  |
| MTS_0170-0060-0060-0070 | 200 | 9886 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0060/section_0070/0170-0060-0060-0070.html |    17-6-607. through 17-6-609 reserved, MCA  |  |
| MTS_0170-0060-0060-0100 | 200 | 9867 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0060/section_0100/0170-0060-0060-0100.html |    17-6-610. Repealed, MCA  |  |
| MTS_0170-0060-0070-0010 | 200 | 9905 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0070/section_0010/0170-0060-0070-0010.html |    17-6-701. Void, MCA  |  |
| MTS_0170-0060-0070-0020 | 200 | 10104 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0070/section_0020/0170-0060-0070-0020.html |    17-6-702. Void, MCA  |  |
| MTS_0170-0060-0070-0030 | 200 | 10104 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0070/section_0030/0170-0060-0070-0030.html |    17-6-703. Void, MCA  |  |
| MTS_0170-0060-0070-0040 | 200 | 10104 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0070/section_0040/0170-0060-0070-0040.html |    17-6-704. Void, MCA  |  |
| MTS_0170-0060-0070-0050 | 200 | 9908 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0070/section_0050/0170-0060-0070-0050.html |    17-6-705. Void, MCA  |  |
| MTS_0170-0060-0080-0010 | 200 | 10742 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0080/section_0010/0170-0060-0080-0010.html |    17-6-801. Montana housing infrastructure revolving loan fund account, MCA  |  |
| MTS_0170-0060-0080-0020 | 200 | 10694 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0080/section_0020/0170-0060-0080-0020.html |    17-6-802. Purpose, MCA  |  |
| MTS_0170-0060-0080-0030 | 200 | 10358 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0080/section_0030/0170-0060-0080-0030.html |    17-6-803. Terms, MCA  |  |
| MTS_0170-0060-0080-0040 | 200 | 10909 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0080/section_0040/0170-0060-0080-0040.html |    17-6-804. Eligibility -- priority, MCA  |  |
| MTS_0170-0060-0080-0050 | 200 | 13526 | https://leg.mt.gov/bills/mca/title_0170/chapter_0060/part_0080/section_0050/0170-0060-0080-0050.html |    17-6-805. Financing -- deed restrictions, MCA  |  |
| MTS_0170-0070-0010-0010 | 200 | 9949 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0010/0170-0070-0010-0010.html |    17-7-101. Short title, MCA  |  |
| MTS_0170-0070-0010-0020 | 200 | 25244 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0020/0170-0070-0010-0020.html |    17-7-102. Definitions, MCA  |  |
| MTS_0170-0070-0010-0030 | 200 | 10952 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0030/0170-0070-0010-0030.html |    17-7-103. Governor chief budget officer -- appointment of budget director, MC |  |
| MTS_0170-0070-0010-0040 | 200 | 10116 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0040/0170-0070-0010-0040.html |    17-7-104. Repealed, MCA  |  |
| MTS_0170-0070-0010-0050 | 200 | 10061 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0050/0170-0070-0010-0050.html |    17-7-105. Repealed, MCA  |  |
| MTS_0170-0070-0010-0060 | 200 | 10076 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0060/0170-0070-0010-0060.html |    17-7-106. Repealed, MCA  |  |
| MTS_0170-0070-0010-0070 | 200 | 9920 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0070/0170-0070-0010-0070.html |    17-7-107. through 17-7-110 reserved, MCA  |  |
| MTS_0170-0070-0010-0110 | 200 | 24650 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0110/0170-0070-0010-0110.html |    17-7-111. Preparation of state budget -- agency program budgets -- form distr |  |
| MTS_0170-0070-0010-0120 | 200 | 15653 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0120/0170-0070-0010-0120.html |    17-7-112. Submission deadlines -- budgeting schedule, MCA  |  |
| MTS_0170-0070-0010-0130 | 200 | 10608 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0130/0170-0070-0010-0130.html |    17-7-113. Inquiries and investigations by budget director, MCA  |  |
| MTS_0170-0070-0010-0140 | 200 | 10081 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0140/0170-0070-0010-0140.html |    17-7-114. Repealed, MCA  |  |
| MTS_0170-0070-0010-0150 | 200 | 9909 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0150/0170-0070-0010-0150.html |    17-7-115. through 17-7-120 reserved, MCA  |  |
| MTS_0170-0070-0010-0210 | 200 | 11660 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0210/0170-0070-0010-0210.html |    17-7-121. Preliminary budget preparation and submission to governor and gover |  |
| MTS_0170-0070-0010-0220 | 200 | 11432 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0220/0170-0070-0010-0220.html |    17-7-122. Preparation of budget, MCA  |  |
| MTS_0170-0070-0010-0230 | 200 | 15140 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0230/0170-0070-0010-0230.html |    17-7-123. Form of executive budget, MCA  |  |
| MTS_0170-0070-0010-0240 | 200 | 10405 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0240/0170-0070-0010-0240.html |    17-7-124. Additional budget data, MCA  |  |
| MTS_0170-0070-0010-0250 | 200 | 9927 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0250/0170-0070-0010-0250.html |    17-7-125. through 17-7-129 reserved, MCA  |  |
| MTS_0170-0070-0010-0300 | 200 | 17382 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0300/0170-0070-0010-0300.html |    17-7-130. Budget stabilization reserve fund -- rules for deposits and transfe |  |
| MTS_0170-0070-0010-0310 | 200 | 11546 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0310/0170-0070-0010-0310.html |    17-7-131. Legislative action -- ending fund balance, MCA  |  |
| MTS_0170-0070-0010-0320 | 200 | 10616 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0320/0170-0070-0010-0320.html |    17-7-132. Right to appear on consideration of budget, MCA  |  |
| MTS_0170-0070-0010-0330 | 200 | 11663 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0330/0170-0070-0010-0330.html |    17-7-133. Montana local disaster resiliency fund, MCA  |  |
| MTS_0170-0070-0010-0340 | 200 | 10022 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0340/0170-0070-0010-0340.html |    17-7-134. Repealed, MCA  |  |
| MTS_0170-0070-0010-0350 | 200 | 13670 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0350/0170-0070-0010-0350.html |    17-7-135. Pension fund, MCA  |  |
| MTS_0170-0070-0010-0360 | 200 | 9833 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0360/0170-0070-0010-0360.html |    17-7-136. and 17-7-137 reserved, MCA  |  |
| MTS_0170-0070-0010-0380 | 200 | 15414 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0380/0170-0070-0010-0380.html |    17-7-138. Operating budget, MCA  |  |
| MTS_0170-0070-0010-0390 | 200 | 13648 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0390/0170-0070-0010-0390.html |    17-7-139. Program transfers, MCA  |  |
| MTS_0170-0070-0010-0400 | 200 | 20251 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0400/0170-0070-0010-0400.html |    17-7-140. Reduction in spending, MCA  |  |
| MTS_0170-0070-0010-0410 | 200 | 10357 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0410/0170-0070-0010-0410.html |    17-7-141. Audit costs, MCA  |  |
| MTS_0170-0070-0010-0420 | 200 | 11246 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0420/0170-0070-0010-0420.html |    17-7-142. Calculation of reversions for funded resident enrollment growth in  |  |
| MTS_0170-0070-0010-0430 | 200 | 9928 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0430/0170-0070-0010-0430.html |    17-7-143. through 17-7-149 reserved, MCA  |  |
| MTS_0170-0070-0010-0500 | 200 | 12137 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0500/0170-0070-0010-0500.html |    17-7-150. Definitions, MCA  |  |
| MTS_0170-0070-0010-0510 | 200 | 11411 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0510/0170-0070-0010-0510.html |    17-7-151. Budget comparison, MCA  |  |
| MTS_0170-0070-0010-0520 | 200 | 10919 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0520/0170-0070-0010-0520.html |    17-7-152. Expenditure comparison, MCA  |  |
| MTS_0170-0070-0010-0530 | 200 | 10602 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0530/0170-0070-0010-0530.html |    17-7-153. State contributions to local government -- expenditure comparison,  |  |
| MTS_0170-0070-0010-0540 | 200 | 10139 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0540/0170-0070-0010-0540.html |    17-7-154. Terminated, MCA  |  |
| MTS_0170-0070-0010-0550 | 200 | 9885 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0550/0170-0070-0010-0550.html |    17-7-155. through 17-7-159 reserved, MCA  |  |
| MTS_0170-0070-0010-0600 | 200 | 11091 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0600/0170-0070-0010-0600.html |    17-7-160. Montana highway patrol exempt from vacancy savings, MCA  |  |
| MTS_0170-0070-0010-0610 | 200 | 11442 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0610/0170-0070-0010-0610.html |    17-7-161. Game warden positions exempt from vacancy savings, MCA  |  |
| MTS_0170-0070-0010-0620 | 200 | 11362 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0620/0170-0070-0010-0620.html |    17-7-162. Montana school for the deaf and blind exempt from vacancy savings,  |  |
| MTS_0170-0070-0010-0630 | 200 | 10058 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0010/section_0630/0170-0070-0010-0630.html |    17-7-163. Appropriations for medicaid expenditures, MCA  |  |
| MTS_0170-0070-0020-0010 | 200 | 16260 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0010/0170-0070-0020-0010.html |    17-7-201. Definitions, MCA  |  |
| MTS_0170-0070-0020-0020 | 200 | 15517 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0020/0170-0070-0020-0020.html |    17-7-202. Preparation of building programs and submission to department of ad |  |
| MTS_0170-0070-0020-0030 | 200 | 12857 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0030/0170-0070-0020-0030.html |    17-7-203. Submission to legislature, MCA  |  |
| MTS_0170-0070-0020-0040 | 200 | 10933 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0040/0170-0070-0020-0040.html |    17-7-204. Long-range building program for capital developments, MCA  |  |
| MTS_0170-0070-0020-0050 | 200 | 9905 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0050/0170-0070-0020-0050.html |    17-7-205. Renumbered 17-7-221, MCA  |  |
| MTS_0170-0070-0020-0060 | 200 | 10055 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0060/0170-0070-0020-0060.html |    17-7-206. Repealed, MCA  |  |
| MTS_0170-0070-0020-0070 | 200 | 9795 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0070/0170-0070-0020-0070.html |    17-7-207. reserved, MCA  |  |
| MTS_0170-0070-0020-0080 | 200 | 13999 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0080/0170-0070-0020-0080.html |    17-7-208. Capital development funding -- transfer as present law base, MCA  |  |
| MTS_0170-0070-0020-0090 | 200 | 12472 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0090/0170-0070-0020-0090.html |    17-7-209. Capital developments long-range building program account, MCA  |  |
| MTS_0170-0070-0020-0100 | 200 | 11592 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0100/0170-0070-0020-0100.html |    17-7-210. Required funding for maintenance of newly authorized state building |  |
| MTS_0170-0070-0020-0110 | 200 | 11288 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0110/0170-0070-0020-0110.html |    17-7-211. Expansion to be authorized -- budget amendment, MCA  |  |
| MTS_0170-0070-0020-0120 | 200 | 10358 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0120/0170-0070-0020-0120.html |    17-7-212. Reappropriation of capital projects, MCA  |  |
| MTS_0170-0070-0020-0130 | 200 | 11744 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0130/0170-0070-0020-0130.html |    17-7-213. High-performance building standards, MCA  |  |
| MTS_0170-0070-0020-0140 | 200 | 12452 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0140/0170-0070-0020-0140.html |    17-7-214. High-performance program for operations and maintenance of existing |  |
| MTS_0170-0070-0020-0150 | 200 | 13049 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0150/0170-0070-0020-0150.html |    17-7-215. Transfer of budgeted utility funds -- special revenue account -- un |  |
| MTS_0170-0070-0020-0160 | 200 | 9981 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0160/0170-0070-0020-0160.html |    17-7-216. through 17-7-220 reserved, MCA  |  |
| MTS_0170-0070-0020-0210 | 200 | 11366 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0210/0170-0070-0020-0210.html |    17-7-221. Major repair long-range building program account, MCA  |  |
| MTS_0170-0070-0020-0220 | 200 | 12997 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0220/0170-0070-0020-0220.html |    17-7-222. Minimum funding for major repair -- restriction of capital developm |  |
| MTS_0170-0070-0020-0230 | 200 | 14124 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0230/0170-0070-0020-0230.html |    17-7-223. Major repair -- submission of list to legislature -- priorities, MC |  |
| MTS_0170-0070-0020-0240 | 200 | 10965 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0240/0170-0070-0020-0240.html |    17-7-224. Funding for major repair -- emergency funding, MCA  |  |
| MTS_0170-0070-0020-0250 | 200 | 10682 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0250/0170-0070-0020-0250.html |    17-7-225. Capitol complex executive branch state special revenue account, MCA |  |
| MTS_0170-0070-0020-0260 | 200 | 13502 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0260/0170-0070-0020-0260.html |    17-7-226. Eligible use of funds, MCA  |  |
| MTS_0170-0070-0020-0270 | 200 | 10666 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0270/0170-0070-0020-0270.html |    17-7-227. Capitol complex legislative branch state special revenue account, M |  |
| MTS_0170-0070-0020-0280 | 200 | 13803 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0020/section_0280/0170-0070-0020-0280.html |    17-7-228. Eligible use of funds, MCA  |  |
| MTS_0170-0070-0030-0010 | 200 | 16227 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0030/section_0010/0170-0070-0030-0010.html |    17-7-301. Authorization to expend during first year of biennium from appropri |  |
| MTS_0170-0070-0030-0020 | 200 | 11590 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0030/section_0020/0170-0070-0030-0020.html |    17-7-302. Encumbrance of fiscal yearend obligations, MCA  |  |
| MTS_0170-0070-0030-0030 | 200 | 10728 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0030/section_0030/0170-0070-0030-0030.html |    17-7-303. Reappropriation of encumbered obligations at end of each fiscal yea |  |
| MTS_0170-0070-0030-0040 | 200 | 16281 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0030/section_0040/0170-0070-0030-0040.html |    17-7-304. Disposal of unexpended appropriations, MCA  |  |
| MTS_0170-0070-0030-0050 | 200 | 10598 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0030/section_0050/0170-0070-0030-0050.html |    17-7-305. Supplemental appropriations for legislative agencies, MCA  |  |
| MTS_0170-0070-0030-0060 | 200 | 10021 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0030/section_0060/0170-0070-0030-0060.html |    17-7-306. through 17-7-310 reserved, MCA  |  |
| MTS_0170-0070-0030-0110 | 200 | 13907 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0030/section_0110/0170-0070-0030-0110.html |    17-7-311. Proposed fiscal year transfer supplemental appropriation -- procedu |  |
| MTS_0170-0070-0040-0010 | 200 | 9860 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0040/section_0010/0170-0070-0040-0010.html |    17-7-401. Repealed, MCA  |  |
| MTS_0170-0070-0040-0020 | 200 | 16672 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0040/section_0020/0170-0070-0040-0020.html |    17-7-402. Budget amendment requirements, MCA  |  |
| MTS_0170-0070-0040-0030 | 200 | 12164 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0040/section_0030/0170-0070-0040-0030.html |    17-7-403. Budget amendment certification, MCA  |  |
| MTS_0170-0070-0040-0040 | 200 | 11321 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0040/section_0040/0170-0070-0040-0040.html |    17-7-404. Budget amendment procedures, MCA  |  |
| MTS_0170-0070-0040-0050 | 200 | 10314 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0040/section_0050/0170-0070-0040-0050.html |    17-7-405. Voidness of improperly certified budget amendments, MCA  |  |
| MTS_0170-0070-0050-0010 | 200 | 10606 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0050/section_0010/0170-0070-0050-0010.html |    17-7-501. Appropriations -- type, MCA  |  |
| MTS_0170-0070-0050-0020 | 200 | 42363 | https://leg.mt.gov/bills/mca/title_0170/chapter_0070/part_0050/section_0020/0170-0070-0050-0020.html |    17-7-502. Statutory appropriations -- definition -- requisites for validity,  |  |
| MTS_0170-0080-0010-0010 | 200 | 14214 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0010/section_0010/0170-0080-0010-0010.html |    17-8-101. Appropriation and disbursement of money from treasury, MCA  |  |
| MTS_0170-0080-0010-0020 | 200 | 11834 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0010/section_0020/0170-0080-0010-0020.html |    17-8-102. Expenditure procedures -- quarterly allotment system, MCA  |  |
| MTS_0170-0080-0010-0030 | 200 | 12275 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0010/section_0030/0170-0080-0010-0030.html |    17-8-103. Expenditures in excess of appropriation unlawful -- conditions in a |  |
| MTS_0170-0080-0010-0040 | 200 | 11928 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0010/section_0040/0170-0080-0010-0040.html |    17-8-104. Civil penalties and remedies for violation, MCA  |  |
| MTS_0170-0080-0010-0050 | 200 | 12129 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0010/section_0050/0170-0080-0010-0050.html |    17-8-105. Definitions applicable to expenditure limitation, MCA  |  |
| MTS_0170-0080-0010-0060 | 200 | 11732 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0010/section_0060/0170-0080-0010-0060.html |    17-8-106. Expenditure limitation -- exception, MCA  |  |
| MTS_0170-0080-0010-0070 | 200 | 11248 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0010/section_0070/0170-0080-0010-0070.html |    17-8-107. Limitations on spending deferred inflows of resources -- exception  |  |
| MTS_0170-0080-0010-0080 | 200 | 10576 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0010/section_0080/0170-0080-0010-0080.html |    17-8-108. Prohibited uses of public funds, MCA  |  |
| MTS_0170-0080-0020-0010 | 200 | 10938 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0010/0170-0080-0020-0010.html |    17-8-201. Authorizations for disbursements -- submission of claim to departme |  |
| MTS_0170-0080-0020-0020 | 200 | 11142 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0020/0170-0080-0020-0020.html |    17-8-202. Preaudit and transmittal of claims, MCA  |  |
| MTS_0170-0080-0020-0030 | 200 | 10430 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0030/0170-0080-0020-0030.html |    17-8-203. Minimum refunds, MCA  |  |
| MTS_0170-0080-0020-0040 | 200 | 9816 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0040/0170-0080-0020-0040.html |    17-8-204. through 17-8-210 reserved, MCA  |  |
| MTS_0170-0080-0020-0110 | 200 | 11232 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0110/0170-0080-0020-0110.html |    17-8-211. Notice required for assignment of claims against state, MCA  |  |
| MTS_0170-0080-0020-0120 | 200 | 10300 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0120/0170-0080-0020-0120.html |    17-8-212. Effect of assignment, MCA  |  |
| MTS_0170-0080-0020-0130 | 200 | 9775 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0130/0170-0080-0020-0130.html |    17-8-213. through 17-8-220 reserved, MCA  |  |
| MTS_0170-0080-0020-0210 | 200 | 10398 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0210/0170-0080-0020-0210.html |    17-8-221. Repealed, MCA  |  |
| MTS_0170-0080-0020-0220 | 200 | 10371 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0220/0170-0080-0020-0220.html |    17-8-222. Repealed, MCA  |  |
| MTS_0170-0080-0020-0230 | 200 | 10025 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0230/0170-0080-0020-0230.html |    17-8-223. Repealed, MCA  |  |
| MTS_0170-0080-0020-0240 | 200 | 10182 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0240/0170-0080-0020-0240.html |    17-8-224. Repealed, MCA  |  |
| MTS_0170-0080-0020-0250 | 200 | 10220 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0250/0170-0080-0020-0250.html |    17-8-225. Repealed, MCA  |  |
| MTS_0170-0080-0020-0260 | 200 | 10042 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0260/0170-0080-0020-0260.html |    17-8-226. Repealed, MCA  |  |
| MTS_0170-0080-0020-0270 | 200 | 9763 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0270/0170-0080-0020-0270.html |    17-8-227. through 17-8-230 reserved, MCA  |  |
| MTS_0170-0080-0020-0310 | 200 | 9981 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0310/0170-0080-0020-0310.html |    17-8-231. Repealed, MCA  |  |
| MTS_0170-0080-0020-0320 | 200 | 9798 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0320/0170-0080-0020-0320.html |    17-8-232. through 17-8-240 reserved, MCA  |  |
| MTS_0170-0080-0020-0410 | 200 | 10883 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0410/0170-0080-0020-0410.html |    17-8-241. Definitions relating to interest assessment, MCA  |  |
| MTS_0170-0080-0020-0420 | 200 | 10867 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0420/0170-0080-0020-0420.html |    17-8-242. Interest assessed on amounts due, MCA  |  |
| MTS_0170-0080-0020-0430 | 200 | 10376 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0430/0170-0080-0020-0430.html |    17-8-243. Source for payment of interest, MCA  |  |
| MTS_0170-0080-0020-0440 | 200 | 11178 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0020/section_0440/0170-0080-0020-0440.html |    17-8-244. Exemptions, MCA  |  |
| MTS_0170-0080-0030-0010 | 200 | 11441 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0030/section_0010/0170-0080-0030-0010.html |    17-8-301. State money -- how expended by treasurer, MCA  |  |
| MTS_0170-0080-0030-0020 | 200 | 10452 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0030/section_0020/0170-0080-0030-0020.html |    17-8-302. Order in which warrants are drawn, MCA  |  |
| MTS_0170-0080-0030-0030 | 200 | 12305 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0030/section_0030/0170-0080-0030-0030.html |    17-8-303. Warrants -- presentation and cancellation, MCA  |  |
| MTS_0170-0080-0030-0040 | 200 | 11486 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0030/section_0040/0170-0080-0030-0040.html |    17-8-304. Payment and registry, MCA  |  |
| MTS_0170-0080-0030-0050 | 200 | 10817 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0030/section_0050/0170-0080-0030-0050.html |    17-8-305. Cost accounting for warrant, MCA  |  |
| MTS_0170-0080-0030-0060 | 200 | 11354 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0030/section_0060/0170-0080-0030-0060.html |    17-8-306. Issuance of replacement warrant, MCA  |  |
| MTS_0170-0080-0030-0070 | 200 | 10121 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0030/section_0070/0170-0080-0030-0070.html |    17-8-307. Repealed, MCA  |  |
| MTS_0170-0080-0030-0080 | 200 | 11167 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0030/section_0080/0170-0080-0030-0080.html |    17-8-308. Payment of interest -- land grant warrants, MCA  |  |
| MTS_0170-0080-0030-0090 | 200 | 9822 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0030/section_0090/0170-0080-0030-0090.html |    17-8-309. and 17-8-310 reserved, MCA  |  |
| MTS_0170-0080-0030-0110 | 200 | 12563 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0030/section_0110/0170-0080-0030-0110.html |    17-8-311. Payments to local government entities -- notice, MCA  |  |
| MTS_0170-0080-0030-0120 | 200 | 10533 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0030/section_0120/0170-0080-0030-0120.html |    17-8-312. Charges for services or supplies among agencies -- valid claim, MCA |  |
| MTS_0170-0080-0040-0010 | 200 | 9770 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0010/0170-0080-0040-0010.html |    17-8-401. Short title, MCA  |  |
| MTS_0170-0080-0040-0020 | 200 | 13801 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0020/0170-0080-0040-0020.html |    17-8-402. Definitions, MCA  |  |
| MTS_0170-0080-0040-0030 | 200 | 18159 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0030/0170-0080-0040-0030.html |    17-8-403. False claims -- procedures -- penalties, MCA  |  |
| MTS_0170-0080-0040-0040 | 200 | 11518 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0040/0170-0080-0040-0040.html |    17-8-404. Limitation of actions, MCA  |  |
| MTS_0170-0080-0040-0050 | 200 | 10527 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0050/0170-0080-0040-0050.html |    17-8-405. Investigation and civil action by government attorney, MCA  |  |
| MTS_0170-0080-0040-0060 | 200 | 14495 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0060/0170-0080-0040-0060.html |    17-8-406. Complaint by person -- civil action, MCA  |  |
| MTS_0170-0080-0040-0070 | 200 | 10383 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0070/0170-0080-0040-0070.html |    17-8-407. Dismissal of civil action, MCA  |  |
| MTS_0170-0080-0040-0080 | 200 | 10021 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0080/0170-0080-0040-0080.html |    17-8-408. Repealed, MCA  |  |
| MTS_0170-0080-0040-0090 | 200 | 10958 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0090/0170-0080-0040-0090.html |    17-8-409. Burden of proof -- effect of criminal conviction, MCA  |  |
| MTS_0170-0080-0040-0100 | 200 | 15110 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0100/0170-0080-0040-0100.html |    17-8-410. Distribution of damages and civil penalty, MCA  |  |
| MTS_0170-0080-0040-0110 | 200 | 11668 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0110/0170-0080-0040-0110.html |    17-8-411. Costs and attorney fees, MCA  |  |
| MTS_0170-0080-0040-0120 | 200 | 12695 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0120/0170-0080-0040-0120.html |    17-8-412. Retaliatory actions prohibited -- remedies, MCA  |  |
| MTS_0170-0080-0040-0130 | 200 | 10385 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0130/0170-0080-0040-0130.html |    17-8-413. Settlement by government attorney, MCA  |  |
| MTS_0170-0080-0040-0140 | 200 | 9787 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0140/0170-0080-0040-0140.html |    17-8-414. and 17-8-415 reserved, MCA  |  |
| MTS_0170-0080-0040-0160 | 200 | 11040 | https://leg.mt.gov/bills/mca/title_0170/chapter_0080/part_0040/section_0160/0170-0080-0040-0160.html |    17-8-416. Reporting, MCA  |  |
| MTS_0180-0010-0010-0010 | 200 | 11990 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0010/0180-0010-0010-0010.html |    18-1-101. Definitions, MCA  |  |
| MTS_0180-0010-0010-0020 | 200 | 12164 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0020/0180-0010-0010-0020.html |    18-1-102. State contracts to lowest bidder -- reciprocity, MCA  |  |
| MTS_0180-0010-0010-0030 | 200 | 11442 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0030/0180-0010-0010-0030.html |    18-1-103. Resident defined, MCA  |  |
| MTS_0180-0010-0010-0040 | 200 | 10092 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0040/0180-0010-0010-0040.html |    18-1-104. Repealed, MCA  |  |
| MTS_0180-0010-0010-0050 | 200 | 10232 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0050/0180-0010-0010-0050.html |    18-1-105. Repealed, MCA  |  |
| MTS_0180-0010-0010-0060 | 200 | 12560 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0060/0180-0010-0010-0060.html |    18-1-106. Department of labor and industry to determine residency of selected |  |
| MTS_0180-0010-0010-0070 | 200 | 10094 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0070/0180-0010-0010-0070.html |    18-1-107. through 18-1-109 reserved, MCA  |  |
| MTS_0180-0010-0010-0100 | 200 | 11699 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0100/0180-0010-0010-0100.html |    18-1-110. Hiring preference for residents of Indian reservations for state co |  |
| MTS_0180-0010-0010-0110 | 200 | 10509 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0110/0180-0010-0010-0110.html |    18-1-111. Impartiality to be shown in letting contracts, MCA  |  |
| MTS_0180-0010-0010-0120 | 200 | 10204 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0120/0180-0010-0010-0120.html |    18-1-112. Repealed, MCA  |  |
| MTS_0180-0010-0010-0130 | 200 | 10726 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0130/0180-0010-0010-0130.html |    18-1-113. Bidder to submit affidavit -- penalty, MCA  |  |
| MTS_0180-0010-0010-0140 | 200 | 10136 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0140/0180-0010-0010-0140.html |    18-1-114. Rules, MCA  |  |
| MTS_0180-0010-0010-0150 | 200 | 9870 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0150/0180-0010-0010-0150.html |    18-1-115. through 18-1-117 reserved, MCA  |  |
| MTS_0180-0010-0010-0180 | 200 | 10557 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0010/section_0180/0180-0010-0010-0180.html |    18-1-118. Access to records of contracting entities, MCA  |  |
| MTS_0180-0010-0020-0010 | 200 | 12183 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0020/section_0010/0180-0010-0020-0010.html |    18-1-201. Requirement for bidder's security, MCA  |  |
| MTS_0180-0010-0020-0020 | 200 | 12883 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0020/section_0020/0180-0010-0020-0020.html |    18-1-202. Advertisement for bid to specify required security, MCA  |  |
| MTS_0180-0010-0020-0030 | 200 | 11852 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0020/section_0030/0180-0010-0020-0030.html |    18-1-203. Form of security, MCA  |  |
| MTS_0180-0010-0020-0040 | 200 | 11418 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0020/section_0040/0180-0010-0020-0040.html |    18-1-204. Forfeiture -- bidder's liability -- waiver, MCA  |  |
| MTS_0180-0010-0020-0050 | 200 | 10203 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0020/section_0050/0180-0010-0020-0050.html |    18-1-205. Return of bid security, MCA  |  |
| MTS_0180-0010-0020-0060 | 200 | 10205 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0020/section_0060/0180-0010-0020-0060.html |    18-1-206. Effect of compliance, MCA  |  |
| MTS_0180-0010-0030-0010 | 200 | 12695 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0030/section_0010/0180-0010-0030-0010.html |    18-1-301. Contractor withdrawals -- deposit of obligations, MCA  |  |
| MTS_0180-0010-0030-0020 | 200 | 10732 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0030/section_0020/0180-0010-0030-0020.html |    18-1-302. Servicing of deposited obligations, MCA  |  |
| MTS_0180-0010-0030-0030 | 200 | 11114 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0030/section_0030/0180-0010-0030-0030.html |    18-1-303. Interest or income on deposits to contractor, MCA  |  |
| MTS_0180-0010-0030-0040 | 200 | 10751 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0030/section_0040/0180-0010-0030-0040.html |    18-1-304. Priority of deductions from retained payments and proceeds of depos |  |
| MTS_0180-0010-0040-0010 | 200 | 10122 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0040/section_0010/0180-0010-0040-0010.html |    18-1-401. Jurisdiction, MCA  |  |
| MTS_0180-0010-0040-0020 | 200 | 11316 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0040/section_0020/0180-0010-0040-0020.html |    18-1-402. Administrative procedures -- exhaustion -- time limitations, MCA  |  |
| MTS_0180-0010-0040-0030 | 200 | 10420 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0040/section_0030/0180-0010-0040-0030.html |    18-1-403. Stipulations restricting enforcement void, MCA  |  |
| MTS_0180-0010-0040-0040 | 200 | 12682 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0040/section_0040/0180-0010-0040-0040.html |    18-1-404. Liability of state -- interest -- costs, MCA  |  |
| MTS_0180-0010-0040-0050 | 200 | 9894 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0040/section_0050/0180-0010-0040-0050.html |    18-1-405. through 18-1-410 reserved, MCA  |  |
| MTS_0180-0010-0040-0110 | 200 | 10494 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0040/section_0110/0180-0010-0040-0110.html |    18-1-411. Practice and procedure, MCA  |  |
| MTS_0180-0010-0040-0120 | 200 | 10504 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0040/section_0120/0180-0010-0040-0120.html |    18-1-412. Service of process upon attorney general, MCA  |  |
| MTS_0180-0010-0040-0130 | 200 | 10741 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0040/section_0130/0180-0010-0040-0130.html |    18-1-413. Litigation -- compromise, MCA  |  |
| MTS_0180-0010-0040-0140 | 200 | 10028 | https://leg.mt.gov/bills/mca/title_0180/chapter_0010/part_0040/section_0140/0180-0010-0040-0140.html |    18-1-414. Judgments -- payment, MCA  |  |
| MTS_0180-0020-0010-0010 | 200 | 13444 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0010/0180-0020-0010-0010.html |    18-2-101. Definitions of building, costs, and construction, MCA  |  |
| MTS_0180-0020-0010-0020 | 200 | 13448 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0020/0180-0020-0010-0020.html |    18-2-102. Authority to construct buildings -- reporting requirement, MCA  |  |
| MTS_0180-0020-0010-0030 | 200 | 15297 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0030/0180-0020-0010-0030.html |    18-2-103. Supervision of construction of buildings, MCA  |  |
| MTS_0180-0020-0010-0040 | 200 | 10562 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0040/0180-0020-0010-0040.html |    18-2-104. Scheduling of state building program, MCA  |  |
| MTS_0180-0020-0010-0050 | 200 | 12543 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0050/0180-0020-0010-0050.html |    18-2-105. General powers and duties of department of administration, MCA  |  |
| MTS_0180-0020-0010-0060 | 200 | 10703 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0060/0180-0020-0010-0060.html |    18-2-106. Pecuniary interest prohibited, MCA  |  |
| MTS_0180-0020-0010-0070 | 200 | 11004 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0070/0180-0020-0010-0070.html |    18-2-107. Deposit of capitol building grant revenue, MCA  |  |
| MTS_0180-0020-0010-0080 | 200 | 10312 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0080/0180-0020-0010-0080.html |    18-2-108. Compliance with state laws and regulations, MCA  |  |
| MTS_0180-0020-0010-0090 | 200 | 10577 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0090/0180-0020-0010-0090.html |    18-2-109. Exemption from environmental review, MCA  |  |
| MTS_0180-0020-0010-0100 | 200 | 9810 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0100/0180-0020-0010-0100.html |    18-2-110. reserved, MCA  |  |
| MTS_0180-0020-0010-0110 | 200 | 12046 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0110/0180-0020-0010-0110.html |    18-2-111. Policy regarding practice of architecture or engineering -- prepara |  |
| MTS_0180-0020-0010-0120 | 200 | 10937 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0120/0180-0020-0010-0120.html |    18-2-112. Appointment of architects and consulting engineers, MCA  |  |
| MTS_0180-0020-0010-0130 | 200 | 10732 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0130/0180-0020-0010-0130.html |    18-2-113. Architects on public buildings to be certified, MCA  |  |
| MTS_0180-0020-0010-0140 | 200 | 10527 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0140/0180-0020-0010-0140.html |    18-2-114. Seal and signature of architect on plans, MCA  |  |
| MTS_0180-0020-0010-0150 | 200 | 10207 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0150/0180-0020-0010-0150.html |    18-2-115. Repealed, MCA  |  |
| MTS_0180-0020-0010-0160 | 200 | 9831 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0160/0180-0020-0010-0160.html |    18-2-116. through 18-2-120 reserved, MCA  |  |
| MTS_0180-0020-0010-0210 | 200 | 10733 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0210/0180-0020-0010-0210.html |    18-2-121. Engineer or land surveyor to supervise project, MCA  |  |
| MTS_0180-0020-0010-0220 | 200 | 10874 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0220/0180-0020-0010-0220.html |    18-2-122. Plans to bear seal, MCA  |  |
| MTS_0180-0020-0010-0230 | 200 | 10531 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0230/0180-0020-0010-0230.html |    18-2-123. Payment of contractors and subcontractors, MCA  |  |
| MTS_0180-0020-0010-0240 | 200 | 12104 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0010/section_0240/0180-0020-0010-0240.html |    18-2-124. Construction contract indemnification provisions, MCA  |  |
| MTS_0180-0020-0020-0010 | 200 | 14277 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0020/section_0010/0180-0020-0020-0010.html |    18-2-201. Security requirements, MCA  |  |
| MTS_0180-0020-0020-0020 | 200 | 11037 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0020/section_0020/0180-0020-0020-0020.html |    18-2-202. Failure to require security -- waiver, MCA  |  |
| MTS_0180-0020-0020-0030 | 200 | 10918 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0020/section_0030/0180-0020-0020-0030.html |    18-2-203. Amount and terms of security, MCA  |  |
| MTS_0180-0020-0020-0040 | 200 | 12561 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0020/section_0040/0180-0020-0020-0040.html |    18-2-204. Right of action on security -- notice, MCA  |  |
| MTS_0180-0020-0020-0050 | 200 | 10559 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0020/section_0050/0180-0020-0020-0050.html |    18-2-205. Effect of dealing with subcontractor, MCA  |  |
| MTS_0180-0020-0020-0060 | 200 | 12585 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0020/section_0060/0180-0020-0020-0060.html |    18-2-206. Notice to contractor concerning subcontractor, MCA  |  |
| MTS_0180-0020-0020-0070 | 200 | 10809 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0020/section_0070/0180-0020-0020-0070.html |    18-2-207. Costs -- attorney fees, MCA  |  |
| MTS_0180-0020-0020-0080 | 200 | 10955 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0020/section_0080/0180-0020-0020-0080.html |    18-2-208. Exceptions, MCA  |  |
| MTS_0180-0020-0030-0010 | 200 | 14363 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0010/0180-0020-0030-0010.html |    18-2-301. Bids required -- public notice, MCA  |  |
| MTS_0180-0020-0030-0020 | 200 | 12754 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0020/0180-0020-0030-0020.html |    18-2-302. Bid security -- waiver -- authority to submit, MCA  |  |
| MTS_0180-0020-0030-0030 | 200 | 13209 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0030/0180-0020-0030-0030.html |    18-2-303. Construction bids -- minimum requirements -- effect of failure to c |  |
| MTS_0180-0020-0030-0040 | 200 | 9969 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0040/0180-0020-0030-0040.html |    18-2-304. and 18-2-305 reserved, MCA  |  |
| MTS_0180-0020-0030-0060 | 200 | 13011 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0060/0180-0020-0030-0060.html |    18-2-306. Time of final acceptance and final payment on construction contract |  |
| MTS_0180-0020-0030-0070 | 200 | 9925 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0070/0180-0020-0030-0070.html |    18-2-307. through 18-2-310 reserved, MCA  |  |
| MTS_0180-0020-0030-0110 | 200 | 10082 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0110/0180-0020-0030-0110.html |    18-2-311. Repealed, MCA  |  |
| MTS_0180-0020-0030-0120 | 200 | 10326 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0120/0180-0020-0030-0120.html |    18-2-312. Excusable delays, MCA  |  |
| MTS_0180-0020-0030-0130 | 200 | 10722 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0130/0180-0020-0030-0130.html |    18-2-313. Contract provisions necessary for federal funds, MCA  |  |
| MTS_0180-0020-0030-0140 | 200 | 10419 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0140/0180-0020-0030-0140.html |    18-2-314. Cost-plus system invalid, MCA  |  |
| MTS_0180-0020-0030-0150 | 200 | 10651 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0150/0180-0020-0030-0150.html |    18-2-315. State purchasing not affected, MCA  |  |
| MTS_0180-0020-0030-0160 | 200 | 11057 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0160/0180-0020-0030-0160.html |    18-2-316. Limit on retainage for public contracts, MCA  |  |
| MTS_0180-0020-0030-0170 | 200 | 10109 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0030/section_0170/0180-0020-0030-0170.html |    18-2-317. State agency performance contracts -- exempt, MCA  |  |
| MTS_0180-0020-0040-0010 | 200 | 18026 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0010/0180-0020-0040-0010.html |    18-2-401. Definitions, MCA  |  |
| MTS_0180-0020-0040-0020 | 200 | 11465 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0020/0180-0020-0040-0020.html |    18-2-402. Standard prevailing rate of wages, MCA  |  |
| MTS_0180-0020-0040-0030 | 200 | 15699 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0030/0180-0020-0040-0030.html |    18-2-403. Preference of Montana labor in public works -- wages -- tax-exempt  |  |
| MTS_0180-0020-0040-0040 | 200 | 11250 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0040/0180-0020-0040-0040.html |    18-2-404. Approval of public works contract -- bond, MCA  |  |
| MTS_0180-0020-0040-0050 | 200 | 10363 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0050/0180-0020-0040-0050.html |    18-2-405. Repealed, MCA  |  |
| MTS_0180-0020-0040-0060 | 200 | 10840 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0060/0180-0020-0040-0060.html |    18-2-406. Posting wage scale and fringe benefits, MCA  |  |
| MTS_0180-0020-0040-0070 | 200 | 12170 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0070/0180-0020-0040-0070.html |    18-2-407. Forfeiture for failure to pay standard prevailing rate of wages, MC |  |
| MTS_0180-0020-0040-0080 | 200 | 10017 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0080/0180-0020-0040-0080.html |    18-2-408. Renumbered 18-2-432, MCA  |  |
| MTS_0180-0020-0040-0090 | 200 | 12090 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0090/0180-0020-0040-0090.html |    18-2-409. Montana residents to be employed on state construction contracts, M |  |
| MTS_0180-0020-0040-0100 | 200 | 9879 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0100/0180-0020-0040-0100.html |    18-2-410. reserved, MCA  |  |
| MTS_0180-0020-0040-0110 | 200 | 13161 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0110/0180-0020-0040-0110.html |    18-2-411. Creation of prevailing wage rate districts, MCA  |  |
| MTS_0180-0020-0040-0120 | 200 | 12203 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0120/0180-0020-0040-0120.html |    18-2-412. Method for payment of standard prevailing wage, MCA  |  |
| MTS_0180-0020-0040-0130 | 200 | 16307 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0130/0180-0020-0040-0130.html |    18-2-413. Standard prevailing rate of wages for building construction service |  |
| MTS_0180-0020-0040-0140 | 200 | 13086 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0140/0180-0020-0040-0140.html |    18-2-414. Standard prevailing rate of wages for heavy construction services a |  |
| MTS_0180-0020-0040-0150 | 200 | 15039 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0150/0180-0020-0040-0150.html |    18-2-415. Standard prevailing rate of wages for nonconstruction services -- s |  |
| MTS_0180-0020-0040-0160 | 200 | 11504 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0160/0180-0020-0040-0160.html |    18-2-416. Wages paid to registered apprentices, MCA  |  |
| MTS_0180-0020-0040-0170 | 200 | 11192 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0170/0180-0020-0040-0170.html |    18-2-417. Wage rate adjustments for multiyear contracts, MCA  |  |
| MTS_0180-0020-0040-0180 | 200 | 10750 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0180/0180-0020-0040-0180.html |    18-2-418. Wage rates based on project classification, MCA  |  |
| MTS_0180-0020-0040-0190 | 200 | 10406 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0190/0180-0020-0040-0190.html |    18-2-419. Zone pay and per diem, MCA  |  |
| MTS_0180-0020-0040-0200 | 200 | 9800 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0200/0180-0020-0040-0200.html |    18-2-420. reserved, MCA  |  |
| MTS_0180-0020-0040-0210 | 200 | 10827 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0210/0180-0020-0040-0210.html |    18-2-421. Notice, MCA  |  |
| MTS_0180-0020-0040-0220 | 200 | 11688 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0220/0180-0020-0040-0220.html |    18-2-422. Bid specification and public works contract to contain standard pre |  |
| MTS_0180-0020-0040-0230 | 200 | 10886 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0230/0180-0020-0040-0230.html |    18-2-423. Submission of payroll records, MCA  |  |
| MTS_0180-0020-0040-0240 | 200 | 10451 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0240/0180-0020-0040-0240.html |    18-2-424. Enforcement, MCA  |  |
| MTS_0180-0020-0040-0250 | 200 | 11560 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0250/0180-0020-0040-0250.html |    18-2-425. Prohibition -- project labor agreement, MCA  |  |
| MTS_0180-0020-0040-0260 | 200 | 9946 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0260/0180-0020-0040-0260.html |    18-2-426. through 18-2-430 reserved, MCA  |  |
| MTS_0180-0020-0040-0310 | 200 | 10177 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0310/0180-0020-0040-0310.html |    18-2-431. Rulemaking authority, MCA  |  |
| MTS_0180-0020-0040-0320 | 200 | 12368 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0040/section_0320/0180-0020-0040-0320.html |    18-2-432. Penalty for violation, MCA  |  |
| MTS_0180-0020-0050-0010 | 200 | 21004 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0050/section_0010/0180-0020-0050-0010.html |    18-2-501. Definitions, MCA  |  |
| MTS_0180-0020-0050-0020 | 200 | 17895 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0050/section_0020/0180-0020-0050-0020.html |    18-2-502. Alternative project delivery contract -- authority -- criteria, MCA |  |
| MTS_0180-0020-0050-0030 | 200 | 20527 | https://leg.mt.gov/bills/mca/title_0180/chapter_0020/part_0050/section_0030/0180-0020-0050-0030.html |    18-2-503. Alternative project delivery contract -- award criteria, MCA  |  |
| MTS_0180-0030-0010-0010 | 200 | 10759 | https://leg.mt.gov/bills/mca/title_0180/chapter_0030/part_0010/section_0010/0180-0030-0010-0010.html |    18-3-101. Authority to lease with option to purchase, MCA  |  |
| MTS_0180-0030-0010-0020 | 200 | 10045 | https://leg.mt.gov/bills/mca/title_0180/chapter_0030/part_0010/section_0020/0180-0030-0010-0020.html |    18-3-102. Repealed, MCA  |  |
| MTS_0180-0030-0010-0030 | 200 | 10011 | https://leg.mt.gov/bills/mca/title_0180/chapter_0030/part_0010/section_0030/0180-0030-0010-0030.html |    18-3-103. Repealed, MCA  |  |
| MTS_0180-0030-0010-0040 | 200 | 10023 | https://leg.mt.gov/bills/mca/title_0180/chapter_0030/part_0010/section_0040/0180-0030-0010-0040.html |    18-3-104. Repealed, MCA  |  |
| MTS_0180-0030-0010-0050 | 200 | 10428 | https://leg.mt.gov/bills/mca/title_0180/chapter_0030/part_0010/section_0050/0180-0030-0010-0050.html |    18-3-105. Location of building, MCA  |  |
| MTS_0180-0030-0010-0060 | 200 | 10233 | https://leg.mt.gov/bills/mca/title_0180/chapter_0030/part_0010/section_0060/0180-0030-0010-0060.html |    18-3-106. Security pledge, MCA  |  |
| MTS_0180-0030-0010-0070 | 200 | 10031 | https://leg.mt.gov/bills/mca/title_0180/chapter_0030/part_0010/section_0070/0180-0030-0010-0070.html |    18-3-107. Repealed, MCA  |  |
| MTS_0180-0030-0010-0080 | 200 | 9785 | https://leg.mt.gov/bills/mca/title_0180/chapter_0030/part_0010/section_0080/0180-0030-0010-0080.html |    18-3-108. and 18-3-109 reserved, MCA  |  |
| MTS_0180-0030-0010-0100 | 200 | 11237 | https://leg.mt.gov/bills/mca/title_0180/chapter_0030/part_0010/section_0100/0180-0030-0010-0100.html |    18-3-110. Requests for proposals, MCA  |  |
| MTS_0180-0030-0010-0110 | 200 | 10140 | https://leg.mt.gov/bills/mca/title_0180/chapter_0030/part_0010/section_0110/0180-0030-0010-0110.html |    18-3-111. Exemption from construction contract requirements, MCA  |  |
| MTS_0180-0040-0010-0010 | 200 | 10109 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0010/0180-0040-0010-0010.html |    18-4-101. Repealed, MCA  |  |
| MTS_0180-0040-0010-0020 | 200 | 10366 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0020/0180-0040-0010-0020.html |    18-4-102. Repealed, MCA  |  |
| MTS_0180-0040-0010-0030 | 200 | 10027 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0030/0180-0040-0010-0030.html |    18-4-103. Repealed, MCA  |  |
| MTS_0180-0040-0010-0040 | 200 | 9808 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0040/0180-0040-0010-0040.html |    18-4-104. Renumbered 18-4-133, MCA  |  |
| MTS_0180-0040-0010-0050 | 200 | 9825 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0050/0180-0040-0010-0050.html |    18-4-105. Renumbered 18-4-141, MCA  |  |
| MTS_0180-0040-0010-0060 | 200 | 9817 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0060/0180-0040-0010-0060.html |    18-4-106. through 18-4-110 reserved, MCA  |  |
| MTS_0180-0040-0010-0110 | 200 | 9831 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0110/0180-0040-0010-0110.html |    18-4-111. Renumbered 2-17-501, MCA  |  |
| MTS_0180-0040-0010-0120 | 200 | 9809 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0120/0180-0040-0010-0120.html |    18-4-112. through 18-4-120 reserved, MCA  |  |
| MTS_0180-0040-0010-0210 | 200 | 10002 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0210/0180-0040-0010-0210.html |    18-4-121. Short title, MCA  |  |
| MTS_0180-0040-0010-0220 | 200 | 11510 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0220/0180-0040-0010-0220.html |    18-4-122. Purpose, MCA  |  |
| MTS_0180-0040-0010-0230 | 200 | 16362 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0230/0180-0040-0010-0230.html |    18-4-123. Definitions, MCA  |  |
| MTS_0180-0040-0010-0240 | 200 | 10895 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0240/0180-0040-0010-0240.html |    18-4-124. Local government adoption of procurement provisions -- alternative  |  |
| MTS_0180-0040-0010-0250 | 200 | 10779 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0250/0180-0040-0010-0250.html |    18-4-125. Collection of data concerning public procurement, MCA  |  |
| MTS_0180-0040-0010-0260 | 200 | 11844 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0260/0180-0040-0010-0260.html |    18-4-126. Public access to procurement information -- records -- retention, M |  |
| MTS_0180-0040-0010-0270 | 200 | 15220 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0270/0180-0040-0010-0270.html |    18-4-127. Procurement of food products -- rulemaking -- reporting, MCA  |  |
| MTS_0180-0040-0010-0280 | 200 | 12692 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0280/0180-0040-0010-0280.html |    18-4-128. Report to interim committee, MCA  |  |
| MTS_0180-0040-0010-0290 | 200 | 9794 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0290/0180-0040-0010-0290.html |    18-4-129. and 18-4-130 reserved, MCA  |  |
| MTS_0180-0040-0010-0310 | 200 | 9995 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0310/0180-0040-0010-0310.html |    18-4-131. Repealed, MCA  |  |
| MTS_0180-0040-0010-0320 | 200 | 15656 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0320/0180-0040-0010-0320.html |    18-4-132. Application, MCA  |  |
| MTS_0180-0040-0010-0330 | 200 | 13351 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0330/0180-0040-0010-0330.html |    18-4-133. Purchases exempt from general requirements, MCA  |  |
| MTS_0180-0040-0010-0340 | 200 | 9890 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0340/0180-0040-0010-0340.html |    18-4-134. through 18-4-140 reserved, MCA  |  |
| MTS_0180-0040-0010-0410 | 200 | 12048 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0010/section_0410/0180-0040-0010-0410.html |    18-4-141. Contract transfers and collusion prohibited -- violations and penal |  |
| MTS_0180-0040-0020-0010 | 200 | 10273 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0010/0180-0040-0020-0010.html |    18-4-201. Repealed, MCA  |  |
| MTS_0180-0040-0020-0020 | 200 | 10198 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0020/0180-0040-0020-0020.html |    18-4-202. Repealed, MCA  |  |
| MTS_0180-0040-0020-0030 | 200 | 10212 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0030/0180-0040-0020-0030.html |    18-4-203. Repealed, MCA  |  |
| MTS_0180-0040-0020-0040 | 200 | 9801 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0040/0180-0040-0020-0040.html |    18-4-204. through 18-4-210 reserved, MCA  |  |
| MTS_0180-0040-0020-0110 | 200 | 10375 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0110/0180-0040-0020-0110.html |    18-4-211. Repealed, MCA  |  |
| MTS_0180-0040-0020-0120 | 200 | 10197 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0120/0180-0040-0020-0120.html |    18-4-212. Repealed, MCA  |  |
| MTS_0180-0040-0020-0130 | 200 | 10374 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0130/0180-0040-0020-0130.html |    18-4-213. Repealed, MCA  |  |
| MTS_0180-0040-0020-0140 | 200 | 10177 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0140/0180-0040-0020-0140.html |    18-4-214. Repealed, MCA  |  |
| MTS_0180-0040-0020-0150 | 200 | 9856 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0150/0180-0040-0020-0150.html |    18-4-215. through 18-4-220 reserved, MCA  |  |
| MTS_0180-0040-0020-0210 | 200 | 11335 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0210/0180-0040-0020-0210.html |    18-4-221. General procurement authority and duties of department -- rules, MC |  |
| MTS_0180-0040-0020-0220 | 200 | 10315 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0220/0180-0040-0020-0220.html |    18-4-222. Delegation of authority by department, MCA  |  |
| MTS_0180-0040-0020-0230 | 200 | 10672 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0230/0180-0040-0020-0230.html |    18-4-223. State procurement rules -- delegation -- existing rights, MCA  |  |
| MTS_0180-0040-0020-0240 | 200 | 13254 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0240/0180-0040-0020-0240.html |    18-4-224. Contract clauses -- rules, MCA  |  |
| MTS_0180-0040-0020-0250 | 200 | 10018 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0250/0180-0040-0020-0250.html |    18-4-225. Repealed, MCA  |  |
| MTS_0180-0040-0020-0260 | 200 | 11893 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0260/0180-0040-0020-0260.html |    18-4-226. Surplus supply -- rules, MCA  |  |
| MTS_0180-0040-0020-0270 | 200 | 11443 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0270/0180-0040-0020-0270.html |    18-4-227. Procurement and term contract rebate account -- funding -- use, MCA |  |
| MTS_0180-0040-0020-0280 | 200 | 9874 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0280/0180-0040-0020-0280.html |    18-4-228. through 18-4-230 reserved, MCA  |  |
| MTS_0180-0040-0020-0310 | 200 | 10529 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0310/0180-0040-0020-0310.html |    18-4-231. Definition of specification, MCA  |  |
| MTS_0180-0040-0020-0320 | 200 | 10397 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0320/0180-0040-0020-0320.html |    18-4-232. Specifications -- rules, MCA  |  |
| MTS_0180-0040-0020-0330 | 200 | 10236 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0330/0180-0040-0020-0330.html |    18-4-233. Using agencies' advice, MCA  |  |
| MTS_0180-0040-0020-0340 | 200 | 10132 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0340/0180-0040-0020-0340.html |    18-4-234. Competition, MCA  |  |
| MTS_0180-0040-0020-0350 | 200 | 9833 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0350/0180-0040-0020-0350.html |    18-4-235. through 18-4-240 reserved, MCA  |  |
| MTS_0180-0040-0020-0410 | 200 | 12913 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0410/0180-0040-0020-0410.html |    18-4-241. Authority to remove or suspend vendor, MCA  |  |
| MTS_0180-0040-0020-0420 | 200 | 14593 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0020/section_0420/0180-0040-0020-0420.html |    18-4-242. Exclusive remedies for unlawful solicitation or award, MCA  |  |
| MTS_0180-0040-0030-0010 | 200 | 13369 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0010/0180-0040-0030-0010.html |    18-4-301. Definitions, MCA  |  |
| MTS_0180-0040-0030-0020 | 200 | 14945 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0020/0180-0040-0030-0020.html |    18-4-302. Methods of source selection -- authorization for alternative procur |  |
| MTS_0180-0040-0030-0030 | 200 | 14572 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0030/0180-0040-0030-0030.html |    18-4-303. Competitive sealed bidding, MCA  |  |
| MTS_0180-0040-0030-0040 | 200 | 12687 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0040/0180-0040-0030-0040.html |    18-4-304. Competitive sealed proposals, MCA  |  |
| MTS_0180-0040-0030-0050 | 200 | 10475 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0050/0180-0040-0030-0050.html |    18-4-305. Small purchases and limited solicitations, MCA  |  |
| MTS_0180-0040-0030-0060 | 200 | 11818 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0060/0180-0040-0030-0060.html |    18-4-306. Sole source procurement -- records, MCA  |  |
| MTS_0180-0040-0030-0070 | 200 | 10728 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0070/0180-0040-0030-0070.html |    18-4-307. Cancellation of invitations for bids or requests for proposals, MCA |  |
| MTS_0180-0040-0030-0080 | 200 | 10561 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0080/0180-0040-0030-0080.html |    18-4-308. Nonresponsibility of bidders and offerors, MCA  |  |
| MTS_0180-0040-0030-0090 | 200 | 10226 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0090/0180-0040-0030-0090.html |    18-4-309. Prequalification of suppliers, MCA  |  |
| MTS_0180-0040-0030-0100 | 200 | 10108 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0100/0180-0040-0030-0100.html |    18-4-310. Types of contracts, MCA  |  |
| MTS_0180-0040-0030-0110 | 200 | 10026 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0110/0180-0040-0030-0110.html |    18-4-311. Repealed, MCA  |  |
| MTS_0180-0040-0030-0120 | 200 | 14744 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0120/0180-0040-0030-0120.html |    18-4-312. Bid and contract performance security, MCA  |  |
| MTS_0180-0040-0030-0130 | 200 | 19385 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0130/0180-0040-0030-0130.html |    18-4-313. Contracts -- terms, extensions, and time limits, MCA  |  |
| MTS_0180-0040-0030-0140 | 200 | 10113 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0030/section_0140/0180-0040-0030-0140.html |    18-4-314. Reporting of anticompetitive practices, MCA  |  |
| MTS_0180-0040-0040-0010 | 200 | 11303 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0040/section_0010/0180-0040-0040-0010.html |    18-4-401. Definitions, MCA  |  |
| MTS_0180-0040-0040-0020 | 200 | 10889 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0040/section_0020/0180-0040-0040-0020.html |    18-4-402. Cooperative purchasing authorized, MCA  |  |
| MTS_0180-0040-0040-0030 | 200 | 10420 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0040/section_0030/0180-0040-0040-0030.html |    18-4-403. Sale, acquisition, or use of supplies by a public procurement unit, |  |
| MTS_0180-0040-0040-0040 | 200 | 10375 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0040/section_0040/0180-0040-0040-0040.html |    18-4-404. Cooperative use of supplies or services, MCA  |  |
| MTS_0180-0040-0040-0050 | 200 | 10276 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0040/section_0050/0180-0040-0040-0050.html |    18-4-405. Joint use of facilities, MCA  |  |
| MTS_0180-0040-0040-0060 | 200 | 12758 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0040/section_0060/0180-0040-0040-0060.html |    18-4-406. Information and services -- fees, MCA  |  |
| MTS_0180-0040-0040-0070 | 200 | 10186 | https://leg.mt.gov/bills/mca/title_0180/chapter_0040/part_0040/section_0070/0180-0040-0040-0070.html |    18-4-407. Review of procurement requirements, MCA  |  |
| MTS_0180-0050-0010-0010 | 200 | 11888 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0010/section_0010/0180-0050-0010-0010.html |    18-5-101. Definitions, MCA  |  |
| MTS_0180-0050-0010-0020 | 200 | 11426 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0010/section_0020/0180-0050-0010-0020.html |    18-5-102. Duties and powers of department of administration, MCA  |  |
| MTS_0180-0050-0010-0030 | 200 | 10369 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0010/section_0030/0180-0050-0010-0030.html |    18-5-103. Procurement requirements, MCA  |  |
| MTS_0180-0050-0010-0040 | 200 | 9884 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0010/section_0040/0180-0050-0010-0040.html |    18-5-104. Repealed, MCA  |  |
| MTS_0180-0050-0020-0010 | 200 | 10405 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0020/section_0010/0180-0050-0020-0010.html |    18-5-201. Administration of the state agency for federal surplus property, MC |  |
| MTS_0180-0050-0020-0020 | 200 | 14821 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0020/section_0020/0180-0050-0020-0020.html |    18-5-202. Authority and duties of the state agency for surplus property, MCA  |  |
| MTS_0180-0050-0020-0030 | 200 | 10682 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0020/section_0030/0180-0050-0020-0030.html |    18-5-203. Agency for surplus property -- authorization for financing, MCA  |  |
| MTS_0180-0050-0020-0040 | 200 | 10620 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0020/section_0040/0180-0050-0020-0040.html |    18-5-204. Department director -- delegating powers, MCA  |  |
| MTS_0180-0050-0020-0050 | 200 | 11461 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0020/section_0050/0180-0050-0020-0050.html |    18-5-205. Officers or employees authorized to secure transfer of federal surp |  |
| MTS_0180-0050-0030-0010 | 200 | 9887 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0030/section_0010/0180-0050-0030-0010.html |    18-5-301. Repealed, MCA  |  |
| MTS_0180-0050-0030-0020 | 200 | 10090 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0030/section_0020/0180-0050-0030-0020.html |    18-5-302. Repealed, MCA  |  |
| MTS_0180-0050-0030-0030 | 200 | 10121 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0030/section_0030/0180-0050-0030-0030.html |    18-5-303. Repealed, MCA  |  |
| MTS_0180-0050-0030-0040 | 200 | 10151 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0030/section_0040/0180-0050-0030-0040.html |    18-5-304. Repealed, MCA  |  |
| MTS_0180-0050-0030-0050 | 200 | 10121 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0030/section_0050/0180-0050-0030-0050.html |    18-5-305. Repealed, MCA  |  |
| MTS_0180-0050-0030-0060 | 200 | 10080 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0030/section_0060/0180-0050-0030-0060.html |    18-5-306. Repealed, MCA  |  |
| MTS_0180-0050-0030-0070 | 200 | 10080 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0030/section_0070/0180-0050-0030-0070.html |    18-5-307. Repealed, MCA  |  |
| MTS_0180-0050-0030-0080 | 200 | 9922 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0030/section_0080/0180-0050-0030-0080.html |    18-5-308. Repealed, MCA  |  |
| MTS_0180-0050-0040-0010 | 200 | 10055 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0010/0180-0050-0040-0010.html |    18-5-401. Purpose, MCA  |  |
| MTS_0180-0050-0040-0020 | 200 | 13211 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0020/0180-0050-0040-0020.html |    18-5-402. Definitions, MCA  |  |
| MTS_0180-0050-0040-0030 | 200 | 10952 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0030/0180-0050-0040-0030.html |    18-5-403. Certification and eligibility of blind persons, MCA  |  |
| MTS_0180-0050-0040-0040 | 200 | 10987 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0040/0180-0050-0040-0040.html |    18-5-404. Vending facilities, equipment, and supplies -- available to certifi |  |
| MTS_0180-0050-0040-0050 | 200 | 10191 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0050/0180-0050-0040-0050.html |    18-5-405. Right to fair hearing, MCA  |  |
| MTS_0180-0050-0040-0060 | 200 | 11063 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0060/0180-0050-0040-0060.html |    18-5-406. Health and retirement fund -- services to vendors, MCA  |  |
| MTS_0180-0050-0040-0070 | 200 | 9896 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0070/0180-0050-0040-0070.html |    18-5-407. through 18-5-410 reserved, MCA  |  |
| MTS_0180-0050-0040-0110 | 200 | 12015 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0110/0180-0050-0040-0110.html |    18-5-411. Administration of vending facilities -- state properties, MCA  |  |
| MTS_0180-0050-0040-0120 | 200 | 10492 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0120/0180-0050-0040-0120.html |    18-5-412. Administration of vending facilities on other property, MCA  |  |
| MTS_0180-0050-0040-0130 | 200 | 10625 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0130/0180-0050-0040-0130.html |    18-5-413. Implementation of Randolph-Sheppard Act, as amended, MCA  |  |
| MTS_0180-0050-0040-0140 | 200 | 10140 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0140/0180-0050-0040-0140.html |    18-5-414. Authority to adopt rules, MCA  |  |
| MTS_0180-0050-0040-0150 | 200 | 12025 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0150/0180-0050-0040-0150.html |    18-5-415. Operation of facilities, MCA  |  |
| MTS_0180-0050-0040-0160 | 200 | 10862 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0160/0180-0050-0040-0160.html |    18-5-416. Vending machines, MCA  |  |
| MTS_0180-0050-0040-0170 | 200 | 11035 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0040/section_0170/0180-0050-0040-0170.html |    18-5-417. Vending machine special revenue account -- purpose -- statutory app |  |
| MTS_0180-0050-0050-0010 | 200 | 12210 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0050/section_0010/0180-0050-0050-0010.html |    18-5-501. Definitions, MCA  |  |
| MTS_0180-0050-0050-0020 | 200 | 10952 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0050/section_0020/0180-0050-0050-0020.html |    18-5-502. Preference to blind persons, MCA  |  |
| MTS_0180-0050-0050-0030 | 200 | 10275 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0050/section_0030/0180-0050-0050-0030.html |    18-5-503. Application of state procurement law, MCA  |  |
| MTS_0180-0050-0050-0040 | 200 | 9901 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0050/section_0040/0180-0050-0050-0040.html |    18-5-504. Blind preference rules, MCA  |  |
| MTS_0180-0050-0060-0010 | 200 | 12876 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0060/section_0010/0180-0050-0060-0010.html |    18-5-601. Findings -- policy, MCA  |  |
| MTS_0180-0050-0060-0020 | 200 | 12593 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0060/section_0020/0180-0050-0060-0020.html |    18-5-602. Definitions, MCA  |  |
| MTS_0180-0050-0060-0030 | 200 | 11050 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0060/section_0030/0180-0050-0060-0030.html |    18-5-603. Nonvisual access ensured, MCA  |  |
| MTS_0180-0050-0060-0040 | 200 | 12145 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0060/section_0040/0180-0050-0060-0040.html |    18-5-604. Procurement requirements, MCA  |  |
| MTS_0180-0050-0060-0050 | 200 | 11636 | https://leg.mt.gov/bills/mca/title_0180/chapter_0050/part_0060/section_0050/0180-0050-0060-0050.html |    18-5-605. Implementation, MCA  |  |
| MTS_0180-0060-0010-0010 | 200 | 11497 | https://leg.mt.gov/bills/mca/title_0180/chapter_0060/part_0010/section_0010/0180-0060-0010-0010.html |    18-6-101. Power to sell state property -- proceeds credited to general fund,  |  |
| MTS_0180-0060-0010-0020 | 200 | 10377 | https://leg.mt.gov/bills/mca/title_0180/chapter_0060/part_0010/section_0020/0180-0060-0010-0020.html |    18-6-102. Interagency transfers, MCA  |  |
| MTS_0180-0060-0010-0030 | 200 | 10404 | https://leg.mt.gov/bills/mca/title_0180/chapter_0060/part_0010/section_0030/0180-0060-0010-0030.html |    18-6-103. Highway equipment by bid, MCA  |  |
| MTS_0180-0070-0010-0010 | 200 | 11708 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0010/section_0010/0180-0070-0010-0010.html |    18-7-101. Power to contract for printing -- exceptions, MCA  |  |
| MTS_0180-0070-0010-0020 | 200 | 10124 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0010/section_0020/0180-0070-0010-0020.html |    18-7-102. Repealed, MCA  |  |
| MTS_0180-0070-0010-0030 | 200 | 10155 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0010/section_0030/0180-0070-0010-0030.html |    18-7-103. Repealed, MCA  |  |
| MTS_0180-0070-0010-0040 | 200 | 12262 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0010/section_0040/0180-0070-0010-0040.html |    18-7-104. Union label, MCA  |  |
| MTS_0180-0070-0010-0050 | 200 | 10587 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0010/section_0050/0180-0070-0010-0050.html |    18-7-105. Penalty, MCA  |  |
| MTS_0180-0070-0010-0060 | 200 | 10706 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0010/section_0060/0180-0070-0010-0060.html |    18-7-106. Approval of purchase orders, MCA  |  |
| MTS_0180-0070-0010-0070 | 200 | 10615 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0010/section_0070/0180-0070-0010-0070.html |    18-7-107. State printing, binding, and stationery work, MCA  |  |
| MTS_0180-0070-0010-0080 | 200 | 9825 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0010/section_0080/0180-0070-0010-0080.html |    18-7-108. through 18-7-110 reserved, MCA  |  |
| MTS_0180-0070-0010-0110 | 200 | 10072 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0010/section_0110/0180-0070-0010-0110.html |    18-7-111. Repealed, MCA  |  |
| MTS_0180-0070-0010-0120 | 200 | 10055 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0010/section_0120/0180-0070-0010-0120.html |    18-7-112. Repealed, MCA  |  |
| MTS_0180-0070-0010-0130 | 200 | 9855 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0010/section_0130/0180-0070-0010-0130.html |    18-7-113. Repealed, MCA  |  |
| MTS_0180-0070-0020-0010 | 200 | 11177 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0020/section_0010/0180-0070-0020-0010.html |    18-7-201. Requirements for choice of newspaper -- price, MCA  |  |
| MTS_0180-0070-0020-0020 | 200 | 10732 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0020/section_0020/0180-0070-0020-0020.html |    18-7-202. Lower rates permissible, MCA  |  |
| MTS_0180-0070-0020-0030 | 200 | 10990 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0020/section_0030/0180-0070-0020-0030.html |    18-7-203. Folio measurement, MCA  |  |
| MTS_0180-0070-0020-0040 | 200 | 11182 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0020/section_0040/0180-0070-0020-0040.html |    18-7-204. Affidavit of printer -- allowance of claims, MCA  |  |
| MTS_0180-0070-0020-0050 | 200 | 10880 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0020/section_0050/0180-0070-0020-0050.html |    18-7-205. Penalty for false affidavit or overcharge, MCA  |  |
| MTS_0180-0070-0030-0010 | 200 | 9813 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0030/section_0010/0180-0070-0030-0010.html |    18-7-301. Short title, MCA  |  |
| MTS_0180-0070-0030-0020 | 200 | 11210 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0030/section_0020/0180-0070-0030-0020.html |    18-7-302. Definitions, MCA  |  |
| MTS_0180-0070-0030-0030 | 200 | 10095 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0030/section_0030/0180-0070-0030-0030.html |    18-7-303. Repealed, MCA  |  |
| MTS_0180-0070-0030-0040 | 200 | 10142 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0030/section_0040/0180-0070-0030-0040.html |    18-7-304. Department to prepare standards, MCA  |  |
| MTS_0180-0070-0030-0050 | 200 | 10046 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0030/section_0050/0180-0070-0030-0050.html |    18-7-305. Repealed, MCA  |  |
| MTS_0180-0070-0030-0060 | 200 | 10972 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0030/section_0060/0180-0070-0030-0060.html |    18-7-306. Public disclosure of costs, MCA  |  |
| MTS_0180-0070-0030-0070 | 200 | 10259 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0030/section_0070/0180-0070-0030-0070.html |    18-7-307. Estimation of costs, MCA  |  |
| MTS_0180-0070-0040-0010 | 200 | 10246 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0040/section_0010/0180-0070-0040-0010.html |    18-7-401. Purpose of part, MCA  |  |
| MTS_0180-0070-0040-0020 | 200 | 10317 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0040/section_0020/0180-0070-0040-0020.html |    18-7-402. Definition, MCA  |  |
| MTS_0180-0070-0040-0030 | 200 | 10232 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0040/section_0030/0180-0070-0040-0030.html |    18-7-403. Repealed, MCA  |  |
| MTS_0180-0070-0040-0040 | 200 | 12003 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0040/section_0040/0180-0070-0040-0040.html |    18-7-404. Establishment of maximum prices -- rulemaking, MCA  |  |
| MTS_0180-0070-0040-0050 | 200 | 10355 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0040/section_0050/0180-0070-0040-0050.html |    18-7-405. Adoption of printing standards, MCA  |  |
| MTS_0180-0070-0040-0060 | 200 | 9836 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0040/section_0060/0180-0070-0040-0060.html |    18-7-406. through 18-7-410 reserved, MCA  |  |
| MTS_0180-0070-0040-0110 | 200 | 12107 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0040/section_0110/0180-0070-0040-0110.html |    18-7-411. County advertising -- contract, MCA  |  |
| MTS_0180-0070-0040-0120 | 200 | 11758 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0040/section_0120/0180-0070-0040-0120.html |    18-7-412. County printing contract, MCA  |  |
| MTS_0180-0070-0040-0130 | 200 | 10675 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0040/section_0130/0180-0070-0040-0130.html |    18-7-413. Competitive bids required, MCA  |  |
| MTS_0180-0070-0040-0140 | 200 | 10159 | https://leg.mt.gov/bills/mca/title_0180/chapter_0070/part_0040/section_0140/0180-0070-0040-0140.html |    18-7-414. Exemption for county fairs, MCA  |  |
| MTS_0180-0080-0010-0010 | 200 | 9788 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0010/section_0010/0180-0080-0010-0010.html |    18-8-101. Repealed, MCA  |  |
| MTS_0180-0080-0010-0020 | 200 | 9991 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0010/section_0020/0180-0080-0010-0020.html |    18-8-102. Repealed, MCA  |  |
| MTS_0180-0080-0010-0030 | 200 | 10146 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0010/section_0030/0180-0080-0010-0030.html |    18-8-103. Repealed, MCA  |  |
| MTS_0180-0080-0010-0040 | 200 | 9991 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0010/section_0040/0180-0080-0010-0040.html |    18-8-104. Repealed, MCA  |  |
| MTS_0180-0080-0010-0050 | 200 | 10022 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0010/section_0050/0180-0080-0010-0050.html |    18-8-105. Repealed, MCA  |  |
| MTS_0180-0080-0010-0060 | 200 | 10008 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0010/section_0060/0180-0080-0010-0060.html |    18-8-106. Repealed, MCA  |  |
| MTS_0180-0080-0010-0070 | 200 | 9807 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0010/section_0070/0180-0080-0010-0070.html |    18-8-107. through 18-8-110 reserved, MCA  |  |
| MTS_0180-0080-0010-0110 | 200 | 10008 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0010/section_0110/0180-0080-0010-0110.html |    18-8-111. Repealed, MCA  |  |
| MTS_0180-0080-0010-0120 | 200 | 9791 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0010/section_0120/0180-0080-0010-0120.html |    18-8-112. Repealed, MCA  |  |
| MTS_0180-0080-0020-0010 | 200 | 10240 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0020/section_0010/0180-0080-0020-0010.html |    18-8-201. Statement of policy, MCA  |  |
| MTS_0180-0080-0020-0020 | 200 | 12297 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0020/section_0020/0180-0080-0020-0020.html |    18-8-202. Definitions, MCA  |  |
| MTS_0180-0080-0020-0030 | 200 | 10908 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0020/section_0030/0180-0080-0020-0030.html |    18-8-203. Public notice of agency requirements, MCA  |  |
| MTS_0180-0080-0020-0040 | 200 | 13594 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0020/section_0040/0180-0080-0020-0040.html |    18-8-204. Procedures for selection, MCA  |  |
| MTS_0180-0080-0020-0050 | 200 | 11801 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0020/section_0050/0180-0080-0020-0050.html |    18-8-205. Negotiation of contract for services, MCA  |  |
| MTS_0180-0080-0020-0060 | 200 | 9961 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0020/section_0060/0180-0080-0020-0060.html |    18-8-206. through 18-8-209 reserved, MCA  |  |
| MTS_0180-0080-0020-0100 | 200 | 10468 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0020/section_0100/0180-0080-0020-0100.html |    18-8-210. Energy performance contracts exempt, MCA  |  |
| MTS_0180-0080-0020-0110 | 200 | 11315 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0020/section_0110/0180-0080-0020-0110.html |    18-8-211. Coordination with other statutes, MCA  |  |
| MTS_0180-0080-0020-0120 | 200 | 10518 | https://leg.mt.gov/bills/mca/title_0180/chapter_0080/part_0020/section_0120/0180-0080-0020-0120.html |    18-8-212. Exception, MCA  |  |
| MTS_0180-0110-0010-0010 | 200 | 10453 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0010/0180-0110-0010-0010.html |    18-11-101. Short title -- purpose, MCA  |  |
| MTS_0180-0110-0010-0020 | 200 | 10726 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0020/0180-0110-0010-0020.html |    18-11-102. Definitions, MCA  |  |
| MTS_0180-0110-0010-0030 | 200 | 12318 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0030/0180-0110-0010-0030.html |    18-11-103. Authorization to enter agreement -- general contents, MCA  |  |
| MTS_0180-0110-0010-0040 | 200 | 14623 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0040/0180-0110-0010-0040.html |    18-11-104. Detailed contents of agreement, MCA  |  |
| MTS_0180-0110-0010-0050 | 200 | 11095 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0050/0180-0110-0010-0050.html |    18-11-105. Submission of agreement to attorney general, MCA  |  |
| MTS_0180-0110-0010-0060 | 200 | 10056 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0060/0180-0110-0010-0060.html |    18-11-106. Repealed, MCA  |  |
| MTS_0180-0110-0010-0070 | 200 | 11157 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0070/0180-0110-0010-0070.html |    18-11-107. Filing of agreement, MCA  |  |
| MTS_0180-0110-0010-0080 | 200 | 10358 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0080/0180-0110-0010-0080.html |    18-11-108. Revocation of agreement, MCA  |  |
| MTS_0180-0110-0010-0090 | 200 | 10557 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0090/0180-0110-0010-0090.html |    18-11-109. Authorization to appropriate funds for purpose of agreement, MCA  |  |
| MTS_0180-0110-0010-0100 | 200 | 11168 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0100/0180-0110-0010-0100.html |    18-11-110. Specific limitations on agreements, MCA  |  |
| MTS_0180-0110-0010-0110 | 200 | 10097 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0110/0180-0110-0010-0110.html |    18-11-111. Repealed, MCA  |  |
| MTS_0180-0110-0010-0120 | 200 | 12785 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0120/0180-0110-0010-0120.html |    18-11-112. Revenue account -- administrative account -- distribution of reven |  |
| MTS_0180-0110-0010-0130 | 200 | 9968 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0130/0180-0110-0010-0130.html |    18-11-113. through 18-11-120 reserved, MCA  |  |
| MTS_0180-0110-0010-0210 | 200 | 10424 | https://leg.mt.gov/bills/mca/title_0180/chapter_0110/part_0010/section_0210/0180-0110-0010-0210.html |    18-11-121. Authorization to become contracting employer in public employees'  |  |
| MTS_0190-0010-0010-0010 | 200 | 10994 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0010/section_0010/0190-0010-0010-0010.html |    19-1-101. Declaration of policy, MCA  |  |
| MTS_0190-0010-0010-0020 | 200 | 15173 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0010/section_0020/0190-0010-0010-0020.html |    19-1-102. Definitions, MCA  |  |
| MTS_0190-0010-0010-0030 | 200 | 10267 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0010/section_0030/0190-0010-0010-0030.html |    19-1-103. Exclusions, MCA  |  |
| MTS_0190-0010-0010-0040 | 200 | 11338 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0010/section_0040/0190-0010-0010-0040.html |    19-1-104. Retirement systems to be considered separate, MCA  |  |
| MTS_0190-0010-0020-0010 | 200 | 10013 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0020/section_0010/0190-0010-0020-0010.html |    19-1-201. Department may adopt rules, MCA  |  |
| MTS_0190-0010-0020-0020 | 200 | 10186 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0020/section_0020/0190-0010-0020-0020.html |    19-1-202. Costs of administration, MCA  |  |
| MTS_0190-0010-0030-0010 | 200 | 10545 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0030/section_0010/0190-0010-0030-0010.html |    19-1-301. Authorization of referendum by governor, MCA  |  |
| MTS_0190-0010-0030-0020 | 200 | 10697 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0030/section_0020/0190-0010-0030-0020.html |    19-1-302. Conduct of referendum, MCA  |  |
| MTS_0190-0010-0030-0030 | 200 | 10751 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0030/section_0030/0190-0010-0030-0030.html |    19-1-303. Notice of referendum, MCA  |  |
| MTS_0190-0010-0030-0040 | 200 | 10416 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0030/section_0040/0190-0010-0030-0040.html |    19-1-304. Certification of referendum by governor, MCA  |  |
| MTS_0190-0010-0040-0010 | 200 | 10699 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0040/section_0010/0190-0010-0040-0010.html |    19-1-401. Authority for federal-state agreement, MCA  |  |
| MTS_0190-0010-0040-0020 | 200 | 12166 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0040/section_0020/0190-0010-0040-0020.html |    19-1-402. Contents of federal-state agreement, MCA  |  |
| MTS_0190-0010-0050-0010 | 200 | 10487 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0050/section_0010/0190-0010-0050-0010.html |    19-1-501. Submission of plan and agreement, MCA  |  |
| MTS_0190-0010-0050-0020 | 200 | 11138 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0050/section_0020/0190-0010-0050-0020.html |    19-1-502. Approval of plan and agreement by department, MCA  |  |
| MTS_0190-0010-0050-0030 | 200 | 11200 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0050/section_0030/0190-0010-0050-0030.html |    19-1-503. Required provisions of plan and agreement, MCA  |  |
| MTS_0190-0010-0060-0010 | 200 | 10037 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0060/section_0010/0190-0010-0060-0010.html |    19-1-601. Repealed, MCA  |  |
| MTS_0190-0010-0060-0020 | 200 | 10370 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0060/section_0020/0190-0010-0060-0020.html |    19-1-602. Repealed, MCA  |  |
| MTS_0190-0010-0060-0030 | 200 | 10240 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0060/section_0030/0190-0010-0060-0030.html |    19-1-603. Repealed, MCA  |  |
| MTS_0190-0010-0060-0040 | 200 | 10040 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0060/section_0040/0190-0010-0060-0040.html |    19-1-604. Repealed, MCA  |  |
| MTS_0190-0010-0070-0010 | 200 | 10007 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0070/section_0010/0190-0010-0070-0010.html |    19-1-701. Repealed, MCA  |  |
| MTS_0190-0010-0070-0020 | 200 | 11517 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0070/section_0020/0190-0010-0070-0020.html |    19-1-702. Contributions by state employees, MCA  |  |
| MTS_0190-0010-0070-0030 | 200 | 10239 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0070/section_0030/0190-0010-0070-0030.html |    19-1-703. Repealed, MCA  |  |
| MTS_0190-0010-0070-0040 | 200 | 10988 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0070/section_0040/0190-0010-0070-0040.html |    19-1-704. Contribution by political subdivision, MCA  |  |
| MTS_0190-0010-0070-0050 | 200 | 11407 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0070/section_0050/0190-0010-0070-0050.html |    19-1-705. Deduction of employee contribution by political subdivision, MCA  |  |
| MTS_0190-0010-0070-0060 | 200 | 10036 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0070/section_0060/0190-0010-0070-0060.html |    19-1-706. Repealed, MCA  |  |
| MTS_0190-0010-0080-0010 | 200 | 9848 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0010/0190-0010-0080-0010.html |    19-1-801. Repealed, MCA  |  |
| MTS_0190-0010-0080-0020 | 200 | 10826 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0020/0190-0010-0080-0020.html |    19-1-802. No effect on rights under other laws, MCA  |  |
| MTS_0190-0010-0080-0030 | 200 | 9867 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0030/0190-0010-0080-0030.html |    19-1-803. through 19-1-810 reserved, MCA  |  |
| MTS_0190-0010-0080-0110 | 200 | 10907 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0110/0190-0010-0080-0110.html |    19-1-811. Referendum by school district, MCA  |  |
| MTS_0190-0010-0080-0120 | 200 | 10473 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0120/0190-0010-0080-0120.html |    19-1-812. Eligibility of staff and teachers, MCA  |  |
