| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0050-0020-0040-0040 | 200 | 9850 | https://leg.mt.gov/bills/mca/title_0050/chapter_0020/part_0040/section_0040/0050-0020-0040-0040.html |    5-2-404. Procedure upon failure of one candidate to receive majority vote, MC |  |
| MTS_0050-0020-0040-0050 | 200 | 9615 | https://leg.mt.gov/bills/mca/title_0050/chapter_0020/part_0040/section_0050/0050-0020-0040-0050.html |    5-2-405. Term of appointee, MCA  |  |
| MTS_0050-0020-0040-0060 | 200 | 11646 | https://leg.mt.gov/bills/mca/title_0050/chapter_0020/part_0040/section_0060/0050-0020-0040-0060.html |    5-2-406. Elections to fill vacancies in senate, MCA  |  |
| MTS_0050-0020-0040-0070 | 200 | 9834 | https://leg.mt.gov/bills/mca/title_0050/chapter_0020/part_0040/section_0070/0050-0020-0040-0070.html |    5-2-407. Anticipated vacancy, MCA  |  |
| MTS_0050-0020-0050-0010 | 200 | 9850 | https://leg.mt.gov/bills/mca/title_0050/chapter_0020/part_0050/section_0010/0050-0020-0050-0010.html |    5-2-501. Declaration of policy and purpose, MCA  |  |
| MTS_0050-0020-0050-0020 | 200 | 9650 | https://leg.mt.gov/bills/mca/title_0050/chapter_0020/part_0050/section_0020/0050-0020-0050-0020.html |    5-2-502. Structure of legislative branch, MCA  |  |
| MTS_0050-0020-0050-0030 | 200 | 12375 | https://leg.mt.gov/bills/mca/title_0050/chapter_0020/part_0050/section_0030/0050-0020-0050-0030.html |    5-2-503. Consolidation of legislative branch entities for specified purposes, |  |
| MTS_0050-0020-0050-0040 | 200 | 11148 | https://leg.mt.gov/bills/mca/title_0050/chapter_0020/part_0050/section_0040/0050-0020-0050-0040.html |    5-2-504. Legislative branch consolidated, MCA  |  |
| MTS_0050-0030-0010-0010 | 200 | 10748 | https://leg.mt.gov/bills/mca/title_0050/chapter_0030/part_0010/section_0010/0050-0030-0010-0010.html |    5-3-101. Convening of special session -- limiting subjects -- committee meeti |  |
| MTS_0050-0030-0010-0020 | 200 | 9492 | https://leg.mt.gov/bills/mca/title_0050/chapter_0030/part_0010/section_0020/0050-0030-0010-0020.html |    5-3-102. Calling of a future special session when legislature is in session,  |  |
| MTS_0050-0030-0010-0030 | 200 | 8901 | https://leg.mt.gov/bills/mca/title_0050/chapter_0030/part_0010/section_0030/0050-0030-0010-0030.html |    5-3-103. and 5-3-104 reserved, MCA  |  |
| MTS_0050-0030-0010-0050 | 200 | 10247 | https://leg.mt.gov/bills/mca/title_0050/chapter_0030/part_0010/section_0050/0050-0030-0010-0050.html |    5-3-105. Request by 30 members to poll legislators, MCA  |  |
| MTS_0050-0030-0010-0060 | 200 | 11204 | https://leg.mt.gov/bills/mca/title_0050/chapter_0030/part_0010/section_0060/0050-0030-0010-0060.html |    5-3-106. Procedure for polling legislators, MCA  |  |
| MTS_0050-0030-0010-0070 | 200 | 9391 | https://leg.mt.gov/bills/mca/title_0050/chapter_0030/part_0010/section_0070/0050-0030-0010-0070.html |    5-3-107. Notice of time of approved special session, MCA  |  |
| MTS_0050-0030-0010-0080 | 200 | 10147 | https://leg.mt.gov/bills/mca/title_0050/chapter_0030/part_0010/section_0080/0050-0030-0010-0080.html |    5-3-108. Failure to approve special session -- ballots void, MCA  |  |
| MTS_0050-0040-0010-0010 | 200 | 8956 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0010/section_0010/0050-0040-0010-0010.html |    5-4-101. Form of enacting clause, MCA  |  |
| MTS_0050-0040-0010-0020 | 200 | 9290 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0010/section_0020/0050-0040-0010-0020.html |    5-4-102. Limitation on title of referred legislation, MCA  |  |
| MTS_0050-0040-0010-0030 | 200 | 9208 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0010/section_0030/0050-0040-0010-0030.html |    5-4-103. Rulemaking authority, MCA  |  |
| MTS_0050-0040-0010-0040 | 200 | 10737 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0010/section_0040/0050-0040-0010-0040.html |    5-4-104. Tax expenditure criteria -- legislation, MCA  |  |
| MTS_0050-0040-0010-0050 | 200 | 9623 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0010/section_0050/0050-0040-0010-0050.html |    5-4-105. Predrafting, MCA  |  |
| MTS_0050-0040-0020-0010 | 200 | 9504 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0020/section_0010/0050-0040-0020-0010.html |    5-4-201. Requirement of fiscal notes with committee reports, MCA  |  |
| MTS_0050-0040-0020-0020 | 200 | 9822 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0020/section_0020/0050-0040-0020-0020.html |    5-4-202. Requests for notes by committee, house, or sponsor, MCA  |  |
| MTS_0050-0040-0020-0030 | 200 | 9762 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0020/section_0030/0050-0040-0020-0030.html |    5-4-203. Budget director to prepare note, MCA  |  |
| MTS_0050-0040-0020-0040 | 200 | 13365 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0020/section_0040/0050-0040-0020-0040.html |    5-4-204. Submission of fiscal note -- sponsor's fiscal note rebuttal -- distr |  |
| MTS_0050-0040-0020-0050 | 200 | 10983 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0020/section_0050/0050-0040-0020-0050.html |    5-4-205. Contents of notes, MCA  |  |
| MTS_0050-0040-0020-0060 | 200 | 9398 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0020/section_0060/0050-0040-0020-0060.html |    5-4-206. Background information to legislators on request, MCA  |  |
| MTS_0050-0040-0020-0070 | 200 | 9156 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0020/section_0070/0050-0040-0020-0070.html |    5-4-207. Repealed, MCA  |  |
| MTS_0050-0040-0020-0080 | 200 | 11135 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0020/section_0080/0050-0040-0020-0080.html |    5-4-208. Report of actual costs for legislation with projected fiscal impact, |  |
| MTS_0050-0040-0020-0090 | 200 | 8833 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0020/section_0090/0050-0040-0020-0090.html |    5-4-209. reserved, MCA  |  |
| MTS_0050-0040-0020-0100 | 200 | 10399 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0020/section_0100/0050-0040-0020-0100.html |    5-4-210. Estimate of fiscal impact on local government required, MCA  |  |
| MTS_0050-0040-0030-0010 | 200 | 9646 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0030/section_0010/0050-0040-0030-0010.html |    5-4-301. Bills received by governor -- how endorsed, MCA  |  |
| MTS_0050-0040-0030-0020 | 200 | 9379 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0030/section_0020/0050-0040-0030-0020.html |    5-4-302. Approval of bills, MCA  |  |
| MTS_0050-0040-0030-0030 | 200 | 9827 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0030/section_0030/0050-0040-0030-0030.html |    5-4-303. Line item veto, MCA  |  |
| MTS_0050-0040-0030-0040 | 200 | 11103 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0030/section_0040/0050-0040-0030-0040.html |    5-4-304. Amendatory veto, MCA  |  |
| MTS_0050-0040-0030-0050 | 200 | 10940 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0030/section_0050/0050-0040-0030-0050.html |    5-4-305. Bills returned without approval, MCA  |  |
| MTS_0050-0040-0030-0060 | 200 | 13068 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0030/section_0060/0050-0040-0030-0060.html |    5-4-306. Return when legislature not in session, MCA  |  |
| MTS_0050-0040-0030-0070 | 200 | 10019 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0030/section_0070/0050-0040-0030-0070.html |    5-4-307. Bills remaining with governor, MCA  |  |
| MTS_0050-0040-0030-0080 | 200 | 9153 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0030/section_0080/0050-0040-0030-0080.html |    5-4-308. Transmittal of veto messages to legislative services division, MCA  |  |
| MTS_0050-0040-0040-0010 | 200 | 8857 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0040/section_0010/0050-0040-0040-0010.html |    5-4-401. Repealed, MCA  |  |
| MTS_0050-0040-0040-0020 | 200 | 9151 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0040/section_0020/0050-0040-0040-0020.html |    5-4-402. Repealed, MCA  |  |
| MTS_0050-0040-0040-0030 | 200 | 9059 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0040/section_0030/0050-0040-0040-0030.html |    5-4-403. Repealed, MCA  |  |
| MTS_0050-0040-0040-0040 | 200 | 8921 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0040/section_0040/0050-0040-0040-0040.html |    5-4-404. Repealed, MCA  |  |
| MTS_0050-0040-0050-0010 | 200 | 8899 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0050/section_0010/0050-0040-0050-0010.html |    5-4-501. Terminated, MCA  |  |
| MTS_0050-0040-0050-0020 | 200 | 9103 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0050/section_0020/0050-0040-0050-0020.html |    5-4-502. Terminated, MCA  |  |
| MTS_0050-0040-0050-0030 | 200 | 9103 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0050/section_0030/0050-0040-0050-0030.html |    5-4-503. Terminated, MCA  |  |
| MTS_0050-0040-0050-0040 | 200 | 9103 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0050/section_0040/0050-0040-0050-0040.html |    5-4-504. Terminated, MCA  |  |
| MTS_0050-0040-0050-0050 | 200 | 8902 | https://leg.mt.gov/bills/mca/title_0050/chapter_0040/part_0050/section_0050/0050-0040-0050-0050.html |    5-4-505. Terminated, MCA  |  |
| MTS_0050-0050-0010-0010 | 200 | 8679 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0010/0050-0050-0010-0010.html |    5-5-101. Renumbered 5-5-107, MCA  |  |
| MTS_0050-0050-0010-0020 | 200 | 8891 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0020/0050-0050-0010-0020.html |    5-5-102. Renumbered 5-5-108, MCA  |  |
| MTS_0050-0050-0010-0030 | 200 | 8891 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0030/0050-0050-0010-0030.html |    5-5-103. Renumbered 5-5-109, MCA  |  |
| MTS_0050-0050-0010-0040 | 200 | 8891 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0040/0050-0050-0010-0040.html |    5-5-104. Renumbered 5-5-111, MCA  |  |
| MTS_0050-0050-0010-0050 | 200 | 8930 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0050/0050-0050-0010-0050.html |    5-5-105. Renumbered 5-5-112, MCA  |  |
| MTS_0050-0050-0010-0060 | 200 | 11557 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0060/0050-0050-0010-0060.html |    5-5-106. Scope and application of legislature investigative powers, MCA  |  |
| MTS_0050-0050-0010-0070 | 200 | 13554 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0070/0050-0050-0010-0070.html |    5-5-107. Subpoenas -- witnesses -- records, MCA  |  |
| MTS_0050-0050-0010-0080 | 200 | 9615 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0080/0050-0050-0010-0080.html |    5-5-108. Service of subpoenas, MCA  |  |
| MTS_0050-0050-0010-0090 | 200 | 10831 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0090/0050-0050-0010-0090.html |    5-5-109. Contempt -- misdemeanor, MCA  |  |
| MTS_0050-0050-0010-0100 | 200 | 9058 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0100/0050-0050-0010-0100.html |    5-5-110. Terminated, MCA  |  |
| MTS_0050-0050-0010-0110 | 200 | 9632 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0110/0050-0050-0010-0110.html |    5-5-111. Compelling attendance, MCA  |  |
| MTS_0050-0050-0010-0120 | 200 | 10184 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0120/0050-0050-0010-0120.html |    5-5-112. Immunity of witness, MCA  |  |
| MTS_0050-0050-0010-0130 | 200 | 14061 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0010/section_0130/0050-0050-0010-0130.html |    5-5-113. Procedure for certifying contempt of legislature, MCA  |  |
| MTS_0050-0050-0020-0010 | 200 | 9160 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0010/0050-0050-0020-0010.html |    5-5-201. Power to administer oaths, MCA  |  |
| MTS_0050-0050-0020-0020 | 200 | 12217 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0020/0050-0050-0020-0020.html |    5-5-202. Interim committees, MCA  |  |
| MTS_0050-0050-0020-0030 | 200 | 8926 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0030/0050-0050-0020-0030.html |    5-5-203. through 5-5-210 reserved, MCA  |  |
| MTS_0050-0050-0020-0110 | 200 | 13230 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0110/0050-0050-0020-0110.html |    5-5-211. Appointment and composition of interim committees, MCA  |  |
| MTS_0050-0050-0020-0120 | 200 | 9671 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0120/0050-0050-0020-0120.html |    5-5-212. Implied resignation of member -- vacancies, MCA  |  |
| MTS_0050-0050-0020-0130 | 200 | 9443 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0130/0050-0050-0020-0130.html |    5-5-213. Officers of interim committees, MCA  |  |
| MTS_0050-0050-0020-0140 | 200 | 9494 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0140/0050-0050-0020-0140.html |    5-5-214. Interim activity, MCA  |  |
| MTS_0050-0050-0020-0150 | 200 | 13175 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0150/0050-0050-0020-0150.html |    5-5-215. Duties of interim committees, MCA  |  |
| MTS_0050-0050-0020-0160 | 200 | 9717 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0160/0050-0050-0020-0160.html |    5-5-216. Recommendations of committees, MCA  |  |
| MTS_0050-0050-0020-0170 | 200 | 10926 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0170/0050-0050-0020-0170.html |    5-5-217. Selection and assignment of interim studies, MCA  |  |
| MTS_0050-0050-0020-0180 | 200 | 8910 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0180/0050-0050-0020-0180.html |    5-5-218. through 5-5-220 reserved, MCA  |  |
| MTS_0050-0050-0020-0210 | 200 | 9150 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0210/0050-0050-0020-0210.html |    5-5-221. Repealed, MCA  |  |
| MTS_0050-0050-0020-0220 | 200 | 9155 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0220/0050-0050-0020-0220.html |    5-5-222. Repealed, MCA  |  |
| MTS_0050-0050-0020-0230 | 200 | 11700 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0230/0050-0050-0020-0230.html |    5-5-223. Economic affairs interim committee, MCA  |  |
| MTS_0050-0050-0020-0240 | 200 | 9924 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0240/0050-0050-0020-0240.html |    5-5-224. Education interim committee, MCA  |  |
| MTS_0050-0050-0020-0250 | 200 | 9652 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0250/0050-0050-0020-0250.html |    5-5-225. Children, families, health, and human services interim committee, MC |  |
| MTS_0050-0050-0020-0260 | 200 | 9865 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0260/0050-0050-0020-0260.html |    5-5-226. Law and justice interim committee, MCA  |  |
| MTS_0050-0050-0020-0270 | 200 | 13132 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0270/0050-0050-0020-0270.html |    5-5-227. Revenue interim committee -- powers and duties -- revenue estimating |  |
| MTS_0050-0050-0020-0280 | 200 | 12997 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0280/0050-0050-0020-0280.html |    5-5-228. State administration and veterans' affairs interim committee, MCA  |  |
| MTS_0050-0050-0020-0290 | 200 | 10830 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0290/0050-0050-0020-0290.html |    5-5-229. State-tribal relations committee, MCA  |  |
| MTS_0050-0050-0020-0300 | 200 | 9452 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0300/0050-0050-0020-0300.html |    5-5-230. Energy and technology interim committee, MCA  |  |
| MTS_0050-0050-0020-0310 | 200 | 11206 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0310/0050-0050-0020-0310.html |    5-5-231. Water policy interim committee, MCA  |  |
| MTS_0050-0050-0020-0320 | 200 | 13024 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0320/0050-0050-0020-0320.html |    5-5-232. Local government interim committee, MCA  |  |
| MTS_0050-0050-0020-0330 | 200 | 9472 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0330/0050-0050-0020-0330.html |    5-5-233. Transportation interim committee, MCA  |  |
| MTS_0050-0050-0020-0340 | 200 | 12553 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0340/0050-0050-0020-0340.html |    5-5-234. Appointments, MCA  |  |
| MTS_0050-0050-0020-0350 | 200 | 16046 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0020/section_0350/0050-0050-0020-0350.html |    5-5-235. Montana criminal justice oversight council -- duties -- membership,  |  |
| MTS_0050-0050-0030-0010 | 200 | 9549 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0030/section_0010/0050-0050-0030-0010.html |    5-5-301. Governor to transmit list of appointments to legislature, MCA  |  |
| MTS_0050-0050-0030-0020 | 200 | 9505 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0030/section_0020/0050-0050-0030-0020.html |    5-5-302. Nominations to senate to be in writing, MCA  |  |
| MTS_0050-0050-0030-0030 | 200 | 9272 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0030/section_0030/0050-0050-0030-0030.html |    5-5-303. Resolution of concurrence, MCA  |  |
| MTS_0050-0050-0040-0010 | 200 | 9559 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0010/0050-0050-0040-0010.html |    5-5-401. Officers liable to impeachment, MCA  |  |
| MTS_0050-0050-0040-0020 | 200 | 9431 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0020/0050-0050-0040-0020.html |    5-5-402. Sole power of impeachment, MCA  |  |
| MTS_0050-0050-0040-0030 | 200 | 10076 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0030/0050-0050-0040-0030.html |    5-5-403. Trial of impeachments, MCA  |  |
| MTS_0050-0050-0040-0040 | 200 | 9667 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0040/0050-0050-0040-0040.html |    5-5-404. Officers of the court, MCA  |  |
| MTS_0050-0050-0040-0050 | 200 | 9112 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0050/0050-0050-0040-0050.html |    5-5-405. Senate subpoenas, MCA  |  |
| MTS_0050-0050-0040-0060 | 200 | 8829 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0060/0050-0050-0040-0060.html |    5-5-406. through 5-5-410 reserved, MCA  |  |
| MTS_0050-0050-0040-0110 | 200 | 9656 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0110/0050-0050-0040-0110.html |    5-5-411. Articles of impeachment, MCA  |  |
| MTS_0050-0050-0040-0120 | 200 | 9439 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0120/0050-0050-0040-0120.html |    5-5-412. Delivery of articles to senate, MCA  |  |
| MTS_0050-0050-0040-0130 | 200 | 10065 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0130/0050-0050-0040-0130.html |    5-5-413. Suspension pending trial -- filling vacancy, MCA  |  |
| MTS_0050-0050-0040-0140 | 200 | 9775 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0140/0050-0050-0040-0140.html |    5-5-414. Time of hearing -- service of defendant, MCA  |  |
| MTS_0050-0050-0040-0150 | 200 | 9626 | https://leg.mt.gov/bills/mca/title_0050/chapter_0050/part_0040/section_0150/0050-0050-0040-0150.html |    5-5-415. Service -- how made, MCA  |  |
