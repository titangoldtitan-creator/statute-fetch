| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0020-0160-0010-0010 | 200 | 10780 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0010/section_0010/0020-0160-0010-0010.html |    2-16-101. Classification of public officers, MCA  |  |
| MTS_0020-0160-0010-0020 | 200 | 11206 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0010/section_0020/0020-0160-0010-0020.html |    2-16-102. Qualifications generally -- age and citizenship, MCA  |  |
| MTS_0020-0160-0010-0030 | 200 | 9550 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0010/section_0030/0020-0160-0010-0030.html |    2-16-103. through 2-16-106 reserved, MCA  |  |
| MTS_0020-0160-0010-0070 | 200 | 10169 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0010/section_0070/0020-0160-0010-0070.html |    2-16-107. Use of Montana flag at funerals, MCA  |  |
| MTS_0020-0160-0010-0080 | 200 | 9524 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0010/section_0080/0020-0160-0010-0080.html |    2-16-108. through 2-16-110 reserved, MCA  |  |
| MTS_0020-0160-0010-0110 | 200 | 10499 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0010/section_0110/0020-0160-0010-0110.html |    2-16-111. Residence of officers, MCA  |  |
| MTS_0020-0160-0010-0120 | 200 | 10318 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0010/section_0120/0020-0160-0010-0120.html |    2-16-112. Absence from state, MCA  |  |
| MTS_0020-0160-0010-0130 | 200 | 10252 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0010/section_0130/0020-0160-0010-0130.html |    2-16-113. Seals, MCA  |  |
| MTS_0020-0160-0010-0140 | 200 | 12956 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0010/section_0140/0020-0160-0010-0140.html |    2-16-114. Facsimile signatures and seals, MCA  |  |
| MTS_0020-0160-0010-0150 | 200 | 10248 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0010/section_0150/0020-0160-0010-0150.html |    2-16-115. Signature of officer acting ex officio, MCA  |  |
| MTS_0020-0160-0010-0160 | 200 | 9937 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0010/section_0160/0020-0160-0010-0160.html |    2-16-116. Power to administer oaths, MCA  |  |
| MTS_0020-0160-0010-0170 | 200 | 12273 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0010/section_0170/0020-0160-0010-0170.html |    2-16-117. Office hours, MCA  |  |
| MTS_0020-0160-0020-0010 | 200 | 9933 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0020/section_0010/0020-0160-0020-0010.html |    2-16-201. Manner of election of certain officers, MCA  |  |
| MTS_0020-0160-0020-0020 | 200 | 10522 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0020/section_0020/0020-0160-0020-0020.html |    2-16-202. Title contested -- salary withheld, MCA  |  |
| MTS_0020-0160-0020-0030 | 200 | 10033 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0020/section_0030/0020-0160-0020-0030.html |    2-16-203. Manner of appointments, MCA  |  |
| MTS_0020-0160-0020-0040 | 200 | 10688 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0020/section_0040/0020-0160-0020-0040.html |    2-16-204. Gubernatorial commissions, MCA  |  |
| MTS_0020-0160-0020-0050 | 200 | 9995 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0020/section_0050/0020-0160-0020-0050.html |    2-16-205. Other commissions, MCA  |  |
| MTS_0020-0160-0020-0060 | 200 | 9528 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0020/section_0060/0020-0160-0020-0060.html |    2-16-206. through 2-16-210 reserved, MCA  |  |
| MTS_0020-0160-0020-0110 | 200 | 11093 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0020/section_0110/0020-0160-0020-0110.html |    2-16-211. Oaths -- form -- before whom -- when, MCA  |  |
| MTS_0020-0160-0020-0120 | 200 | 11178 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0020/section_0120/0020-0160-0020-0120.html |    2-16-212. Filing, MCA  |  |
| MTS_0020-0160-0020-0130 | 200 | 10841 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0020/section_0130/0020-0160-0020-0130.html |    2-16-213. Term of office -- holdover -- assumption of office, MCA  |  |
| MTS_0020-0160-0020-0140 | 200 | 9990 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0020/section_0140/0020-0160-0020-0140.html |    2-16-214. Definition of current term for purposes of term limits, MCA  |  |
| MTS_0020-0160-0030-0010 | 200 | 10812 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0030/section_0010/0020-0160-0030-0010.html |    2-16-301. Appointment of deputies and subordinate officers -- number, MCA  |  |
| MTS_0020-0160-0030-0020 | 200 | 9965 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0030/section_0020/0020-0160-0030-0020.html |    2-16-302. Oath of deputies, MCA  |  |
| MTS_0020-0160-0030-0030 | 200 | 9686 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0030/section_0030/0020-0160-0030-0030.html |    2-16-303. Powers, MCA  |  |
| MTS_0020-0160-0040-0010 | 200 | 9805 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0040/section_0010/0020-0160-0040-0010.html |    2-16-401. Repealed, MCA  |  |
| MTS_0020-0160-0040-0020 | 200 | 9822 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0040/section_0020/0020-0160-0040-0020.html |    2-16-402. Repealed, MCA  |  |
| MTS_0020-0160-0040-0030 | 200 | 10563 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0040/section_0030/0020-0160-0040-0030.html |    2-16-403. Salaries of supreme court justices, MCA  |  |
| MTS_0020-0160-0040-0040 | 200 | 9734 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0040/section_0040/0020-0160-0040-0040.html |    2-16-404. Repealed, MCA  |  |
| MTS_0020-0160-0040-0050 | 200 | 12183 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0040/section_0050/0020-0160-0040-0050.html |    2-16-405. Salaries of certain elected state officials, MCA  |  |
| MTS_0020-0160-0040-0060 | 200 | 10449 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0040/section_0060/0020-0160-0040-0060.html |    2-16-406. Salary for all services -- how paid, MCA  |  |
| MTS_0020-0160-0050-0010 | 200 | 12291 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0010/0020-0160-0050-0010.html |    2-16-501. Vacancies created, MCA  |  |
| MTS_0020-0160-0050-0020 | 200 | 11683 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0020/0020-0160-0050-0020.html |    2-16-502. Resignations, MCA  |  |
| MTS_0020-0160-0050-0030 | 200 | 10446 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0030/0020-0160-0050-0030.html |    2-16-503. Notice of removal, MCA  |  |
| MTS_0020-0160-0050-0040 | 200 | 11696 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0040/0020-0160-0050-0040.html |    2-16-504. Elective officers' inability to perform -- filling vacancy -- notic |  |
| MTS_0020-0160-0050-0050 | 200 | 10471 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0050/0020-0160-0050-0050.html |    2-16-505. Filling vacancies in certain elective offices, MCA  |  |
| MTS_0020-0160-0050-0060 | 200 | 10926 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0060/0020-0160-0050-0060.html |    2-16-506. Filling vacancies -- recess appointments, MCA  |  |
| MTS_0020-0160-0050-0070 | 200 | 10301 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0070/0020-0160-0050-0070.html |    2-16-507. Powers and duties of officer filling unexpired term, MCA  |  |
| MTS_0020-0160-0050-0080 | 200 | 9588 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0080/0020-0160-0050-0080.html |    2-16-508. through 2-16-510 reserved, MCA  |  |
| MTS_0020-0160-0050-0110 | 200 | 10510 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0110/0020-0160-0050-0110.html |    2-16-511. Vacancy in office of governor and lieutenant governor, MCA  |  |
| MTS_0020-0160-0050-0120 | 200 | 10608 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0120/0020-0160-0050-0120.html |    2-16-512. Election by legislature if president of senate and speaker unable t |  |
| MTS_0020-0160-0050-0130 | 200 | 11085 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0130/0020-0160-0050-0130.html |    2-16-513. Succession in case of termination or incapacitation of primary succ |  |
| MTS_0020-0160-0050-0140 | 200 | 10115 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0140/0020-0160-0050-0140.html |    2-16-514. Successor to serve until next general election, MCA  |  |
| MTS_0020-0160-0050-0150 | 200 | 10324 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0150/0020-0160-0050-0150.html |    2-16-515. Governor and lieutenant governor incapacitated, MCA  |  |
| MTS_0020-0160-0050-0160 | 200 | 9555 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0160/0020-0160-0050-0160.html |    2-16-516. through 2-16-520 reserved, MCA  |  |
| MTS_0020-0160-0050-0210 | 200 | 10230 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0050/section_0210/0020-0160-0050-0210.html |    2-16-521. Powers of acting governor, MCA  |  |
| MTS_0020-0160-0060-0010 | 200 | 9547 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0010/0020-0160-0060-0010.html |    2-16-601. Short title, MCA  |  |
| MTS_0020-0160-0060-0020 | 200 | 11516 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0020/0020-0160-0060-0020.html |    2-16-602. Definitions, MCA  |  |
| MTS_0020-0160-0060-0030 | 200 | 11047 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0030/0020-0160-0060-0030.html |    2-16-603. Officers subject to recall -- grounds for recall, MCA  |  |
| MTS_0020-0160-0060-0040 | 200 | 9548 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0040/0020-0160-0060-0040.html |    2-16-604. through 2-16-610 reserved, MCA  |  |
| MTS_0020-0160-0060-0110 | 200 | 9937 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0110/0020-0160-0060-0110.html |    2-16-611. Method of removal cumulative, MCA  |  |
| MTS_0020-0160-0060-0120 | 200 | 11537 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0120/0020-0160-0060-0120.html |    2-16-612. Persons qualified to petition -- penalty for false signatures, MCA  |  |
| MTS_0020-0160-0060-0130 | 200 | 10845 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0130/0020-0160-0060-0130.html |    2-16-613. Limitations on recall petitions, MCA  |  |
| MTS_0020-0160-0060-0140 | 200 | 11982 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0140/0020-0160-0060-0140.html |    2-16-614. Number of electors required for recall petition, MCA  |  |
| MTS_0020-0160-0060-0150 | 200 | 11681 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0150/0020-0160-0060-0150.html |    2-16-615. Filing of recall petitions -- mandamus for refusal, MCA  |  |
| MTS_0020-0160-0060-0160 | 200 | 12133 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0160/0020-0160-0060-0160.html |    2-16-616. Form of recall petition, MCA  |  |
| MTS_0020-0160-0060-0170 | 200 | 11463 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0170/0020-0160-0060-0170.html |    2-16-617. Form of circulation sheets, MCA  |  |
| MTS_0020-0160-0060-0180 | 200 | 9947 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0180/0020-0160-0060-0180.html |    2-16-618. Forms not mandatory, MCA  |  |
| MTS_0020-0160-0060-0190 | 200 | 11544 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0190/0020-0160-0060-0190.html |    2-16-619. Submission of circulation sheets -- certification of signatures, MC |  |
| MTS_0020-0160-0060-0200 | 200 | 12383 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0200/0020-0160-0060-0200.html |    2-16-620. County clerk to verify signatures, MCA  |  |
| MTS_0020-0160-0060-0210 | 200 | 10819 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0210/0020-0160-0060-0210.html |    2-16-621. Notification to officer -- statement of justification, MCA  |  |
| MTS_0020-0160-0060-0220 | 200 | 11140 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0220/0020-0160-0060-0220.html |    2-16-622. Resignation of officer -- proclamation of election, MCA  |  |
| MTS_0020-0160-0060-0230 | 200 | 9547 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0230/0020-0160-0060-0230.html |    2-16-623. through 2-16-630 reserved, MCA  |  |
| MTS_0020-0160-0060-0310 | 200 | 10330 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0310/0020-0160-0060-0310.html |    2-16-631. Notice of recall election, MCA  |  |
| MTS_0020-0160-0060-0320 | 200 | 10759 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0320/0020-0160-0060-0320.html |    2-16-632. Conduct of special elections, MCA  |  |
| MTS_0020-0160-0060-0330 | 200 | 10580 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0330/0020-0160-0060-0330.html |    2-16-633. Form of ballot, MCA  |  |
| MTS_0020-0160-0060-0340 | 200 | 10303 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0340/0020-0160-0060-0340.html |    2-16-634. Expenses of election, MCA  |  |
| MTS_0020-0160-0060-0350 | 200 | 10217 | https://leg.mt.gov/bills/mca/title_0020/chapter_0160/part_0060/section_0350/0020-0160-0060-0350.html |    2-16-635. Officer to remain in office until results declared -- filling of va |  |
| MTS_0020-0170-0010-0010 | 200 | 14389 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0010/0020-0170-0010-0010.html |    2-17-101. Allocation of space -- leasing -- definition, MCA  |  |
| MTS_0020-0170-0010-0020 | 200 | 9972 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0020/0020-0170-0010-0020.html |    2-17-102. Warehouses, MCA  |  |
| MTS_0020-0170-0010-0030 | 200 | 9968 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0030/0020-0170-0010-0030.html |    2-17-103. Press room, MCA  |  |
| MTS_0020-0170-0010-0040 | 200 | 10469 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0040/0020-0170-0010-0040.html |    2-17-104. Deductible insurance plan for state buildings and contents -- admin |  |
| MTS_0020-0170-0010-0050 | 200 | 12382 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0050/0020-0170-0010-0050.html |    2-17-105. Insurance on state buildings -- use of proceeds -- building replace |  |
| MTS_0020-0170-0010-0060 | 200 | 9893 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0060/0020-0170-0010-0060.html |    2-17-106. Repealed, MCA  |  |
| MTS_0020-0170-0010-0070 | 200 | 11166 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0070/0020-0170-0010-0070.html |    2-17-107. State consideration for use of heritage properties, MCA  |  |
| MTS_0020-0170-0010-0080 | 200 | 14648 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0080/0020-0170-0010-0080.html |    2-17-108. Allocation of legislative space, MCA  |  |
| MTS_0020-0170-0010-0090 | 200 | 9605 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0090/0020-0170-0010-0090.html |    2-17-109. Renumbered 2-17-810, MCA  |  |
| MTS_0020-0170-0010-0100 | 200 | 9786 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0100/0020-0170-0010-0100.html |    2-17-110. Repealed, MCA  |  |
| MTS_0020-0170-0010-0110 | 200 | 9647 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0110/0020-0170-0010-0110.html |    2-17-111. Renumbered 2-17-811, MCA  |  |
| MTS_0020-0170-0010-0120 | 200 | 10722 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0120/0020-0170-0010-0120.html |    2-17-112. Fire protection for state-owned buildings -- department of administ |  |
| MTS_0020-0170-0010-0130 | 200 | 9705 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0130/0020-0170-0010-0130.html |    2-17-113. Renumbered 2-17-816, MCA  |  |
| MTS_0020-0170-0010-0140 | 200 | 13948 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0140/0020-0170-0010-0140.html |    2-17-114. Reservation of space for legislature -- legislative council duties, |  |
| MTS_0020-0170-0010-0150 | 200 | 10843 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0150/0020-0170-0010-0150.html |    2-17-115. Reservation of space for executive branch, MCA  |  |
| MTS_0020-0170-0010-0160 | 200 | 9612 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0160/0020-0170-0010-0160.html |    2-17-116. through 2-17-120 reserved, MCA  |  |
| MTS_0020-0170-0010-0210 | 200 | 9780 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0210/0020-0170-0010-0210.html |    2-17-121. Repealed, MCA  |  |
| MTS_0020-0170-0010-0220 | 200 | 9763 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0220/0020-0170-0010-0220.html |    2-17-122. Repealed, MCA  |  |
| MTS_0020-0170-0010-0230 | 200 | 9763 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0230/0020-0170-0010-0230.html |    2-17-123. Repealed, MCA  |  |
| MTS_0020-0170-0010-0240 | 200 | 9763 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0240/0020-0170-0010-0240.html |    2-17-124. Repealed, MCA  |  |
| MTS_0020-0170-0010-0250 | 200 | 9763 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0250/0020-0170-0010-0250.html |    2-17-125. Repealed, MCA  |  |
| MTS_0020-0170-0010-0260 | 200 | 9763 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0260/0020-0170-0010-0260.html |    2-17-126. Repealed, MCA  |  |
| MTS_0020-0170-0010-0270 | 200 | 9779 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0270/0020-0170-0010-0270.html |    2-17-127. Repealed, MCA  |  |
| MTS_0020-0170-0010-0280 | 200 | 9590 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0280/0020-0170-0010-0280.html |    2-17-128. through 2-17-130 reserved, MCA  |  |
| MTS_0020-0170-0010-0310 | 200 | 9616 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0310/0020-0170-0010-0310.html |    2-17-131. Renumbered 2-17-817, MCA  |  |
| MTS_0020-0170-0010-0320 | 200 | 9620 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0320/0020-0170-0010-0320.html |    2-17-132. through 2-17-134 reserved, MCA  |  |
| MTS_0020-0170-0010-0350 | 200 | 11720 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0010/section_0350/0020-0170-0010-0350.html |    2-17-135. Lease or exchange of historic property, MCA  |  |
| MTS_0020-0170-0020-0010 | 200 | 9983 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0020/section_0010/0020-0170-0020-0010.html |    2-17-201. Inspection of property and warehouses, MCA  |  |
| MTS_0020-0170-0020-0020 | 200 | 11105 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0020/section_0020/0020-0170-0020-0020.html |    2-17-202. Inventory -- property to be charged to receiving agency, MCA  |  |
| MTS_0020-0170-0030-0010 | 200 | 10922 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0010/0020-0170-0030-0010.html |    2-17-301. Supervision of mailing and copying facilities, MCA  |  |
| MTS_0020-0170-0030-0020 | 200 | 10024 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0020/0020-0170-0030-0020.html |    2-17-302. Repealed, MCA  |  |
| MTS_0020-0170-0030-0030 | 200 | 9562 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0030/0020-0170-0030-0030.html |    2-17-303. Renumbered 2-17-531, MCA  |  |
