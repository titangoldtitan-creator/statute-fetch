| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0020-0170-0030-0040 | 200 | 9753 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0040/0020-0170-0030-0040.html |    2-17-304. Repealed, MCA  |  |
| MTS_0020-0170-0030-0050 | 200 | 9721 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0050/0020-0170-0030-0050.html |    2-17-305. Repealed, MCA  |  |
| MTS_0020-0170-0030-0060 | 200 | 9528 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0060/0020-0170-0030-0060.html |    2-17-306. Renumbered 2-17-546, MCA  |  |
| MTS_0020-0170-0030-0070 | 200 | 9526 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0070/0020-0170-0030-0070.html |    2-17-307. through 2-17-310 reserved, MCA  |  |
| MTS_0020-0170-0030-0110 | 200 | 9539 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0110/0020-0170-0030-0110.html |    2-17-311. Renumbered 2-17-541, MCA  |  |
| MTS_0020-0170-0030-0120 | 200 | 9533 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0120/0020-0170-0030-0120.html |    2-17-312. Renumbered 2-17-542, MCA  |  |
| MTS_0020-0170-0030-0130 | 200 | 9539 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0130/0020-0170-0030-0130.html |    2-17-313. Renumbered 2-17-543, MCA  |  |
| MTS_0020-0170-0030-0140 | 200 | 9515 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0140/0020-0170-0030-0140.html |    2-17-314. through 2-17-320 reserved, MCA  |  |
| MTS_0020-0170-0030-0210 | 200 | 9747 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0210/0020-0170-0030-0210.html |    2-17-321. Repealed, MCA  |  |
| MTS_0020-0170-0030-0220 | 200 | 9522 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0220/0020-0170-0030-0220.html |    2-17-322. Renumbered 2-17-532, MCA  |  |
| MTS_0020-0170-0030-0230 | 200 | 9322 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0030/section_0230/0020-0170-0030-0230.html |    2-17-323. Renumbered 2-17-533, MCA  |  |
| MTS_0020-0170-0040-0010 | 200 | 10070 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0010/0020-0170-0040-0010.html |    2-17-401. Title to motor vehicles, MCA  |  |
| MTS_0020-0170-0040-0020 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0020/0020-0170-0040-0020.html |    2-17-402. Seal on motor vehicles, MCA  |  |
| MTS_0020-0170-0040-0030 | 200 | 9971 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0030/0020-0170-0040-0030.html |    2-17-403. Requisitions for purchases, MCA  |  |
| MTS_0020-0170-0040-0040 | 200 | 9537 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0040/0020-0170-0040-0040.html |    2-17-404. through 2-17-410 reserved, MCA  |  |
| MTS_0020-0170-0040-0110 | 200 | 10851 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0110/0020-0170-0040-0110.html |    2-17-411. Motor pool -- department of transportation -- exceptions, MCA  |  |
| MTS_0020-0170-0040-0120 | 200 | 10570 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0120/0020-0170-0040-0120.html |    2-17-412. Assignment and transfer, MCA  |  |
| MTS_0020-0170-0040-0130 | 200 | 9818 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0130/0020-0170-0040-0130.html |    2-17-413. Repealed, MCA  |  |
| MTS_0020-0170-0040-0140 | 200 | 11170 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0140/0020-0170-0040-0140.html |    2-17-414. State vehicles to use ethanol-blended gasoline -- definition, MCA  |  |
| MTS_0020-0170-0040-0150 | 200 | 11079 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0150/0020-0170-0040-0150.html |    2-17-415. Definitions, MCA  |  |
| MTS_0020-0170-0040-0160 | 200 | 10996 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0160/0020-0170-0040-0160.html |    2-17-416. Fuel economy standards -- exceptions, MCA  |  |
| MTS_0020-0170-0040-0170 | 200 | 10753 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0170/0020-0170-0040-0170.html |    2-17-417. Vehicle fleet energy conservation plan, MCA  |  |
| MTS_0020-0170-0040-0180 | 200 | 10082 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0180/0020-0170-0040-0180.html |    2-17-418. Agency records on fuel efficiency measures, MCA  |  |
| MTS_0020-0170-0040-0190 | 200 | 9588 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0190/0020-0170-0040-0190.html |    2-17-419. and 2-17-420 reserved, MCA  |  |
| MTS_0020-0170-0040-0210 | 200 | 11905 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0210/0020-0170-0040-0210.html |    2-17-421. Use -- state business only -- exception -- compensation for driving |  |
| MTS_0020-0170-0040-0220 | 200 | 10381 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0220/0020-0170-0040-0220.html |    2-17-422. Operating history, MCA  |  |
| MTS_0020-0170-0040-0230 | 200 | 11465 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0230/0020-0170-0040-0230.html |    2-17-423. Rules, MCA  |  |
| MTS_0020-0170-0040-0240 | 200 | 10559 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0240/0020-0170-0040-0240.html |    2-17-424. Acceptable uses -- rulemaking, MCA  |  |
| MTS_0020-0170-0040-0250 | 200 | 13011 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0250/0020-0170-0040-0250.html |    2-17-425. Limit on use of state vehicle to commute to worksite -- definitions |  |
| MTS_0020-0170-0040-0260 | 200 | 9530 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0260/0020-0170-0040-0260.html |    2-17-426. through 2-17-430 reserved, MCA  |  |
| MTS_0020-0170-0040-0310 | 200 | 9839 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0310/0020-0170-0040-0310.html |    2-17-431. Repealed, MCA  |  |
| MTS_0020-0170-0040-0320 | 200 | 9623 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0040/section_0320/0020-0170-0040-0320.html |    2-17-432. Violation a misdemeanor, MCA  |  |
| MTS_0020-0170-0050-0010 | 200 | 9801 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0010/0020-0170-0050-0010.html |    2-17-501. Repealed, MCA  |  |
| MTS_0020-0170-0050-0020 | 200 | 9828 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0020/0020-0170-0050-0020.html |    2-17-502. Repealed, MCA  |  |
| MTS_0020-0170-0050-0030 | 200 | 9583 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0030/0020-0170-0050-0030.html |    2-17-503. Renumbered 2-17-534, MCA  |  |
| MTS_0020-0170-0050-0040 | 200 | 9781 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0040/0020-0170-0050-0040.html |    2-17-504. Short title, MCA  |  |
| MTS_0020-0170-0050-0050 | 200 | 15357 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0050/0020-0170-0050-0050.html |    2-17-505. Policy, MCA  |  |
| MTS_0020-0170-0050-0060 | 200 | 13013 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0060/0020-0170-0050-0060.html |    2-17-506. Definitions, MCA  |  |
| MTS_0020-0170-0050-0070 | 200 | 9603 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0070/0020-0170-0050-0070.html |    2-17-507. through 2-17-510 reserved, MCA  |  |
| MTS_0020-0170-0050-0110 | 200 | 10574 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0110/0020-0170-0050-0110.html |    2-17-511. Chief information officer -- duties, MCA  |  |
| MTS_0020-0170-0050-0120 | 200 | 16798 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0120/0020-0170-0050-0120.html |    2-17-512. Powers and duties of department, MCA  |  |
| MTS_0020-0170-0050-0130 | 200 | 15399 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0130/0020-0170-0050-0130.html |    2-17-513. Duties of board, MCA  |  |
| MTS_0020-0170-0050-0140 | 200 | 11896 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0140/0020-0170-0050-0140.html |    2-17-514. Department -- enforcement responsibilities, MCA  |  |
| MTS_0020-0170-0050-0150 | 200 | 10883 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0150/0020-0170-0050-0150.html |    2-17-515. Granting exceptions to state agencies, MCA  |  |
| MTS_0020-0170-0050-0160 | 200 | 15945 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0160/0020-0170-0050-0160.html |    2-17-516. Exemptions -- department of justice -- secretary of state -- univer |  |
| MTS_0020-0170-0050-0170 | 200 | 10169 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0170/0020-0170-0050-0170.html |    2-17-517. Legislative and judicial branch information sharing, MCA  |  |
| MTS_0020-0170-0050-0180 | 200 | 13379 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0180/0020-0170-0050-0180.html |    2-17-518. Rulemaking authority, MCA  |  |
| MTS_0020-0170-0050-0190 | 200 | 9619 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0190/0020-0170-0050-0190.html |    2-17-519. and 2-17-520 reserved, MCA  |  |
| MTS_0020-0170-0050-0210 | 200 | 12800 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0210/0020-0170-0050-0210.html |    2-17-521. State strategic information technology plan -- biennial report, MCA |  |
| MTS_0020-0170-0050-0220 | 200 | 11044 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0220/0020-0170-0050-0220.html |    2-17-522. State strategic information technology plan -- distribution, MCA  |  |
| MTS_0020-0170-0050-0230 | 200 | 10863 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0230/0020-0170-0050-0230.html |    2-17-523. Agency information technology plans -- policy, MCA  |  |
| MTS_0020-0170-0050-0240 | 200 | 13598 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0240/0020-0170-0050-0240.html |    2-17-524. Agency information technology plans -- form and content -- performa |  |
| MTS_0020-0170-0050-0250 | 200 | 9565 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0250/0020-0170-0050-0250.html |    2-17-525. reserved, MCA  |  |
| MTS_0020-0170-0050-0260 | 200 | 13371 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0260/0020-0170-0050-0260.html |    2-17-526. Information technology project budget summary, MCA  |  |
| MTS_0020-0170-0050-0270 | 200 | 11235 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0270/0020-0170-0050-0270.html |    2-17-527. Agency information technology plans -- review and approval -- updat |  |
| MTS_0020-0170-0050-0280 | 200 | 9634 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0280/0020-0170-0050-0280.html |    2-17-528. through 2-17-530 reserved, MCA  |  |
| MTS_0020-0170-0050-0310 | 200 | 10009 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0310/0020-0170-0050-0310.html |    2-17-531. Repealed, MCA  |  |
| MTS_0020-0170-0050-0320 | 200 | 11961 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0320/0020-0170-0050-0320.html |    2-17-532. Establishment, MCA  |  |
| MTS_0020-0170-0050-0330 | 200 | 11314 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0330/0020-0170-0050-0330.html |    2-17-533. Responsibilities, MCA  |  |
| MTS_0020-0170-0050-0340 | 200 | 11771 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0340/0020-0170-0050-0340.html |    2-17-534. Security responsibilities of department, MCA  |  |
| MTS_0020-0170-0050-0350 | 200 | 9604 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0350/0020-0170-0050-0350.html |    2-17-535. through 2-17-540 reserved, MCA  |  |
| MTS_0020-0170-0050-0410 | 200 | 9907 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0410/0020-0170-0050-0410.html |    2-17-541. Repealed, MCA  |  |
| MTS_0020-0170-0050-0420 | 200 | 9945 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0420/0020-0170-0050-0420.html |    2-17-542. Repealed, MCA  |  |
| MTS_0020-0170-0050-0430 | 200 | 11590 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0430/0020-0170-0050-0430.html |    2-17-543. 9-1-1 and mutual aid frequency programs -- rulemaking authority, MC |  |
| MTS_0020-0170-0050-0440 | 200 | 10308 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0440/0020-0170-0050-0440.html |    2-17-544. Mutual aid frequency program for land mobile radio, MCA  |  |
| MTS_0020-0170-0050-0450 | 200 | 10173 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0450/0020-0170-0050-0450.html |    2-17-545. Mutual aid frequencies manual -- land mobile radio, MCA  |  |
| MTS_0020-0170-0050-0460 | 200 | 10552 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0460/0020-0170-0050-0460.html |    2-17-546. Exemption of criminal justice information network -- exception, MCA |  |
| MTS_0020-0170-0050-0470 | 200 | 9630 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0470/0020-0170-0050-0470.html |    2-17-547. through 2-17-549 reserved, MCA  |  |
| MTS_0020-0170-0050-0500 | 200 | 10029 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0500/0020-0170-0050-0500.html |    2-17-550. Short title, MCA  |  |
| MTS_0020-0170-0050-0510 | 200 | 13811 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0510/0020-0170-0050-0510.html |    2-17-551. Definitions, MCA  |  |
| MTS_0020-0170-0050-0520 | 200 | 12409 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0520/0020-0170-0050-0520.html |    2-17-552. Collection of personally identifiable information -- requirements,  |  |
| MTS_0020-0170-0050-0530 | 200 | 10433 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0530/0020-0170-0050-0530.html |    2-17-553. No change of privacy right or public right to know, MCA  |  |
| MTS_0020-0170-0050-0540 | 200 | 9681 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0540/0020-0170-0050-0540.html |    2-17-554. through 2-17-559 reserved, MCA  |  |
| MTS_0020-0170-0050-0600 | 200 | 10362 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0600/0020-0170-0050-0600.html |    2-17-560. Reappropriation of long-range information technology capital projec |  |
| MTS_0020-0170-0050-0610 | 200 | 10010 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0050/section_0610/0020-0170-0050-0610.html |    2-17-561. Approval required, MCA  |  |
| MTS_0020-0170-0060-0010 | 200 | 10732 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0060/section_0010/0020-0170-0060-0010.html |    2-17-601. Statement of purpose -- policy, MCA  |  |
| MTS_0020-0170-0060-0020 | 200 | 10773 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0060/section_0020/0020-0170-0060-0020.html |    2-17-602. Definitions, MCA  |  |
| MTS_0020-0170-0060-0030 | 200 | 12930 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0060/section_0030/0020-0170-0060-0030.html |    2-17-603. Government competition with private internet services providers pro |  |
| MTS_0020-0170-0060-0040 | 200 | 10038 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0060/section_0040/0020-0170-0060-0040.html |    2-17-604. Alternatives to public internet services providers, MCA  |  |
| MTS_0020-0170-0080-0010 | 200 | 9536 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0010/0020-0170-0080-0010.html |    2-17-801. Short title, MCA  |  |
| MTS_0020-0170-0080-0020 | 200 | 16626 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0020/0020-0170-0080-0020.html |    2-17-802. Definitions, MCA  |  |
| MTS_0020-0170-0080-0030 | 200 | 13299 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0030/0020-0170-0080-0030.html |    2-17-803. Capitol complex advisory council established -- membership -- staff |  |
| MTS_0020-0170-0080-0040 | 200 | 13391 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0040/0020-0170-0080-0040.html |    2-17-804. Council duties and responsibilities, MCA  |  |
| MTS_0020-0170-0080-0050 | 200 | 18167 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0050/0020-0170-0080-0050.html |    2-17-805. Function of department of administration -- long-range master plan  |  |
| MTS_0020-0170-0080-0060 | 200 | 10603 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0060/0020-0170-0080-0060.html |    2-17-806. Department of administration to establish policies on capitol, MCA  |  |
| MTS_0020-0170-0080-0070 | 200 | 16130 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0070/0020-0170-0080-0070.html |    2-17-807. Approval for displays and naming buildings, spaces, and rooms, MCA  |  |
| MTS_0020-0170-0080-0080 | 200 | 17982 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0080/0020-0170-0080-0080.html |    2-17-808. Placement of certain busts, plaques, statues, memorials, monuments, |  |
| MTS_0020-0170-0080-0090 | 200 | 9893 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0090/0020-0170-0080-0090.html |    2-17-809. Repealed, MCA  |  |
| MTS_0020-0170-0080-0100 | 200 | 11188 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0100/0020-0170-0080-0100.html |    2-17-810. Remodeling and renovation -- senate chambers and former supreme cou |  |
| MTS_0020-0170-0080-0110 | 200 | 13161 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0110/0020-0170-0080-0110.html |    2-17-811. Custodial care of capitol buildings and grounds, MCA  |  |
| MTS_0020-0170-0080-0120 | 200 | 10516 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0120/0020-0170-0080-0120.html |    2-17-812. Inventory of improvements, MCA  |  |
| MTS_0020-0170-0080-0130 | 200 | 10419 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0130/0020-0170-0080-0130.html |    2-17-813. Certain items entrusted to Montana historical society, MCA  |  |
| MTS_0020-0170-0080-0140 | 200 | 9597 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0140/0020-0170-0080-0140.html |    2-17-814. and 2-17-815 reserved, MCA  |  |
| MTS_0020-0170-0080-0160 | 200 | 10565 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0160/0020-0170-0080-0160.html |    2-17-816. Parking citations within capitol complex, MCA  |  |
| MTS_0020-0170-0080-0170 | 200 | 10852 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0170/0020-0170-0080-0170.html |    2-17-817. Highway patrol officers' memorial, MCA  |  |
| MTS_0020-0170-0080-0180 | 200 | 10569 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0180/0020-0170-0080-0180.html |    2-17-818. Joseph P. Mazurek building, memorial, and plaque -- funding, MCA  |  |
| MTS_0020-0170-0080-0190 | 200 | 10954 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0190/0020-0170-0080-0190.html |    2-17-819. Memorial for Montana's organ donors -- display -- private funding,  |  |
| MTS_0020-0170-0080-0200 | 200 | 9610 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0200/0020-0170-0080-0200.html |    2-17-820. through 2-17-824 reserved, MCA  |  |
| MTS_0020-0170-0080-0250 | 200 | 10403 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0080/section_0250/0020-0170-0080-0250.html |    2-17-825. Report to legislature, MCA  |  |
| MTS_0020-0170-0110-0010 | 200 | 9572 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0110/section_0010/0020-0170-0110-0010.html |    2-17-1101. Short title, MCA  |  |
