| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0050-0180-0010-0040 | 200 | 9645 | https://leg.mt.gov/bills/mca/title_0050/chapter_0180/part_0010/section_0040/0050-0180-0010-0040.html |    5-18-104. Repealed, MCA  |  |
| MTS_0050-0180-0010-0050 | 200 | 9645 | https://leg.mt.gov/bills/mca/title_0050/chapter_0180/part_0010/section_0050/0050-0180-0010-0050.html |    5-18-105. Repealed, MCA  |  |
| MTS_0050-0180-0010-0060 | 200 | 9645 | https://leg.mt.gov/bills/mca/title_0050/chapter_0180/part_0010/section_0060/0050-0180-0010-0060.html |    5-18-106. Repealed, MCA  |  |
| MTS_0050-0180-0010-0070 | 200 | 9893 | https://leg.mt.gov/bills/mca/title_0050/chapter_0180/part_0010/section_0070/0050-0180-0010-0070.html |    5-18-107. Repealed, MCA  |  |
| MTS_0050-0180-0010-0080 | 200 | 9645 | https://leg.mt.gov/bills/mca/title_0050/chapter_0180/part_0010/section_0080/0050-0180-0010-0080.html |    5-18-108. Repealed, MCA  |  |
| MTS_0050-0180-0010-0090 | 200 | 9645 | https://leg.mt.gov/bills/mca/title_0050/chapter_0180/part_0010/section_0090/0050-0180-0010-0090.html |    5-18-109. Repealed, MCA  |  |
| MTS_0050-0180-0010-0100 | 200 | 9663 | https://leg.mt.gov/bills/mca/title_0050/chapter_0180/part_0010/section_0100/0050-0180-0010-0100.html |    5-18-110. Repealed, MCA  |  |
| MTS_0050-0180-0010-0110 | 200 | 9462 | https://leg.mt.gov/bills/mca/title_0050/chapter_0180/part_0010/section_0110/0050-0180-0010-0110.html |    5-18-111. through 5-18-114 reserved, MCA  |  |
| MTS_0050-0180-0010-0150 | 200 | 9504 | https://leg.mt.gov/bills/mca/title_0050/chapter_0180/part_0010/section_0150/0050-0180-0010-0150.html |    5-18-115. Repealed, MCA  |  |
| MTS_0050-0180-0020-0010 | 200 | 9483 | https://leg.mt.gov/bills/mca/title_0050/chapter_0180/part_0020/section_0010/0050-0180-0020-0010.html |    5-18-201. Repealed, MCA  |  |
| MTS_0050-0180-0020-0020 | 200 | 9686 | https://leg.mt.gov/bills/mca/title_0050/chapter_0180/part_0020/section_0020/0050-0180-0020-0020.html |    5-18-202. Repealed, MCA  |  |
| MTS_0050-0180-0020-0030 | 200 | 9548 | https://leg.mt.gov/bills/mca/title_0050/chapter_0180/part_0020/section_0030/0050-0180-0020-0030.html |    5-18-203. Repealed, MCA  |  |
| MTS_0050-0190-0010-0010 | 200 | 9411 | https://leg.mt.gov/bills/mca/title_0050/chapter_0190/part_0010/section_0010/0050-0190-0010-0010.html |    5-19-101. Repealed, MCA  |  |
| MTS_0050-0190-0010-0020 | 200 | 9645 | https://leg.mt.gov/bills/mca/title_0050/chapter_0190/part_0010/section_0020/0050-0190-0010-0020.html |    5-19-102. Repealed, MCA  |  |
| MTS_0050-0190-0010-0030 | 200 | 9614 | https://leg.mt.gov/bills/mca/title_0050/chapter_0190/part_0010/section_0030/0050-0190-0010-0030.html |    5-19-103. Repealed, MCA  |  |
| MTS_0050-0190-0010-0040 | 200 | 9646 | https://leg.mt.gov/bills/mca/title_0050/chapter_0190/part_0010/section_0040/0050-0190-0010-0040.html |    5-19-104. Repealed, MCA  |  |
| MTS_0050-0190-0010-0050 | 200 | 9614 | https://leg.mt.gov/bills/mca/title_0050/chapter_0190/part_0010/section_0050/0050-0190-0010-0050.html |    5-19-105. Repealed, MCA  |  |
| MTS_0050-0190-0010-0060 | 200 | 9614 | https://leg.mt.gov/bills/mca/title_0050/chapter_0190/part_0010/section_0060/0050-0190-0010-0060.html |    5-19-106. Repealed, MCA  |  |
| MTS_0050-0190-0010-0070 | 200 | 9646 | https://leg.mt.gov/bills/mca/title_0050/chapter_0190/part_0010/section_0070/0050-0190-0010-0070.html |    5-19-107. Repealed, MCA  |  |
| MTS_0050-0190-0010-0080 | 200 | 9446 | https://leg.mt.gov/bills/mca/title_0050/chapter_0190/part_0010/section_0080/0050-0190-0010-0080.html |    5-19-108. Repealed, MCA  |  |
| MTS_0050-0200-0010-0010 | 200 | 9510 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0010/section_0010/0050-0200-0010-0010.html |    5-20-101. Terminated, MCA  |  |
| MTS_0050-0200-0010-0020 | 200 | 9715 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0010/section_0020/0050-0200-0010-0020.html |    5-20-102. Terminated, MCA  |  |
| MTS_0050-0200-0010-0030 | 200 | 9715 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0010/section_0030/0050-0200-0010-0030.html |    5-20-103. Terminated, MCA  |  |
| MTS_0050-0200-0010-0040 | 200 | 9715 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0010/section_0040/0050-0200-0010-0040.html |    5-20-104. Terminated, MCA  |  |
| MTS_0050-0200-0010-0050 | 200 | 9715 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0010/section_0050/0050-0200-0010-0050.html |    5-20-105. Terminated, MCA  |  |
| MTS_0050-0200-0010-0060 | 200 | 9513 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0010/section_0060/0050-0200-0010-0060.html |    5-20-106. Terminated, MCA  |  |
| MTS_0050-0200-0020-0010 | 200 | 9505 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0020/section_0010/0050-0200-0020-0010.html |    5-20-201. Repealed, MCA  |  |
| MTS_0050-0200-0020-0020 | 200 | 9708 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0020/section_0020/0050-0200-0020-0020.html |    5-20-202. Repealed, MCA  |  |
| MTS_0050-0200-0020-0030 | 200 | 9708 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0020/section_0030/0050-0200-0020-0030.html |    5-20-203. Repealed, MCA  |  |
| MTS_0050-0200-0020-0040 | 200 | 9708 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0020/section_0040/0050-0200-0020-0040.html |    5-20-204. Repealed, MCA  |  |
| MTS_0050-0200-0020-0050 | 200 | 9708 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0020/section_0050/0050-0200-0020-0050.html |    5-20-205. Repealed, MCA  |  |
| MTS_0050-0200-0020-0060 | 200 | 9708 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0020/section_0060/0050-0200-0020-0060.html |    5-20-206. Repealed, MCA  |  |
| MTS_0050-0200-0020-0070 | 200 | 9708 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0020/section_0070/0050-0200-0020-0070.html |    5-20-207. Repealed, MCA  |  |
| MTS_0050-0200-0020-0080 | 200 | 9508 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0020/section_0080/0050-0200-0020-0080.html |    5-20-208. Repealed, MCA  |  |
| MTS_0050-0200-0030-0010 | 200 | 19688 | https://leg.mt.gov/bills/mca/title_0050/chapter_0200/part_0030/section_0010/0050-0200-0030-0010.html |    5-20-301. School funding interim commission, MCA  |  |
| MTS_0050-0210-0010-0010 | 200 | 9451 | https://leg.mt.gov/bills/mca/title_0050/chapter_0210/part_0010/section_0010/0050-0210-0010-0010.html |    5-21-101. Repealed, MCA  |  |
| MTS_0050-0210-0010-0020 | 200 | 9654 | https://leg.mt.gov/bills/mca/title_0050/chapter_0210/part_0010/section_0020/0050-0210-0010-0020.html |    5-21-102. Repealed, MCA  |  |
| MTS_0050-0210-0010-0030 | 200 | 9654 | https://leg.mt.gov/bills/mca/title_0050/chapter_0210/part_0010/section_0030/0050-0210-0010-0030.html |    5-21-103. Repealed, MCA  |  |
| MTS_0050-0210-0010-0040 | 200 | 9654 | https://leg.mt.gov/bills/mca/title_0050/chapter_0210/part_0010/section_0040/0050-0210-0010-0040.html |    5-21-104. Repealed, MCA  |  |
| MTS_0050-0210-0010-0050 | 200 | 9485 | https://leg.mt.gov/bills/mca/title_0050/chapter_0210/part_0010/section_0050/0050-0210-0010-0050.html |    5-21-105. Repealed, MCA  |  |
| MTS_0050-0220-0010-0010 | 200 | 9456 | https://leg.mt.gov/bills/mca/title_0050/chapter_0220/part_0010/section_0010/0050-0220-0010-0010.html |    5-22-101. Repealed, MCA  |  |
| MTS_0050-0220-0010-0020 | 200 | 9459 | https://leg.mt.gov/bills/mca/title_0050/chapter_0220/part_0010/section_0020/0050-0220-0010-0020.html |    5-22-102. Repealed, MCA  |  |
| MTS_0050-0230-0010-0010 | 200 | 9506 | https://leg.mt.gov/bills/mca/title_0050/chapter_0230/part_0010/section_0010/0050-0230-0010-0010.html |    5-23-101. Repealed, MCA  |  |
| MTS_0050-0230-0010-0020 | 200 | 9709 | https://leg.mt.gov/bills/mca/title_0050/chapter_0230/part_0010/section_0020/0050-0230-0010-0020.html |    5-23-102. Repealed, MCA  |  |
| MTS_0050-0230-0010-0030 | 200 | 9709 | https://leg.mt.gov/bills/mca/title_0050/chapter_0230/part_0010/section_0030/0050-0230-0010-0030.html |    5-23-103. Repealed, MCA  |  |
| MTS_0050-0230-0010-0040 | 200 | 9709 | https://leg.mt.gov/bills/mca/title_0050/chapter_0230/part_0010/section_0040/0050-0230-0010-0040.html |    5-23-104. Repealed, MCA  |  |
| MTS_0050-0230-0010-0050 | 200 | 9709 | https://leg.mt.gov/bills/mca/title_0050/chapter_0230/part_0010/section_0050/0050-0230-0010-0050.html |    5-23-105. Repealed, MCA  |  |
| MTS_0050-0230-0010-0060 | 200 | 9709 | https://leg.mt.gov/bills/mca/title_0050/chapter_0230/part_0010/section_0060/0050-0230-0010-0060.html |    5-23-106. Repealed, MCA  |  |
| MTS_0050-0230-0010-0070 | 200 | 9709 | https://leg.mt.gov/bills/mca/title_0050/chapter_0230/part_0010/section_0070/0050-0230-0010-0070.html |    5-23-107. Repealed, MCA  |  |
| MTS_0050-0230-0010-0080 | 200 | 9709 | https://leg.mt.gov/bills/mca/title_0050/chapter_0230/part_0010/section_0080/0050-0230-0010-0080.html |    5-23-108. Repealed, MCA  |  |
| MTS_0050-0230-0010-0090 | 200 | 9509 | https://leg.mt.gov/bills/mca/title_0050/chapter_0230/part_0010/section_0090/0050-0230-0010-0090.html |    5-23-109. Repealed, MCA  |  |
| MTS_0070-0010-0010-0010 | 200 | 9873 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0010/0070-0010-0010-0010.html |    7-1-101. Self-government powers, MCA  |  |
| MTS_0070-0010-0010-0020 | 200 | 10308 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0020/0070-0010-0010-0020.html |    7-1-102. Authorization for self-government services and functions, MCA  |  |
| MTS_0070-0010-0010-0030 | 200 | 10372 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0030/0070-0010-0010-0030.html |    7-1-103. General power government limitations not applicable, MCA  |  |
| MTS_0070-0010-0010-0040 | 200 | 10115 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0040/0070-0010-0010-0040.html |    7-1-104. Legislative power vested in legislative bodies, MCA  |  |
| MTS_0070-0010-0010-0050 | 200 | 10094 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0050/0070-0010-0010-0050.html |    7-1-105. State law applicable until superseded, MCA  |  |
| MTS_0070-0010-0010-0060 | 200 | 10130 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0060/0070-0010-0010-0060.html |    7-1-106. Construction of self-government powers, MCA  |  |
| MTS_0070-0010-0010-0070 | 200 | 9546 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0070/0070-0010-0010-0070.html |    7-1-107. through 7-1-110 reserved, MCA  |  |
| MTS_0070-0010-0010-0110 | 200 | 23050 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0110/0070-0010-0010-0110.html |    7-1-111. Powers denied, MCA  |  |
| MTS_0070-0010-0010-0120 | 200 | 11222 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0120/0070-0010-0010-0120.html |    7-1-112. Powers requiring delegation, MCA  |  |
| MTS_0070-0010-0010-0130 | 200 | 10703 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0130/0070-0010-0010-0130.html |    7-1-113. Consistency with state regulation required, MCA  |  |
| MTS_0070-0010-0010-0140 | 200 | 12196 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0140/0070-0010-0010-0140.html |    7-1-114. Mandatory provisions, MCA  |  |
| MTS_0070-0010-0010-0150 | 200 | 10812 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0150/0070-0010-0010-0150.html |    7-1-115. Governmental right to sue firearms or ammunition manufacturer, trade |  |
| MTS_0070-0010-0010-0160 | 200 | 11619 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0160/0070-0010-0010-0160.html |    7-1-116. Carbon fees, taxation, or penalties -- prohibition, MCA  |  |
| MTS_0070-0010-0010-0170 | 200 | 10493 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0170/0070-0010-0010-0170.html |    7-1-117. Energy source restrictions -- prohibition, MCA  |  |
| MTS_0070-0010-0010-0180 | 200 | 11951 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0180/0070-0010-0010-0180.html |    7-1-118. Legislative finding -- extreme risk protection order prohibition, MC |  |
| MTS_0070-0010-0010-0190 | 200 | 9457 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0190/0070-0010-0010-0190.html |    7-1-119. reserved, MCA  |  |
| MTS_0070-0010-0010-0200 | 200 | 9785 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0200/0070-0010-0010-0200.html |    7-1-120. Repealed, MCA  |  |
| MTS_0070-0010-0010-0210 | 200 | 12897 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0010/section_0210/0070-0010-0010-0210.html |    7-1-121. Statewide uniformity for auxiliary container regulations -- local pr |  |
| MTS_0070-0010-0020-0010 | 200 | 17725 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0020/section_0010/0070-0010-0020-0010.html |    7-1-201. Boards, MCA  |  |
| MTS_0070-0010-0020-0020 | 200 | 11038 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0020/section_0020/0070-0010-0020-0020.html |    7-1-202. Creation of new boards, MCA  |  |
| MTS_0070-0010-0020-0030 | 200 | 10507 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0020/section_0030/0070-0010-0020-0030.html |    7-1-203. County commissioners to assume duties of administrative boards, dist |  |
| MTS_0070-0010-0020-0040 | 200 | 10319 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0020/section_0040/0070-0010-0020-0040.html |    7-1-204. Board minutes, MCA  |  |
| MTS_0070-0010-0020-0050 | 200 | 11838 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0020/section_0050/0070-0010-0020-0050.html |    7-1-205. Service on more than one special purpose district board authorized i |  |
| MTS_0070-0010-0020-0060 | 200 | 13023 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0020/section_0060/0070-0010-0020-0060.html |    7-1-206. Local district board oversight -- methods for redress, MCA  |  |
| MTS_0070-0010-0210-0010 | 200 | 9974 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0210/section_0010/0070-0010-0210-0010.html |    7-1-2101. Nature of county, MCA  |  |
| MTS_0070-0010-0210-0020 | 200 | 9967 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0210/section_0020/0070-0010-0210-0020.html |    7-1-2102. Name of county, MCA  |  |
| MTS_0070-0010-0210-0030 | 200 | 11203 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0210/section_0030/0070-0010-0210-0030.html |    7-1-2103. County powers, MCA  |  |
| MTS_0070-0010-0210-0040 | 200 | 9838 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0210/section_0040/0070-0010-0210-0040.html |    7-1-2104. Exercise of county power, MCA  |  |
| MTS_0070-0010-0210-0050 | 200 | 11508 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0210/section_0050/0070-0010-0210-0050.html |    7-1-2105. Finding -- contract authority, MCA  |  |
| MTS_0070-0010-0210-0060 | 200 | 9346 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0210/section_0060/0070-0010-0210-0060.html |    7-1-2106. through 7-1-2110 reserved, MCA  |  |
| MTS_0070-0010-0210-0110 | 200 | 10383 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0210/section_0110/0070-0010-0210-0110.html |    7-1-2111. Repealed, MCA  |  |
| MTS_0070-0010-0210-0120 | 200 | 9733 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0210/section_0120/0070-0010-0210-0120.html |    7-1-2112. Repealed, MCA  |  |
| MTS_0070-0010-0210-0130 | 200 | 9374 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0210/section_0130/0070-0010-0210-0130.html |    7-1-2113. through 7-1-2120 reserved, MCA  |  |
| MTS_0070-0010-0210-0210 | 200 | 14935 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0210/section_0210/0070-0010-0210-0210.html |    7-1-2121. Publication and content of notice -- proof of publication, MCA  |  |
| MTS_0070-0010-0210-0220 | 200 | 11133 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0210/section_0220/0070-0010-0210-0220.html |    7-1-2122. Mail notice, MCA  |  |
| MTS_0070-0010-0210-0230 | 200 | 9618 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0210/section_0230/0070-0010-0210-0230.html |    7-1-2123. Posting, MCA  |  |
| MTS_0070-0010-0400-0010 | 200 | 9748 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0400/section_0010/0070-0010-0400-0010.html |    7-1-4001. Payment of contractors and subcontractors, MCA  |  |
| MTS_0070-0010-0410-0010 | 200 | 9724 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0410/section_0010/0070-0010-0410-0010.html |    7-1-4101. Nature of municipalities, MCA  |  |
| MTS_0070-0010-0410-0020 | 200 | 9868 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0410/section_0020/0070-0010-0410-0020.html |    7-1-4102. Name of municipality, MCA  |  |
| MTS_0070-0010-0410-0030 | 200 | 9706 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0410/section_0030/0070-0010-0410-0030.html |    7-1-4103. Repealed, MCA  |  |
| MTS_0070-0010-0410-0040 | 200 | 9969 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0410/section_0040/0070-0010-0410-0040.html |    7-1-4104. Repealed, MCA  |  |
| MTS_0070-0010-0410-0050 | 200 | 10926 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0410/section_0050/0070-0010-0410-0050.html |    7-1-4105. Finding -- contract authority, MCA  |  |
| MTS_0070-0010-0410-0060 | 200 | 9388 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0410/section_0060/0070-0010-0410-0060.html |    7-1-4106. through 7-1-4110 reserved, MCA  |  |
| MTS_0070-0010-0410-0110 | 200 | 10438 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0410/section_0110/0070-0010-0410-0110.html |    7-1-4111. Classification of municipalities, MCA  |  |
| MTS_0070-0010-0410-0120 | 200 | 11377 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0410/section_0120/0070-0010-0410-0120.html |    7-1-4112. Exceptions from classification system, MCA  |  |
| MTS_0070-0010-0410-0130 | 200 | 10097 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0410/section_0130/0070-0010-0410-0130.html |    7-1-4113. Basis of classification, MCA  |  |
| MTS_0070-0010-0410-0140 | 200 | 10382 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0410/section_0140/0070-0010-0410-0140.html |    7-1-4114. Advance in classification of municipalities, MCA  |  |
| MTS_0070-0010-0410-0150 | 200 | 11017 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0410/section_0150/0070-0010-0410-0150.html |    7-1-4115. Procedure to advance municipal classification, MCA  |  |
| MTS_0070-0010-0410-0160 | 200 | 10284 | https://leg.mt.gov/bills/mca/title_0070/chapter_0010/part_0410/section_0160/0070-0010-0410-0160.html |    7-1-4116. Officers of reclassified municipality, MCA  |  |
