| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0500-0040-0050-0040 | 200 | 11152 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0050/section_0040/0500-0040-0050-0040.html |    50-4-504. Definitions, MCA  |  |
| MTS_0500-0040-0050-0050 | 200 | 10378 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0050/section_0050/0500-0040-0050-0050.html |    50-4-505. Uniform claim forms and procedures, MCA  |  |
| MTS_0500-0040-0050-0060 | 200 | 9817 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0050/section_0060/0500-0040-0050-0060.html |    50-4-506. through 50-4-509 reserved, MCA  |  |
| MTS_0500-0040-0050-0100 | 200 | 10266 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0050/section_0100/0500-0040-0050-0100.html |    50-4-510. Short title, MCA  |  |
| MTS_0500-0040-0050-0110 | 200 | 10367 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0050/section_0110/0500-0040-0050-0110.html |    50-4-511. Legislative purpose, MCA  |  |
| MTS_0500-0040-0050-0120 | 200 | 11426 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0050/section_0120/0500-0040-0050-0120.html |    50-4-512. Disclosures required of health care providers, MCA  |  |
| MTS_0500-0040-0050-0130 | 200 | 9828 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0050/section_0130/0500-0040-0050-0130.html |    50-4-513. through 50-4-515 reserved, MCA  |  |
| MTS_0500-0040-0050-0160 | 200 | 10267 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0050/section_0160/0500-0040-0050-0160.html |    50-4-516. Short title, MCA  |  |
| MTS_0500-0040-0050-0170 | 200 | 10635 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0050/section_0170/0500-0040-0050-0170.html |    50-4-517. Legislative purpose, MCA  |  |
| MTS_0500-0040-0050-0180 | 200 | 10845 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0050/section_0180/0500-0040-0050-0180.html |    50-4-518. Disclosures required of health insurers -- limitations, MCA  |  |
| MTS_0500-0040-0060-0010 | 200 | 9897 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0010/0500-0040-0060-0010.html |    50-4-601. Repealed, MCA  |  |
| MTS_0500-0040-0060-0020 | 200 | 10063 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0020/0500-0040-0060-0020.html |    50-4-602. Repealed, MCA  |  |
| MTS_0500-0040-0060-0030 | 200 | 10131 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0030/0500-0040-0060-0030.html |    50-4-603. Repealed, MCA  |  |
| MTS_0500-0040-0060-0040 | 200 | 10064 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0040/0500-0040-0060-0040.html |    50-4-604. Repealed, MCA  |  |
| MTS_0500-0040-0060-0050 | 200 | 10112 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0050/0500-0040-0060-0050.html |    50-4-605. Repealed, MCA  |  |
| MTS_0500-0040-0060-0060 | 200 | 9848 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0060/0500-0040-0060-0060.html |    50-4-606. through 50-4-608 reserved, MCA  |  |
| MTS_0500-0040-0060-0090 | 200 | 10081 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0090/0500-0040-0060-0090.html |    50-4-609. Repealed, MCA  |  |
| MTS_0500-0040-0060-0100 | 200 | 10064 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0100/0500-0040-0060-0100.html |    50-4-610. Repealed, MCA  |  |
| MTS_0500-0040-0060-0110 | 200 | 10100 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0110/0500-0040-0060-0110.html |    50-4-611. Repealed, MCA  |  |
| MTS_0500-0040-0060-0120 | 200 | 10081 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0120/0500-0040-0060-0120.html |    50-4-612. Repealed, MCA  |  |
| MTS_0500-0040-0060-0130 | 200 | 9848 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0130/0500-0040-0060-0130.html |    50-4-613. through 50-4-620 reserved, MCA  |  |
| MTS_0500-0040-0060-0210 | 200 | 10080 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0210/0500-0040-0060-0210.html |    50-4-621. Repealed, MCA  |  |
| MTS_0500-0040-0060-0220 | 200 | 10063 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0220/0500-0040-0060-0220.html |    50-4-622. Repealed, MCA  |  |
| MTS_0500-0040-0060-0230 | 200 | 9863 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0060/section_0230/0500-0040-0060-0230.html |    50-4-623. Repealed, MCA  |  |
| MTS_0500-0040-0070-0010 | 200 | 21033 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0010/0500-0040-0070-0010.html |    50-4-701. Definitions, MCA  |  |
| MTS_0500-0040-0070-0020 | 200 | 10411 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0020/0500-0040-0070-0020.html |    50-4-702. Conversion transaction -- approval, MCA  |  |
| MTS_0500-0040-0070-0030 | 200 | 10938 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0030/0500-0040-0070-0030.html |    50-4-703. Rulemaking authority, MCA  |  |
| MTS_0500-0040-0070-0040 | 200 | 15254 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0040/0500-0040-0070-0040.html |    50-4-704. Rights and powers, MCA  |  |
| MTS_0500-0040-0070-0050 | 200 | 9973 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0050/0500-0040-0070-0050.html |    50-4-705. and 50-4-706 reserved, MCA  |  |
| MTS_0500-0040-0070-0070 | 200 | 12394 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0070/0500-0040-0070-0070.html |    50-4-707. Application process -- content, MCA  |  |
| MTS_0500-0040-0070-0080 | 200 | 11018 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0080/0500-0040-0070-0080.html |    50-4-708. Public records, MCA  |  |
| MTS_0500-0040-0070-0090 | 200 | 11656 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0090/0500-0040-0070-0090.html |    50-4-709. Receiving an application -- notice of application, MCA  |  |
| MTS_0500-0040-0070-0100 | 200 | 10540 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0100/0500-0040-0070-0100.html |    50-4-710. Public hearing, MCA  |  |
| MTS_0500-0040-0070-0110 | 200 | 12179 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0110/0500-0040-0070-0110.html |    50-4-711. Procedures, MCA  |  |
| MTS_0500-0040-0070-0120 | 200 | 11301 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0120/0500-0040-0070-0120.html |    50-4-712. Experts, MCA  |  |
| MTS_0500-0040-0070-0130 | 200 | 11326 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0130/0500-0040-0070-0130.html |    50-4-713. Deadline for approval or nonapproval, MCA  |  |
| MTS_0500-0040-0070-0140 | 200 | 10608 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0140/0500-0040-0070-0140.html |    50-4-714. Effect of determination, MCA  |  |
| MTS_0500-0040-0070-0150 | 200 | 13070 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0150/0500-0040-0070-0150.html |    50-4-715. Criteria for attorney general approval of conversion transaction, M |  |
| MTS_0500-0040-0070-0160 | 200 | 12211 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0160/0500-0040-0070-0160.html |    50-4-716. Criteria for distribution of assets, MCA  |  |
| MTS_0500-0040-0070-0170 | 200 | 14147 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0170/0500-0040-0070-0170.html |    50-4-717. Criteria for commissioner approval of conversion transaction, MCA  |  |
| MTS_0500-0040-0070-0180 | 200 | 10610 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0180/0500-0040-0070-0180.html |    50-4-718. Deposit of assets, MCA  |  |
| MTS_0500-0040-0070-0190 | 200 | 11028 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0190/0500-0040-0070-0190.html |    50-4-719. For-profit health entity, MCA  |  |
| MTS_0500-0040-0070-0200 | 200 | 15606 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0070/section_0200/0500-0040-0070-0200.html |    50-4-720. Distribution of proceeds -- annual report, MCA  |  |
| MTS_0500-0040-0080-0010 | 200 | 9839 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0080/section_0010/0500-0040-0080-0010.html |    50-4-801. Short title, MCA  |  |
| MTS_0500-0040-0080-0020 | 200 | 10447 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0080/section_0020/0500-0040-0080-0020.html |    50-4-802. Legislative intent and purpose, MCA  |  |
| MTS_0500-0040-0080-0030 | 200 | 12004 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0080/section_0030/0500-0040-0080-0030.html |    50-4-803. Definitions, MCA  |  |
| MTS_0500-0040-0080-0040 | 200 | 10869 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0080/section_0040/0500-0040-0080-0040.html |    50-4-804. Rulemaking authority, MCA  |  |
| MTS_0500-0040-0080-0050 | 200 | 12682 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0080/section_0050/0500-0040-0080-0050.html |    50-4-805. Program expenditures, MCA  |  |
| MTS_0500-0040-0080-0060 | 200 | 11684 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0080/section_0060/0500-0040-0080-0060.html |    50-4-806. Grants -- application process -- obligation of communities, MCA  |  |
| MTS_0500-0040-0080-0070 | 200 | 9862 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0080/section_0070/0500-0040-0080-0070.html |    50-4-807. through 50-4-809 reserved, MCA  |  |
| MTS_0500-0040-0080-0100 | 200 | 10011 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0080/section_0100/0500-0040-0080-0100.html |    50-4-810. Repealed, MCA  |  |
| MTS_0500-0040-0080-0110 | 200 | 10011 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0080/section_0110/0500-0040-0080-0110.html |    50-4-811. Repealed, MCA  |  |
| MTS_0500-0040-0080-0120 | 200 | 9835 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0080/section_0120/0500-0040-0080-0120.html |    50-4-812. through 50-4-814 reserved, MCA  |  |
| MTS_0500-0040-0080-0150 | 200 | 10550 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0080/section_0150/0500-0040-0080-0150.html |    50-4-815. Community health center account, MCA  |  |
| MTS_0500-0040-0090-0010 | 200 | 9855 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0090/section_0010/0500-0040-0090-0010.html |    50-4-901. Short title, MCA  |  |
| MTS_0500-0040-0090-0020 | 200 | 11156 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0090/section_0020/0500-0040-0090-0020.html |    50-4-902. Health insurance purchase mandate prohibited -- exceptions, MCA  |  |
| MTS_0500-0040-0100-0010 | 200 | 9760 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0100/section_0010/0500-0040-0100-0010.html |    50-4-1001. Short title, MCA  |  |
| MTS_0500-0040-0100-0020 | 200 | 10241 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0100/section_0020/0500-0040-0100-0020.html |    50-4-1002. Purpose, MCA  |  |
| MTS_0500-0040-0100-0030 | 200 | 13347 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0100/section_0030/0500-0040-0100-0030.html |    50-4-1003. Definitions, MCA  |  |
| MTS_0500-0040-0100-0040 | 200 | 16822 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0100/section_0040/0500-0040-0100-0040.html |    50-4-1004. Prohibitions, MCA  |  |
| MTS_0500-0040-0100-0050 | 200 | 9981 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0100/section_0050/0500-0040-0100-0050.html |    50-4-1005. Repealed, MCA  |  |
| MTS_0500-0040-0100-0060 | 200 | 10142 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0100/section_0060/0500-0040-0100-0060.html |    50-4-1006. Prohibited insurance coverage, MCA  |  |
| MTS_0500-0040-0110-0010 | 200 | 15041 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0110/section_0010/0500-0040-0110-0010.html |    50-4-1101. Definitions, MCA  |  |
| MTS_0500-0040-0110-0020 | 200 | 12289 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0110/section_0020/0500-0040-0110-0020.html |    50-4-1102. Right of conscience for health care institutions and health care p |  |
| MTS_0500-0040-0110-0030 | 200 | 12831 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0110/section_0030/0500-0040-0110-0030.html |    50-4-1103. Right of conscience for medical practitioners -- affirmative conse |  |
| MTS_0500-0040-0110-0040 | 200 | 10960 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0110/section_0040/0500-0040-0110-0040.html |    50-4-1104. Exercise of conscience not grounds for loss of privileges, immunit |  |
| MTS_0500-0040-0110-0050 | 200 | 12365 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0110/section_0050/0500-0040-0110-0050.html |    50-4-1105. Whistleblower protections, MCA  |  |
| MTS_0500-0040-0110-0060 | 200 | 11650 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0110/section_0060/0500-0040-0110-0060.html |    50-4-1106. Free speech protections -- notification of complaints -- penalty,  |  |
| MTS_0500-0040-0110-0070 | 200 | 11179 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0110/section_0070/0500-0040-0110-0070.html |    50-4-1107. Unlawful interference, MCA  |  |
| MTS_0500-0040-0120-0010 | 200 | 10216 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0120/section_0010/0500-0040-0120-0010.html |    50-4-1201. Purpose, MCA  |  |
| MTS_0500-0040-0120-0020 | 200 | 14524 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0120/section_0020/0500-0040-0120-0020.html |    50-4-1202. Definitions, MCA  |  |
| MTS_0500-0040-0120-0030 | 200 | 13367 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0120/section_0030/0500-0040-0120-0030.html |    50-4-1203. Safety and privacy in covered entities, MCA  |  |
| MTS_0500-0040-0120-0040 | 200 | 11240 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0120/section_0040/0500-0040-0120-0040.html |    50-4-1204. Remedies, MCA  |  |
| MTS_0500-0040-0130-0010 | 200 | 9494 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0130/section_0010/0500-0040-0130-0010.html |    50-4-1301. reserved, MCA  |  |
| MTS_0500-0040-0130-0020 | 200 | 13579 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0130/section_0020/0500-0040-0130-0020.html |    50-4-1302. Definitions, MCA  |  |
| MTS_0500-0040-0130-0030 | 200 | 12773 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0130/section_0030/0500-0040-0130-0030.html |    50-4-1303. Prohibition on interference with work of pregnancy center, MCA  |  |
| MTS_0500-0040-0130-0040 | 200 | 9881 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0130/section_0040/0500-0040-0130-0040.html |    50-4-1304. through 50-4-1308 reserved, MCA  |  |
| MTS_0500-0040-0130-0090 | 200 | 10962 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0130/section_0090/0500-0040-0130-0090.html |    50-4-1309. Legal remedies -- damages, MCA  |  |
| MTS_0500-0040-0130-0100 | 200 | 9845 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0130/section_0100/0500-0040-0130-0100.html |    50-4-1310. through 50-4-1314 reserved, MCA  |  |
| MTS_0500-0040-0130-0150 | 200 | 10024 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0130/section_0150/0500-0040-0130-0150.html |    50-4-1315. Right of intervention, MCA  |  |
| MTS_0500-0040-0140-0010 | 200 | 9756 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0140/section_0010/0500-0040-0140-0010.html |    50-4-1401. through 50-4-1404 reserved, MCA  |  |
| MTS_0500-0040-0140-0050 | 200 | 19396 | https://leg.mt.gov/bills/mca/title_0500/chapter_0040/part_0140/section_0050/0500-0040-0140-0050.html |    50-4-1405. Private cause of action for injuries caused by treatment of gender |  |
| MTS_0500-0050-0010-0010 | 200 | 64122 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0010/0500-0050-0010-0010.html |    50-5-101. Definitions, MCA  |  |
| MTS_0500-0050-0010-0020 | 200 | 10040 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0020/0500-0050-0010-0020.html |    50-5-102. Repealed, MCA  |  |
| MTS_0500-0050-0010-0030 | 200 | 12169 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0030/0500-0050-0010-0030.html |    50-5-103. Rules and standards -- accreditation, MCA  |  |
| MTS_0500-0050-0010-0040 | 200 | 10803 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0040/0500-0050-0010-0040.html |    50-5-104. Certain exemptions for spiritual healing institution, MCA  |  |
| MTS_0500-0050-0010-0050 | 200 | 12393 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0050/0500-0050-0010-0050.html |    50-5-105. Discrimination prohibited, MCA  |  |
| MTS_0500-0050-0010-0060 | 200 | 12839 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0060/0500-0050-0010-0060.html |    50-5-106. Records and reports required of health care facilities -- confident |  |
| MTS_0500-0050-0010-0070 | 200 | 10325 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0070/0500-0050-0010-0070.html |    50-5-107. Unlawful use of word nursing, MCA  |  |
| MTS_0500-0050-0010-0080 | 200 | 10836 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0080/0500-0050-0010-0080.html |    50-5-108. Injunction, MCA  |  |
| MTS_0500-0050-0010-0090 | 200 | 10056 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0090/0500-0050-0010-0090.html |    50-5-109. Repealed, MCA  |  |
| MTS_0500-0050-0010-0100 | 200 | 17160 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0100/0500-0050-0010-0100.html |    50-5-110. Patient bill of rights, MCA  |  |
| MTS_0500-0050-0010-0110 | 200 | 10637 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0110/0500-0050-0010-0110.html |    50-5-111. Prohibited activities, MCA  |  |
| MTS_0500-0050-0010-0120 | 200 | 12274 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0120/0500-0050-0010-0120.html |    50-5-112. Civil penalties, MCA  |  |
| MTS_0500-0050-0010-0130 | 200 | 13194 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0130/0500-0050-0010-0130.html |    50-5-113. Criminal penalties, MCA  |  |
| MTS_0500-0050-0010-0140 | 200 | 13539 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0140/0500-0050-0010-0140.html |    50-5-114. Administrative enforcement -- notice -- order for corrective action |  |
| MTS_0500-0050-0010-0150 | 200 | 14015 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0150/0500-0050-0010-0150.html |    50-5-115. Receiverships, MCA  |  |
| MTS_0500-0050-0010-0160 | 200 | 10782 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0160/0500-0050-0010-0160.html |    50-5-116. Facility inspections, MCA  |  |
| MTS_0500-0050-0010-0170 | 200 | 16588 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0170/0500-0050-0010-0170.html |    50-5-117. Economic credentialing of physicians prohibited -- definitions, MCA |  |
| MTS_0500-0050-0010-0180 | 200 | 12164 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0180/0500-0050-0010-0180.html |    50-5-118. Nonprofit hospital reporting requirements -- rulemaking authority,  |  |
| MTS_0500-0050-0010-0190 | 200 | 12443 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0190/0500-0050-0010-0190.html |    50-5-119. Community benefit to equal potential property tax liability -- fee, |  |
| MTS_0500-0050-0010-0200 | 200 | 11280 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0200/0500-0050-0010-0200.html |    50-5-120. Critical access health care special revenue account -- rulemaking a |  |
| MTS_0500-0050-0010-0210 | 200 | 15185 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0210/0500-0050-0010-0210.html |    50-5-121. Hospital discrimination based on ability to pay prohibited -- commu |  |
| MTS_0500-0050-0010-0220 | 200 | 10529 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0010/section_0220/0500-0050-0010-0220.html |    50-5-122. Transfer of hospital patients, MCA  |  |
| MTS_0500-0050-0020-0010 | 200 | 10926 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0010/0500-0050-0020-0010.html |    50-5-201. License requirements, MCA  |  |
| MTS_0500-0050-0020-0020 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0020/0500-0050-0020-0020.html |    50-5-202. License fees, MCA  |  |
| MTS_0500-0050-0020-0030 | 200 | 11893 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0030/0500-0050-0020-0030.html |    50-5-203. Application for license, MCA  |  |
| MTS_0500-0050-0020-0040 | 200 | 11719 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0040/0500-0050-0020-0040.html |    50-5-204. Issuance and renewal of licenses -- inspections, MCA  |  |
| MTS_0500-0050-0020-0050 | 200 | 10086 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0050/0500-0050-0020-0050.html |    50-5-205. Repealed, MCA  |  |
| MTS_0500-0050-0020-0060 | 200 | 10095 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0060/0500-0050-0020-0060.html |    50-5-206. Repealed, MCA  |  |
| MTS_0500-0050-0020-0070 | 200 | 13879 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0070/0500-0050-0020-0070.html |    50-5-207. Denial, suspension, or revocation of health care facility license - |  |
| MTS_0500-0050-0020-0080 | 200 | 10780 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0080/0500-0050-0020-0080.html |    50-5-208. Hearing required, MCA  |  |
| MTS_0500-0050-0020-0090 | 200 | 10065 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0090/0500-0050-0020-0090.html |    50-5-209. Repealed, MCA  |  |
| MTS_0500-0050-0020-0100 | 200 | 11412 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0100/0500-0050-0020-0100.html |    50-5-210. Department to make rules -- standards for hospices, MCA  |  |
| MTS_0500-0050-0020-0110 | 200 | 10466 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0110/0500-0050-0020-0110.html |    50-5-211. Hospital hospice programs -- exemptions from separate licensure, MC |  |
| MTS_0500-0050-0020-0120 | 200 | 11637 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0120/0500-0050-0020-0120.html |    50-5-212. Organ procurement program required, MCA  |  |
| MTS_0500-0050-0020-0130 | 200 | 10369 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0130/0500-0050-0020-0130.html |    50-5-213. Requirements for home infusion therapy services, MCA  |  |
| MTS_0500-0050-0020-0140 | 200 | 10255 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0140/0500-0050-0020-0140.html |    50-5-214. Requirements for retirement homes, MCA  |  |
| MTS_0500-0050-0020-0150 | 200 | 10555 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0150/0500-0050-0020-0150.html |    50-5-215. Standards for adult foster care homes, MCA  |  |
| MTS_0500-0050-0020-0160 | 200 | 12826 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0160/0500-0050-0020-0160.html |    50-5-216. Limitation on care provided in adult foster care home, MCA  |  |
| MTS_0500-0050-0020-0170 | 200 | 9864 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0170/0500-0050-0020-0170.html |    50-5-217. through 50-5-219 reserved, MCA  |  |
| MTS_0500-0050-0020-0200 | 200 | 10941 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0200/0500-0050-0020-0200.html |    50-5-220. Licensure of outdoor behavioral programs -- exemption, MCA  |  |
| MTS_0500-0050-0020-0210 | 200 | 10017 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0210/0500-0050-0020-0210.html |    50-5-221. Repealed, MCA  |  |
| MTS_0500-0050-0020-0220 | 200 | 9766 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0220/0500-0050-0020-0220.html |    50-5-222. and 50-5-223 reserved, MCA  |  |
| MTS_0500-0050-0020-0240 | 200 | 9867 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0240/0500-0050-0020-0240.html |    50-5-224. Renumbered 53-21-199, MCA  |  |
| MTS_0500-0050-0020-0250 | 200 | 13335 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0250/0500-0050-0020-0250.html |    50-5-225. Assisted living facilities -- services to residents -- employee bac |  |
| MTS_0500-0050-0020-0260 | 200 | 24476 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0260/0500-0050-0020-0260.html |    50-5-226. Placement in assisted living facilities, MCA  |  |
| MTS_0500-0050-0020-0270 | 200 | 13143 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0270/0500-0050-0020-0270.html |    50-5-227. Licensing assisted living facilities, MCA  |  |
| MTS_0500-0050-0020-0280 | 200 | 10686 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0280/0500-0050-0020-0280.html |    50-5-228. Limited licensing, MCA  |  |
| MTS_0500-0050-0020-0290 | 200 | 9967 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0290/0500-0050-0020-0290.html |    50-5-229. Repealed, MCA  |  |
| MTS_0500-0050-0020-0300 | 200 | 9958 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0300/0500-0050-0020-0300.html |    50-5-230. Repealed, MCA  |  |
| MTS_0500-0050-0020-0310 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0310/0500-0050-0020-0310.html |    50-5-231. Repealed, MCA  |  |
| MTS_0500-0050-0020-0320 | 200 | 11125 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0320/0500-0050-0020-0320.html |    50-5-232. Patient protection account -- deposit of funds, MCA  |  |
| MTS_0500-0050-0020-0330 | 200 | 12867 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0330/0500-0050-0020-0330.html |    50-5-233. Designation of critical access hospitals -- adoption of rules, MCA  |  |
| MTS_0500-0050-0020-0340 | 200 | 15316 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0340/0500-0050-0020-0340.html |    50-5-234. Designation as rural emergency hospital -- requirements -- rulemaki |  |
| MTS_0500-0050-0020-0350 | 200 | 10739 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0350/0500-0050-0020-0350.html |    50-5-235. Hourly limitation waivable by department or department's designee,  |  |
| MTS_0500-0050-0020-0360 | 200 | 9885 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0360/0500-0050-0020-0360.html |    50-5-236. and 50-5-237 reserved, MCA  |  |
| MTS_0500-0050-0020-0380 | 200 | 11870 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0380/0500-0050-0020-0380.html |    50-5-238. Licensure of intermediate care facility for developmentally disable |  |
| MTS_0500-0050-0020-0390 | 200 | 9922 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0390/0500-0050-0020-0390.html |    50-5-239. through 50-5-244 reserved, MCA  |  |
| MTS_0500-0050-0020-0450 | 200 | 14013 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0450/0500-0050-0020-0450.html |    50-5-245. Department to license specialty hospitals -- standards -- rulemakin |  |
| MTS_0500-0050-0020-0460 | 200 | 13215 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0460/0500-0050-0020-0460.html |    50-5-246. Specialty hospital application process -- impact study, MCA  |  |
| MTS_0500-0050-0020-0470 | 200 | 12063 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0470/0500-0050-0020-0470.html |    50-5-247. Licensure of eating disorder centers -- rulemaking -- definition, M |  |
| MTS_0500-0050-0020-0480 | 200 | 13350 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0480/0500-0050-0020-0480.html |    50-5-248. Licensing of residential treatment centers -- rulemaking, MCA  |  |
| MTS_0500-0050-0020-0490 | 200 | 9764 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0490/0500-0050-0020-0490.html |    50-5-249. reserved, MCA  |  |
| MTS_0500-0050-0020-0500 | 200 | 12582 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0500/0500-0050-0020-0500.html |    50-5-250. Licensure of experimental treatment centers -- fees -- rulemaking,  |  |
| MTS_0500-0050-0020-0510 | 200 | 11818 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0510/0500-0050-0020-0510.html |    50-5-251. Health freedom and access requirement, MCA  |  |
| MTS_0500-0050-0020-0520 | 200 | 11749 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0020/section_0520/0500-0050-0020-0520.html |    50-5-252. Insurance premium support account -- contributions -- nonsupplantat |  |
| MTS_0500-0050-0030-0010 | 200 | 16786 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0010/0500-0050-0030-0010.html |    50-5-301. When certificate of need is required -- definitions -- report on ca |  |
| MTS_0500-0050-0030-0020 | 200 | 16244 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0020/0500-0050-0030-0020.html |    50-5-302. Letter of intent -- application and review process -- rulemaking, M |  |
| MTS_0500-0050-0030-0030 | 200 | 10178 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0030/0500-0050-0030-0030.html |    50-5-303. Repealed, MCA  |  |
| MTS_0500-0050-0030-0040 | 200 | 14274 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0040/0500-0050-0030-0040.html |    50-5-304. Review criteria, required findings, and standards, MCA  |  |
| MTS_0500-0050-0030-0050 | 200 | 12043 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0050/0500-0050-0030-0050.html |    50-5-305. Period of validity of approved application, MCA  |  |
| MTS_0500-0050-0030-0060 | 200 | 12890 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0060/0500-0050-0030-0060.html |    50-5-306. Right to hearing and appeal, MCA  |  |
| MTS_0500-0050-0030-0070 | 200 | 11147 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0070/0500-0050-0030-0070.html |    50-5-307. Civil penalty -- injunction, MCA  |  |
| MTS_0500-0050-0030-0080 | 200 | 10827 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0080/0500-0050-0030-0080.html |    50-5-308. Special circumstances, MCA  |  |
| MTS_0500-0050-0030-0090 | 200 | 10714 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0090/0500-0050-0030-0090.html |    50-5-309. Exemptions from certificate of need review, MCA  |  |
| MTS_0500-0050-0030-0100 | 200 | 10526 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0100/0500-0050-0030-0100.html |    50-5-310. Fees, MCA  |  |
| MTS_0500-0050-0030-0110 | 200 | 9800 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0110/0500-0050-0030-0110.html |    50-5-311. through 50-5-315 reserved, MCA  |  |
| MTS_0500-0050-0030-0160 | 200 | 10004 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0160/0500-0050-0030-0160.html |    50-5-316. Repealed, MCA  |  |
| MTS_0500-0050-0030-0170 | 200 | 9787 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0030/section_0170/0500-0050-0030-0170.html |    50-5-317. Repealed, MCA  |  |
| MTS_0500-0050-0040-0010 | 200 | 10077 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0010/0500-0050-0040-0010.html |    50-5-401. Repealed, MCA  |  |
| MTS_0500-0050-0040-0020 | 200 | 10172 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0020/0500-0050-0040-0020.html |    50-5-402. Repealed, MCA  |  |
| MTS_0500-0050-0040-0030 | 200 | 10135 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0030/0500-0050-0040-0030.html |    50-5-403. Repealed, MCA  |  |
| MTS_0500-0050-0040-0040 | 200 | 10229 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0040/0500-0050-0040-0040.html |    50-5-404. Repealed, MCA  |  |
| MTS_0500-0050-0040-0050 | 200 | 10172 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0050/0500-0050-0040-0050.html |    50-5-405. Repealed, MCA  |  |
| MTS_0500-0050-0040-0060 | 200 | 10166 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0060/0500-0050-0040-0060.html |    50-5-406. Repealed, MCA  |  |
| MTS_0500-0050-0040-0070 | 200 | 10135 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0070/0500-0050-0040-0070.html |    50-5-407. Repealed, MCA  |  |
| MTS_0500-0050-0040-0080 | 200 | 10134 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0080/0500-0050-0040-0080.html |    50-5-408. Repealed, MCA  |  |
| MTS_0500-0050-0040-0090 | 200 | 10150 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0090/0500-0050-0040-0090.html |    50-5-409. Repealed, MCA  |  |
| MTS_0500-0050-0040-0100 | 200 | 10150 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0100/0500-0050-0040-0100.html |    50-5-410. Repealed, MCA  |  |
| MTS_0500-0050-0040-0110 | 200 | 10134 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0110/0500-0050-0040-0110.html |    50-5-411. Repealed, MCA  |  |
| MTS_0500-0050-0040-0120 | 200 | 10122 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0120/0500-0050-0040-0120.html |    50-5-412. Repealed, MCA  |  |
| MTS_0500-0050-0040-0130 | 200 | 9897 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0130/0500-0050-0040-0130.html |    50-5-413. through 50-5-420 reserved, MCA  |  |
| MTS_0500-0050-0040-0210 | 200 | 10099 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0210/0500-0050-0040-0210.html |    50-5-421. Repealed, MCA  |  |
| MTS_0500-0050-0040-0220 | 200 | 10082 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0220/0500-0050-0040-0220.html |    50-5-422. Repealed, MCA  |  |
| MTS_0500-0050-0040-0230 | 200 | 10082 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0230/0500-0050-0040-0230.html |    50-5-423. Repealed, MCA  |  |
| MTS_0500-0050-0040-0240 | 200 | 9882 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0040/section_0240/0500-0050-0040-0240.html |    50-5-424. Repealed, MCA  |  |
| MTS_0500-0050-0050-0010 | 200 | 10361 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0050/section_0010/0500-0050-0050-0010.html |    50-5-501. Definitions, MCA  |  |
| MTS_0500-0050-0050-0020 | 200 | 11221 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0050/section_0020/0500-0050-0050-0020.html |    50-5-502. Refusal by hospital or health care facility to participate in steri |  |
| MTS_0500-0050-0050-0030 | 200 | 11301 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0050/section_0030/0500-0050-0050-0030.html |    50-5-503. Refusal by individual to participate in sterilization, MCA  |  |
| MTS_0500-0050-0050-0040 | 200 | 10716 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0050/section_0040/0500-0050-0050-0040.html |    50-5-504. Unlawful to interfere with right of refusal, MCA  |  |
| MTS_0500-0050-0050-0050 | 200 | 10439 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0050/section_0050/0500-0050-0050-0050.html |    50-5-505. Refusal not grounds for loss of privileges, immunities, or public b |  |
| MTS_0500-0050-0060-0010 | 200 | 9850 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0060/section_0010/0500-0050-0060-0010.html |    50-5-601. Short title, MCA  |  |
| MTS_0500-0050-0060-0020 | 200 | 11395 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0060/section_0020/0500-0050-0060-0020.html |    50-5-602. Definitions, MCA  |  |
| MTS_0500-0050-0060-0030 | 200 | 10797 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0060/section_0030/0500-0050-0060-0030.html |    50-5-603. Montana family practice training program, MCA  |  |
| MTS_0500-0050-0060-0040 | 200 | 9892 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0060/section_0040/0500-0050-0060-0040.html |    50-5-604. through 50-5-610 reserved, MCA  |  |
| MTS_0500-0050-0060-0110 | 200 | 10219 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0060/section_0110/0500-0050-0060-0110.html |    50-5-611. Funding limitations, MCA  |  |
| MTS_0500-0050-0070-0010 | 200 | 12732 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0070/section_0010/0500-0050-0070-0010.html |    50-5-701. Definitions, MCA  |  |
| MTS_0500-0050-0070-0020 | 200 | 12859 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0070/section_0020/0500-0050-0070-0020.html |    50-5-702. Lay caregiver -- designation, MCA  |  |
| MTS_0500-0050-0070-0030 | 200 | 10789 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0070/section_0030/0500-0050-0070-0030.html |    50-5-703. Notice to designated lay caregiver, MCA  |  |
| MTS_0500-0050-0070-0040 | 200 | 12581 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0070/section_0040/0500-0050-0070-0040.html |    50-5-704. Instruction to designated lay caregiver, MCA  |  |
| MTS_0500-0050-0070-0050 | 200 | 10773 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0070/section_0050/0500-0050-0070-0050.html |    50-5-705. Noninterference with powers of existing health care directives, MCA |  |
| MTS_0500-0050-0070-0060 | 200 | 10407 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0070/section_0060/0500-0050-0070-0060.html |    50-5-706. Noninterference with care or discharge, MCA  |  |
| MTS_0500-0050-0070-0070 | 200 | 10434 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0070/section_0070/0500-0050-0070-0070.html |    50-5-707. Immunity, MCA  |  |
| MTS_0500-0050-0110-0010 | 200 | 9874 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0110/section_0010/0500-0050-0110-0010.html |    50-5-1101. Short title, MCA  |  |
| MTS_0500-0050-0110-0020 | 200 | 10651 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0110/section_0020/0500-0050-0110-0020.html |    50-5-1102. Findings and purpose, MCA  |  |
| MTS_0500-0050-0110-0030 | 200 | 12063 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0110/section_0030/0500-0050-0110-0030.html |    50-5-1103. Definitions, MCA  |  |
| MTS_0500-0050-0110-0040 | 200 | 15258 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0110/section_0040/0500-0050-0110-0040.html |    50-5-1104. Rights of long-term care facility residents, MCA  |  |
| MTS_0500-0050-0110-0050 | 200 | 12002 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0110/section_0050/0500-0050-0110-0050.html |    50-5-1105. Long-term care facility to adopt and post residents' rights, MCA  |  |
| MTS_0500-0050-0110-0060 | 200 | 11024 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0110/section_0060/0500-0050-0110-0060.html |    50-5-1106. Resident's rights devolve to authorized representative, MCA  |  |
| MTS_0500-0050-0110-0070 | 200 | 10381 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0110/section_0070/0500-0050-0110-0070.html |    50-5-1107. Enforcement of residents' rights, MCA  |  |
| MTS_0500-0050-0120-0010 | 200 | 12119 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0120/section_0010/0500-0050-0120-0010.html |    50-5-1201. Use of safety devices -- request and consent -- allowed individual |  |
| MTS_0500-0050-0120-0020 | 200 | 11710 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0120/section_0020/0500-0050-0120-0020.html |    50-5-1202. Definitions, MCA  |  |
| MTS_0500-0050-0120-0030 | 200 | 11303 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0120/section_0030/0500-0050-0120-0030.html |    50-5-1203. Procedures -- informed consent -- physician involvement, MCA  |  |
| MTS_0500-0050-0120-0040 | 200 | 11031 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0120/section_0040/0500-0050-0120-0040.html |    50-5-1204. Long-term care facility procedures, MCA  |  |
| MTS_0500-0050-0120-0050 | 200 | 11581 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0120/section_0050/0500-0050-0120-0050.html |    50-5-1205. Survey compliance and department enforcement -- rulemaking authori |  |
| MTS_0500-0050-0130-0010 | 200 | 13465 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0130/section_0010/0500-0050-0130-0010.html |    50-5-1301. Definitions, MCA  |  |
| MTS_0500-0050-0130-0020 | 200 | 13056 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0130/section_0020/0500-0050-0130-0020.html |    50-5-1302. Determination of decisional capacity -- use of proxy decisionmaker |  |
| MTS_0500-0050-0130-0030 | 200 | 12690 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0130/section_0030/0500-0050-0130-0030.html |    50-5-1303. Notification to interested persons -- selection of proxy decisionm |  |
| MTS_0500-0050-0130-0040 | 200 | 13877 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0130/section_0040/0500-0050-0130-0040.html |    50-5-1304. Appointment of certain health care providers as medical proxy deci |  |
| MTS_0500-0050-0130-0050 | 200 | 13992 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0130/section_0050/0500-0050-0130-0050.html |    50-5-1305. Treatment guidelines when health care providers serve as proxy dec |  |
| MTS_0500-0050-0130-0060 | 200 | 10869 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0130/section_0060/0500-0050-0130-0060.html |    50-5-1306. Medical ethics committee assistance in decisions on withholding or |  |
| MTS_0500-0050-0130-0070 | 200 | 11046 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0130/section_0070/0500-0050-0130-0070.html |    50-5-1307. Redetermination of authority of lay or medical proxy decisionmaker |  |
| MTS_0500-0050-0130-0080 | 200 | 11952 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0130/section_0080/0500-0050-0130-0080.html |    50-5-1308. Immunity, MCA  |  |
| MTS_0500-0050-0130-0090 | 200 | 9830 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0130/section_0090/0500-0050-0130-0090.html |    50-5-1309. reserved, MCA  |  |
| MTS_0500-0050-0130-0100 | 200 | 13295 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0130/section_0100/0500-0050-0130-0100.html |    50-5-1310. Patient designation of trusted decisionmaker as proxy -- documenta |  |
| MTS_0500-0050-0130-0110 | 200 | 11672 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0130/section_0110/0500-0050-0130-0110.html |    50-5-1311. Hierarchy of decisionmaker selection, MCA  |  |
| MTS_0500-0050-0140-0010 | 200 | 9795 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0140/section_0010/0500-0050-0140-0010.html |    50-5-1401. Short title, MCA  |  |
| MTS_0500-0050-0140-0020 | 200 | 10533 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0140/section_0020/0500-0050-0140-0020.html |    50-5-1402. Legislative intent, MCA  |  |
| MTS_0500-0050-0140-0030 | 200 | 11017 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0140/section_0030/0500-0050-0140-0030.html |    50-5-1403. Definitions, MCA  |  |
| MTS_0500-0050-0140-0040 | 200 | 12048 | https://leg.mt.gov/bills/mca/title_0500/chapter_0050/part_0140/section_0040/0500-0050-0140-0040.html |    50-5-1404. Patient visitation rights, MCA  |  |
| MTS_0500-0060-0010-0010 | 200 | 11122 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0010/section_0010/0500-0060-0010-0010.html |    50-6-101. Legislative purpose, MCA  |  |
| MTS_0500-0060-0010-0020 | 200 | 10387 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0010/section_0020/0500-0060-0010-0020.html |    50-6-102. Department to establish and administer program, MCA  |  |
| MTS_0500-0060-0010-0030 | 200 | 12104 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0010/section_0030/0500-0060-0010-0030.html |    50-6-103. Powers of department, MCA  |  |
| MTS_0500-0060-0010-0040 | 200 | 10624 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0010/section_0040/0500-0060-0010-0040.html |    50-6-104. Interdepartmental cooperation required, MCA  |  |
| MTS_0500-0060-0010-0050 | 200 | 14011 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0010/section_0050/0500-0060-0010-0050.html |    50-6-105. Medical care standards -- review process, MCA  |  |
| MTS_0500-0060-0020-0010 | 200 | 11590 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0020/section_0010/0500-0060-0020-0010.html |    50-6-201. Legislative findings -- duty of department of labor and industry, M |  |
| MTS_0500-0060-0020-0020 | 200 | 12442 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0020/section_0020/0500-0060-0020-0020.html |    50-6-202. Definitions, MCA  |  |
| MTS_0500-0060-0020-0030 | 200 | 11437 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0020/section_0030/0500-0060-0020-0030.html |    50-6-203. Rules, MCA  |  |
| MTS_0500-0060-0020-0040 | 200 | 10019 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0020/section_0040/0500-0060-0020-0040.html |    50-6-204. Repealed, MCA  |  |
| MTS_0500-0060-0020-0050 | 200 | 10043 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0020/section_0050/0500-0060-0020-0050.html |    50-6-205. Repealed, MCA  |  |
| MTS_0500-0060-0020-0060 | 200 | 10364 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0020/section_0060/0500-0060-0020-0060.html |    50-6-206. Consent, MCA  |  |
| MTS_0500-0060-0020-0070 | 200 | 10282 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0020/section_0070/0500-0060-0020-0070.html |    50-6-207. Construction, MCA  |  |
| MTS_0500-0060-0020-0080 | 200 | 9832 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0020/section_0080/0500-0060-0020-0080.html |    50-6-208. and 50-6-209 reserved, MCA  |  |
| MTS_0500-0060-0020-0100 | 200 | 10270 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0020/section_0100/0500-0060-0020-0100.html |    50-6-210. Provision of patient care in health care facility, MCA  |  |
| MTS_0500-0060-0030-0010 | 200 | 10572 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0010/0500-0060-0030-0010.html |    50-6-301. Findings, MCA  |  |
| MTS_0500-0060-0030-0020 | 200 | 17076 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0020/0500-0060-0030-0020.html |    50-6-302. Definitions, MCA  |  |
| MTS_0500-0060-0030-0030 | 200 | 10112 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0030/0500-0060-0030-0030.html |    50-6-303. Repealed, MCA  |  |
| MTS_0500-0060-0030-0040 | 200 | 10618 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0040/0500-0060-0030-0040.html |    50-6-304. Cooperative agreements -- gifts, grants, and donations, MCA  |  |
| MTS_0500-0060-0030-0050 | 200 | 10112 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0050/0500-0060-0030-0050.html |    50-6-305. Repealed, MCA  |  |
| MTS_0500-0060-0030-0060 | 200 | 11146 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0060/0500-0060-0030-0060.html |    50-6-306. License required, MCA  |  |
| MTS_0500-0060-0030-0070 | 200 | 10655 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0070/0500-0060-0030-0070.html |    50-6-307. License fee, MCA  |  |
| MTS_0500-0060-0030-0080 | 200 | 10503 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0080/0500-0060-0030-0080.html |    50-6-308. Cancellation of license, MCA  |  |
| MTS_0500-0060-0030-0090 | 200 | 10094 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0090/0500-0060-0030-0090.html |    50-6-309. Repealed, MCA  |  |
| MTS_0500-0060-0030-0100 | 200 | 10846 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0100/0500-0060-0030-0100.html |    50-6-310. Notice and hearing required, MCA  |  |
| MTS_0500-0060-0030-0110 | 200 | 10371 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0110/0500-0060-0030-0110.html |    50-6-311. Return of license for destruction or deletion, MCA  |  |
| MTS_0500-0060-0030-0120 | 200 | 10100 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0120/0500-0060-0030-0120.html |    50-6-312. Repealed, MCA  |  |
| MTS_0500-0060-0030-0130 | 200 | 11548 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0130/0500-0060-0030-0130.html |    50-6-313. Inspections, MCA  |  |
| MTS_0500-0060-0030-0140 | 200 | 10431 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0140/0500-0060-0030-0140.html |    50-6-314. Authority of department to compel and take testimony, MCA  |  |
| MTS_0500-0060-0030-0150 | 200 | 10494 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0150/0500-0060-0030-0150.html |    50-6-315. County attorney to prosecute violations, MCA  |  |
| MTS_0500-0060-0030-0160 | 200 | 12161 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0160/0500-0060-0030-0160.html |    50-6-316. Criminal and civil penalties, MCA  |  |
| MTS_0500-0060-0030-0170 | 200 | 11561 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0170/0500-0060-0030-0170.html |    50-6-317. Liability protection, MCA  |  |
| MTS_0500-0060-0030-0180 | 200 | 9875 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0180/0500-0060-0030-0180.html |    50-6-318. and 50-6-319 reserved, MCA  |  |
| MTS_0500-0060-0030-0200 | 200 | 12992 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0200/0500-0060-0030-0200.html |    50-6-320. Private air ambulance service -- findings -- exemptions from insura |  |
| MTS_0500-0060-0030-0210 | 200 | 9834 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0210/0500-0060-0030-0210.html |    50-6-321. reserved, MCA  |  |
| MTS_0500-0060-0030-0220 | 200 | 11366 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0220/0500-0060-0030-0220.html |    50-6-322. Staffing -- nonemergency ambulance transports -- transports in rura |  |
| MTS_0500-0060-0030-0230 | 200 | 13589 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0230/0500-0060-0030-0230.html |    50-6-323. Powers and duties of department, MCA  |  |
| MTS_0500-0060-0030-0240 | 200 | 10895 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0240/0500-0060-0030-0240.html |    50-6-324. Advisory committee, MCA  |  |
| MTS_0500-0060-0030-0250 | 200 | 11382 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0250/0500-0060-0030-0250.html |    50-6-325. Waiver of licensing requirements, MCA  |  |
| MTS_0500-0060-0030-0260 | 200 | 11031 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0260/0500-0060-0030-0260.html |    50-6-326. Injunction to require compliance, MCA  |  |
| MTS_0500-0060-0030-0270 | 200 | 11951 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0030/section_0270/0500-0060-0030-0270.html |    50-6-327. Administrative enforcement, MCA  |  |
| MTS_0500-0060-0040-0010 | 200 | 13601 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0040/section_0010/0500-0060-0040-0010.html |    50-6-401. Definitions, MCA  |  |
| MTS_0500-0060-0040-0020 | 200 | 14548 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0040/section_0020/0500-0060-0040-0020.html |    50-6-402. Department duties -- rules, MCA  |  |
| MTS_0500-0060-0040-0030 | 200 | 10032 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0040/section_0030/0500-0060-0040-0030.html |    50-6-403. Repealed, MCA  |  |
| MTS_0500-0060-0040-0040 | 200 | 11520 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0040/section_0040/0500-0060-0040-0040.html |    50-6-404. Duties of trauma care committee, MCA  |  |
| MTS_0500-0060-0040-0050 | 200 | 9902 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0040/section_0050/0500-0060-0040-0050.html |    50-6-405. through 50-6-409 reserved, MCA  |  |
| MTS_0500-0060-0040-0100 | 200 | 12715 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0040/section_0100/0500-0060-0040-0100.html |    50-6-410. Department designation of trauma facility -- revocation of designat |  |
| MTS_0500-0060-0040-0110 | 200 | 11580 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0040/section_0110/0500-0060-0040-0110.html |    50-6-411. Regional trauma care advisory committees, MCA  |  |
| MTS_0500-0060-0040-0120 | 200 | 11456 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0040/section_0120/0500-0060-0040-0120.html |    50-6-412. Duties of regional trauma care advisory committees, MCA  |  |
| MTS_0500-0060-0040-0130 | 200 | 9836 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0040/section_0130/0500-0060-0040-0130.html |    50-6-413. and 50-6-414 reserved, MCA  |  |
| MTS_0500-0060-0040-0150 | 200 | 12915 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0040/section_0150/0500-0060-0040-0150.html |    50-6-415. Confidentiality, MCA  |  |
| MTS_0500-0060-0050-0010 | 200 | 11728 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0050/section_0010/0500-0060-0050-0010.html |    50-6-501. Definitions, MCA  |  |
| MTS_0500-0060-0050-0020 | 200 | 10869 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0050/section_0020/0500-0060-0050-0020.html |    50-6-502. Requirements for AED use, MCA  |  |
| MTS_0500-0060-0050-0030 | 200 | 10134 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0050/section_0030/0500-0060-0050-0030.html |    50-6-503. Repealed, MCA  |  |
| MTS_0500-0060-0050-0040 | 200 | 10401 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0050/section_0040/0500-0060-0050-0040.html |    50-6-504. Enforcement -- injunction, MCA  |  |
| MTS_0500-0060-0050-0050 | 200 | 11535 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0050/section_0050/0500-0060-0050-0050.html |    50-6-505. Liability limitations, MCA  |  |
| MTS_0500-0060-0050-0060 | 200 | 10237 | https://leg.mt.gov/bills/mca/title_0500/chapter_0060/part_0050/section_0060/0500-0060-0050-0060.html |    50-6-506. Exemptions, MCA  |  |
| MTS_0500-0070-0010-0010 | 200 | 9846 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0010/section_0010/0500-0070-0010-0010.html |    50-7-101. Repealed, MCA  |  |
| MTS_0500-0070-0010-0020 | 200 | 10049 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0010/section_0020/0500-0070-0010-0020.html |    50-7-102. Repealed, MCA  |  |
| MTS_0500-0070-0010-0030 | 200 | 10053 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0010/section_0030/0500-0070-0010-0030.html |    50-7-103. Repealed, MCA  |  |
| MTS_0500-0070-0010-0040 | 200 | 9858 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0010/section_0040/0500-0070-0010-0040.html |    50-7-104. Repealed, MCA  |  |
| MTS_0500-0070-0020-0010 | 200 | 9860 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0020/section_0010/0500-0070-0020-0010.html |    50-7-201. Repealed, MCA  |  |
| MTS_0500-0070-0020-0020 | 200 | 10067 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0020/section_0020/0500-0070-0020-0020.html |    50-7-202. Repealed, MCA  |  |
| MTS_0500-0070-0020-0030 | 200 | 10058 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0020/section_0030/0500-0070-0020-0030.html |    50-7-203. Repealed, MCA  |  |
| MTS_0500-0070-0020-0040 | 200 | 10058 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0020/section_0040/0500-0070-0020-0040.html |    50-7-204. Repealed, MCA  |  |
| MTS_0500-0070-0020-0050 | 200 | 10058 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0020/section_0050/0500-0070-0020-0050.html |    50-7-205. Repealed, MCA  |  |
| MTS_0500-0070-0020-0060 | 200 | 9858 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0020/section_0060/0500-0070-0020-0060.html |    50-7-206. Repealed, MCA  |  |
| MTS_0500-0070-0030-0010 | 200 | 9819 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0030/section_0010/0500-0070-0030-0010.html |    50-7-301. Repealed, MCA  |  |
| MTS_0500-0070-0030-0020 | 200 | 10022 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0030/section_0020/0500-0070-0030-0020.html |    50-7-302. Repealed, MCA  |  |
| MTS_0500-0070-0030-0030 | 200 | 10027 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0030/section_0030/0500-0070-0030-0030.html |    50-7-303. Repealed, MCA  |  |
| MTS_0500-0070-0030-0040 | 200 | 10019 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0030/section_0040/0500-0070-0030-0040.html |    50-7-304. Repealed, MCA  |  |
| MTS_0500-0070-0030-0050 | 200 | 10019 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0030/section_0050/0500-0070-0030-0050.html |    50-7-305. Repealed, MCA  |  |
| MTS_0500-0070-0030-0060 | 200 | 10019 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0030/section_0060/0500-0070-0030-0060.html |    50-7-306. Repealed, MCA  |  |
| MTS_0500-0070-0030-0070 | 200 | 10019 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0030/section_0070/0500-0070-0030-0070.html |    50-7-307. Repealed, MCA  |  |
| MTS_0500-0070-0030-0080 | 200 | 10022 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0030/section_0080/0500-0070-0030-0080.html |    50-7-308. Repealed, MCA  |  |
| MTS_0500-0070-0030-0090 | 200 | 9819 | https://leg.mt.gov/bills/mca/title_0500/chapter_0070/part_0030/section_0090/0500-0070-0030-0090.html |    50-7-309. Repealed, MCA  |  |
| MTS_0500-0080-0010-0010 | 200 | 12208 | https://leg.mt.gov/bills/mca/title_0500/chapter_0080/part_0010/section_0010/0500-0080-0010-0010.html |    50-8-101. Definitions, MCA  |  |
| MTS_0500-0080-0010-0020 | 200 | 11396 | https://leg.mt.gov/bills/mca/title_0500/chapter_0080/part_0010/section_0020/0500-0080-0010-0020.html |    50-8-102. One-step licensing required, MCA  |  |
| MTS_0500-0080-0010-0030 | 200 | 9793 | https://leg.mt.gov/bills/mca/title_0500/chapter_0080/part_0010/section_0030/0500-0080-0010-0030.html |    50-8-103. and 50-8-104 reserved, MCA  |  |
| MTS_0500-0080-0010-0050 | 200 | 11386 | https://leg.mt.gov/bills/mca/title_0500/chapter_0080/part_0010/section_0050/0500-0080-0010-0050.html |    50-8-105. Inspections by employees of other department, MCA  |  |
| MTS_0500-0090-0010-0010 | 200 | 9807 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0010/section_0010/0500-0090-0010-0010.html |    50-9-101. Short title, MCA  |  |
| MTS_0500-0090-0010-0020 | 200 | 15175 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0010/section_0020/0500-0090-0010-0020.html |    50-9-102. Definitions, MCA  |  |
| MTS_0500-0090-0010-0030 | 200 | 16588 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0010/section_0030/0500-0090-0010-0030.html |    50-9-103. Declaration relating to use of life-sustaining treatment -- designe |  |
| MTS_0500-0090-0010-0040 | 200 | 11328 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0010/section_0040/0500-0090-0010-0040.html |    50-9-104. Revocation of declaration, MCA  |  |
| MTS_0500-0090-0010-0050 | 200 | 11334 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0010/section_0050/0500-0090-0010-0050.html |    50-9-105. When declaration operative, MCA  |  |
| MTS_0500-0090-0010-0060 | 200 | 13587 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0010/section_0060/0500-0090-0010-0060.html |    50-9-106. Consent by others to withholding or withdrawal of treatment, MCA  |  |
| MTS_0500-0090-0010-0070 | 200 | 10393 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0010/section_0070/0500-0090-0010-0070.html |    50-9-107. When health care provider may presume validity of declaration, MCA  |  |
| MTS_0500-0090-0010-0080 | 200 | 10258 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0010/section_0080/0500-0090-0010-0080.html |    50-9-108. Effect of previous declaration, MCA  |  |
| MTS_0500-0090-0010-0090 | 200 | 9691 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0010/section_0090/0500-0090-0010-0090.html |    50-9-109. reserved, MCA  |  |
| MTS_0500-0090-0010-0100 | 200 | 10066 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0010/section_0100/0500-0090-0010-0100.html |    50-9-110. Authority to adopt rules, MCA  |  |
| MTS_0500-0090-0010-0110 | 200 | 10180 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0010/section_0110/0500-0090-0010-0110.html |    50-9-111. Recognition of declarations executed in other states, MCA  |  |
| MTS_0500-0090-0020-0010 | 200 | 10452 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0020/section_0010/0500-0090-0020-0010.html |    50-9-201. Recording determination of terminal condition and content of declar |  |
| MTS_0500-0090-0020-0020 | 200 | 11107 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0020/section_0020/0500-0090-0020-0020.html |    50-9-202. Treatment of qualified patients, MCA  |  |
| MTS_0500-0090-0020-0030 | 200 | 10751 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0020/section_0030/0500-0090-0020-0030.html |    50-9-203. Transfer of patients, MCA  |  |
| MTS_0500-0090-0020-0040 | 200 | 12868 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0020/section_0040/0500-0090-0020-0040.html |    50-9-204. Immunities, MCA  |  |
| MTS_0500-0090-0020-0050 | 200 | 12235 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0020/section_0050/0500-0090-0020-0050.html |    50-9-205. Effect on insurance -- patient's decision, MCA  |  |
| MTS_0500-0090-0020-0060 | 200 | 12434 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0020/section_0060/0500-0090-0020-0060.html |    50-9-206. Penalties, MCA  |  |
| MTS_0500-0090-0050-0010 | 200 | 12123 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0050/section_0010/0500-0090-0050-0010.html |    50-9-501. Health care declaration registry -- website -- rulemaking, MCA  |  |
| MTS_0500-0090-0050-0020 | 200 | 13579 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0050/section_0020/0500-0090-0050-0020.html |    50-9-502. Health care declaration registry filing provisions -- special reven |  |
| MTS_0500-0090-0050-0030 | 200 | 14717 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0050/section_0030/0500-0090-0050-0030.html |    50-9-503. Entry of declaration into health care declaration registry -- remov |  |
| MTS_0500-0090-0050-0040 | 200 | 12636 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0050/section_0040/0500-0090-0050-0040.html |    50-9-504. Registry information -- confidentiality -- transfer of information, |  |
| MTS_0500-0090-0050-0050 | 200 | 11654 | https://leg.mt.gov/bills/mca/title_0500/chapter_0090/part_0050/section_0050/0500-0090-0050-0050.html |    50-9-505. Statewide education and outreach program, MCA  |  |
| MTS_0500-0100-0010-0010 | 200 | 14601 | https://leg.mt.gov/bills/mca/title_0500/chapter_0100/part_0010/section_0010/0500-0100-0010-0010.html |    50-10-101. Definitions, MCA  |  |
| MTS_0500-0100-0010-0020 | 200 | 12772 | https://leg.mt.gov/bills/mca/title_0500/chapter_0100/part_0010/section_0020/0500-0100-0010-0020.html |    50-10-102. Immunities, MCA  |  |
| MTS_0500-0100-0010-0030 | 200 | 12066 | https://leg.mt.gov/bills/mca/title_0500/chapter_0100/part_0010/section_0030/0500-0100-0010-0030.html |    50-10-103. Adherence to do not resuscitate protocol -- transfer of patients,  |  |
| MTS_0500-0100-0010-0040 | 200 | 13025 | https://leg.mt.gov/bills/mca/title_0500/chapter_0100/part_0010/section_0040/0500-0100-0010-0040.html |    50-10-104. Effect on insurance -- patient's decision, MCA  |  |
| MTS_0500-0100-0010-0050 | 200 | 11047 | https://leg.mt.gov/bills/mca/title_0500/chapter_0100/part_0010/section_0050/0500-0100-0010-0050.html |    50-10-105. Rulemaking authority, MCA  |  |
| MTS_0500-0100-0010-0060 | 200 | 11975 | https://leg.mt.gov/bills/mca/title_0500/chapter_0100/part_0010/section_0060/0500-0100-0010-0060.html |    50-10-106. Penalties, MCA  |  |
| MTS_0500-0100-0010-0070 | 200 | 10714 | https://leg.mt.gov/bills/mca/title_0500/chapter_0100/part_0010/section_0070/0500-0100-0010-0070.html |    50-10-107. DNR form to be readily available, MCA  |  |
| MTS_0500-0110-0010-0010 | 200 | 11989 | https://leg.mt.gov/bills/mca/title_0500/chapter_0110/part_0010/section_0010/0500-0110-0010-0010.html |    50-11-101. Definitions, MCA  |  |
| MTS_0500-0110-0010-0020 | 200 | 11958 | https://leg.mt.gov/bills/mca/title_0500/chapter_0110/part_0010/section_0020/0500-0110-0010-0020.html |    50-11-102. Prohibited acts -- penalties, MCA  |  |
| MTS_0500-0110-0010-0030 | 200 | 12139 | https://leg.mt.gov/bills/mca/title_0500/chapter_0110/part_0010/section_0030/0500-0110-0010-0030.html |    50-11-103. Scientific research -- exception, MCA  |  |
| MTS_0500-0120-0010-0010 | 200 | 10557 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0010/section_0010/0500-0120-0010-0010.html |    50-12-101. Short title, MCA  |  |
| MTS_0500-0120-0010-0020 | 200 | 13510 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0010/section_0020/0500-0120-0010-0020.html |    50-12-102. Definitions, MCA  |  |
| MTS_0500-0120-0010-0030 | 200 | 11681 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0010/section_0030/0500-0120-0010-0030.html |    50-12-103. Availability of experimental treatments, MCA  |  |
| MTS_0500-0120-0010-0040 | 200 | 11589 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0010/section_0040/0500-0120-0010-0040.html |    50-12-104. Patient requirements, MCA  |  |
| MTS_0500-0120-0010-0050 | 200 | 14699 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0010/section_0050/0500-0120-0010-0050.html |    50-12-105. Informed consent required, MCA  |  |
| MTS_0500-0120-0010-0060 | 200 | 13803 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0010/section_0060/0500-0120-0010-0060.html |    50-12-106. Effect on insurance coverage and health care services, MCA  |  |
| MTS_0500-0120-0010-0070 | 200 | 11102 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0010/section_0070/0500-0120-0010-0070.html |    50-12-107. Heirs not liable for payments, MCA  |  |
| MTS_0500-0120-0010-0080 | 200 | 11800 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0010/section_0080/0500-0120-0010-0080.html |    50-12-108. Disciplinary action prohibited, MCA  |  |
| MTS_0500-0120-0010-0090 | 200 | 11482 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0010/section_0090/0500-0120-0010-0090.html |    50-12-109. State action prohibited, MCA  |  |
| MTS_0500-0120-0010-0100 | 200 | 11121 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0010/section_0100/0500-0120-0010-0100.html |    50-12-110. Immunity from suit, MCA  |  |
| MTS_0500-0120-0020-0010 | 200 | 11666 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0020/section_0010/0500-0120-0020-0010.html |    50-12-201. Legislative findings -- purpose, MCA  |  |
| MTS_0500-0120-0020-0020 | 200 | 11981 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0020/section_0020/0500-0120-0020-0020.html |    50-12-202. Definitions, MCA  |  |
| MTS_0500-0120-0020-0030 | 200 | 13629 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0020/section_0030/0500-0120-0020-0030.html |    50-12-203. Palliative care and quality of life interdisciplinary advisory cou |  |
| MTS_0500-0120-0020-0040 | 200 | 11936 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0020/section_0040/0500-0120-0020-0040.html |    50-12-204. Duties of council, MCA  |  |
| MTS_0500-0120-0020-0050 | 200 | 12692 | https://leg.mt.gov/bills/mca/title_0500/chapter_0120/part_0020/section_0050/0500-0120-0020-0050.html |    50-12-205. Palliative care consumer and professional information and educatio |  |
| MTS_0500-0150-0010-0010 | 200 | 17893 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0010/0500-0150-0010-0010.html |    50-15-101. Definitions, MCA  |  |
| MTS_0500-0150-0010-0020 | 200 | 11159 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0020/0500-0150-0010-0020.html |    50-15-102. Statewide system of vital statistics to be established, MCA  |  |
| MTS_0500-0150-0010-0030 | 200 | 12032 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0030/0500-0150-0010-0030.html |    50-15-103. Duties of department, MCA  |  |
| MTS_0500-0150-0010-0040 | 200 | 11212 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0040/0500-0150-0010-0040.html |    50-15-104. Appointment and supervision of local registrars, MCA  |  |
| MTS_0500-0150-0010-0050 | 200 | 10995 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0050/0500-0150-0010-0050.html |    50-15-105. Appointment of deputies authorized, MCA  |  |
| MTS_0500-0150-0010-0060 | 200 | 11079 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0060/0500-0150-0010-0060.html |    50-15-106. Registrars and deputies to report violations, MCA  |  |
| MTS_0500-0150-0010-0070 | 200 | 11997 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0070/0500-0150-0010-0070.html |    50-15-107. Payment of fees to local registrars, MCA  |  |
| MTS_0500-0150-0010-0080 | 200 | 11488 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0080/0500-0150-0010-0080.html |    50-15-108. Duty to furnish information, MCA  |  |
| MTS_0500-0150-0010-0090 | 200 | 11873 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0090/0500-0150-0010-0090.html |    50-15-109. Certificates, MCA  |  |
| MTS_0500-0150-0010-0100 | 200 | 10798 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0100/0500-0150-0010-0100.html |    50-15-110. Repealed, MCA  |  |
| MTS_0500-0150-0010-0110 | 200 | 14457 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0110/0500-0150-0010-0110.html |    50-15-111. Certified copy fees -- transfer, MCA  |  |
| MTS_0500-0150-0010-0120 | 200 | 10923 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0120/0500-0150-0010-0120.html |    50-15-112. Repealed, MCA  |  |
| MTS_0500-0150-0010-0130 | 200 | 10815 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0130/0500-0150-0010-0130.html |    50-15-113. Repealed, MCA  |  |
| MTS_0500-0150-0010-0140 | 200 | 13865 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0140/0500-0150-0010-0140.html |    50-15-114. Unlawful acts and penalties, MCA  |  |
| MTS_0500-0150-0010-0150 | 200 | 10585 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0150/0500-0150-0010-0150.html |    50-15-115. through 50-15-120 reserved, MCA  |  |
| MTS_0500-0150-0010-0210 | 200 | 15812 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0210/0500-0150-0010-0210.html |    50-15-121. Copies from system of vital statistics, MCA  |  |
| MTS_0500-0150-0010-0220 | 200 | 18264 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0220/0500-0150-0010-0220.html |    50-15-122. Disclosure of information from vital records or vital reports -- r |  |
| MTS_0500-0150-0010-0230 | 200 | 11254 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0230/0500-0150-0010-0230.html |    50-15-123. Preservation of vital records, MCA  |  |
| MTS_0500-0150-0010-0240 | 200 | 11600 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0010/section_0240/0500-0150-0010-0240.html |    50-15-124. Content of certificates, records, and reports, MCA  |  |
| MTS_0500-0150-0020-0010 | 200 | 10545 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0010/0500-0150-0020-0010.html |    50-15-201. Repealed, MCA  |  |
| MTS_0500-0150-0020-0020 | 200 | 11554 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0020/0500-0150-0020-0020.html |    50-15-202. Unattended birth, MCA  |  |
| MTS_0500-0150-0020-0030 | 200 | 12099 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0030/0500-0150-0020-0030.html |    50-15-203. Child of unknown parentage, MCA  |  |
| MTS_0500-0150-0020-0040 | 200 | 14137 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0040/0500-0150-0020-0040.html |    50-15-204. Delayed or amended birth certificate, MCA  |  |
| MTS_0500-0150-0020-0050 | 200 | 10769 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0050/0500-0150-0020-0050.html |    50-15-205. Repealed, MCA  |  |
| MTS_0500-0150-0020-0060 | 200 | 10833 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0060/0500-0150-0020-0060.html |    50-15-206. Repealed, MCA  |  |
| MTS_0500-0150-0020-0070 | 200 | 11405 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0070/0500-0150-0020-0070.html |    50-15-207. New birth certificate upon proof of legitimation, MCA  |  |
| MTS_0500-0150-0020-0080 | 200 | 12965 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0080/0500-0150-0020-0080.html |    50-15-208. Birth registration for stillbirth -- requirements, MCA  |  |
| MTS_0500-0150-0020-0090 | 200 | 14369 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0090/0500-0150-0020-0090.html |    50-15-209. Certificate of nonviable birth -- requirements, MCA  |  |
| MTS_0500-0150-0020-0100 | 200 | 13293 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0100/0500-0150-0020-0100.html |    50-15-210. Paternity acknowledgment, MCA  |  |
| MTS_0500-0150-0020-0110 | 200 | 10523 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0110/0500-0150-0020-0110.html |    50-15-211. through 50-15-220 reserved, MCA  |  |
| MTS_0500-0150-0020-0210 | 200 | 17729 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0210/0500-0150-0020-0210.html |    50-15-221. Birth registration, MCA  |  |
| MTS_0500-0150-0020-0220 | 200 | 13940 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0220/0500-0150-0020-0220.html |    50-15-222. Judicial birth facts procedure, MCA  |  |
| MTS_0500-0150-0020-0230 | 200 | 17342 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0230/0500-0150-0020-0230.html |    50-15-223. Certificates of birth following adoption, legitimation, or determi |  |
| MTS_0500-0150-0020-0240 | 200 | 11726 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0020/section_0240/0500-0150-0020-0240.html |    50-15-224. Sex change designation on birth certificate, MCA  |  |
| MTS_0500-0150-0030-0010 | 200 | 10997 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0030/section_0010/0500-0150-0030-0010.html |    50-15-301. Marriage certificates, MCA  |  |
| MTS_0500-0150-0030-0020 | 200 | 12528 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0030/section_0020/0500-0150-0030-0020.html |    50-15-302. Clerk to report decree of dissolution or declaration of invalidity |  |
| MTS_0500-0150-0030-0030 | 200 | 11595 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0030/section_0030/0500-0150-0030-0030.html |    50-15-303. Certificates of dissolution of marriage or declaration of invalidi |  |
| MTS_0500-0150-0030-0040 | 200 | 13946 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0030/section_0040/0500-0150-0030-0040.html |    50-15-304. Substitute birth certificate for person adopted, MCA  |  |
| MTS_0500-0150-0030-0050 | 200 | 10674 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0030/section_0050/0500-0150-0030-0050.html |    50-15-305. through 50-15-310 reserved, MCA  |  |
| MTS_0500-0150-0030-0110 | 200 | 14709 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0030/section_0110/0500-0150-0030-0110.html |    50-15-311. Certificates of adoption or annulment of adoption -- report of ame |  |
| MTS_0500-0150-0040-0010 | 200 | 10574 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0040/section_0010/0500-0150-0040-0010.html |    50-15-401. Repealed, MCA  |  |
| MTS_0500-0150-0040-0020 | 200 | 11200 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0040/section_0020/0500-0150-0040-0020.html |    50-15-402. Copy to be forwarded to deceased's county of residence, MCA  |  |
| MTS_0500-0150-0040-0030 | 200 | 13934 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0040/section_0030/0500-0150-0040-0030.html |    50-15-403. Preparation and filing of death or fetal death certificate, MCA  |  |
| MTS_0500-0150-0040-0040 | 200 | 11623 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0040/section_0040/0500-0150-0040-0040.html |    50-15-404. Preparation of certificate when death not medically attended, MCA  |  |
| MTS_0500-0150-0040-0050 | 200 | 13077 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0040/section_0050/0500-0150-0040-0050.html |    50-15-405. Authorization for removal of body from place of death, MCA  |  |
| MTS_0500-0150-0040-0060 | 200 | 11005 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0040/section_0060/0500-0150-0040-0060.html |    50-15-406. Body brought into state for disposition, MCA  |  |
| MTS_0500-0150-0040-0070 | 200 | 11430 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0040/section_0070/0500-0150-0040-0070.html |    50-15-407. Disinterment permit, MCA  |  |
| MTS_0500-0150-0040-0080 | 200 | 10443 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0040/section_0080/0500-0150-0040-0080.html |    50-15-408. reserved, MCA  |  |
| MTS_0500-0150-0040-0090 | 200 | 11432 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0040/section_0090/0500-0150-0040-0090.html |    50-15-409. List of deaths to be made by department -- copy to county clerk, M |  |
| MTS_0500-0150-0040-0100 | 200 | 10478 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0040/section_0100/0500-0150-0040-0100.html |    50-15-410. reserved, MCA  |  |
| MTS_0500-0150-0040-0110 | 200 | 11743 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0040/section_0110/0500-0150-0040-0110.html |    50-15-411. Sudden infant death syndrome -- findings -- definition, MCA  |  |
| MTS_0500-0150-0040-0120 | 200 | 10826 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0040/section_0120/0500-0150-0040-0120.html |    50-15-412. Cause of death -- sudden infant death syndrome, MCA  |  |
| MTS_0500-0150-0070-0010 | 200 | 10501 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0070/section_0010/0500-0150-0070-0010.html |    50-15-701. Short title, MCA  |  |
| MTS_0500-0150-0070-0020 | 200 | 11836 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0070/section_0020/0500-0150-0070-0020.html |    50-15-702. Definitions, MCA  |  |
| MTS_0500-0150-0070-0030 | 200 | 11745 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0070/section_0030/0500-0150-0070-0030.html |    50-15-703. Duty to report tumors, MCA  |  |
| MTS_0500-0150-0070-0040 | 200 | 11826 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0070/section_0040/0500-0150-0070-0040.html |    50-15-704. Confidentiality, MCA  |  |
| MTS_0500-0150-0070-0050 | 200 | 10948 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0070/section_0050/0500-0150-0070-0050.html |    50-15-705. Tumor registry, MCA  |  |
| MTS_0500-0150-0070-0060 | 200 | 11001 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0070/section_0060/0500-0150-0070-0060.html |    50-15-706. Rules, MCA  |  |
| MTS_0500-0150-0070-0070 | 200 | 10536 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0070/section_0070/0500-0150-0070-0070.html |    50-15-707. through 50-15-709 reserved, MCA  |  |
| MTS_0500-0150-0070-0100 | 200 | 10882 | https://leg.mt.gov/bills/mca/title_0500/chapter_0150/part_0070/section_0100/0500-0150-0070-0100.html |    50-15-710. Immunity from liability, MCA  |  |
| MTS_0500-0160-0010-0010 | 200 | 11055 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0010/section_0010/0500-0160-0010-0010.html |    50-16-101. Public officials and corporations to furnish information on reques |  |
| MTS_0500-0160-0010-0020 | 200 | 12623 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0010/section_0020/0500-0160-0010-0020.html |    50-16-102. Information on infant morbidity and mortality, MCA  |  |
| MTS_0500-0160-0010-0030 | 200 | 13509 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0010/section_0030/0500-0160-0010-0030.html |    50-16-103. Information on shaken baby syndrome -- program, MCA  |  |
| MTS_0500-0160-0010-0040 | 200 | 12196 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0010/section_0040/0500-0160-0010-0040.html |    50-16-104. Information on shaken baby syndrome -- distribution, MCA  |  |
| MTS_0500-0160-0010-0050 | 200 | 10632 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0010/section_0050/0500-0160-0010-0050.html |    50-16-105. through 50-16-107 reserved, MCA  |  |
| MTS_0500-0160-0010-0080 | 200 | 11739 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0010/section_0080/0500-0160-0010-0080.html |    50-16-108. Privacy in health care -- ownership of firearms, MCA  |  |
| MTS_0500-0160-0020-0010 | 200 | 14117 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0020/section_0010/0500-0160-0020-0010.html |    50-16-201. Definitions, MCA  |  |
| MTS_0500-0160-0020-0020 | 200 | 11905 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0020/section_0020/0500-0160-0020-0020.html |    50-16-202. Committees to have access to information, MCA  |  |
| MTS_0500-0160-0020-0030 | 200 | 11586 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0020/section_0030/0500-0160-0020-0030.html |    50-16-203. Committee health care information and proceedings confidential and |  |
| MTS_0500-0160-0020-0040 | 200 | 11822 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0020/section_0040/0500-0160-0020-0040.html |    50-16-204. Restrictions on use or publication of information, MCA  |  |
| MTS_0500-0160-0020-0050 | 200 | 11179 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0020/section_0050/0500-0160-0020-0050.html |    50-16-205. Data confidential -- inadmissible in judicial proceedings, MCA  |  |
| MTS_0500-0160-0030-0010 | 200 | 10630 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0030/section_0010/0500-0160-0030-0010.html |    50-16-301. Repealed, MCA  |  |
| MTS_0500-0160-0030-0020 | 200 | 10834 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0030/section_0020/0500-0160-0030-0020.html |    50-16-302. Repealed, MCA  |  |
| MTS_0500-0160-0030-0030 | 200 | 10834 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0030/section_0030/0500-0160-0030-0030.html |    50-16-303. Repealed, MCA  |  |
| MTS_0500-0160-0030-0040 | 200 | 10834 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0030/section_0040/0500-0160-0030-0040.html |    50-16-304. Repealed, MCA  |  |
| MTS_0500-0160-0030-0050 | 200 | 10852 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0030/section_0050/0500-0160-0030-0050.html |    50-16-305. Repealed, MCA  |  |
| MTS_0500-0160-0030-0060 | 200 | 10655 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0030/section_0060/0500-0160-0030-0060.html |    50-16-306. through 50-16-310 reserved, MCA  |  |
| MTS_0500-0160-0030-0110 | 200 | 10883 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0030/section_0110/0500-0160-0030-0110.html |    50-16-311. Repealed, MCA  |  |
| MTS_0500-0160-0030-0120 | 200 | 10834 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0030/section_0120/0500-0160-0030-0120.html |    50-16-312. Repealed, MCA  |  |
| MTS_0500-0160-0030-0130 | 200 | 10834 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0030/section_0130/0500-0160-0030-0130.html |    50-16-313. Repealed, MCA  |  |
| MTS_0500-0160-0030-0140 | 200 | 10633 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0030/section_0140/0500-0160-0030-0140.html |    50-16-314. Repealed, MCA  |  |
| MTS_0500-0160-0040-0010 | 200 | 10376 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0040/section_0010/0500-0160-0040-0010.html |    50-16-401. Repealed, MCA  |  |
| MTS_0500-0160-0050-0010 | 200 | 10592 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0010/0500-0160-0050-0010.html |    50-16-501. Short title, MCA  |  |
| MTS_0500-0160-0050-0020 | 200 | 13323 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0020/0500-0160-0050-0020.html |    50-16-502. Legislative findings, MCA  |  |
| MTS_0500-0160-0050-0030 | 200 | 11071 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0030/0500-0160-0050-0030.html |    50-16-503. Uniformity of application and construction, MCA  |  |
| MTS_0500-0160-0050-0040 | 200 | 15344 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0040/0500-0160-0050-0040.html |    50-16-504. Definitions, MCA  |  |
| MTS_0500-0160-0050-0050 | 200 | 11063 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0050/0500-0160-0050-0050.html |    50-16-505. Limit on applicability, MCA  |  |
| MTS_0500-0160-0050-0060 | 200 | 10628 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0060/0500-0160-0050-0060.html |    50-16-506. through 50-16-510 reserved, MCA  |  |
| MTS_0500-0160-0050-0110 | 200 | 10991 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0110/0500-0160-0050-0110.html |    50-16-511. Duty to adopt security safeguards, MCA  |  |
| MTS_0500-0160-0050-0120 | 200 | 11914 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0120/0500-0160-0050-0120.html |    50-16-512. Content and dissemination of notice, MCA  |  |
| MTS_0500-0160-0050-0130 | 200 | 11393 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0130/0500-0160-0050-0130.html |    50-16-513. Retention of record, MCA  |  |
| MTS_0500-0160-0050-0140 | 200 | 10619 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0140/0500-0160-0050-0140.html |    50-16-514. through 50-16-520 reserved, MCA  |  |
| MTS_0500-0160-0050-0210 | 200 | 11632 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0210/0500-0160-0050-0210.html |    50-16-521. Health care representatives, MCA  |  |
| MTS_0500-0160-0050-0220 | 200 | 11579 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0220/0500-0160-0050-0220.html |    50-16-522. Representative of deceased patient, MCA  |  |
| MTS_0500-0160-0050-0230 | 200 | 10621 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0230/0500-0160-0050-0230.html |    50-16-523. and 50-16-524 reserved, MCA  |  |
| MTS_0500-0160-0050-0250 | 200 | 12616 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0250/0500-0160-0050-0250.html |    50-16-525. Disclosure by health care provider, MCA  |  |
| MTS_0500-0160-0050-0260 | 200 | 12692 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0260/0500-0160-0050-0260.html |    50-16-526. Patient authorization to health care provider for disclosure, MCA  |  |
| MTS_0500-0160-0050-0270 | 200 | 14852 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0270/0500-0160-0050-0270.html |    50-16-527. Patient authorization -- retention -- effective period -- exceptio |  |
| MTS_0500-0160-0050-0280 | 200 | 11579 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0280/0500-0160-0050-0280.html |    50-16-528. Patient's revocation of authorization for disclosure, MCA  |  |
| MTS_0500-0160-0050-0290 | 200 | 15702 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0290/0500-0160-0050-0290.html |    50-16-529. Disclosure without patient's authorization based on need to know,  |  |
| MTS_0500-0160-0050-0300 | 200 | 13210 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0300/0500-0160-0050-0300.html |    50-16-530. Disclosure without patient's authorization, MCA  |  |
| MTS_0500-0160-0050-0310 | 200 | 12449 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0310/0500-0160-0050-0310.html |    50-16-531. Immunity of health care providers pursuant to written authorizatio |  |
| MTS_0500-0160-0050-0320 | 200 | 10717 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0320/0500-0160-0050-0320.html |    50-16-532. through 50-16-534 reserved, MCA  |  |
| MTS_0500-0160-0050-0350 | 200 | 14915 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0350/0500-0160-0050-0350.html |    50-16-535. When health care information available by compulsory process, MCA  |  |
| MTS_0500-0160-0050-0360 | 200 | 15460 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0360/0500-0160-0050-0360.html |    50-16-536. Method of compulsory process, MCA  |  |
| MTS_0500-0160-0050-0370 | 200 | 10624 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0370/0500-0160-0050-0370.html |    50-16-537. through 50-16-539 reserved, MCA  |  |
| MTS_0500-0160-0050-0400 | 200 | 11110 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0400/0500-0160-0050-0400.html |    50-16-540. Reasonable fees allowed, MCA  |  |
| MTS_0500-0160-0050-0410 | 200 | 13430 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0410/0500-0160-0050-0410.html |    50-16-541. Requirements and procedures for patient's examination and copying, |  |
| MTS_0500-0160-0050-0420 | 200 | 14607 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0420/0500-0160-0050-0420.html |    50-16-542. Denial of examination and copying, MCA  |  |
| MTS_0500-0160-0050-0430 | 200 | 13002 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0430/0500-0160-0050-0430.html |    50-16-543. Request for correction or amendment, MCA  |  |
| MTS_0500-0160-0050-0440 | 200 | 12471 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0440/0500-0160-0050-0440.html |    50-16-544. Procedure for adding correction, amendment, or statement of disagr |  |
| MTS_0500-0160-0050-0450 | 200 | 12017 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0450/0500-0160-0050-0450.html |    50-16-545. Dissemination of corrected or amended information or statement of  |  |
| MTS_0500-0160-0050-0460 | 200 | 12821 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0460/0500-0160-0050-0460.html |    50-16-546. Digital health care information -- confidentiality -- penalties -- |  |
| MTS_0500-0160-0050-0470 | 200 | 10693 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0470/0500-0160-0050-0470.html |    50-16-547. through 50-16-550 reserved, MCA  |  |
| MTS_0500-0160-0050-0510 | 200 | 11863 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0510/0500-0160-0050-0510.html |    50-16-551. Criminal penalty, MCA  |  |
| MTS_0500-0160-0050-0520 | 200 | 11003 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0520/0500-0160-0050-0520.html |    50-16-552. Civil enforcement, MCA  |  |
| MTS_0500-0160-0050-0530 | 200 | 12803 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0050/section_0530/0500-0160-0050-0530.html |    50-16-553. Civil remedies, MCA  |  |
| MTS_0500-0160-0060-0010 | 200 | 10595 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0060/section_0010/0500-0160-0060-0010.html |    50-16-601. Short title, MCA  |  |
| MTS_0500-0160-0060-0020 | 200 | 12293 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0060/section_0020/0500-0160-0060-0020.html |    50-16-602. Definitions, MCA  |  |
| MTS_0500-0160-0060-0030 | 200 | 13687 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0060/section_0030/0500-0160-0060-0030.html |    50-16-603. Confidentiality of health care information, MCA  |  |
| MTS_0500-0160-0060-0040 | 200 | 11318 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0060/section_0040/0500-0160-0060-0040.html |    50-16-604. Secondary release of health care information, MCA  |  |
| MTS_0500-0160-0060-0050 | 200 | 11782 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0060/section_0050/0500-0160-0060-0050.html |    50-16-605. Judicial, legislative, and administrative proceedings -- testimony |  |
| MTS_0500-0160-0060-0060 | 200 | 11409 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0060/section_0060/0500-0160-0060-0060.html |    50-16-606. Correlation with Uniform Health Care Information Act, MCA  |  |
| MTS_0500-0160-0060-0070 | 200 | 14317 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0060/section_0070/0500-0160-0060-0070.html |    50-16-607. Duties of department during public health emergency, MCA  |  |
| MTS_0500-0160-0060-0080 | 200 | 10640 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0060/section_0080/0500-0160-0060-0080.html |    50-16-608. through 50-16-610 reserved, MCA  |  |
| MTS_0500-0160-0060-0110 | 200 | 10770 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0060/section_0110/0500-0160-0060-0110.html |    50-16-611. Penalty, MCA  |  |
| MTS_0500-0160-0070-0010 | 200 | 13849 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0070/section_0010/0500-0160-0070-0010.html |    50-16-701. Definitions, MCA  |  |
| MTS_0500-0160-0070-0020 | 200 | 15086 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0070/section_0020/0500-0160-0070-0020.html |    50-16-702. Notification of exposure to infectious disease -- report of exposu |  |
| MTS_0500-0160-0070-0030 | 200 | 12583 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0070/section_0030/0500-0160-0070-0030.html |    50-16-703. Notification of precautions after exposure to infectious disease,  |  |
| MTS_0500-0160-0070-0040 | 200 | 12485 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0070/section_0040/0500-0160-0070-0040.html |    50-16-704. Confidentiality -- penalty for violation -- immunity from liabilit |  |
| MTS_0500-0160-0070-0050 | 200 | 11770 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0070/section_0050/0500-0160-0070-0050.html |    50-16-705. Rulemaking authority, MCA  |  |
| MTS_0500-0160-0070-0060 | 200 | 10737 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0070/section_0060/0500-0160-0070-0060.html |    50-16-706. through 50-16-710 reserved, MCA  |  |
| MTS_0500-0160-0070-0110 | 200 | 12528 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0070/section_0110/0500-0160-0070-0110.html |    50-16-711. Health care facility and emergency services organization responsib |  |
| MTS_0500-0160-0070-0120 | 200 | 11796 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0070/section_0120/0500-0160-0070-0120.html |    50-16-712. Notification to mortuary personnel -- exposure to infectious disea |  |
| MTS_0500-0160-0080-0010 | 200 | 12056 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0010/0500-0160-0080-0010.html |    50-16-801. Legislative findings, MCA  |  |
| MTS_0500-0160-0080-0020 | 200 | 11141 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0020/0500-0160-0080-0020.html |    50-16-802. Applicability, MCA  |  |
| MTS_0500-0160-0080-0030 | 200 | 13768 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0030/0500-0160-0080-0030.html |    50-16-803. Definitions, MCA  |  |
| MTS_0500-0160-0080-0040 | 200 | 11716 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0040/0500-0160-0080-0040.html |    50-16-804. Representative of deceased patient's estate, MCA  |  |
| MTS_0500-0160-0080-0050 | 200 | 13299 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0050/0500-0160-0080-0050.html |    50-16-805. Disclosure of information allowed for certain purposes, MCA  |  |
| MTS_0500-0160-0080-0060 | 200 | 13084 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0060/0500-0160-0080-0060.html |    50-16-806. Privacy of electronic health records, MCA  |  |
| MTS_0500-0160-0080-0070 | 200 | 10801 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0070/0500-0160-0080-0070.html |    50-16-807. through 50-16-810 reserved, MCA  |  |
| MTS_0500-0160-0080-0110 | 200 | 14702 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0110/0500-0160-0080-0110.html |    50-16-811. When health care information available by compulsory process, MCA  |  |
| MTS_0500-0160-0080-0120 | 200 | 14894 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0120/0500-0160-0080-0120.html |    50-16-812. Method of compulsory process, MCA  |  |
| MTS_0500-0160-0080-0130 | 200 | 10748 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0130/0500-0160-0080-0130.html |    50-16-813. through 50-16-815 reserved, MCA  |  |
| MTS_0500-0160-0080-0160 | 200 | 11196 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0160/0500-0160-0080-0160.html |    50-16-816. Reasonable fees, MCA  |  |
| MTS_0500-0160-0080-0170 | 200 | 12685 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0170/0500-0160-0080-0170.html |    50-16-817. Civil remedies, MCA  |  |
| MTS_0500-0160-0080-0180 | 200 | 10857 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0080/section_0180/0500-0160-0080-0180.html |    50-16-818. Good faith, MCA  |  |
| MTS_0500-0160-0100-0010 | 200 | 10579 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0100/section_0010/0500-0160-0100-0010.html |    50-16-1001. Short title, MCA  |  |
| MTS_0500-0160-0100-0020 | 200 | 11617 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0100/section_0020/0500-0160-0100-0020.html |    50-16-1002. Statement of purpose, MCA  |  |
| MTS_0500-0160-0100-0030 | 200 | 14342 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0100/section_0030/0500-0160-0100-0030.html |    50-16-1003. Definitions, MCA  |  |
| MTS_0500-0160-0100-0040 | 200 | 11854 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0100/section_0040/0500-0160-0100-0040.html |    50-16-1004. AIDS, HIV-related conditions, and HIV infection to be treated as  |  |
| MTS_0500-0160-0100-0050 | 200 | 10662 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0100/section_0050/0500-0160-0100-0050.html |    50-16-1005. and 50-16-1006 reserved, MCA  |  |
| MTS_0500-0160-0100-0070 | 200 | 10938 | https://leg.mt.gov/bills/mca/title_0500/chapter_0160/part_0100/section_0070/0500-0160-0100-0070.html |    50-16-1007. Repealed, MCA  |  |
