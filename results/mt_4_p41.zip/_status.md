| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0330-0180-0060-0020 | 200 | 10958 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0060/section_0020/0330-0180-0060-0020.html |    33-18-602. Purpose, MCA  |  |
| MTS_0330-0180-0060-0030 | 200 | 11276 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0060/section_0030/0330-0180-0060-0030.html |    33-18-603. Scope, MCA  |  |
| MTS_0330-0180-0060-0040 | 200 | 14010 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0060/section_0040/0330-0180-0060-0040.html |    33-18-604. Definitions, MCA  |  |
| MTS_0330-0180-0060-0050 | 200 | 19740 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0060/section_0050/0330-0180-0060-0050.html |    33-18-605. Use of credit information, MCA  |  |
| MTS_0330-0180-0060-0060 | 200 | 11763 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0060/section_0060/0330-0180-0060-0060.html |    33-18-606. Dispute resolution and error correction, MCA  |  |
| MTS_0330-0180-0060-0070 | 200 | 11943 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0060/section_0070/0330-0180-0060-0070.html |    33-18-607. Initial notification, MCA  |  |
| MTS_0330-0180-0060-0080 | 200 | 11980 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0060/section_0080/0330-0180-0060-0080.html |    33-18-608. Adverse action notification, MCA  |  |
| MTS_0330-0180-0060-0090 | 200 | 11202 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0060/section_0090/0330-0180-0060-0090.html |    33-18-609. Filing, MCA  |  |
| MTS_0330-0180-0060-0100 | 200 | 11457 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0060/section_0100/0330-0180-0060-0100.html |    33-18-610. Indemnification, MCA  |  |
| MTS_0330-0180-0060-0110 | 200 | 12159 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0060/section_0110/0330-0180-0060-0110.html |    33-18-611. Sale of policy term information by consumer reporting agency, MCA  |  |
| MTS_0330-0180-0060-0120 | 200 | 11171 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0060/section_0120/0330-0180-0060-0120.html |    33-18-612. Refund for expunged record, MCA  |  |
| MTS_0330-0180-0090-0010 | 200 | 12807 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0090/section_0010/0330-0180-0090-0010.html |    33-18-901. Definitions, MCA  |  |
| MTS_0330-0180-0090-0020 | 200 | 12016 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0090/section_0020/0330-0180-0090-0020.html |    33-18-902. Requirement for genetic testing -- limitations, MCA  |  |
| MTS_0330-0180-0090-0030 | 200 | 13647 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0090/section_0030/0330-0180-0090-0030.html |    33-18-903. Discrimination on basis of genetic traits prohibited, MCA  |  |
| MTS_0330-0180-0090-0040 | 200 | 11705 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0090/section_0040/0330-0180-0090-0040.html |    33-18-904. Seeking genetic information for nontherapeutic purposes prohibited |  |
| MTS_0330-0180-0100-0010 | 200 | 11817 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0100/section_0010/0330-0180-0100-0010.html |    33-18-1001. Complaint handling -- marketing -- performance -- record, MCA  |  |
| MTS_0330-0180-0100-0020 | 200 | 11263 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0100/section_0020/0330-0180-0100-0020.html |    33-18-1002. Power of commissioner to examine insurers, MCA  |  |
| MTS_0330-0180-0100-0030 | 200 | 13173 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0100/section_0030/0330-0180-0100-0030.html |    33-18-1003. Undefined unfair practices -- procedures for determining and rest |  |
| MTS_0330-0180-0100-0040 | 200 | 12725 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0100/section_0040/0330-0180-0100-0040.html |    33-18-1004. Desist orders for prohibited practices, MCA  |  |
| MTS_0330-0180-0100-0050 | 200 | 11977 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0100/section_0050/0330-0180-0100-0050.html |    33-18-1005. Penalty for violation of cease and desist orders, MCA  |  |
| MTS_0330-0180-0100-0060 | 200 | 11170 | https://leg.mt.gov/bills/mca/title_0330/chapter_0180/part_0100/section_0060/0330-0180-0100-0060.html |    33-18-1006. Desist orders for prohibited practices, MCA  |  |
| MTS_0330-0190-0010-0010 | 200 | 10600 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0010/section_0010/0330-0190-0010-0010.html |    33-19-101. Short title, MCA  |  |
| MTS_0330-0190-0010-0020 | 200 | 12173 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0010/section_0020/0330-0190-0010-0020.html |    33-19-102. Purpose, MCA  |  |
| MTS_0330-0190-0010-0030 | 200 | 14161 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0010/section_0030/0330-0190-0010-0030.html |    33-19-103. Scope, MCA  |  |
| MTS_0330-0190-0010-0040 | 200 | 27628 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0010/section_0040/0330-0190-0010-0040.html |    33-19-104. Definitions, MCA  |  |
| MTS_0330-0190-0010-0050 | 200 | 17013 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0010/section_0050/0330-0190-0010-0050.html |    33-19-105. Exemption based on federal standards for privacy of individually i |  |
| MTS_0330-0190-0010-0060 | 200 | 10779 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0010/section_0060/0330-0190-0010-0060.html |    33-19-106. Rulemaking authorized, MCA  |  |
| MTS_0330-0190-0020-0010 | 200 | 11581 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0020/section_0010/0330-0190-0020-0010.html |    33-19-201. Pretext interviews prohibited -- exception, MCA  |  |
| MTS_0330-0190-0020-0020 | 200 | 21329 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0020/section_0020/0330-0190-0020-0020.html |    33-19-202. Notice of insurance information practices -- delivery of notice, M |  |
| MTS_0330-0190-0020-0030 | 200 | 11139 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0020/section_0030/0330-0190-0020-0030.html |    33-19-203. Marketing and research surveys, MCA  |  |
| MTS_0330-0190-0020-0040 | 200 | 10888 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0020/section_0040/0330-0190-0020-0040.html |    33-19-204. Repealed, MCA  |  |
| MTS_0330-0190-0020-0050 | 200 | 12632 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0020/section_0050/0330-0190-0020-0050.html |    33-19-205. Investigative consumer reports, MCA  |  |
| MTS_0330-0190-0020-0060 | 200 | 13107 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0020/section_0060/0330-0190-0020-0060.html |    33-19-206. Disclosure authorizations -- content -- conditions prohibited, MCA |  |
| MTS_0330-0190-0030-0010 | 200 | 18305 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0030/section_0010/0330-0190-0030-0010.html |    33-19-301. Access to recorded personal information, MCA  |  |
| MTS_0330-0190-0030-0020 | 200 | 16761 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0030/section_0020/0330-0190-0030-0020.html |    33-19-302. Correction, amendment, or deletion of recorded personal informatio |  |
| MTS_0330-0190-0030-0030 | 200 | 14859 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0030/section_0030/0330-0190-0030-0030.html |    33-19-303. Reasons for adverse underwriting decisions, MCA  |  |
| MTS_0330-0190-0030-0040 | 200 | 11944 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0030/section_0040/0330-0190-0030-0040.html |    33-19-304. Information concerning previous adverse underwriting decisions, MC |  |
| MTS_0330-0190-0030-0050 | 200 | 12006 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0030/section_0050/0330-0190-0030-0050.html |    33-19-305. Previous adverse underwriting decisions, MCA  |  |
| MTS_0330-0190-0030-0060 | 200 | 25750 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0030/section_0060/0330-0190-0030-0060.html |    33-19-306. Disclosure limitations and conditions, MCA  |  |
| MTS_0330-0190-0030-0070 | 200 | 14667 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0030/section_0070/0330-0190-0030-0070.html |    33-19-307. Personal information used for marketing purposes -- restrictions,  |  |
| MTS_0330-0190-0030-0080 | 200 | 13344 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0030/section_0080/0330-0190-0030-0080.html |    33-19-308. Disclosure of underwriting information, MCA  |  |
| MTS_0330-0190-0030-0090 | 200 | 14183 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0030/section_0090/0330-0190-0030-0090.html |    33-19-309. Health carrier and patient access to health information -- exempti |  |
| MTS_0330-0190-0030-0100 | 200 | 10714 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0030/section_0100/0330-0190-0030-0100.html |    33-19-310. through 33-19-320 reserved, MCA  |  |
| MTS_0330-0190-0030-0210 | 200 | 15607 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0030/section_0210/0330-0190-0030-0210.html |    33-19-321. Computer security breach, MCA  |  |
| MTS_0330-0190-0040-0010 | 200 | 11415 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0040/section_0010/0330-0190-0040-0010.html |    33-19-401. Power of the commissioner, MCA  |  |
| MTS_0330-0190-0040-0020 | 200 | 10846 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0040/section_0020/0330-0190-0040-0020.html |    33-19-402. Repealed, MCA  |  |
| MTS_0330-0190-0040-0030 | 200 | 11418 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0040/section_0030/0330-0190-0040-0030.html |    33-19-403. Service of process -- insurance-support organizations, MCA  |  |
| MTS_0330-0190-0040-0040 | 200 | 10834 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0040/section_0040/0330-0190-0040-0040.html |    33-19-404. Repealed, MCA  |  |
| MTS_0330-0190-0040-0050 | 200 | 10975 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0040/section_0050/0330-0190-0040-0050.html |    33-19-405. Civil penalty, MCA  |  |
| MTS_0330-0190-0040-0060 | 200 | 10800 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0040/section_0060/0330-0190-0040-0060.html |    33-19-406. Repealed, MCA  |  |
| MTS_0330-0190-0040-0070 | 200 | 13023 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0040/section_0070/0330-0190-0040-0070.html |    33-19-407. Individual remedies, MCA  |  |
| MTS_0330-0190-0040-0080 | 200 | 11339 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0040/section_0080/0330-0190-0040-0080.html |    33-19-408. Immunity, MCA  |  |
| MTS_0330-0190-0040-0090 | 200 | 11163 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0040/section_0090/0330-0190-0040-0090.html |    33-19-409. Obtaining information under false pretenses, MCA  |  |
| MTS_0330-0190-0040-0100 | 200 | 10586 | https://leg.mt.gov/bills/mca/title_0330/chapter_0190/part_0040/section_0100/0330-0190-0040-0100.html |    33-19-410. Repealed, MCA  |  |
| MTS_0330-0200-0010-0010 | 200 | 11597 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0010/0330-0200-0010-0010.html |    33-20-101. Scope, MCA  |  |
| MTS_0330-0200-0010-0020 | 200 | 11158 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0020/0330-0200-0010-0020.html |    33-20-102. Industrial life insurance defined, MCA  |  |
| MTS_0330-0200-0010-0030 | 200 | 12447 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0030/0330-0200-0010-0030.html |    33-20-103. Standard provisions required -- exceptions, MCA  |  |
| MTS_0330-0200-0010-0040 | 200 | 11293 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0040/0330-0200-0010-0040.html |    33-20-104. Grace period, MCA  |  |
| MTS_0330-0200-0010-0050 | 200 | 11977 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0050/0330-0200-0010-0050.html |    33-20-105. Incontestability, MCA  |  |
| MTS_0330-0200-0010-0060 | 200 | 11134 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0060/0330-0200-0010-0060.html |    33-20-106. Entire contract, MCA  |  |
| MTS_0330-0200-0010-0070 | 200 | 11015 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0070/0330-0200-0010-0070.html |    33-20-107. Misstatement of age, MCA  |  |
| MTS_0330-0200-0010-0080 | 200 | 13199 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0080/0330-0200-0010-0080.html |    33-20-108. Dividends, MCA  |  |
| MTS_0330-0200-0010-0090 | 200 | 10541 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0090/0330-0200-0010-0090.html |    33-20-109. Renumbered 33-20-131, MCA  |  |
| MTS_0330-0200-0010-0100 | 200 | 11185 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0100/0330-0200-0010-0100.html |    33-20-110. Table of values, MCA  |  |
| MTS_0330-0200-0010-0110 | 200 | 10942 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0110/0330-0200-0010-0110.html |    33-20-111. Table of installments, MCA  |  |
| MTS_0330-0200-0010-0120 | 200 | 11915 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0120/0330-0200-0010-0120.html |    33-20-112. Reinstatement, MCA  |  |
| MTS_0330-0200-0010-0130 | 200 | 10811 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0130/0330-0200-0010-0130.html |    33-20-113. Payment of premiums, MCA  |  |
| MTS_0330-0200-0010-0140 | 200 | 11974 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0140/0330-0200-0010-0140.html |    33-20-114. Payment of claims -- interest, MCA  |  |
| MTS_0330-0200-0010-0150 | 200 | 12859 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0150/0330-0200-0010-0150.html |    33-20-115. Beneficiary -- industrial policies, MCA  |  |
| MTS_0330-0200-0010-0160 | 200 | 10797 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0160/0330-0200-0010-0160.html |    33-20-116. Title, MCA  |  |
| MTS_0330-0200-0010-0170 | 200 | 12074 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0170/0330-0200-0010-0170.html |    33-20-117. Nonforfeiture rights -- policies issued before operative date, MCA |  |
| MTS_0330-0200-0010-0180 | 200 | 11393 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0180/0330-0200-0010-0180.html |    33-20-118. Contestability -- excluded or restricted coverage, MCA  |  |
| MTS_0330-0200-0010-0190 | 200 | 11956 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0190/0330-0200-0010-0190.html |    33-20-119. Incontestability -- limitation on liability after reinstatement of |  |
| MTS_0330-0200-0010-0200 | 200 | 12435 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0200/0330-0200-0010-0200.html |    33-20-120. Policy settlements -- holding proceeds -- indebtedness deducted fr |  |
| MTS_0330-0200-0010-0210 | 200 | 14399 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0210/0330-0200-0010-0210.html |    33-20-121. Prohibited provisions -- limitations on liability, MCA  |  |
| MTS_0330-0200-0010-0220 | 200 | 12396 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0220/0330-0200-0010-0220.html |    33-20-122. Prohibited provisions -- industrial life insurance, MCA  |  |
| MTS_0330-0200-0010-0230 | 200 | 12184 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0230/0330-0200-0010-0230.html |    33-20-123. Prohibited policy plans -- life insurance policies or annuity cont |  |
| MTS_0330-0200-0010-0240 | 200 | 11350 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0240/0330-0200-0010-0240.html |    33-20-124. Policy provisions -- conformity with state statutes, MCA  |  |
| MTS_0330-0200-0010-0250 | 200 | 10651 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0250/0330-0200-0010-0250.html |    33-20-125. and 33-20-126 reserved, MCA  |  |
| MTS_0330-0200-0010-0270 | 200 | 13084 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0270/0330-0200-0010-0270.html |    33-20-127. Life insurance policy with long-term care provision or accelerated |  |
| MTS_0330-0200-0010-0280 | 200 | 12069 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0280/0330-0200-0010-0280.html |    33-20-128. Life insurance policy paying long-term benefits -- monthly report, |  |
| MTS_0330-0200-0010-0290 | 200 | 10591 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0290/0330-0200-0010-0290.html |    33-20-129. and 33-20-130 reserved, MCA  |  |
| MTS_0330-0200-0010-0310 | 200 | 14443 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0310/0330-0200-0010-0310.html |    33-20-131. Policy loan or certificate loan, MCA  |  |
| MTS_0330-0200-0010-0320 | 200 | 11330 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0320/0330-0200-0010-0320.html |    33-20-132. Variable policy loan interest rates -- purpose, MCA  |  |
| MTS_0330-0200-0010-0330 | 200 | 11662 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0330/0330-0200-0010-0330.html |    33-20-133. Variable interest rates -- exclusions from application, MCA  |  |
| MTS_0330-0200-0010-0340 | 200 | 11686 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0340/0330-0200-0010-0340.html |    33-20-134. Variable interest rates -- published monthly average defined, MCA  |  |
| MTS_0330-0200-0010-0350 | 200 | 16720 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0350/0330-0200-0010-0350.html |    33-20-135. Variable interest rates on policy loans, MCA  |  |
| MTS_0330-0200-0010-0360 | 200 | 11415 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0360/0330-0200-0010-0360.html |    33-20-136. Variable interest rates -- applicability to policies issued before |  |
| MTS_0330-0200-0010-0370 | 200 | 10626 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0370/0330-0200-0010-0370.html |    33-20-137. through 33-20-140 reserved, MCA  |  |
| MTS_0330-0200-0010-0410 | 200 | 12873 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0410/0330-0200-0010-0410.html |    33-20-141. Notice required for cancellation, MCA  |  |
| MTS_0330-0200-0010-0420 | 200 | 13400 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0420/0330-0200-0010-0420.html |    33-20-142. Contents of notice -- proof -- limitation on recovery -- exemption |  |
| MTS_0330-0200-0010-0430 | 200 | 10658 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0430/0330-0200-0010-0430.html |    33-20-143. through 33-20-149 reserved, MCA  |  |
| MTS_0330-0200-0010-0500 | 200 | 12804 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0500/0330-0200-0010-0500.html |    33-20-150. Life insurance policy and sales illustrations -- annuity disclosur |  |
| MTS_0330-0200-0010-0510 | 200 | 10579 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0010/section_0510/0330-0200-0010-0510.html |    33-20-151. Repealed, MCA  |  |
| MTS_0330-0200-0020-0010 | 200 | 10771 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0010/0330-0200-0020-0010.html |    33-20-201. Short title, MCA  |  |
| MTS_0330-0200-0020-0020 | 200 | 16770 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0020/0330-0200-0020-0020.html |    33-20-202. Nonforfeiture provisions, MCA  |  |
| MTS_0330-0200-0020-0030 | 200 | 15218 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0030/0330-0200-0020-0030.html |    33-20-203. Cash surrender value -- paid-up nonforfeiture benefit -- life, MCA |  |
| MTS_0330-0200-0020-0040 | 200 | 15500 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0040/0330-0200-0020-0040.html |    33-20-204. Adjusted premium, MCA  |  |
| MTS_0330-0200-0020-0050 | 200 | 12971 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0050/0330-0200-0020-0050.html |    33-20-205. Calculation -- mortality table -- rates of interest, MCA  |  |
| MTS_0330-0200-0020-0060 | 200 | 13804 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0060/0330-0200-0020-0060.html |    33-20-206. Mortality tables -- policies issued after operative date, MCA  |  |
| MTS_0330-0200-0020-0070 | 200 | 13477 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0070/0330-0200-0020-0070.html |    33-20-207. Industrial policies -- mortality tables, MCA  |  |
| MTS_0330-0200-0020-0080 | 200 | 25373 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0080/0330-0200-0020-0080.html |    33-20-208. Mortality tables -- interest rate adjusted premiums, MCA  |  |
| MTS_0330-0200-0020-0090 | 200 | 12587 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0090/0330-0200-0020-0090.html |    33-20-209. Determination of nonforfeiture values for special plans, MCA  |  |
| MTS_0330-0200-0020-0100 | 200 | 16452 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0100/0330-0200-0020-0100.html |    33-20-210. Additional rules for calculating cash surrender values, MCA  |  |
| MTS_0330-0200-0020-0110 | 200 | 13755 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0110/0330-0200-0020-0110.html |    33-20-211. Calculation of values -- other requisites, MCA  |  |
| MTS_0330-0200-0020-0120 | 200 | 13488 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0120/0330-0200-0020-0120.html |    33-20-212. Exceptions, MCA  |  |
| MTS_0330-0200-0020-0130 | 200 | 12038 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0020/section_0130/0330-0200-0020-0130.html |    33-20-213. Operative date, MCA  |  |
| MTS_0330-0200-0030-0010 | 200 | 11601 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0030/section_0010/0330-0200-0030-0010.html |    33-20-301. Standard provisions -- annuity and pure endowment contracts, MCA  |  |
| MTS_0330-0200-0030-0020 | 200 | 11712 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0030/section_0020/0330-0200-0030-0020.html |    33-20-302. Grace period, MCA  |  |
| MTS_0330-0200-0030-0030 | 200 | 11622 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0030/section_0030/0330-0200-0030-0030.html |    33-20-303. Incontestability, MCA  |  |
| MTS_0330-0200-0030-0040 | 200 | 11161 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0030/section_0040/0330-0200-0030-0040.html |    33-20-304. Entire contract, MCA  |  |
| MTS_0330-0200-0030-0050 | 200 | 11568 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0030/section_0050/0330-0200-0030-0050.html |    33-20-305. Misstatement of age, MCA  |  |
| MTS_0330-0200-0030-0060 | 200 | 10967 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0030/section_0060/0330-0200-0030-0060.html |    33-20-306. Dividends, MCA  |  |
| MTS_0330-0200-0030-0070 | 200 | 11388 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0030/section_0070/0330-0200-0030-0070.html |    33-20-307. Reinstatement, MCA  |  |
| MTS_0330-0200-0030-0080 | 200 | 11644 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0030/section_0080/0330-0200-0030-0080.html |    33-20-308. Annuity information, MCA  |  |
| MTS_0330-0200-0030-0090 | 200 | 11960 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0030/section_0090/0330-0200-0030-0090.html |    33-20-309. Annuity penalty -- 10-year prohibition, MCA  |  |
| MTS_0330-0200-0040-0010 | 200 | 12315 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0040/section_0010/0330-0200-0040-0010.html |    33-20-401. Standard provisions, MCA  |  |
| MTS_0330-0200-0050-0010 | 200 | 10669 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0010/0330-0200-0050-0010.html |    33-20-501. Short title, MCA  |  |
| MTS_0330-0200-0050-0020 | 200 | 11576 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0020/0330-0200-0050-0020.html |    33-20-502. Application, MCA  |  |
| MTS_0330-0200-0050-0030 | 200 | 13854 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0030/0330-0200-0050-0030.html |    33-20-503. Nonforfeiture provisions, MCA  |  |
| MTS_0330-0200-0050-0040 | 200 | 11625 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0040/0330-0200-0050-0040.html |    33-20-504. Exception, MCA  |  |
| MTS_0330-0200-0050-0050 | 200 | 15408 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0050/0330-0200-0050-0050.html |    33-20-505. Minimum nonforfeiture amounts, MCA  |  |
| MTS_0330-0200-0050-0060 | 200 | 11417 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0060/0330-0200-0050-0060.html |    33-20-506. Present value to equal minimum nonforfeiture amount, MCA  |  |
| MTS_0330-0200-0050-0070 | 200 | 11979 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0070/0330-0200-0050-0070.html |    33-20-507. Cash surrender benefits, MCA  |  |
| MTS_0330-0200-0050-0080 | 200 | 12030 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0080/0330-0200-0050-0080.html |    33-20-508. Paid-up annuity benefits, MCA  |  |
| MTS_0330-0200-0050-0090 | 200 | 11480 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0090/0330-0200-0050-0090.html |    33-20-509. Maturity date, MCA  |  |
| MTS_0330-0200-0050-0100 | 200 | 11284 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0100/0330-0200-0050-0100.html |    33-20-510. Statement of noninclusion of certain death benefits, MCA  |  |
| MTS_0330-0200-0050-0110 | 200 | 11277 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0110/0330-0200-0050-0110.html |    33-20-511. Adjusted benefit, MCA  |  |
| MTS_0330-0200-0050-0120 | 200 | 12532 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0120/0330-0200-0050-0120.html |    33-20-512. Calculation of benefits -- special benefits excluded, MCA  |  |
| MTS_0330-0200-0050-0130 | 200 | 11168 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0050/section_0130/0330-0200-0050-0130.html |    33-20-513. Operative date, MCA  |  |
| MTS_0330-0200-0060-0010 | 200 | 10533 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0060/section_0010/0330-0200-0060-0010.html |    33-20-601. Short title, MCA  |  |
| MTS_0330-0200-0060-0020 | 200 | 10988 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0060/section_0020/0330-0200-0060-0020.html |    33-20-602. Powers of commissioner, MCA  |  |
| MTS_0330-0200-0060-0030 | 200 | 16518 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0060/section_0030/0330-0200-0060-0030.html |    33-20-603. Separate accounts for life insurance or annuities, MCA  |  |
| MTS_0330-0200-0060-0040 | 200 | 11518 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0060/section_0040/0330-0200-0060-0040.html |    33-20-604. Contract to contain statement of essential features, MCA  |  |
| MTS_0330-0200-0060-0050 | 200 | 12449 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0060/section_0050/0330-0200-0060-0050.html |    33-20-605. Requirements for doing business, MCA  |  |
| MTS_0330-0200-0060-0060 | 200 | 13156 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0060/section_0060/0330-0200-0060-0060.html |    33-20-606. Variable contracts to meet insurance contract requirements, MCA  |  |
| MTS_0330-0200-0070-0010 | 200 | 13057 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0070/section_0010/0330-0200-0070-0010.html |    33-20-701. Definitions, MCA  |  |
| MTS_0330-0200-0070-0020 | 200 | 11260 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0070/section_0020/0330-0200-0070-0020.html |    33-20-702. Charitable gift annuity not insurance, MCA  |  |
| MTS_0330-0200-0070-0030 | 200 | 10761 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0070/section_0030/0330-0200-0070-0030.html |    33-20-703. Repealed, MCA  |  |
| MTS_0330-0200-0070-0040 | 200 | 10764 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0070/section_0040/0330-0200-0070-0040.html |    33-20-704. Repealed, MCA  |  |
| MTS_0330-0200-0070-0050 | 200 | 10531 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0070/section_0050/0330-0200-0070-0050.html |    33-20-705. Repealed, MCA  |  |
| MTS_0330-0200-0080-0010 | 200 | 10602 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0080/section_0010/0330-0200-0080-0010.html |    33-20-801. Short title, MCA  |  |
| MTS_0330-0200-0080-0020 | 200 | 11716 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0080/section_0020/0330-0200-0080-0020.html |    33-20-802. Purpose -- scope, MCA  |  |
| MTS_0330-0200-0080-0030 | 200 | 12592 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0080/section_0030/0330-0200-0080-0030.html |    33-20-803. Exemptions, MCA  |  |
| MTS_0330-0200-0080-0040 | 200 | 17522 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0080/section_0040/0330-0200-0080-0040.html |    33-20-804. Definitions, MCA  |  |
| MTS_0330-0200-0080-0050 | 200 | 37330 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0080/section_0050/0330-0200-0080-0050.html |    33-20-805. Duties of insurers and producers-- best interest obligations, MCA  |  |
| MTS_0330-0200-0080-0060 | 200 | 12596 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0080/section_0060/0330-0200-0080-0060.html |    33-20-806. Compliance mitigation -- penalties -- enforcement, MCA  |  |
| MTS_0330-0200-0080-0070 | 200 | 14697 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0080/section_0070/0330-0200-0080-0070.html |    33-20-807. Producer training, MCA  |  |
| MTS_0330-0200-0090-0010 | 200 | 10525 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0090/section_0010/0330-0200-0090-0010.html |    33-20-901. Short title, MCA  |  |
| MTS_0330-0200-0090-0020 | 200 | 11117 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0090/section_0020/0330-0200-0090-0020.html |    33-20-902. Purpose, MCA  |  |
| MTS_0330-0200-0090-0030 | 200 | 13368 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0090/section_0030/0330-0200-0090-0030.html |    33-20-903. Applicability, MCA  |  |
| MTS_0330-0200-0090-0040 | 200 | 13400 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0090/section_0040/0330-0200-0090-0040.html |    33-20-904. Definitions, MCA  |  |
| MTS_0330-0200-0090-0050 | 200 | 15976 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0090/section_0050/0330-0200-0090-0050.html |    33-20-905. Standards for disclosure document and buyer's guide, MCA  |  |
| MTS_0330-0200-0090-0060 | 200 | 11855 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0090/section_0060/0330-0200-0090-0060.html |    33-20-906. Report to contract owners, MCA  |  |
| MTS_0330-0200-0090-0070 | 200 | 10735 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0090/section_0070/0330-0200-0090-0070.html |    33-20-907. Penalties, MCA  |  |
| MTS_0330-0200-0100-0010 | 200 | 11949 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0100/section_0010/0330-0200-0100-0010.html |    33-20-1001. Group contracts required to meet group requirements, MCA  |  |
| MTS_0330-0200-0100-0020 | 200 | 11506 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0100/section_0020/0330-0200-0100-0020.html |    33-20-1002. Employee life insurance defined, MCA  |  |
| MTS_0330-0200-0100-0030 | 200 | 10619 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0100/section_0030/0330-0200-0100-0030.html |    33-20-1003. Repealed, MCA  |  |
| MTS_0330-0200-0110-0010 | 200 | 13870 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0110/section_0010/0330-0200-0110-0010.html |    33-20-1101. Employee groups, MCA  |  |
| MTS_0330-0200-0110-0020 | 200 | 12824 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0110/section_0020/0330-0200-0110-0020.html |    33-20-1102. Labor union groups, MCA  |  |
| MTS_0330-0200-0110-0030 | 200 | 15055 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0110/section_0030/0330-0200-0110-0030.html |    33-20-1103. Employer and labor union combinations -- trustee groups, MCA  |  |
| MTS_0330-0200-0110-0040 | 200 | 13631 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0110/section_0040/0330-0200-0110-0040.html |    33-20-1104. Public employee groups, MCA  |  |
| MTS_0330-0200-0110-0050 | 200 | 13577 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0110/section_0050/0330-0200-0110-0050.html |    33-20-1105. Debtor groups, MCA  |  |
| MTS_0330-0200-0110-0060 | 200 | 12851 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0110/section_0060/0330-0200-0110-0060.html |    33-20-1106. Credit union groups, MCA  |  |
| MTS_0330-0200-0110-0070 | 200 | 10642 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0110/section_0070/0330-0200-0110-0070.html |    33-20-1107. through 33-20-1110 reserved, MCA  |  |
| MTS_0330-0200-0110-0110 | 200 | 15081 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0110/section_0110/0330-0200-0110-0110.html |    33-20-1111. Dependents of employee and labor union groups -- coverage, MCA  |  |
| MTS_0330-0200-0110-0120 | 200 | 12125 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0110/section_0120/0330-0200-0110-0120.html |    33-20-1112. Discretionary groups, MCA  |  |
| MTS_0330-0200-0120-0010 | 200 | 12262 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0010/0330-0200-0120-0010.html |    33-20-1201. Provisions required in group contracts, MCA  |  |
| MTS_0330-0200-0120-0020 | 200 | 11394 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0020/0330-0200-0120-0020.html |    33-20-1202. Grace period, MCA  |  |
| MTS_0330-0200-0120-0030 | 200 | 11435 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0030/0330-0200-0120-0030.html |    33-20-1203. Incontestability, MCA  |  |
| MTS_0330-0200-0120-0040 | 200 | 11474 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0040/0330-0200-0120-0040.html |    33-20-1204. Application -- statements considered representations, MCA  |  |
| MTS_0330-0200-0120-0050 | 200 | 11135 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0050/0330-0200-0120-0050.html |    33-20-1205. Insurability, MCA  |  |
| MTS_0330-0200-0120-0060 | 200 | 11105 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0060/0330-0200-0120-0060.html |    33-20-1206. Misstatement of age, MCA  |  |
| MTS_0330-0200-0120-0070 | 200 | 11997 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0070/0330-0200-0120-0070.html |    33-20-1207. Payment of benefits, MCA  |  |
| MTS_0330-0200-0120-0080 | 200 | 11336 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0080/0330-0200-0120-0080.html |    33-20-1208. Certificate, MCA  |  |
| MTS_0330-0200-0120-0090 | 200 | 14993 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0090/0330-0200-0120-0090.html |    33-20-1209. Conversion on termination of eligibility, MCA  |  |
| MTS_0330-0200-0120-0100 | 200 | 12724 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0100/0330-0200-0120-0100.html |    33-20-1210. Conversion on termination of policy or certificate, MCA  |  |
| MTS_0330-0200-0120-0110 | 200 | 11674 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0110/0330-0200-0120-0110.html |    33-20-1211. Death pending conversion, MCA  |  |
| MTS_0330-0200-0120-0120 | 200 | 12070 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0120/0330-0200-0120-0120.html |    33-20-1212. Notice as to conversion right, MCA  |  |
| MTS_0330-0200-0120-0130 | 200 | 11276 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0120/section_0130/0330-0200-0120-0130.html |    33-20-1213. Policy and certificate provisions -- conformity with state statut |  |
| MTS_0330-0200-0130-0010 | 200 | 10531 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0010/0330-0200-0130-0010.html |    33-20-1301. Short title, MCA  |  |
| MTS_0330-0200-0130-0020 | 200 | 18965 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0020/0330-0200-0130-0020.html |    33-20-1302. Definitions, MCA  |  |
| MTS_0330-0200-0130-0030 | 200 | 18611 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0030/0330-0200-0130-0030.html |    33-20-1303. License requirements, MCA  |  |
| MTS_0330-0200-0130-0040 | 200 | 12360 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0040/0330-0200-0130-0040.html |    33-20-1304. Issuance of license, MCA  |  |
| MTS_0330-0200-0130-0050 | 200 | 11266 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0050/0330-0200-0130-0050.html |    33-20-1305. Expiration of license, MCA  |  |
| MTS_0330-0200-0130-0060 | 200 | 11361 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0060/0330-0200-0130-0060.html |    33-20-1306. Notification by licensee of material change affecting qualificati |  |
| MTS_0330-0200-0130-0070 | 200 | 15244 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0070/0330-0200-0130-0070.html |    33-20-1307. Suspension -- revocation -- refusal to issue or renew license, MC |  |
| MTS_0330-0200-0130-0080 | 200 | 14318 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0080/0330-0200-0130-0080.html |    33-20-1308. Terms of contract, MCA  |  |
| MTS_0330-0200-0130-0090 | 200 | 11702 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0090/0330-0200-0130-0090.html |    33-20-1309. Annual report by provider, MCA  |  |
| MTS_0330-0200-0130-0100 | 200 | 12773 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0100/0330-0200-0130-0100.html |    33-20-1310. Examination of business and practices of licensee or applicant -- |  |
| MTS_0330-0200-0130-0110 | 200 | 13352 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0110/0330-0200-0130-0110.html |    33-20-1311. Disclosure of information to policyholder, MCA  |  |
| MTS_0330-0200-0130-0120 | 200 | 14059 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0120/0330-0200-0130-0120.html |    33-20-1312. Conditions precedent to entering into viatical settlement contrac |  |
| MTS_0330-0200-0130-0130 | 200 | 17053 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0130/0330-0200-0130-0130.html |    33-20-1313. Requirements for entering into viatical settlement contract -- pr |  |
| MTS_0330-0200-0130-0140 | 200 | 12601 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0140/0330-0200-0130-0140.html |    33-20-1314. Payment to escrow or trust account -- lump-sum payment, MCA  |  |
| MTS_0330-0200-0130-0150 | 200 | 13239 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0150/0330-0200-0130-0150.html |    33-20-1315. Rules -- standards -- bond, MCA  |  |
| MTS_0330-0200-0130-0160 | 200 | 11196 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0160/0330-0200-0130-0160.html |    33-20-1316. Service of process, MCA  |  |
| MTS_0330-0200-0130-0170 | 200 | 17070 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0170/0330-0200-0130-0170.html |    33-20-1317. Disclosure of information to viatical settlement purchasers, MCA  |  |
| MTS_0330-0200-0130-0180 | 200 | 12506 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0130/section_0180/0330-0200-0130-0180.html |    33-20-1318. Conflict of laws, MCA  |  |
| MTS_0330-0200-0140-0010 | 200 | 10580 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0140/section_0010/0330-0200-0140-0010.html |    33-20-1401. Short title, MCA  |  |
| MTS_0330-0200-0140-0020 | 200 | 18498 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0140/section_0020/0330-0200-0140-0020.html |    33-20-1402. Definitions, MCA  |  |
| MTS_0330-0200-0140-0030 | 200 | 12914 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0140/section_0030/0330-0200-0140-0030.html |    33-20-1403. Disclosure to payee, MCA  |  |
| MTS_0330-0200-0140-0040 | 200 | 12152 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0140/section_0040/0330-0200-0140-0040.html |    33-20-1404. Transfer of structured settlement payment right -- conditions, MC |  |
| MTS_0330-0200-0140-0050 | 200 | 12395 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0140/section_0050/0330-0200-0140-0050.html |    33-20-1405. Obligations after transfer, MCA  |  |
| MTS_0330-0200-0140-0060 | 200 | 10958 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0140/section_0060/0330-0200-0140-0060.html |    33-20-1406. Additional transfers, MCA  |  |
| MTS_0330-0200-0140-0070 | 200 | 13247 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0140/section_0070/0330-0200-0140-0070.html |    33-20-1407. Jurisdiction -- notice, MCA  |  |
| MTS_0330-0200-0140-0080 | 200 | 10833 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0140/section_0080/0330-0200-0140-0080.html |    33-20-1408. Waiver not allowed, MCA  |  |
| MTS_0330-0200-0140-0090 | 200 | 11335 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0140/section_0090/0330-0200-0140-0090.html |    33-20-1409. Disputes -- entry of judgment, MCA  |  |
| MTS_0330-0200-0140-0100 | 200 | 11515 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0140/section_0100/0330-0200-0140-0100.html |    33-20-1410. Contingent payment conditions, MCA  |  |
| MTS_0330-0200-0140-0110 | 200 | 12017 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0140/section_0110/0330-0200-0140-0110.html |    33-20-1411. Responsibility for compliance -- liability, MCA  |  |
| MTS_0330-0200-0140-0120 | 200 | 10791 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0140/section_0120/0330-0200-0140-0120.html |    33-20-1412. Construction, MCA  |  |
| MTS_0330-0200-0150-0010 | 200 | 17015 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0150/section_0010/0330-0200-0150-0010.html |    33-20-1501. Funeral insurance, MCA  |  |
| MTS_0330-0200-0150-0020 | 200 | 10974 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0150/section_0020/0330-0200-0150-0020.html |    33-20-1502. Excess funeral insurance proceeds, MCA  |  |
| MTS_0330-0200-0150-0030 | 200 | 10631 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0150/section_0030/0330-0200-0150-0030.html |    33-20-1503. Rules, MCA  |  |
| MTS_0330-0200-0160-0010 | 200 | 10592 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0160/section_0010/0330-0200-0160-0010.html |    33-20-1601. Short title, MCA  |  |
| MTS_0330-0200-0160-0020 | 200 | 11010 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0160/section_0020/0330-0200-0160-0020.html |    33-20-1602. Purpose, MCA  |  |
| MTS_0330-0200-0160-0030 | 200 | 11620 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0160/section_0030/0330-0200-0160-0030.html |    33-20-1603. Application of part, MCA  |  |
| MTS_0330-0200-0160-0040 | 200 | 13385 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0160/section_0040/0330-0200-0160-0040.html |    33-20-1604. Definitions, MCA  |  |
| MTS_0330-0200-0160-0050 | 200 | 14963 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0160/section_0050/0330-0200-0160-0050.html |    33-20-1605. Insurer conduct, MCA  |  |
| MTS_0330-0200-0160-0060 | 200 | 10879 | https://leg.mt.gov/bills/mca/title_0330/chapter_0200/part_0160/section_0060/0330-0200-0160-0060.html |    33-20-1606. Unfair trade practices, MCA  |  |
| MTS_0330-0210-0010-0010 | 200 | 10655 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0010/section_0010/0330-0210-0010-0010.html |    33-21-101. Short title, MCA  |  |
| MTS_0330-0210-0010-0020 | 200 | 12725 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0010/section_0020/0330-0210-0010-0020.html |    33-21-102. Purpose and scope, MCA  |  |
| MTS_0330-0210-0010-0030 | 200 | 14047 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0010/section_0030/0330-0210-0010-0030.html |    33-21-103. Definitions, MCA  |  |
| MTS_0330-0210-0010-0040 | 200 | 11345 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0010/section_0040/0330-0210-0010-0040.html |    33-21-104. Existing insurance -- choice of insurer, MCA  |  |
| MTS_0330-0210-0010-0050 | 200 | 11892 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0010/section_0050/0330-0210-0010-0050.html |    33-21-105. Claims, MCA  |  |
| MTS_0330-0210-0010-0060 | 200 | 10599 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0010/section_0060/0330-0210-0010-0060.html |    33-21-106. through 33-21-110 reserved, MCA  |  |
| MTS_0330-0210-0010-0110 | 200 | 11633 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0010/section_0110/0330-0210-0010-0110.html |    33-21-111. Rules -- enforcement of chapter, MCA  |  |
| MTS_0330-0210-0010-0120 | 200 | 11042 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0010/section_0120/0330-0210-0010-0120.html |    33-21-112. Judicial review, MCA  |  |
| MTS_0330-0210-0010-0130 | 200 | 11456 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0010/section_0130/0330-0210-0010-0130.html |    33-21-113. Penalties, MCA  |  |
| MTS_0330-0210-0020-0010 | 200 | 12030 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0020/section_0010/0330-0210-0020-0010.html |    33-21-201. Form of issuance, MCA  |  |
| MTS_0330-0210-0020-0020 | 200 | 14300 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0020/section_0020/0330-0210-0020-0020.html |    33-21-202. Amount, MCA  |  |
| MTS_0330-0210-0020-0030 | 200 | 12673 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0020/section_0030/0330-0210-0020-0030.html |    33-21-203. Term, MCA  |  |
| MTS_0330-0210-0020-0040 | 200 | 14896 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0020/section_0040/0330-0210-0020-0040.html |    33-21-204. Policy or certificate delivered -- time of delivery -- provisions, |  |
| MTS_0330-0210-0020-0050 | 200 | 13703 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0020/section_0050/0330-0210-0020-0050.html |    33-21-205. Filing, approval, and withdrawal of forms and rates -- disapproval |  |
| MTS_0330-0210-0020-0060 | 200 | 13282 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0020/section_0060/0330-0210-0020-0060.html |    33-21-206. Premiums and refunds, MCA  |  |
| MTS_0330-0210-0020-0070 | 200 | 11104 | https://leg.mt.gov/bills/mca/title_0330/chapter_0210/part_0020/section_0070/0330-0210-0020-0070.html |    33-21-207. Issuance of policies, MCA  |  |
| MTS_0330-0220-0010-0010 | 200 | 15029 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0010/0330-0220-0010-0010.html |    33-22-101. Exceptions to scope, MCA  |  |
| MTS_0330-0220-0010-0020 | 200 | 11096 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0020/0330-0220-0010-0020.html |    33-22-102. Third-party ownership, MCA  |  |
| MTS_0330-0220-0010-0030 | 200 | 10780 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0030/0330-0220-0010-0030.html |    33-22-103. Repealed, MCA  |  |
| MTS_0330-0220-0010-0040 | 200 | 10625 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0040/0330-0220-0010-0040.html |    33-22-104. through 33-22-106 reserved, MCA  |  |
| MTS_0330-0220-0010-0070 | 200 | 13624 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0070/0330-0220-0010-0070.html |    33-22-107. Premium increase restriction -- exception -- notice of rate increa |  |
| MTS_0330-0220-0010-0080 | 200 | 10503 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0080/0330-0220-0010-0080.html |    33-22-108. reserved, MCA  |  |
| MTS_0330-0220-0010-0090 | 200 | 11693 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0090/0330-0220-0010-0090.html |    33-22-109. Riders, MCA  |  |
| MTS_0330-0220-0010-0100 | 200 | 12331 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0100/0330-0220-0010-0100.html |    33-22-110. Preexisting conditions, MCA  |  |
| MTS_0330-0220-0010-0110 | 200 | 13345 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0110/0330-0220-0010-0110.html |    33-22-111. Policies and certificates to provide for freedom of choice of prac |  |
| MTS_0330-0220-0010-0120 | 200 | 12832 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0120/0330-0220-0010-0120.html |    33-22-112. Disability insurance coverage of services of state institutions -- |  |
| MTS_0330-0220-0010-0130 | 200 | 11587 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0130/0330-0220-0010-0130.html |    33-22-113. Disability insurance coverage of persons eligible for public medic |  |
| MTS_0330-0220-0010-0140 | 200 | 12970 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0140/0330-0220-0010-0140.html |    33-22-114. Coverage required for services provided by physician assistants, a |  |
| MTS_0330-0220-0010-0150 | 200 | 14396 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0150/0330-0220-0010-0150.html |    33-22-115. Provider agreement limited to covered services -- dental network c |  |
| MTS_0330-0220-0010-0160 | 200 | 12058 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0160/0330-0220-0010-0160.html |    33-22-116. Prohibition on coverage of abortion services in qualified health p |  |
| MTS_0330-0220-0010-0170 | 200 | 11153 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0170/0330-0220-0010-0170.html |    33-22-117. Construction, MCA  |  |
| MTS_0330-0220-0010-0180 | 200 | 10594 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0180/0330-0220-0010-0180.html |    33-22-118. through 33-22-120 reserved, MCA  |  |
| MTS_0330-0220-0010-0210 | 200 | 13276 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0210/0330-0220-0010-0210.html |    33-22-121. Notice required for cancellation or refusal to renew, MCA  |  |
| MTS_0330-0220-0010-0220 | 200 | 13707 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0220/0330-0220-0010-0220.html |    33-22-122. Contents of notice -- proof -- limitation on recovery -- exemption |  |
| MTS_0330-0220-0010-0230 | 200 | 11326 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0230/0330-0220-0010-0230.html |    33-22-123. Return of unearned premium, MCA  |  |
| MTS_0330-0220-0010-0240 | 200 | 10502 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0240/0330-0220-0010-0240.html |    33-22-124. reserved, MCA  |  |
| MTS_0330-0220-0010-0250 | 200 | 14219 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0250/0330-0220-0010-0250.html |    33-22-125. Independent chiropractic physical examination or review of records |  |
| MTS_0330-0220-0010-0260 | 200 | 10523 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0260/0330-0220-0010-0260.html |    33-22-126. reserved, MCA  |  |
| MTS_0330-0220-0010-0270 | 200 | 11034 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0270/0330-0220-0010-0270.html |    33-22-127. Coverage of oral therapy -- opioid use disorder, MCA  |  |
| MTS_0330-0220-0010-0280 | 200 | 16398 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0280/0330-0220-0010-0280.html |    33-22-128. Coverage for children who are deaf or hard of hearing -- definitio |  |
| MTS_0330-0220-0010-0290 | 200 | 15775 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0290/0330-0220-0010-0290.html |    33-22-129. Coverage for treatment of diabetes -- outpatient self-management t |  |
| MTS_0330-0220-0010-0300 | 200 | 12411 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0300/0330-0220-0010-0300.html |    33-22-130. Coverage for adopted children from time of placement -- preexistin |  |
| MTS_0330-0220-0010-0310 | 200 | 13876 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0310/0330-0220-0010-0310.html |    33-22-131. Coverage for treatment of inborn errors of metabolism, MCA  |  |
| MTS_0330-0220-0010-0320 | 200 | 15772 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0320/0330-0220-0010-0320.html |    33-22-132. Coverage for minimum mammography and other breast examinations, MC |  |
| MTS_0330-0220-0010-0330 | 200 | 13310 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0330/0330-0220-0010-0330.html |    33-22-133. Coverage for minimum hospital stay following childbirth, MCA  |  |
| MTS_0330-0220-0010-0340 | 200 | 11699 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0340/0330-0220-0010-0340.html |    33-22-134. Postmastectomy care, MCA  |  |
| MTS_0330-0220-0010-0350 | 200 | 14329 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0350/0330-0220-0010-0350.html |    33-22-135. Coverage for reconstructive breast surgery after mastectomy -- ben |  |
| MTS_0330-0220-0010-0360 | 200 | 14251 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0360/0330-0220-0010-0360.html |    33-22-136. Insurance for spouse and dependents of deceased peace officer, gam |  |
| MTS_0330-0220-0010-0370 | 200 | 11897 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0370/0330-0220-0010-0370.html |    33-22-137. Cost-sharing requirements -- applicability, MCA  |  |
| MTS_0330-0220-0010-0380 | 200 | 17217 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0380/0330-0220-0010-0380.html |    33-22-138. Coverage for telehealth services -- rulemaking, MCA  |  |
| MTS_0330-0220-0010-0390 | 200 | 15222 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0390/0330-0220-0010-0390.html |    33-22-139. Coverage of therapies for Down syndrome, MCA  |  |
| MTS_0330-0220-0010-0400 | 200 | 26934 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0400/0330-0220-0010-0400.html |    33-22-140. Definitions, MCA  |  |
| MTS_0330-0220-0010-0410 | 200 | 14780 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0410/0330-0220-0010-0410.html |    33-22-141. Crediting previous coverage, MCA  |  |
| MTS_0330-0220-0010-0420 | 200 | 14607 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0420/0330-0220-0010-0420.html |    33-22-142. Certification of creditable coverage, MCA  |  |
| MTS_0330-0220-0010-0430 | 200 | 11521 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0430/0330-0220-0010-0430.html |    33-22-143. Rules, MCA  |  |
| MTS_0330-0220-0010-0440 | 200 | 10595 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0440/0330-0220-0010-0440.html |    33-22-144. through 33-22-148 reserved, MCA  |  |
| MTS_0330-0220-0010-0490 | 200 | 13664 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0490/0330-0220-0010-0490.html |    33-22-149. Reciprocity in gender transition treatment coverage required, MCA  |  |
| MTS_0330-0220-0010-0500 | 200 | 15397 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0500/0330-0220-0010-0500.html |    33-22-150. Reciprocal limitations on claim filing and claim audits -- time li |  |
| MTS_0330-0220-0010-0510 | 200 | 11196 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0510/0330-0220-0010-0510.html |    33-22-151. Offset agreement, MCA  |  |
| MTS_0330-0220-0010-0520 | 200 | 11595 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0520/0330-0220-0010-0520.html |    33-22-152. Continuation of dependent coverage, MCA  |  |
| MTS_0330-0220-0010-0530 | 200 | 17200 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0530/0330-0220-0010-0530.html |    33-22-153. Coverage of routine patient costs for participants in cancer clini |  |
| MTS_0330-0220-0010-0540 | 200 | 12779 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0540/0330-0220-0010-0540.html |    33-22-154. Coverage for refill of eyedrops, MCA  |  |
| MTS_0330-0220-0010-0550 | 200 | 13351 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0550/0330-0220-0010-0550.html |    33-22-155. Coverage of contraceptives, MCA  |  |
| MTS_0330-0220-0010-0560 | 200 | 15666 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0560/0330-0220-0010-0560.html |    33-22-156. Health insurance rates -- filing required -- use, MCA  |  |
| MTS_0330-0220-0010-0570 | 200 | 17164 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0570/0330-0220-0010-0570.html |    33-22-157. Standards for review -- notice of deficiency, MCA  |  |
| MTS_0330-0220-0010-0580 | 200 | 11588 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0580/0330-0220-0010-0580.html |    33-22-158. Trade secret disclosure exemption, MCA  |  |
| MTS_0330-0220-0010-0590 | 200 | 11189 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0590/0330-0220-0010-0590.html |    33-22-159. Rulemaking, MCA  |  |
| MTS_0330-0220-0010-0600 | 200 | 10548 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0600/0330-0220-0010-0600.html |    33-22-160. through 33-22-165 reserved, MCA  |  |
| MTS_0330-0220-0010-0660 | 200 | 10760 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0660/0330-0220-0010-0660.html |    33-22-166. Repealed, MCA  |  |
| MTS_0330-0220-0010-0670 | 200 | 10549 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0670/0330-0220-0010-0670.html |    33-22-167. through 33-22-169 reserved, MCA  |  |
| MTS_0330-0220-0010-0700 | 200 | 20921 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0700/0330-0220-0010-0700.html |    33-22-170. Definitions, MCA  |  |
| MTS_0330-0220-0010-0710 | 200 | 12874 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0710/0330-0220-0010-0710.html |    33-22-171. Maximum allowable cost list -- limitations on drugs, MCA  |  |
| MTS_0330-0220-0010-0720 | 200 | 19635 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0720/0330-0220-0010-0720.html |    33-22-172. Maximum allowable cost or reference price list -- price formulatio |  |
| MTS_0330-0220-0010-0730 | 200 | 13467 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0730/0330-0220-0010-0730.html |    33-22-173. Maximum allowable cost -- appeals process, MCA  |  |
| MTS_0330-0220-0010-0740 | 200 | 11871 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0740/0330-0220-0010-0740.html |    33-22-174. Opt-out of reference pricing -- notification, MCA  |  |
| MTS_0330-0220-0010-0750 | 200 | 14573 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0750/0330-0220-0010-0750.html |    33-22-175. Allowable and prohibited fees on pharmacies, MCA  |  |
| MTS_0330-0220-0010-0760 | 200 | 11123 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0760/0330-0220-0010-0760.html |    33-22-176. Limitation on copayments, MCA  |  |
| MTS_0330-0220-0010-0770 | 200 | 22339 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0770/0330-0220-0010-0770.html |    33-22-177. Rights of pharmacies, MCA  |  |
| MTS_0330-0220-0010-0780 | 200 | 10579 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0780/0330-0220-0010-0780.html |    33-22-178. and 33-22-179 reserved, MCA  |  |
| MTS_0330-0220-0010-0800 | 200 | 12558 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0010/section_0800/0330-0220-0010-0800.html |    33-22-180. Contract coverage -- nondiscrimination -- penalty, MCA  |  |
| MTS_0330-0220-0020-0010 | 200 | 13991 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0010/0330-0220-0020-0010.html |    33-22-201. Format and content, MCA  |  |
| MTS_0330-0220-0020-0020 | 200 | 13655 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0020/0330-0220-0020-0020.html |    33-22-202. Required provisions -- captions -- omissions -- substitutions -- o |  |
| MTS_0330-0220-0020-0030 | 200 | 12605 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0030/0330-0220-0020-0030.html |    33-22-203. Requirement of other jurisdictions -- statutes -- violation, MCA  |  |
| MTS_0330-0220-0020-0040 | 200 | 11417 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0040/0330-0220-0020-0040.html |    33-22-204. Entire contract -- changes, MCA  |  |
| MTS_0330-0220-0020-0050 | 200 | 13174 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0050/0330-0220-0020-0050.html |    33-22-205. Time limit on certain defenses, MCA  |  |
| MTS_0330-0220-0020-0060 | 200 | 11815 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0060/0330-0220-0020-0060.html |    33-22-206. Grace period, MCA  |  |
| MTS_0330-0220-0020-0070 | 200 | 12886 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0070/0330-0220-0020-0070.html |    33-22-207. Reinstatement, MCA  |  |
| MTS_0330-0220-0020-0080 | 200 | 12927 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0080/0330-0220-0020-0080.html |    33-22-208. Notice of claim, MCA  |  |
| MTS_0330-0220-0020-0090 | 200 | 11383 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0090/0330-0220-0020-0090.html |    33-22-209. Claim forms, MCA  |  |
| MTS_0330-0220-0020-0100 | 200 | 11589 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0100/0330-0220-0020-0100.html |    33-22-210. Proofs of loss, MCA  |  |
| MTS_0330-0220-0020-0110 | 200 | 11603 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0110/0330-0220-0020-0110.html |    33-22-211. Time of payment of claims, MCA  |  |
| MTS_0330-0220-0020-0120 | 200 | 12868 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0120/0330-0220-0020-0120.html |    33-22-212. Payment of claims, MCA  |  |
| MTS_0330-0220-0020-0130 | 200 | 11263 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0130/0330-0220-0020-0130.html |    33-22-213. Physical examination and autopsy, MCA  |  |
| MTS_0330-0220-0020-0140 | 200 | 11236 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0140/0330-0220-0020-0140.html |    33-22-214. Legal actions, MCA  |  |
| MTS_0330-0220-0020-0150 | 200 | 11464 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0150/0330-0220-0020-0150.html |    33-22-215. Change of beneficiary, MCA  |  |
| MTS_0330-0220-0020-0160 | 200 | 10792 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0160/0330-0220-0020-0160.html |    33-22-216. Repealed, MCA  |  |
| MTS_0330-0220-0020-0170 | 200 | 10615 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0170/0330-0220-0020-0170.html |    33-22-217. through 33-22-220 reserved, MCA  |  |
| MTS_0330-0220-0020-0210 | 200 | 11962 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0210/0330-0220-0020-0210.html |    33-22-221. Optional policy provisions -- substitutes, MCA  |  |
| MTS_0330-0220-0020-0220 | 200 | 12562 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0220/0330-0220-0020-0220.html |    33-22-222. Change of occupation, MCA  |  |
| MTS_0330-0220-0020-0230 | 200 | 11095 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0230/0330-0220-0020-0230.html |    33-22-223. Misstatement of age, MCA  |  |
| MTS_0330-0220-0020-0240 | 200 | 12064 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0240/0330-0220-0020-0240.html |    33-22-224. Other insurance in this insurer, MCA  |  |
| MTS_0330-0220-0020-0250 | 200 | 13950 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0250/0330-0220-0020-0250.html |    33-22-225. Insurance with other insurers -- provision of service or expense i |  |
| MTS_0330-0220-0020-0260 | 200 | 13356 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0260/0330-0220-0020-0260.html |    33-22-226. Insurance with other insurers -- other benefits, MCA  |  |
| MTS_0330-0220-0020-0270 | 200 | 13485 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0270/0330-0220-0020-0270.html |    33-22-227. Relation of earnings to insurance, MCA  |  |
| MTS_0330-0220-0020-0280 | 200 | 11070 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0280/0330-0220-0020-0280.html |    33-22-228. Unpaid premiums, MCA  |  |
| MTS_0330-0220-0020-0290 | 200 | 11289 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0290/0330-0220-0020-0290.html |    33-22-229. Conformity with state statutes, MCA  |  |
| MTS_0330-0220-0020-0300 | 200 | 11145 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0300/0330-0220-0020-0300.html |    33-22-230. Illegal occupation, MCA  |  |
| MTS_0330-0220-0020-0310 | 200 | 10813 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0310/0330-0220-0020-0310.html |    33-22-231. Repealed, MCA  |  |
| MTS_0330-0220-0020-0320 | 200 | 12148 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0320/0330-0220-0020-0320.html |    33-22-232. Renewal at option of insurer, MCA  |  |
| MTS_0330-0220-0020-0330 | 200 | 10605 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0330/0330-0220-0020-0330.html |    33-22-233. through 33-22-240 reserved, MCA  |  |
| MTS_0330-0220-0020-0410 | 200 | 13543 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0410/0330-0220-0020-0410.html |    33-22-241. Definitions, MCA  |  |
| MTS_0330-0220-0020-0420 | 200 | 11804 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0420/0330-0220-0020-0420.html |    33-22-242. Waiver of preexisting condition exclusion -- exclusion prohibited, |  |
| MTS_0330-0220-0020-0430 | 200 | 13052 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0430/0330-0220-0020-0430.html |    33-22-243. Premium increases to be distributed proportionately, MCA  |  |
| MTS_0330-0220-0020-0440 | 200 | 14141 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0440/0330-0220-0020-0440.html |    33-22-244. Disclosure standards -- individual policy, MCA  |  |
| MTS_0330-0220-0020-0450 | 200 | 10868 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0450/0330-0220-0020-0450.html |    33-22-245. Repealed, MCA  |  |
| MTS_0330-0220-0020-0460 | 200 | 11796 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0460/0330-0220-0020-0460.html |    33-22-246. Preexisting conditions relating to individual market, MCA  |  |
| MTS_0330-0220-0020-0470 | 200 | 16490 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0470/0330-0220-0020-0470.html |    33-22-247. Guaranteed renewability of individual health insurance coverage, M |  |
| MTS_0330-0220-0020-0480 | 200 | 10639 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0480/0330-0220-0020-0480.html |    33-22-248. through 33-22-260 reserved, MCA  |  |
| MTS_0330-0220-0020-0610 | 200 | 10791 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0610/0330-0220-0020-0610.html |    33-22-261. Terminated, MCA  |  |
| MTS_0330-0220-0020-0620 | 200 | 10837 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0620/0330-0220-0020-0620.html |    33-22-262. Terminated, MCA  |  |
| MTS_0330-0220-0020-0630 | 200 | 10572 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0020/section_0630/0330-0220-0020-0630.html |    33-22-263. Terminated, MCA  |  |
| MTS_0330-0220-0030-0010 | 200 | 12533 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0010/0330-0220-0030-0010.html |    33-22-301. Coverage of newborn under disability policy, MCA  |  |
| MTS_0330-0220-0030-0020 | 200 | 12350 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0020/0330-0220-0030-0020.html |    33-22-302. Age limits -- effect on coverage, MCA  |  |
| MTS_0330-0220-0030-0030 | 200 | 13832 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0030/0330-0220-0030-0030.html |    33-22-303. Coverage for well-child care, MCA  |  |
| MTS_0330-0220-0030-0040 | 200 | 12715 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0040/0330-0220-0030-0040.html |    33-22-304. Continuation of coverage for individuals with disabilities -- indi |  |
| MTS_0330-0220-0030-0050 | 200 | 11153 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0050/0330-0220-0030-0050.html |    33-22-305. Short title, MCA  |  |
| MTS_0330-0220-0030-0060 | 200 | 11433 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0060/0330-0220-0030-0060.html |    33-22-306. Purpose, MCA  |  |
| MTS_0330-0220-0030-0070 | 200 | 12717 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0070/0330-0220-0030-0070.html |    33-22-307. Continuity of coverage, MCA  |  |
| MTS_0330-0220-0030-0080 | 200 | 12708 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0080/0330-0220-0030-0080.html |    33-22-308. Form of coverage -- requirements -- evidence of insurability -- pr |  |
| MTS_0330-0220-0030-0090 | 200 | 11128 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0090/0330-0220-0030-0090.html |    33-22-309. Notice, MCA  |  |
| MTS_0330-0220-0030-0100 | 200 | 11318 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0100/0330-0220-0030-0100.html |    33-22-310. Nonduplication, MCA  |  |
| MTS_0330-0220-0030-0110 | 200 | 11798 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0110/0330-0220-0030-0110.html |    33-22-311. Overinsurance, MCA  |  |
| MTS_0330-0220-0030-0120 | 200 | 11830 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0120/0330-0220-0030-0120.html |    33-22-312. Limitations on cost sharing for insulin, MCA  |  |
| MTS_0330-0220-0030-0130 | 200 | 10727 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0130/0330-0220-0030-0130.html |    33-22-313. through 33-22-315 reserved, MCA  |  |
| MTS_0330-0220-0030-0160 | 200 | 12880 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0030/section_0160/0330-0220-0030-0160.html |    33-22-316. Coverage for self-management training and education for treatment  |  |
| MTS_0330-0220-0040-0010 | 200 | 10412 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0040/section_0010/0330-0220-0040-0010.html |    33-22-401. Repealed, MCA  |  |
| MTS_0330-0220-0050-0010 | 200 | 14851 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0010/0330-0220-0050-0010.html |    33-22-501. Group disability insurance defined -- eligible groups, MCA  |  |
| MTS_0330-0220-0050-0020 | 200 | 12926 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0020/0330-0220-0050-0020.html |    33-22-502. Required provisions of group policies, MCA  |  |
| MTS_0330-0220-0050-0030 | 200 | 11360 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0030/0330-0220-0050-0030.html |    33-22-503. Continuation of benefits to dependents, MCA  |  |
| MTS_0330-0220-0050-0040 | 200 | 13129 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0040/0330-0220-0050-0040.html |    33-22-504. Newborn infant coverage, MCA  |  |
| MTS_0330-0220-0050-0050 | 200 | 11491 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0050/0330-0220-0050-0050.html |    33-22-505. Direct payment of hospital and medical services, MCA  |  |
| MTS_0330-0220-0050-0060 | 200 | 12709 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0060/0330-0220-0050-0060.html |    33-22-506. Continuation of coverage for persons with disabilities -- group co |  |
| MTS_0330-0220-0050-0070 | 200 | 11683 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0070/0330-0220-0050-0070.html |    33-22-507. Continuing group coverage after reduction of work schedule, MCA  |  |
| MTS_0330-0220-0050-0080 | 200 | 15446 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0080/0330-0220-0050-0080.html |    33-22-508. Conversion on termination of eligibility, MCA  |  |
| MTS_0330-0220-0050-0090 | 200 | 11090 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0090/0330-0220-0050-0090.html |    33-22-509. Preexisting conditions, MCA  |  |
| MTS_0330-0220-0050-0100 | 200 | 12254 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0100/0330-0220-0050-0100.html |    33-22-510. Insured's family -- conversion entitlement, MCA  |  |
| MTS_0330-0220-0050-0110 | 200 | 11047 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0110/0330-0220-0050-0110.html |    33-22-511. Applicability, MCA  |  |
| MTS_0330-0220-0050-0120 | 200 | 13667 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0120/0330-0220-0050-0120.html |    33-22-512. Coverage for well-child care, MCA  |  |
| MTS_0330-0220-0050-0130 | 200 | 11727 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0130/0330-0220-0050-0130.html |    33-22-513. Limitation of eligibility on conversion, MCA  |  |
| MTS_0330-0220-0050-0140 | 200 | 12169 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0140/0330-0220-0050-0140.html |    33-22-514. Preexisting conditions relating to group market, MCA  |  |
| MTS_0330-0220-0050-0150 | 200 | 16953 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0150/0330-0220-0050-0150.html |    33-22-515. Coverage of autism spectrum disorders, MCA  |  |
| MTS_0330-0220-0050-0160 | 200 | 10627 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0160/0330-0220-0050-0160.html |    33-22-516. through 33-22-520 reserved, MCA  |  |
| MTS_0330-0220-0050-0210 | 200 | 14457 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0210/0330-0220-0050-0210.html |    33-22-521. Disclosure standards -- group policy, MCA  |  |
| MTS_0330-0220-0050-0220 | 200 | 10826 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0220/0330-0220-0050-0220.html |    33-22-522. Repealed, MCA  |  |
| MTS_0330-0220-0050-0230 | 200 | 14601 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0230/0330-0220-0050-0230.html |    33-22-523. Special enrollment periods, MCA  |  |
| MTS_0330-0220-0050-0240 | 200 | 16981 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0240/0330-0220-0050-0240.html |    33-22-524. Guaranteed renewability of coverage for employers in group market, |  |
| MTS_0330-0220-0050-0250 | 200 | 12687 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0250/0330-0220-0050-0250.html |    33-22-525. Guaranteed renewability in multiple employer welfare arrangements, |  |
| MTS_0330-0220-0050-0260 | 200 | 14318 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0260/0330-0220-0050-0260.html |    33-22-526. Group health discrimination prohibited, MCA  |  |
| MTS_0330-0220-0050-0270 | 200 | 10665 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0270/0330-0220-0050-0270.html |    33-22-527. through 33-22-529 reserved, MCA  |  |
| MTS_0330-0220-0050-0300 | 200 | 13096 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0050/section_0300/0330-0220-0050-0300.html |    33-22-530. Notice required for cancellation for nonpayment of group health in |  |
| MTS_0330-0220-0060-0010 | 200 | 13178 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0060/section_0010/0330-0220-0060-0010.html |    33-22-601. Blanket disability insurance defined, MCA  |  |
| MTS_0330-0220-0060-0020 | 200 | 15029 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0060/section_0020/0330-0220-0060-0020.html |    33-22-602. Required provisions of blanket policies, MCA  |  |
| MTS_0330-0220-0060-0030 | 200 | 11126 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0060/section_0030/0330-0220-0060-0030.html |    33-22-603. Application and certificates not required, MCA  |  |
| MTS_0330-0220-0060-0040 | 200 | 11935 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0060/section_0040/0330-0220-0060-0040.html |    33-22-604. Payment of claims -- discharge, MCA  |  |
| MTS_0330-0220-0070-0010 | 200 | 11954 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0070/section_0010/0330-0220-0070-0010.html |    33-22-701. Short title -- purpose -- scope of part -- exceptions, MCA  |  |
| MTS_0330-0220-0070-0020 | 200 | 19241 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0070/section_0020/0330-0220-0070-0020.html |    33-22-702. Definitions, MCA  |  |
| MTS_0330-0220-0070-0030 | 200 | 13240 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0070/section_0030/0330-0220-0070-0030.html |    33-22-703. Coverage for mental illness, severe mental illness, and substance  |  |
| MTS_0330-0220-0070-0040 | 200 | 11113 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0070/section_0040/0330-0220-0070-0040.html |    33-22-704. Repealed, MCA  |  |
| MTS_0330-0220-0070-0050 | 200 | 15127 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0070/section_0050/0330-0220-0070-0050.html |    33-22-705. Inpatient and outpatient benefits -- use of psychiatric collaborat |  |
| MTS_0330-0220-0070-0060 | 200 | 11013 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0070/section_0060/0330-0220-0070-0060.html |    33-22-706. Repealed, MCA  |  |
| MTS_0330-0220-0070-0070 | 200 | 11235 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0070/section_0070/0330-0220-0070-0070.html |    33-22-707. Parity compliance records, MCA  |  |
| MTS_0330-0220-0070-0080 | 200 | 10587 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0070/section_0080/0330-0220-0070-0080.html |    33-22-708. and 33-22-709 reserved, MCA  |  |
| MTS_0330-0220-0070-0100 | 200 | 10597 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0070/section_0100/0330-0220-0070-0100.html |    33-22-710. Rulemaking, MCA  |  |
| MTS_0330-0220-0080-0010 | 200 | 10596 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0010/0330-0220-0080-0010.html |    33-22-801. Repealed, MCA  |  |
| MTS_0330-0220-0080-0020 | 200 | 10800 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0020/0330-0220-0080-0020.html |    33-22-802. Repealed, MCA  |  |
| MTS_0330-0220-0080-0030 | 200 | 10806 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0030/0330-0220-0080-0030.html |    33-22-803. Repealed, MCA  |  |
| MTS_0330-0220-0080-0040 | 200 | 10863 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0040/0330-0220-0080-0040.html |    33-22-804. Repealed, MCA  |  |
| MTS_0330-0220-0080-0050 | 200 | 10837 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0050/0330-0220-0080-0050.html |    33-22-805. Repealed, MCA  |  |
| MTS_0330-0220-0080-0060 | 200 | 10818 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0060/0330-0220-0080-0060.html |    33-22-806. Repealed, MCA  |  |
| MTS_0330-0220-0080-0070 | 200 | 10600 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0070/0330-0220-0080-0070.html |    33-22-807. through 33-22-810 reserved, MCA  |  |
| MTS_0330-0220-0080-0110 | 200 | 10824 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0110/0330-0220-0080-0110.html |    33-22-811. Repealed, MCA  |  |
| MTS_0330-0220-0080-0120 | 200 | 10838 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0120/0330-0220-0080-0120.html |    33-22-812. Repealed, MCA  |  |
| MTS_0330-0220-0080-0130 | 200 | 10882 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0130/0330-0220-0080-0130.html |    33-22-813. Repealed, MCA  |  |
| MTS_0330-0220-0080-0140 | 200 | 10806 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0140/0330-0220-0080-0140.html |    33-22-814. Repealed, MCA  |  |
| MTS_0330-0220-0080-0150 | 200 | 10806 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0150/0330-0220-0080-0150.html |    33-22-815. Repealed, MCA  |  |
| MTS_0330-0220-0080-0160 | 200 | 10605 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0080/section_0160/0330-0220-0080-0160.html |    33-22-816. Repealed, MCA  |  |
| MTS_0330-0220-0090-0010 | 200 | 10639 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0010/0330-0220-0090-0010.html |    33-22-901. Short title, MCA  |  |
| MTS_0330-0220-0090-0020 | 200 | 10981 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0020/0330-0220-0090-0020.html |    33-22-902. Purpose, MCA  |  |
| MTS_0330-0220-0090-0030 | 200 | 15178 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0030/0330-0220-0090-0030.html |    33-22-903. Definitions, MCA  |  |
| MTS_0330-0220-0090-0040 | 200 | 14792 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0040/0330-0220-0090-0040.html |    33-22-904. Standards for policy provisions -- rules, MCA  |  |
| MTS_0330-0220-0090-0050 | 200 | 11398 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0050/0330-0220-0090-0050.html |    33-22-905. Minimum standards for benefits and payment of claims -- rules, MCA |  |
| MTS_0330-0220-0090-0060 | 200 | 14125 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0060/0330-0220-0090-0060.html |    33-22-906. Loss ratio standards and filing requirements -- limits on compensa |  |
| MTS_0330-0220-0090-0070 | 200 | 15669 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0070/0330-0220-0090-0070.html |    33-22-907. Disclosure standards -- informational brochure -- rules, MCA  |  |
| MTS_0330-0220-0090-0080 | 200 | 11494 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0080/0330-0220-0090-0080.html |    33-22-908. Notice of free examination, MCA  |  |
| MTS_0330-0220-0090-0090 | 200 | 11090 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0090/0330-0220-0090-0090.html |    33-22-909. Administrative procedures, MCA  |  |
| MTS_0330-0220-0090-0100 | 200 | 11233 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0100/0330-0220-0090-0100.html |    33-22-910. Filing requirements for advertising, MCA  |  |
| MTS_0330-0220-0090-0110 | 200 | 11339 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0110/0330-0220-0090-0110.html |    33-22-911. Penalties, MCA  |  |
| MTS_0330-0220-0090-0120 | 200 | 10704 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0120/0330-0220-0090-0120.html |    33-22-912. through 33-22-920 reserved, MCA  |  |
| MTS_0330-0220-0090-0210 | 200 | 12571 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0210/0330-0220-0090-0210.html |    33-22-921. Discontinuance or nonrenewal -- alternate policy or certificate -- |  |
| MTS_0330-0220-0090-0220 | 200 | 12106 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0220/0330-0220-0090-0220.html |    33-22-922. Discontinuance or nonrenewal -- alternate policy -- unauthorized b |  |
| MTS_0330-0220-0090-0230 | 200 | 12589 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0230/0330-0220-0090-0230.html |    33-22-923. Replacement policy or certificate -- different issuer, MCA  |  |
| MTS_0330-0220-0090-0240 | 200 | 11792 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0090/section_0240/0330-0220-0090-0240.html |    33-22-924. Renewal requirement, MCA  |  |
| MTS_0330-0220-0100-0010 | 200 | 11757 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0100/section_0010/0330-0220-0100-0010.html |    33-22-1001. Definition of home health care, MCA  |  |
| MTS_0330-0220-0100-0020 | 200 | 11339 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0100/section_0020/0330-0220-0100-0020.html |    33-22-1002. Availability of coverage for home health care, MCA  |  |
| MTS_0330-0220-0100-0030 | 200 | 11031 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0100/section_0030/0330-0220-0100-0030.html |    33-22-1003. Applicability, MCA  |  |
| MTS_0330-0220-0110-0010 | 200 | 10568 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0010/0330-0220-0110-0010.html |    33-22-1101. Short title, MCA  |  |
| MTS_0330-0220-0110-0020 | 200 | 11597 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0020/0330-0220-0110-0020.html |    33-22-1102. Purpose, MCA  |  |
| MTS_0330-0220-0110-0030 | 200 | 10905 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0030/0330-0220-0110-0030.html |    33-22-1103. Compliance required, MCA  |  |
| MTS_0330-0220-0110-0040 | 200 | 11058 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0040/0330-0220-0110-0040.html |    33-22-1104. Scope, MCA  |  |
| MTS_0330-0220-0110-0050 | 200 | 10571 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0050/0330-0220-0110-0050.html |    33-22-1105. and 33-22-1106 reserved, MCA  |  |
| MTS_0330-0220-0110-0070 | 200 | 23917 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0070/0330-0220-0110-0070.html |    33-22-1107. Definitions, MCA  |  |
| MTS_0330-0220-0110-0080 | 200 | 13377 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0080/0330-0220-0110-0080.html |    33-22-1108. Preexisting condition -- definition, MCA  |  |
| MTS_0330-0220-0110-0090 | 200 | 10609 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0090/0330-0220-0110-0090.html |    33-22-1109. and 33-22-1110 reserved, MCA  |  |
| MTS_0330-0220-0110-0110 | 200 | 14150 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0110/0330-0220-0110-0110.html |    33-22-1111. Outline of coverage, MCA  |  |
| MTS_0330-0220-0110-0120 | 200 | 11508 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0120/0330-0220-0110-0120.html |    33-22-1112. Required content for certificate, MCA  |  |
| MTS_0330-0220-0110-0130 | 200 | 14184 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0130/0330-0220-0110-0130.html |    33-22-1113. Disclosure and performance standards for long-term care insurance |  |
| MTS_0330-0220-0110-0140 | 200 | 12047 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0140/0330-0220-0110-0140.html |    33-22-1114. Prohibited practices and policy provisions, MCA  |  |
| MTS_0330-0220-0110-0150 | 200 | 12987 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0150/0330-0220-0110-0150.html |    33-22-1115. Prior hospitalization or institutionalization, MCA  |  |
| MTS_0330-0220-0110-0160 | 200 | 12165 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0160/0330-0220-0110-0160.html |    33-22-1116. Nonforfeiture benefits -- offer requirement, MCA  |  |
| MTS_0330-0220-0110-0170 | 200 | 11168 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0170/0330-0220-0110-0170.html |    33-22-1117. Appropriate sale criteria, MCA  |  |
| MTS_0330-0220-0110-0180 | 200 | 10548 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0180/0330-0220-0110-0180.html |    33-22-1118. reserved, MCA  |  |
| MTS_0330-0220-0110-0190 | 200 | 12929 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0190/0330-0220-0110-0190.html |    33-22-1119. Right to return policy -- free look -- refunds upon denial of app |  |
| MTS_0330-0220-0110-0200 | 200 | 11427 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0200/0330-0220-0110-0200.html |    33-22-1120. Extraterritorial jurisdiction, MCA  |  |
| MTS_0330-0220-0110-0210 | 200 | 13321 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0210/0330-0220-0110-0210.html |    33-22-1121. Rules, MCA  |  |
| MTS_0330-0220-0110-0220 | 200 | 11184 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0220/0330-0220-0110-0220.html |    33-22-1122. Policy waiting periods not cumulative, MCA  |  |
| MTS_0330-0220-0110-0230 | 200 | 14346 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0230/0330-0220-0110-0230.html |    33-22-1123. Delivery of policy -- policy summary -- monthly reports, MCA  |  |
| MTS_0330-0220-0110-0240 | 200 | 11328 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0240/0330-0220-0110-0240.html |    33-22-1124. Denial of claims, MCA  |  |
| MTS_0330-0220-0110-0250 | 200 | 13333 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0250/0330-0220-0110-0250.html |    33-22-1125. Benefit triggers, MCA  |  |
| MTS_0330-0220-0110-0260 | 200 | 15676 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0260/0330-0220-0110-0260.html |    33-22-1126. Additional standards for qualified long-term care contracts -- de |  |
| MTS_0330-0220-0110-0270 | 200 | 13145 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0270/0330-0220-0110-0270.html |    33-22-1127. Incontestability period, MCA  |  |
| MTS_0330-0220-0110-0280 | 200 | 15019 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0280/0330-0220-0110-0280.html |    33-22-1128. Insurance producer training requirements, MCA  |  |
| MTS_0330-0220-0110-0290 | 200 | 10939 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0110/section_0290/0330-0220-0110-0290.html |    33-22-1129. Penalties, MCA  |  |
| MTS_0330-0220-0120-0010 | 200 | 10617 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0120/section_0010/0330-0220-0120-0010.html |    33-22-1201. Repealed, MCA  |  |
| MTS_0330-0220-0120-0020 | 200 | 10886 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0120/section_0020/0330-0220-0120-0020.html |    33-22-1202. Repealed, MCA  |  |
| MTS_0330-0220-0120-0030 | 200 | 10822 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0120/section_0030/0330-0220-0120-0030.html |    33-22-1203. Repealed, MCA  |  |
| MTS_0330-0220-0120-0040 | 200 | 10822 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0120/section_0040/0330-0220-0120-0040.html |    33-22-1204. Repealed, MCA  |  |
| MTS_0330-0220-0120-0050 | 200 | 10620 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0120/section_0050/0330-0220-0120-0050.html |    33-22-1205. Repealed, MCA  |  |
| MTS_0330-0220-0130-0010 | 200 | 10893 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0010/0330-0220-0130-0010.html |    33-22-1301. Short title -- purpose, MCA  |  |
| MTS_0330-0220-0130-0020 | 200 | 12730 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0020/0330-0220-0130-0020.html |    33-22-1302. Reinsurance association -- mandatory membership -- exceptions, MC |  |
| MTS_0330-0220-0130-0030 | 200 | 15012 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0030/0330-0220-0130-0030.html |    33-22-1303. Definitions, MCA  |  |
| MTS_0330-0220-0130-0040 | 200 | 10617 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0040/0330-0220-0130-0040.html |    33-22-1304. and 33-22-1305 reserved, MCA  |  |
| MTS_0330-0220-0130-0060 | 200 | 12215 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0060/0330-0220-0130-0060.html |    33-22-1306. Association board of directors, MCA  |  |
| MTS_0330-0220-0130-0070 | 200 | 12468 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0070/0330-0220-0130-0070.html |    33-22-1307. Duties of commissioner -- rulemaking, MCA  |  |
| MTS_0330-0220-0130-0080 | 200 | 13931 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0080/0330-0220-0130-0080.html |    33-22-1308. Board duties -- powers, MCA  |  |
| MTS_0330-0220-0130-0090 | 200 | 11852 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0090/0330-0220-0130-0090.html |    33-22-1309. Association administrator, MCA  |  |
| MTS_0330-0220-0130-0100 | 200 | 10651 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0100/0330-0220-0130-0100.html |    33-22-1310. through 33-22-1312 reserved, MCA  |  |
| MTS_0330-0220-0130-0130 | 200 | 13814 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0130/0330-0220-0130-0130.html |    33-22-1313. Association member assessments, MCA  |  |
| MTS_0330-0220-0130-0140 | 200 | 12277 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0140/0330-0220-0130-0140.html |    33-22-1314. Payment parameters, MCA  |  |
| MTS_0330-0220-0130-0150 | 200 | 12069 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0150/0330-0220-0130-0150.html |    33-22-1315. Calculation of reinsurance payments, MCA  |  |
| MTS_0330-0220-0130-0160 | 200 | 13178 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0160/0330-0220-0130-0160.html |    33-22-1316. Administration of reinsurance payments, MCA  |  |
| MTS_0330-0220-0130-0170 | 200 | 12834 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0170/0330-0220-0130-0170.html |    33-22-1317. Eligible health insurer requests for reinsurance payments, MCA  |  |
| MTS_0330-0220-0130-0180 | 200 | 10665 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0180/0330-0220-0130-0180.html |    33-22-1318. and 33-22-1319 reserved, MCA  |  |
| MTS_0330-0220-0130-0200 | 200 | 11038 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0200/0330-0220-0130-0200.html |    33-22-1320. Liability of association members, MCA  |  |
| MTS_0330-0220-0130-0210 | 200 | 15545 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0210/0330-0220-0130-0210.html |    33-22-1321. State and federal special revenue accounts -- reinsurance program |  |
| MTS_0330-0220-0130-0220 | 200 | 10994 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0130/section_0220/0330-0220-0130-0220.html |    33-22-1322. State innovation waiver, MCA  |  |
| MTS_0330-0220-0150-0010 | 200 | 10913 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0010/0330-0220-0150-0010.html |    33-22-1501. Repealed, MCA  |  |
| MTS_0330-0220-0150-0020 | 200 | 10992 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0020/0330-0220-0150-0020.html |    33-22-1502. Repealed, MCA  |  |
| MTS_0330-0220-0150-0030 | 200 | 10929 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0030/0330-0220-0150-0030.html |    33-22-1503. Repealed, MCA  |  |
| MTS_0330-0220-0150-0040 | 200 | 11054 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0040/0330-0220-0150-0040.html |    33-22-1504. Repealed, MCA  |  |
| MTS_0330-0220-0150-0050 | 200 | 10856 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0050/0330-0220-0150-0050.html |    33-22-1505. Repealed, MCA  |  |
| MTS_0330-0220-0150-0060 | 200 | 10663 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0060/0330-0220-0150-0060.html |    33-22-1506. through 33-22-1510 reserved, MCA  |  |
| MTS_0330-0220-0150-0110 | 200 | 10887 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0110/0330-0220-0150-0110.html |    33-22-1511. Repealed, MCA  |  |
| MTS_0330-0220-0150-0120 | 200 | 11025 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0120/0330-0220-0150-0120.html |    33-22-1512. Repealed, MCA  |  |
| MTS_0330-0220-0150-0130 | 200 | 11183 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0130/0330-0220-0150-0130.html |    33-22-1513. Repealed, MCA  |  |
| MTS_0330-0220-0150-0140 | 200 | 10964 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0140/0330-0220-0150-0140.html |    33-22-1514. Repealed, MCA  |  |
| MTS_0330-0220-0150-0150 | 200 | 10994 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0150/0330-0220-0150-0150.html |    33-22-1515. Repealed, MCA  |  |
| MTS_0330-0220-0150-0160 | 200 | 11027 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0160/0330-0220-0150-0160.html |    33-22-1516. Repealed, MCA  |  |
| MTS_0330-0220-0150-0170 | 200 | 10900 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0170/0330-0220-0150-0170.html |    33-22-1517. Repealed, MCA  |  |
| MTS_0330-0220-0150-0180 | 200 | 10851 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0180/0330-0220-0150-0180.html |    33-22-1518. Repealed, MCA  |  |
| MTS_0330-0220-0150-0190 | 200 | 10643 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0190/0330-0220-0150-0190.html |    33-22-1519. and 33-22-1520 reserved, MCA  |  |
| MTS_0330-0220-0150-0210 | 200 | 11040 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0210/0330-0220-0150-0210.html |    33-22-1521. Repealed, MCA  |  |
| MTS_0330-0220-0150-0220 | 200 | 10837 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0220/0330-0220-0150-0220.html |    33-22-1522. Repealed, MCA  |  |
| MTS_0330-0220-0150-0230 | 200 | 10837 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0230/0330-0220-0150-0230.html |    33-22-1523. Repealed, MCA  |  |
| MTS_0330-0220-0150-0240 | 200 | 10665 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0150/section_0240/0330-0220-0150-0240.html |    33-22-1524. Repealed, MCA  |  |
| MTS_0330-0220-0160-0010 | 200 | 11085 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0160/section_0010/0330-0220-0160-0010.html |    33-22-1601. Subrogation rights, MCA  |  |
| MTS_0330-0220-0160-0020 | 200 | 11805 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0160/section_0020/0330-0220-0160-0020.html |    33-22-1602. Notice -- shared costs of third-party action -- limitation, MCA  |  |
| MTS_0330-0220-0170-0010 | 200 | 10576 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0170/section_0010/0330-0220-0170-0010.html |    33-22-1701. Short title, MCA  |  |
| MTS_0330-0220-0170-0020 | 200 | 11346 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0170/section_0020/0330-0220-0170-0020.html |    33-22-1702. Purpose, MCA  |  |
| MTS_0330-0220-0170-0030 | 200 | 14533 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0170/section_0030/0330-0220-0170-0030.html |    33-22-1703. Definitions, MCA  |  |
| MTS_0330-0220-0170-0040 | 200 | 13782 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0170/section_0040/0330-0220-0170-0040.html |    33-22-1704. Preferred provider agreements authorized, MCA  |  |
| MTS_0330-0220-0170-0050 | 200 | 12077 | https://leg.mt.gov/bills/mca/title_0330/chapter_0220/part_0170/section_0050/0330-0220-0170-0050.html |    33-22-1705. Incentives in health benefit plans, MCA  |  |
