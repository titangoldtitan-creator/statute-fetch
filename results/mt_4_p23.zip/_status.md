| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0190-0010-0080-0130 | 200 | 10510 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0130/0190-0010-0080-0130.html |    19-1-813. Collection of contributions, MCA  |  |
| MTS_0190-0010-0080-0140 | 200 | 10226 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0140/0190-0010-0080-0140.html |    19-1-814. Repealed, MCA  |  |
| MTS_0190-0010-0080-0150 | 200 | 11048 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0150/0190-0010-0080-0150.html |    19-1-815. Merger of reporting entities, MCA  |  |
| MTS_0190-0010-0080-0160 | 200 | 9962 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0160/0190-0010-0080-0160.html |    19-1-816. through 19-1-820 reserved, MCA  |  |
| MTS_0190-0010-0080-0210 | 200 | 10726 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0210/0190-0010-0080-0210.html |    19-1-821. Retirement system to be considered separate for each institution, M |  |
| MTS_0190-0010-0080-0220 | 200 | 10631 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0220/0190-0010-0080-0220.html |    19-1-822. Referendum -- institution of higher education, MCA  |  |
| MTS_0190-0010-0080-0230 | 200 | 10685 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0230/0190-0010-0080-0230.html |    19-1-823. Certification by governor, MCA  |  |
| MTS_0190-0010-0080-0240 | 200 | 10637 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0240/0190-0010-0080-0240.html |    19-1-824. Federal-state agreement, MCA  |  |
| MTS_0190-0010-0080-0250 | 200 | 10496 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0250/0190-0010-0080-0250.html |    19-1-825. Collection of contributions, MCA  |  |
| MTS_0190-0010-0080-0260 | 200 | 10177 | https://leg.mt.gov/bills/mca/title_0190/chapter_0010/part_0080/section_0260/0190-0010-0080-0260.html |    19-1-826. Changes in federal law, MCA  |  |
| MTS_0190-0020-0010-0010 | 200 | 9784 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0010/section_0010/0190-0020-0010-0010.html |    19-2-101. Renumbered 19-50-101, MCA  |  |
| MTS_0190-0020-0010-0020 | 200 | 9999 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0010/section_0020/0190-0020-0010-0020.html |    19-2-102. Renumbered 19-50-102, MCA  |  |
| MTS_0190-0020-0010-0030 | 200 | 9787 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0010/section_0030/0190-0020-0010-0030.html |    19-2-103. Renumbered 19-50-103, MCA  |  |
| MTS_0190-0020-0020-0010 | 200 | 9811 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0020/section_0010/0190-0020-0020-0010.html |    19-2-201. Renumbered 19-50-201, MCA  |  |
| MTS_0190-0020-0020-0020 | 200 | 10026 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0020/section_0020/0190-0020-0020-0020.html |    19-2-202. Renumbered 19-50-202, MCA  |  |
| MTS_0190-0020-0020-0030 | 200 | 10026 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0020/section_0030/0190-0020-0020-0030.html |    19-2-203. Renumbered 19-50-203, MCA  |  |
| MTS_0190-0020-0020-0040 | 200 | 10014 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0020/section_0040/0190-0020-0020-0040.html |    19-2-204. Renumbered 19-50-204, MCA  |  |
| MTS_0190-0020-0020-0050 | 200 | 10266 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0020/section_0050/0190-0020-0020-0050.html |    19-2-205. Repealed, MCA  |  |
| MTS_0190-0020-0020-0060 | 200 | 9802 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0020/section_0060/0190-0020-0020-0060.html |    19-2-206. Renumbered 19-50-206, MCA  |  |
| MTS_0190-0020-0030-0010 | 200 | 9931 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0030/section_0010/0190-0020-0030-0010.html |    19-2-301. Short title, MCA  |  |
| MTS_0190-0020-0030-0020 | 200 | 10317 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0030/section_0020/0190-0020-0030-0020.html |    19-2-302. Applicability, MCA  |  |
| MTS_0190-0020-0030-0030 | 200 | 35912 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0030/section_0030/0190-0020-0030-0030.html |    19-2-303. Definitions, MCA  |  |
| MTS_0190-0020-0040-0010 | 200 | 11543 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0040/section_0010/0190-0020-0040-0010.html |    19-2-401. Location of board -- jurisdiction and venue for judicial review --  |  |
| MTS_0190-0020-0040-0020 | 200 | 10708 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0040/section_0020/0190-0020-0040-0020.html |    19-2-402. Compensation of board members, MCA  |  |
| MTS_0190-0020-0040-0030 | 200 | 16592 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0040/section_0030/0190-0020-0040-0030.html |    19-2-403. Powers and duties of board, MCA  |  |
| MTS_0190-0020-0040-0040 | 200 | 10664 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0040/section_0040/0190-0020-0040-0040.html |    19-2-404. Appointment and compensation of administrative staff, MCA  |  |
| MTS_0190-0020-0040-0050 | 200 | 13530 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0040/section_0050/0190-0020-0040-0050.html |    19-2-405. Employment of actuary -- annual investigation and valuation, MCA  |  |
| MTS_0190-0020-0040-0060 | 200 | 13498 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0040/section_0060/0190-0020-0040-0060.html |    19-2-406. Disability retirement -- application -- determination -- benefit co |  |
| MTS_0190-0020-0040-0070 | 200 | 12010 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0040/section_0070/0190-0020-0040-0070.html |    19-2-407. Reports, MCA  |  |
| MTS_0190-0020-0040-0080 | 200 | 13564 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0040/section_0080/0190-0020-0040-0080.html |    19-2-408. Administrative expenses, MCA  |  |
| MTS_0190-0020-0040-0090 | 200 | 11222 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0040/section_0090/0190-0020-0040-0090.html |    19-2-409. Plans to be funded on actuarially sound basis -- definition, MCA  |  |
| MTS_0190-0020-0040-0100 | 200 | 10471 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0040/section_0100/0190-0020-0040-0100.html |    19-2-410. Presentation to board of investments, MCA  |  |
| MTS_0190-0020-0050-0010 | 200 | 10346 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0050/section_0010/0190-0020-0050-0010.html |    19-2-501. Pension trust funds established, MCA  |  |
| MTS_0190-0020-0050-0020 | 200 | 11051 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0050/section_0020/0190-0020-0050-0020.html |    19-2-502. Payments from pension trust funds, MCA  |  |
| MTS_0190-0020-0050-0030 | 200 | 11495 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0050/section_0030/0190-0020-0050-0030.html |    19-2-503. Management of pension trust funds, MCA  |  |
| MTS_0190-0020-0050-0040 | 200 | 14411 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0050/section_0040/0190-0020-0050-0040.html |    19-2-504. Investment of pension trust funds, MCA  |  |
| MTS_0190-0020-0050-0050 | 200 | 13282 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0050/section_0050/0190-0020-0050-0050.html |    19-2-505. Restrictions on use of funds, MCA  |  |
| MTS_0190-0020-0050-0060 | 200 | 13780 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0050/section_0060/0190-0020-0050-0060.html |    19-2-506. Payment of contributions by employers -- accompanying reports -- pe |  |
| MTS_0190-0020-0050-0070 | 200 | 10855 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0050/section_0070/0190-0020-0050-0070.html |    19-2-507. Transfer between funds, MCA  |  |
| MTS_0190-0020-0050-0080 | 200 | 10048 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0050/section_0080/0190-0020-0050-0080.html |    19-2-508. through 19-2-510 reserved, MCA  |  |
| MTS_0190-0020-0050-0110 | 200 | 11692 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0050/section_0110/0190-0020-0050-0110.html |    19-2-511. Limitation of liability, MCA  |  |
| MTS_0190-0020-0060-0010 | 200 | 10493 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0060/section_0010/0190-0020-0060-0010.html |    19-2-601. Termination of membership, MCA  |  |
| MTS_0190-0020-0060-0020 | 200 | 13139 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0060/section_0020/0190-0020-0060-0020.html |    19-2-602. Refund of member's contributions on termination of service, MCA  |  |
| MTS_0190-0020-0060-0030 | 200 | 11251 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0060/section_0030/0190-0020-0060-0030.html |    19-2-603. Reinstatement after withdrawal of contributions, MCA  |  |
| MTS_0190-0020-0070-0010 | 200 | 10878 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0010/0190-0020-0070-0010.html |    19-2-701. Service credit, MCA  |  |
| MTS_0190-0020-0070-0020 | 200 | 10891 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0020/0190-0020-0070-0020.html |    19-2-702. Membership service, MCA  |  |
| MTS_0190-0020-0070-0030 | 200 | 11076 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0030/0190-0020-0070-0030.html |    19-2-703. No duplication of benefits for same service, MCA  |  |
| MTS_0190-0020-0070-0040 | 200 | 17380 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0040/0190-0020-0070-0040.html |    19-2-704. Purchasing service credits allowed -- payroll deduction, MCA  |  |
| MTS_0190-0020-0070-0050 | 200 | 10568 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0050/0190-0020-0070-0050.html |    19-2-705. Repealed, MCA  |  |
| MTS_0190-0020-0070-0060 | 200 | 15635 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0060/0190-0020-0070-0060.html |    19-2-706. Additional service credit for active member involuntarily terminate |  |
| MTS_0190-0020-0070-0070 | 200 | 10840 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0070/0190-0020-0070-0070.html |    19-2-707. Qualified military service, MCA  |  |
| MTS_0190-0020-0070-0080 | 200 | 11426 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0080/0190-0020-0070-0080.html |    19-2-708. Rollover of contributions, MCA  |  |
| MTS_0190-0020-0070-0090 | 200 | 11623 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0090/0190-0020-0070-0090.html |    19-2-709. Transfer of service and contributions from other Montana public emp |  |
| MTS_0190-0020-0070-0100 | 200 | 10711 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0100/0190-0020-0070-0100.html |    19-2-710. Nonapplication of part to defined contribution plan, MCA  |  |
| MTS_0190-0020-0070-0110 | 200 | 10073 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0110/0190-0020-0070-0110.html |    19-2-711. through 19-2-714 reserved, MCA  |  |
| MTS_0190-0020-0070-0150 | 200 | 13871 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0150/0190-0020-0070-0150.html |    19-2-715. Purchase of Montana public service, MCA  |  |
| MTS_0190-0020-0070-0160 | 200 | 10820 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0070/section_0160/0190-0020-0070-0160.html |    19-2-716. Compromise or settlement of claims by public employees regarding re |  |
| MTS_0190-0020-0080-0010 | 200 | 13609 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0080/section_0010/0190-0020-0080-0010.html |    19-2-801. Designation of beneficiary, MCA  |  |
| MTS_0190-0020-0080-0020 | 200 | 13171 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0080/section_0020/0190-0020-0080-0020.html |    19-2-802. Effect of no designation of beneficiary or no surviving statutory o |  |
| MTS_0190-0020-0080-0030 | 200 | 11964 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0080/section_0030/0190-0020-0080-0030.html |    19-2-803. Payment to custodian of minor beneficiary, MCA  |  |
| MTS_0190-0020-0080-0040 | 200 | 10641 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0080/section_0040/0190-0020-0080-0040.html |    19-2-804. Limitations on payment of benefits to person causing member's death |  |
| MTS_0190-0020-0090-0010 | 200 | 10661 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0090/section_0010/0190-0020-0090-0010.html |    19-2-901. Estimate of benefit when information incomplete, MCA  |  |
| MTS_0190-0020-0090-0020 | 200 | 11954 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0090/section_0020/0190-0020-0090-0020.html |    19-2-902. Payment of benefits, MCA  |  |
| MTS_0190-0020-0090-0030 | 200 | 16066 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0090/section_0030/0190-0020-0090-0030.html |    19-2-903. Correction of errors and suspension of payments, MCA  |  |
| MTS_0190-0020-0090-0040 | 200 | 11759 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0090/section_0040/0190-0020-0090-0040.html |    19-2-904. Withholding of group insurance premium from retirement benefit, MCA |  |
| MTS_0190-0020-0090-0050 | 200 | 10700 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0090/section_0050/0190-0020-0090-0050.html |    19-2-905. Payments under workers' compensation, MCA  |  |
| MTS_0190-0020-0090-0060 | 200 | 10998 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0090/section_0060/0190-0020-0090-0060.html |    19-2-906. Limitations on disability or survivorship benefits, MCA  |  |
| MTS_0190-0020-0090-0070 | 200 | 17824 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0090/section_0070/0190-0020-0090-0070.html |    19-2-907. Alternate payees -- family law orders -- rulemaking, MCA  |  |
| MTS_0190-0020-0090-0080 | 200 | 15933 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0090/section_0080/0190-0020-0090-0080.html |    19-2-908. Time of commencement of benefit -- rulemaking, MCA  |  |
| MTS_0190-0020-0090-0090 | 200 | 15895 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0090/section_0090/0190-0020-0090-0090.html |    19-2-909. Execution or withholding for support obligation -- rulemaking, MCA  |  |
| MTS_0190-0020-0100-0010 | 200 | 31064 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0010/0190-0020-0100-0010.html |    19-2-1001. Maximum contribution and benefit limitations, MCA  |  |
| MTS_0190-0020-0100-0020 | 200 | 11523 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0020/0190-0020-0100-0020.html |    19-2-1002. Termination of plan, MCA  |  |
| MTS_0190-0020-0100-0030 | 200 | 11155 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0030/0190-0020-0100-0030.html |    19-2-1003. Transfer of dormant, nonvested member-accumulated contributions, M |  |
| MTS_0190-0020-0100-0040 | 200 | 13156 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0040/0190-0020-0100-0040.html |    19-2-1004. Exemption from taxes and legal process, MCA  |  |
| MTS_0190-0020-0100-0050 | 200 | 12016 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0050/0190-0020-0100-0050.html |    19-2-1005. Compensation limit, MCA  |  |
| MTS_0190-0020-0100-0060 | 200 | 10654 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0060/0190-0020-0100-0060.html |    19-2-1006. Use of forfeitures, MCA  |  |
| MTS_0190-0020-0100-0070 | 200 | 12903 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0070/0190-0020-0100-0070.html |    19-2-1007. Required distributions, MCA  |  |
| MTS_0190-0020-0100-0080 | 200 | 10416 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0080/0190-0020-0100-0080.html |    19-2-1008. Budget Act superseded, MCA  |  |
| MTS_0190-0020-0100-0090 | 200 | 10675 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0090/0190-0020-0100-0090.html |    19-2-1009. Penalty for fraud, MCA  |  |
| MTS_0190-0020-0100-0100 | 200 | 11763 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0100/0190-0020-0100-0100.html |    19-2-1010. Retaining qualified plan status -- content of plan document -- boa |  |
| MTS_0190-0020-0100-0110 | 200 | 13233 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0110/0190-0020-0100-0110.html |    19-2-1011. Limitations on eligible rollover distributions, MCA  |  |
| MTS_0190-0020-0100-0120 | 200 | 9917 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0120/0190-0020-0100-0120.html |    19-2-1012. reserved, MCA  |  |
| MTS_0190-0020-0100-0130 | 200 | 10765 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0130/0190-0020-0100-0130.html |    19-2-1013. Compliance with federal restrictions on interest rate crediting, M |  |
| MTS_0190-0020-0100-0140 | 200 | 11566 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0140/0190-0020-0100-0140.html |    19-2-1014. Compliance with federal laws regarding service in uniformed servic |  |
| MTS_0190-0020-0100-0150 | 200 | 10319 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0100/section_0150/0190-0020-0100-0150.html |    19-2-1015. Probate and nonprobate transfer statutes superseded, MCA  |  |
| MTS_0190-0020-0110-0010 | 200 | 10090 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0110/section_0010/0190-0020-0110-0010.html |    19-2-1101. Repealed, MCA  |  |
| MTS_0190-0020-0110-0020 | 200 | 10037 | https://leg.mt.gov/bills/mca/title_0190/chapter_0020/part_0110/section_0020/0190-0020-0110-0020.html |    19-2-1102. Repealed, MCA  |  |
| MTS_0190-0030-0010-0010 | 200 | 9931 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0010/0190-0030-0010-0010.html |    19-3-101. Short title, MCA  |  |
| MTS_0190-0030-0010-0020 | 200 | 10177 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0020/0190-0030-0010-0020.html |    19-3-102. Repealed, MCA  |  |
| MTS_0190-0030-0010-0030 | 200 | 10924 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0030/0190-0030-0010-0030.html |    19-3-103. Retirement system created -- system to consist of two plans, MCA  |  |
| MTS_0190-0030-0010-0040 | 200 | 9973 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0040/0190-0030-0010-0040.html |    19-3-104. Renumbered 19-2-303, MCA  |  |
| MTS_0190-0030-0010-0050 | 200 | 9938 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0050/0190-0030-0010-0050.html |    19-3-105. Renumbered 19-2-1004, MCA  |  |
| MTS_0190-0030-0010-0060 | 200 | 9939 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0060/0190-0030-0010-0060.html |    19-3-106. Renumbered 19-2-1008, MCA  |  |
| MTS_0190-0030-0010-0070 | 200 | 9930 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0070/0190-0030-0010-0070.html |    19-3-107. Renumbered 19-2-1001, MCA  |  |
| MTS_0190-0030-0010-0080 | 200 | 16155 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0080/0190-0030-0010-0080.html |    19-3-108. Definitions, MCA  |  |
| MTS_0190-0030-0010-0090 | 200 | 10482 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0090/0190-0030-0010-0090.html |    19-3-109. Public employees' retirement system benefit policy statement, MCA  |  |
| MTS_0190-0030-0010-0100 | 200 | 9918 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0100/0190-0030-0010-0100.html |    19-3-110. reserved, MCA  |  |
| MTS_0190-0030-0010-0110 | 200 | 11137 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0110/0190-0030-0010-0110.html |    19-3-111. Exemption for certain university temporary employees -- "temporary  |  |
| MTS_0190-0030-0010-0120 | 200 | 16432 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0120/0190-0030-0010-0120.html |    19-3-112. Education fund established -- allocation of employer contributions  |  |
| MTS_0190-0030-0010-0130 | 200 | 10012 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0130/0190-0030-0010-0130.html |    19-3-113. through 19-3-116 reserved, MCA  |  |
| MTS_0190-0030-0010-0170 | 200 | 10657 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0010/section_0170/0190-0030-0010-0170.html |    19-3-117. Board report required, MCA  |  |
| MTS_0190-0030-0020-0010 | 200 | 14761 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0020/section_0010/0190-0030-0020-0010.html |    19-3-201. Contracts with political subdivisions, MCA  |  |
| MTS_0190-0030-0020-0020 | 200 | 11064 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0020/section_0020/0190-0030-0020-0020.html |    19-3-202. Request by individual employee for employer to participate, MCA  |  |
| MTS_0190-0030-0020-0030 | 200 | 13029 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0020/section_0030/0190-0030-0020-0030.html |    19-3-203. Conversion of local or state retirement plan, MCA  |  |
| MTS_0190-0030-0020-0040 | 200 | 11228 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0020/section_0040/0190-0030-0020-0040.html |    19-3-204. Tax levy to meet employer's obligations, MCA  |  |
| MTS_0190-0030-0030-0010 | 200 | 9739 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0010/0190-0030-0030-0010.html |    19-3-301. Renumbered 19-2-401, MCA  |  |
| MTS_0190-0030-0030-0020 | 200 | 9942 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0020/0190-0030-0030-0020.html |    19-3-302. Renumbered 19-2-402, MCA  |  |
| MTS_0190-0030-0030-0030 | 200 | 10203 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0030/0190-0030-0030-0030.html |    19-3-303. Repealed, MCA  |  |
| MTS_0190-0030-0030-0040 | 200 | 9942 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0040/0190-0030-0030-0040.html |    19-3-304. Renumbered 19-2-403, MCA  |  |
| MTS_0190-0030-0030-0050 | 200 | 9953 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0050/0190-0030-0030-0050.html |    19-3-305. Renumbered 19-2-405, MCA  |  |
| MTS_0190-0030-0030-0060 | 200 | 9942 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0060/0190-0030-0030-0060.html |    19-3-306. Renumbered 19-2-407, MCA  |  |
| MTS_0190-0030-0030-0070 | 200 | 10189 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0070/0190-0030-0030-0070.html |    19-3-307. Repealed, MCA  |  |
| MTS_0190-0030-0030-0080 | 200 | 10136 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0080/0190-0030-0030-0080.html |    19-3-308. Terminated, MCA  |  |
| MTS_0190-0030-0030-0090 | 200 | 9956 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0090/0190-0030-0030-0090.html |    19-3-309. through 19-3-314 reserved, MCA  |  |
| MTS_0190-0030-0030-0150 | 200 | 13767 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0150/0190-0030-0030-0150.html |    19-3-315. Member's contribution to be deducted, MCA  |  |
| MTS_0190-0030-0030-0160 | 200 | 13608 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0160/0190-0030-0030-0160.html |    19-3-316. Employer contribution rates, MCA  |  |
| MTS_0190-0030-0030-0170 | 200 | 10843 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0170/0190-0030-0030-0170.html |    19-3-317. State employer to include costs in budget, MCA  |  |
| MTS_0190-0030-0030-0180 | 200 | 11018 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0180/0190-0030-0030-0180.html |    19-3-318. Credit of contributions made after member becomes inactive, MCA  |  |
| MTS_0190-0030-0030-0190 | 200 | 12025 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0190/0190-0030-0030-0190.html |    19-3-319. State contributions for local government and school district employ |  |
| MTS_0190-0030-0030-0200 | 200 | 11323 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0030/section_0200/0190-0030-0030-0200.html |    19-3-320. Supplemental state contribution -- appropriation, MCA  |  |
| MTS_0190-0030-0040-0010 | 200 | 13029 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0040/section_0010/0190-0030-0040-0010.html |    19-3-401. Membership -- inactive vested members -- inactive nonvested members |  |
| MTS_0190-0030-0040-0020 | 200 | 10787 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0040/section_0020/0190-0030-0040-0020.html |    19-3-402. Federally subsidized employees eligible, MCA  |  |
| MTS_0190-0030-0040-0030 | 200 | 15871 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0040/section_0030/0190-0030-0040-0030.html |    19-3-403. Exclusions from membership, MCA  |  |
| MTS_0190-0030-0040-0040 | 200 | 9995 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0040/section_0040/0190-0030-0040-0040.html |    19-3-404. Renumbered 19-3-1211, MCA  |  |
| MTS_0190-0030-0040-0050 | 200 | 9984 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0040/section_0050/0190-0030-0040-0050.html |    19-3-405. Renumbered 19-3-318, MCA  |  |
| MTS_0190-0030-0040-0060 | 200 | 9992 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0040/section_0060/0190-0030-0040-0060.html |    19-3-406. Renumbered 19-2-601, MCA  |  |
| MTS_0190-0030-0040-0070 | 200 | 9980 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0040/section_0070/0190-0030-0040-0070.html |    19-3-407. through 19-3-410 reserved, MCA  |  |
| MTS_0190-0030-0040-0110 | 200 | 11276 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0040/section_0110/0190-0030-0040-0110.html |    19-3-411. Eligible employees, MCA  |  |
| MTS_0190-0030-0040-0120 | 200 | 16003 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0040/section_0120/0190-0030-0040-0120.html |    19-3-412. Optional membership -- employees not in elected office, MCA  |  |
| MTS_0190-0030-0040-0130 | 200 | 13380 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0040/section_0130/0190-0030-0040-0130.html |    19-3-413. Optional membership -- elected officials, MCA  |  |
| MTS_0190-0030-0050-0010 | 200 | 10178 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0010/0190-0030-0050-0010.html |    19-3-501. Absence not included in service, MCA  |  |
| MTS_0190-0030-0050-0020 | 200 | 9953 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0020/0190-0030-0050-0020.html |    19-3-502. Renumbered 19-2-705, MCA  |  |
| MTS_0190-0030-0050-0030 | 200 | 12754 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0030/0190-0030-0050-0030.html |    19-3-503. Application to purchase military service, MCA  |  |
| MTS_0190-0030-0050-0040 | 200 | 13109 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0040/0190-0030-0050-0040.html |    19-3-504. Absence due to illness or injury, MCA  |  |
| MTS_0190-0030-0050-0050 | 200 | 12550 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0050/0190-0030-0050-0050.html |    19-3-505. Purchase of previous employment with employer, MCA  |  |
| MTS_0190-0030-0050-0060 | 200 | 10271 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0060/0190-0030-0050-0060.html |    19-3-506. Repealed, MCA  |  |
| MTS_0190-0030-0050-0070 | 200 | 10152 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0070/0190-0030-0050-0070.html |    19-3-507. Repealed, MCA  |  |
| MTS_0190-0030-0050-0080 | 200 | 9898 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0080/0190-0030-0050-0080.html |    19-3-508. Renumbered 19-2-703, MCA  |  |
| MTS_0190-0030-0050-0090 | 200 | 10370 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0090/0190-0030-0050-0090.html |    19-3-509. Repealed, MCA  |  |
| MTS_0190-0030-0050-0100 | 200 | 12023 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0100/0190-0030-0050-0100.html |    19-3-510. Employment in United States government, MCA  |  |
| MTS_0190-0030-0050-0110 | 200 | 16399 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0110/0190-0030-0050-0110.html |    19-3-511. Transfer and purchase of service credits and contributions from tea |  |
| MTS_0190-0030-0050-0120 | 200 | 12481 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0120/0190-0030-0050-0120.html |    19-3-512. Purchase of service credit from other public retirement systems, MC |  |
| MTS_0190-0030-0050-0130 | 200 | 11939 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0130/0190-0030-0050-0130.html |    19-3-513. Application to purchase additional service, MCA  |  |
| MTS_0190-0030-0050-0140 | 200 | 11454 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0140/0190-0030-0050-0140.html |    19-3-514. Service purchase limit -- exception, MCA  |  |
| MTS_0190-0030-0050-0150 | 200 | 11238 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0150/0190-0030-0050-0150.html |    19-3-515. Purchase of federal volunteer service, MCA  |  |
| MTS_0190-0030-0050-0160 | 200 | 9922 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0160/0190-0030-0050-0160.html |    19-3-516. through 19-3-519 reserved, MCA  |  |
| MTS_0190-0030-0050-0200 | 200 | 10283 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0200/0190-0030-0050-0200.html |    19-3-520. Repealed, MCA  |  |
| MTS_0190-0030-0050-0210 | 200 | 10436 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0210/0190-0030-0050-0210.html |    19-3-521. Service credit for legislative members, MCA  |  |
| MTS_0190-0030-0050-0220 | 200 | 10201 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0050/section_0220/0190-0030-0050-0220.html |    19-3-522. Nonapplication of part to defined contribution plan, MCA  |  |
| MTS_0190-0030-0060-0010 | 200 | 9763 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0060/section_0010/0190-0030-0060-0010.html |    19-3-601. Renumbered 19-2-503, MCA  |  |
| MTS_0190-0030-0060-0020 | 200 | 9977 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0060/section_0020/0190-0030-0060-0020.html |    19-3-602. Renumbered 19-2-504, MCA  |  |
| MTS_0190-0030-0060-0030 | 200 | 9978 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0060/section_0030/0190-0030-0060-0030.html |    19-3-603. Renumbered 19-2-505, MCA  |  |
| MTS_0190-0030-0060-0040 | 200 | 9982 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0060/section_0040/0190-0030-0060-0040.html |    19-3-604. Renumbered 19-2-1003, MCA  |  |
| MTS_0190-0030-0060-0050 | 200 | 9979 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0060/section_0050/0190-0030-0060-0050.html |    19-3-605. Renumbered 19-2-507, MCA  |  |
| MTS_0190-0030-0060-0060 | 200 | 9771 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0060/section_0060/0190-0030-0060-0060.html |    19-3-606. Renumbered 19-2-1002, MCA  |  |
| MTS_0190-0030-0070-0010 | 200 | 9766 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0070/section_0010/0190-0030-0070-0010.html |    19-3-701. Renumbered 19-3-315, MCA  |  |
| MTS_0190-0030-0070-0020 | 200 | 9983 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0070/section_0020/0190-0030-0070-0020.html |    19-3-702. Renumbered 19-2-704, MCA  |  |
| MTS_0190-0030-0070-0030 | 200 | 9983 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0070/section_0030/0190-0030-0070-0030.html |    19-3-703. Renumbered 19-2-602, MCA  |  |
| MTS_0190-0030-0070-0040 | 200 | 9772 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0070/section_0040/0190-0030-0070-0040.html |    19-3-704. Renumbered 19-2-603, MCA  |  |
| MTS_0190-0030-0080-0010 | 200 | 9805 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0080/section_0010/0190-0030-0080-0010.html |    19-3-801. Renumbered 19-3-316, MCA  |  |
| MTS_0190-0030-0080-0020 | 200 | 10022 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0080/section_0020/0190-0030-0080-0020.html |    19-3-802. Renumbered 19-2-506, MCA  |  |
| MTS_0190-0030-0080-0030 | 200 | 10008 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0080/section_0030/0190-0030-0080-0030.html |    19-3-803. Renumbered 19-3-317, MCA  |  |
| MTS_0190-0030-0080-0040 | 200 | 10298 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0080/section_0040/0190-0030-0080-0040.html |    19-3-804. Repealed, MCA  |  |
| MTS_0190-0030-0080-0050 | 200 | 9800 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0080/section_0050/0190-0030-0080-0050.html |    19-3-805. Renumbered 19-2-408, MCA  |  |
| MTS_0190-0030-0090-0010 | 200 | 12265 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0090/section_0010/0190-0030-0090-0010.html |    19-3-901. Eligibility for service retirement, MCA  |  |
| MTS_0190-0030-0090-0020 | 200 | 11027 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0090/section_0020/0190-0030-0090-0020.html |    19-3-902. Eligibility for early retirement, MCA  |  |
| MTS_0190-0030-0090-0030 | 200 | 10327 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0090/section_0030/0190-0030-0090-0030.html |    19-3-903. Repealed, MCA  |  |
| MTS_0190-0030-0090-0040 | 200 | 13219 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0090/section_0040/0190-0030-0090-0040.html |    19-3-904. Amount of service retirement benefit, MCA  |  |
| MTS_0190-0030-0090-0050 | 200 | 10543 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0090/section_0050/0190-0030-0090-0050.html |    19-3-905. Adjustment of benefit for certain members, MCA  |  |
| MTS_0190-0030-0090-0060 | 200 | 13487 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0090/section_0060/0190-0030-0090-0060.html |    19-3-906. Early retirement benefit, MCA  |  |
| MTS_0190-0030-0090-0070 | 200 | 9995 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0090/section_0070/0190-0030-0090-0070.html |    19-3-907. Renumbered 19-3-520, MCA  |  |
| MTS_0190-0030-0090-0080 | 200 | 14948 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0090/section_0080/0190-0030-0090-0080.html |    19-3-908. Retirement incentive program -- window of eligibility, MCA  |  |
| MTS_0190-0030-0090-0090 | 200 | 10255 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0090/section_0090/0190-0030-0090-0090.html |    19-3-909. Nonapplication of part to defined contribution plan, MCA  |  |
| MTS_0190-0030-0100-0010 | 200 | 10061 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0100/section_0010/0190-0030-0100-0010.html |    19-3-1001. Repealed, MCA  |  |
| MTS_0190-0030-0100-0020 | 200 | 13746 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0100/section_0020/0190-0030-0100-0020.html |    19-3-1002. Eligibility for disability retirement, MCA  |  |
| MTS_0190-0030-0100-0030 | 200 | 10265 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0100/section_0030/0190-0030-0100-0030.html |    19-3-1003. Repealed, MCA  |  |
| MTS_0190-0030-0100-0040 | 200 | 10236 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0100/section_0040/0190-0030-0100-0040.html |    19-3-1004. Repealed, MCA  |  |
| MTS_0190-0030-0100-0050 | 200 | 10302 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0100/section_0050/0190-0030-0100-0050.html |    19-3-1005. Repealed, MCA  |  |
| MTS_0190-0030-0100-0060 | 200 | 10234 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0100/section_0060/0190-0030-0100-0060.html |    19-3-1006. Repealed, MCA  |  |
| MTS_0190-0030-0100-0070 | 200 | 10918 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0100/section_0070/0190-0030-0100-0070.html |    19-3-1007. Benefit for duty-related disability, MCA  |  |
| MTS_0190-0030-0100-0080 | 200 | 14659 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0100/section_0080/0190-0030-0100-0080.html |    19-3-1008. Benefit for disability, MCA  |  |
| MTS_0190-0030-0100-0090 | 200 | 10037 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0100/section_0090/0190-0030-0100-0090.html |    19-3-1009. through 19-3-1014 reserved, MCA  |  |
| MTS_0190-0030-0100-0150 | 200 | 14687 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0100/section_0150/0190-0030-0100-0150.html |    19-3-1015. Medical examination of disability retiree -- cancellation and rein |  |
| MTS_0190-0030-0100-0160 | 200 | 10295 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0100/section_0160/0190-0030-0100-0160.html |    19-3-1016. Nonapplication of part to defined contribution plan, MCA  |  |
| MTS_0190-0030-0110-0010 | 200 | 9769 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0010/0190-0030-0110-0010.html |    19-3-1101. Renumbered 19-3-1501, MCA  |  |
| MTS_0190-0030-0110-0020 | 200 | 10003 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0020/0190-0030-0110-0020.html |    19-3-1102. Renumbered 19-3-1015, MCA  |  |
| MTS_0190-0030-0110-0030 | 200 | 12050 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0030/0190-0030-0110-0030.html |    19-3-1103. Disability benefit reduced by earnings, MCA  |  |
| MTS_0190-0030-0110-0040 | 200 | 10778 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0040/0190-0030-0110-0040.html |    19-3-1104. Cancellation of disability retirement benefit upon reemployment, M |  |
| MTS_0190-0030-0110-0050 | 200 | 15847 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0050/0190-0030-0110-0050.html |    19-3-1105. Refunds and benefits for reemployed retired members, MCA  |  |
| MTS_0190-0030-0110-0060 | 200 | 16846 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0060/0190-0030-0110-0060.html |    19-3-1106. Limited reemployment -- reduction of service retirement benefit up |  |
| MTS_0190-0030-0110-0070 | 200 | 10268 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0070/0190-0030-0110-0070.html |    19-3-1107. Repealed, MCA  |  |
| MTS_0190-0030-0110-0080 | 200 | 10151 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0080/0190-0030-0110-0080.html |    19-3-1108. Repealed, MCA  |  |
| MTS_0190-0030-0110-0090 | 200 | 9973 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0090/0190-0030-0110-0090.html |    19-3-1109. Renumbered 19-3-1601, MCA  |  |
| MTS_0190-0030-0110-0100 | 200 | 9985 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0100/0190-0030-0110-0100.html |    19-3-1110. Renumbered 19-3-1602, MCA  |  |
| MTS_0190-0030-0110-0110 | 200 | 10016 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0110/0190-0030-0110-0110.html |    19-3-1111. Renumbered 19-3-1603, MCA  |  |
| MTS_0190-0030-0110-0120 | 200 | 10490 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0120/0190-0030-0110-0120.html |    19-3-1112. Nonapplication of part to defined contribution plan, MCA  |  |
| MTS_0190-0030-0110-0130 | 200 | 11360 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0110/section_0130/0190-0030-0110-0130.html |    19-3-1113. Contributions required for retirees who return to work, MCA  |  |
| MTS_0190-0030-0120-0010 | 200 | 10965 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0120/section_0010/0190-0030-0120-0010.html |    19-3-1201. Eligibility for death payments, MCA  |  |
| MTS_0190-0030-0120-0020 | 200 | 11698 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0120/section_0020/0190-0030-0120-0020.html |    19-3-1202. Amount of death payment, MCA  |  |
| MTS_0190-0030-0120-0030 | 200 | 10872 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0120/section_0030/0190-0030-0120-0030.html |    19-3-1203. Election of optional death annuity, MCA  |  |
| MTS_0190-0030-0120-0040 | 200 | 12598 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0120/section_0040/0190-0030-0120-0040.html |    19-3-1204. Survivorship benefit elected by beneficiary, MCA  |  |
| MTS_0190-0030-0120-0050 | 200 | 12788 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0120/section_0050/0190-0030-0120-0050.html |    19-3-1205. Amount of survivorship benefit, MCA  |  |
| MTS_0190-0030-0120-0060 | 200 | 10061 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0120/section_0060/0190-0030-0120-0060.html |    19-3-1206. through 19-3-1209 reserved, MCA  |  |
| MTS_0190-0030-0120-0100 | 200 | 12187 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0120/section_0100/0190-0030-0120-0100.html |    19-3-1210. Death payments to designated beneficiaries of retired members, MCA |  |
| MTS_0190-0030-0120-0110 | 200 | 11104 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0120/section_0110/0190-0030-0120-0110.html |    19-3-1211. Refund when former member dies after transferring to another syste |  |
| MTS_0190-0030-0120-0120 | 200 | 10317 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0120/section_0120/0190-0030-0120-0120.html |    19-3-1212. Nonapplication of part to defined contribution plan, MCA  |  |
| MTS_0190-0030-0130-0010 | 200 | 9790 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0130/section_0010/0190-0030-0130-0010.html |    19-3-1301. Renumbered 19-2-801, MCA  |  |
| MTS_0190-0030-0130-0020 | 200 | 9994 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0130/section_0020/0190-0030-0130-0020.html |    19-3-1302. Renumbered 19-2-802, MCA  |  |
| MTS_0190-0030-0130-0030 | 200 | 10221 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0130/section_0030/0190-0030-0130-0030.html |    19-3-1303. Repealed, MCA  |  |
| MTS_0190-0030-0130-0040 | 200 | 9994 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0130/section_0040/0190-0030-0130-0040.html |    19-3-1304. Renumbered 19-2-803, MCA  |  |
| MTS_0190-0030-0130-0050 | 200 | 9793 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0130/section_0050/0190-0030-0130-0050.html |    19-3-1305. Renumbered 19-2-804, MCA  |  |
| MTS_0190-0030-0140-0010 | 200 | 9808 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0140/section_0010/0190-0030-0140-0010.html |    19-3-1401. Renumbered 19-2-901, MCA  |  |
| MTS_0190-0030-0140-0020 | 200 | 10023 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0140/section_0020/0190-0030-0140-0020.html |    19-3-1402. Renumbered 19-2-902, MCA  |  |
| MTS_0190-0030-0140-0030 | 200 | 10023 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0140/section_0030/0190-0030-0140-0030.html |    19-3-1403. Renumbered 19-2-903, MCA  |  |
| MTS_0190-0030-0140-0040 | 200 | 9811 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0140/section_0040/0190-0030-0140-0040.html |    19-3-1404. Renumbered 19-2-904, MCA  |  |
| MTS_0190-0030-0150-0010 | 200 | 18176 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0150/section_0010/0190-0030-0150-0010.html |    19-3-1501. Optional forms of benefits -- designation of contingent annuitant, |  |
| MTS_0190-0030-0150-0020 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0150/section_0020/0190-0030-0150-0020.html |    19-3-1502. Nonapplication of part to defined contribution plan, MCA  |  |
| MTS_0190-0030-0160-0010 | 200 | 10139 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0160/section_0010/0190-0030-0160-0010.html |    19-3-1601. Repealed, MCA  |  |
| MTS_0190-0030-0160-0020 | 200 | 10343 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0160/section_0020/0190-0030-0160-0020.html |    19-3-1602. Repealed, MCA  |  |
| MTS_0190-0030-0160-0030 | 200 | 10343 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0160/section_0030/0190-0030-0160-0030.html |    19-3-1603. Repealed, MCA  |  |
| MTS_0190-0030-0160-0040 | 200 | 10209 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0160/section_0040/0190-0030-0160-0040.html |    19-3-1604. Repealed, MCA  |  |
| MTS_0190-0030-0160-0050 | 200 | 14408 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0160/section_0050/0190-0030-0160-0050.html |    19-3-1605. Guaranteed annual benefit adjustment, MCA  |  |
| MTS_0190-0030-0160-0060 | 200 | 10250 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0160/section_0060/0190-0030-0160-0060.html |    19-3-1606. Repealed, MCA  |  |
| MTS_0190-0030-0160-0070 | 200 | 10257 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0160/section_0070/0190-0030-0160-0070.html |    19-3-1607. Nonapplication of part to defined contribution plan, MCA  |  |
| MTS_0190-0030-0210-0010 | 200 | 10621 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0010/0190-0030-0210-0010.html |    19-3-2101. Definitions, MCA  |  |
| MTS_0190-0030-0210-0020 | 200 | 11646 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0020/0190-0030-0210-0020.html |    19-3-2102. Defined contribution plan established -- assets to be held in trus |  |
| MTS_0190-0030-0210-0030 | 200 | 11688 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0030/0190-0030-0210-0030.html |    19-3-2103. Legislative intent, MCA  |  |
| MTS_0190-0030-0210-0040 | 200 | 10884 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0040/0190-0030-0210-0040.html |    19-3-2104. Board powers and duties -- rulemaking, MCA  |  |
| MTS_0190-0030-0210-0050 | 200 | 11106 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0050/0190-0030-0210-0050.html |    19-3-2105. Administrative expenses and fees, MCA  |  |
| MTS_0190-0030-0210-0060 | 200 | 10606 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0060/0190-0030-0210-0060.html |    19-3-2106. Limited contract right, MCA  |  |
| MTS_0190-0030-0210-0070 | 200 | 10033 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0070/0190-0030-0210-0070.html |    19-3-2107. through 19-3-2110 reserved, MCA  |  |
| MTS_0190-0030-0210-0110 | 200 | 15506 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0110/0190-0030-0210-0110.html |    19-3-2111. Plan membership -- written election required -- failure to elect - |  |
| MTS_0190-0030-0210-0120 | 200 | 18288 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0120/0190-0030-0210-0120.html |    19-3-2112. Plan choices for members employed by university system -- amount a |  |
| MTS_0190-0030-0210-0130 | 200 | 13549 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0130/0190-0030-0210-0130.html |    19-3-2113. Reinstatement of plan membership -- purchase of prior service cred |  |
| MTS_0190-0030-0210-0140 | 200 | 11002 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0140/0190-0030-0210-0140.html |    19-3-2114. Amount available to transfer, MCA  |  |
| MTS_0190-0030-0210-0150 | 200 | 11787 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0150/0190-0030-0210-0150.html |    19-3-2115. Transfers or rollovers into plan -- service transfers -- membershi |  |
| MTS_0190-0030-0210-0160 | 200 | 12535 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0160/0190-0030-0210-0160.html |    19-3-2116. Vesting -- mandatory termination of membership -- forfeitures, MCA |  |
| MTS_0190-0030-0210-0170 | 200 | 14772 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0170/0190-0030-0210-0170.html |    19-3-2117. Allocation of contributions and forfeitures, MCA  |  |
| MTS_0190-0030-0210-0180 | 200 | 9976 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0180/0190-0030-0210-0180.html |    19-3-2118. through 19-3-2120 reserved, MCA  |  |
| MTS_0190-0030-0210-0210 | 200 | 10315 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0210/0190-0030-0210-0210.html |    19-3-2121. Repealed, MCA  |  |
| MTS_0190-0030-0210-0220 | 200 | 13571 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0220/0190-0030-0210-0220.html |    19-3-2122. Investment alternatives -- notice of changes -- default fund, MCA  |  |
| MTS_0190-0030-0210-0230 | 200 | 11782 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0230/0190-0030-0210-0230.html |    19-3-2123. Payout of vested account balances when terminating plan membership |  |
| MTS_0190-0030-0210-0240 | 200 | 12223 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0240/0190-0030-0210-0240.html |    19-3-2124. Distribution options for plan members -- rulemaking -- minimum dis |  |
| MTS_0190-0030-0210-0250 | 200 | 10536 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0250/0190-0030-0210-0250.html |    19-3-2125. Death benefits, MCA  |  |
| MTS_0190-0030-0210-0260 | 200 | 13633 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0260/0190-0030-0210-0260.html |    19-3-2126. Refunds -- minimum account balance -- adjustment by rule, MCA  |  |
| MTS_0190-0030-0210-0270 | 200 | 9991 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0270/0190-0030-0210-0270.html |    19-3-2127. through 19-3-2130 reserved, MCA  |  |
| MTS_0190-0030-0210-0310 | 200 | 10154 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0310/0190-0030-0210-0310.html |    19-3-2131. Terminated, MCA  |  |
| MTS_0190-0030-0210-0320 | 200 | 10164 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0320/0190-0030-0210-0320.html |    19-3-2132. Terminated, MCA  |  |
| MTS_0190-0030-0210-0330 | 200 | 11476 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0330/0190-0030-0210-0330.html |    19-3-2133. Employee investment advisory council, MCA  |  |
| MTS_0190-0030-0210-0340 | 200 | 10180 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0340/0190-0030-0210-0340.html |    19-3-2134. Terminated, MCA  |  |
| MTS_0190-0030-0210-0350 | 200 | 10026 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0350/0190-0030-0210-0350.html |    19-3-2135. through 19-3-2140 reserved, MCA  |  |
| MTS_0190-0030-0210-0410 | 200 | 17305 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0410/0190-0030-0210-0410.html |    19-3-2141. Long-term disability plan -- benefit amount -- eligibility -- admi |  |
| MTS_0190-0030-0210-0420 | 200 | 10802 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0420/0190-0030-0210-0420.html |    19-3-2142. Disability benefit recipients to remain members -- access to accou |  |
| MTS_0190-0030-0210-0430 | 200 | 10682 | https://leg.mt.gov/bills/mca/title_0190/chapter_0030/part_0210/section_0430/0190-0030-0210-0430.html |    19-3-2143. Implementation, MCA  |  |
| MTS_0190-0040-0010-0010 | 200 | 9782 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0010/section_0010/0190-0040-0010-0010.html |    19-4-101. Renumbered 19-20-101, MCA  |  |
| MTS_0190-0040-0010-0020 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0010/section_0020/0190-0040-0010-0020.html |    19-4-102. Renumbered 19-20-102, MCA  |  |
| MTS_0190-0040-0010-0030 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0010/section_0030/0190-0040-0010-0030.html |    19-4-103. Renumbered 19-20-103, MCA  |  |
| MTS_0190-0040-0010-0040 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0010/section_0040/0190-0040-0010-0040.html |    19-4-104. Renumbered 19-20-104, MCA  |  |
| MTS_0190-0040-0010-0050 | 200 | 9785 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0010/section_0050/0190-0040-0010-0050.html |    19-4-105. Renumbered 19-20-105, MCA  |  |
| MTS_0190-0040-0020-0010 | 200 | 9800 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0020/section_0010/0190-0040-0020-0010.html |    19-4-201. Renumbered 19-20-201, MCA  |  |
| MTS_0190-0040-0020-0020 | 200 | 10015 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0020/section_0020/0190-0040-0020-0020.html |    19-4-202. Renumbered 19-20-202, MCA  |  |
| MTS_0190-0040-0020-0030 | 200 | 10015 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0020/section_0030/0190-0040-0020-0030.html |    19-4-203. Renumbered 19-20-203, MCA  |  |
| MTS_0190-0040-0020-0040 | 200 | 10015 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0020/section_0040/0190-0040-0020-0040.html |    19-4-204. Renumbered 19-20-204, MCA  |  |
| MTS_0190-0040-0020-0050 | 200 | 10015 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0020/section_0050/0190-0040-0020-0050.html |    19-4-205. Renumbered 19-20-205, MCA  |  |
| MTS_0190-0040-0020-0060 | 200 | 10015 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0020/section_0060/0190-0040-0020-0060.html |    19-4-206. Renumbered 19-20-206, MCA  |  |
| MTS_0190-0040-0020-0070 | 200 | 10015 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0020/section_0070/0190-0040-0020-0070.html |    19-4-207. Renumbered 19-20-207, MCA  |  |
| MTS_0190-0040-0020-0080 | 200 | 9803 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0020/section_0080/0190-0040-0020-0080.html |    19-4-208. Renumbered 19-20-208, MCA  |  |
| MTS_0190-0040-0030-0010 | 200 | 9797 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0030/section_0010/0190-0040-0030-0010.html |    19-4-301. Renumbered 19-20-301, MCA  |  |
| MTS_0190-0040-0030-0020 | 200 | 10012 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0030/section_0020/0190-0040-0030-0020.html |    19-4-302. Renumbered 19-20-302, MCA  |  |
| MTS_0190-0040-0030-0030 | 200 | 10012 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0030/section_0030/0190-0040-0030-0030.html |    19-4-303. Renumbered 19-20-303, MCA  |  |
| MTS_0190-0040-0030-0040 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0030/section_0040/0190-0040-0030-0040.html |    19-4-304. Renumbered 19-20-304, MCA  |  |
| MTS_0190-0040-0030-0050 | 200 | 10230 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0030/section_0050/0190-0040-0030-0050.html |    19-4-305. Repealed, MCA  |  |
| MTS_0190-0040-0040-0010 | 200 | 9782 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0010/0190-0040-0040-0010.html |    19-4-401. Renumbered 19-20-401, MCA  |  |
| MTS_0190-0040-0040-0020 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0020/0190-0040-0040-0020.html |    19-4-402. Renumbered 19-20-402, MCA  |  |
| MTS_0190-0040-0040-0030 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0030/0190-0040-0040-0030.html |    19-4-403. Renumbered 19-20-403, MCA  |  |
| MTS_0190-0040-0040-0040 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0040/0190-0040-0040-0040.html |    19-4-404. Renumbered 19-20-404, MCA  |  |
| MTS_0190-0040-0040-0050 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0050/0190-0040-0040-0050.html |    19-4-405. Renumbered 19-20-405, MCA  |  |
| MTS_0190-0040-0040-0060 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0060/0190-0040-0040-0060.html |    19-4-406. Renumbered 19-20-406, MCA  |  |
| MTS_0190-0040-0040-0070 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0070/0190-0040-0040-0070.html |    19-4-407. Renumbered 19-20-407, MCA  |  |
| MTS_0190-0040-0040-0080 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0080/0190-0040-0040-0080.html |    19-4-408. Renumbered 19-20-408, MCA  |  |
| MTS_0190-0040-0040-0090 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0090/0190-0040-0040-0090.html |    19-4-409. Renumbered 19-20-409, MCA  |  |
| MTS_0190-0040-0040-0100 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0100/0190-0040-0040-0100.html |    19-4-410. Renumbered 19-20-410, MCA  |  |
| MTS_0190-0040-0040-0110 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0110/0190-0040-0040-0110.html |    19-4-411. Renumbered 19-20-411, MCA  |  |
| MTS_0190-0040-0040-0120 | 200 | 9997 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0120/0190-0040-0040-0120.html |    19-4-412. Renumbered 19-20-412, MCA  |  |
| MTS_0190-0040-0040-0130 | 200 | 9785 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0040/section_0130/0190-0040-0040-0130.html |    19-4-413. Renumbered 19-20-413, MCA  |  |
| MTS_0190-0040-0050-0010 | 200 | 9785 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0050/section_0010/0190-0040-0050-0010.html |    19-4-501. Renumbered 19-20-501, MCA  |  |
| MTS_0190-0040-0050-0020 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0050/section_0020/0190-0040-0050-0020.html |    19-4-502. Renumbered 19-20-502, MCA  |  |
| MTS_0190-0040-0050-0030 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0050/section_0030/0190-0040-0050-0030.html |    19-4-503. Renumbered 19-20-503, MCA  |  |
| MTS_0190-0040-0050-0040 | 200 | 9788 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0050/section_0040/0190-0040-0050-0040.html |    19-4-504. Renumbered 19-20-504, MCA  |  |
| MTS_0190-0040-0060-0010 | 200 | 9833 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0060/section_0010/0190-0040-0060-0010.html |    19-4-601. Renumbered 19-20-601, MCA  |  |
| MTS_0190-0040-0060-0020 | 200 | 10048 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0060/section_0020/0190-0040-0060-0020.html |    19-4-602. Renumbered 19-20-602, MCA  |  |
| MTS_0190-0040-0060-0030 | 200 | 10036 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0060/section_0030/0190-0040-0060-0030.html |    19-4-603. Renumbered 19-20-603, MCA  |  |
| MTS_0190-0040-0060-0040 | 200 | 10475 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0060/section_0040/0190-0040-0060-0040.html |    19-4-604. Repealed, MCA  |  |
| MTS_0190-0040-0060-0050 | 200 | 10036 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0060/section_0050/0190-0040-0060-0050.html |    19-4-605. Renumbered 19-20-605, MCA  |  |
| MTS_0190-0040-0060-0060 | 200 | 9836 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0060/section_0060/0190-0040-0060-0060.html |    19-4-606. Renumbered 19-20-606, MCA  |  |
| MTS_0190-0040-0070-0010 | 200 | 9785 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0010/0190-0040-0070-0010.html |    19-4-701. Renumbered 19-20-701, MCA  |  |
| MTS_0190-0040-0070-0020 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0020/0190-0040-0070-0020.html |    19-4-702. Renumbered 19-20-702, MCA  |  |
| MTS_0190-0040-0070-0030 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0030/0190-0040-0070-0030.html |    19-4-703. Renumbered 19-20-703, MCA  |  |
| MTS_0190-0040-0070-0040 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0040/0190-0040-0070-0040.html |    19-4-704. Renumbered 19-20-704, MCA  |  |
| MTS_0190-0040-0070-0050 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0050/0190-0040-0070-0050.html |    19-4-705. Renumbered 19-20-705, MCA  |  |
| MTS_0190-0040-0070-0060 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0060/0190-0040-0070-0060.html |    19-4-706. Renumbered 19-20-706, MCA  |  |
| MTS_0190-0040-0070-0070 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0070/0190-0040-0070-0070.html |    19-4-707. Renumbered 19-20-707, MCA  |  |
| MTS_0190-0040-0070-0080 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0080/0190-0040-0070-0080.html |    19-4-708. Renumbered 19-20-708, MCA  |  |
| MTS_0190-0040-0070-0090 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0090/0190-0040-0070-0090.html |    19-4-709. Renumbered 19-20-709, MCA  |  |
| MTS_0190-0040-0070-0100 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0100/0190-0040-0070-0100.html |    19-4-710. Renumbered 19-20-710, MCA  |  |
| MTS_0190-0040-0070-0110 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0110/0190-0040-0070-0110.html |    19-4-711. Renumbered 19-20-711, MCA  |  |
| MTS_0190-0040-0070-0120 | 200 | 10000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0120/0190-0040-0070-0120.html |    19-4-712. Renumbered 19-20-712, MCA  |  |
| MTS_0190-0040-0070-0130 | 200 | 9788 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0070/section_0130/0190-0040-0070-0130.html |    19-4-713. Renumbered 19-20-713, MCA  |  |
| MTS_0190-0040-0080-0010 | 200 | 9842 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0080/section_0010/0190-0040-0080-0010.html |    19-4-801. Renumbered 19-20-801, MCA  |  |
| MTS_0190-0040-0080-0020 | 200 | 10045 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0080/section_0020/0190-0040-0080-0020.html |    19-4-802. Renumbered 19-20-802, MCA  |  |
| MTS_0190-0040-0080-0030 | 200 | 10518 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0080/section_0030/0190-0040-0080-0030.html |    19-4-803. Repealed, MCA  |  |
| MTS_0190-0040-0080-0040 | 200 | 9833 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0080/section_0040/0190-0040-0080-0040.html |    19-4-804. Renumbered 19-20-804, MCA  |  |
| MTS_0190-0040-0090-0010 | 200 | 9791 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0090/section_0010/0190-0040-0090-0010.html |    19-4-901. Renumbered 19-20-901, MCA  |  |
| MTS_0190-0040-0090-0020 | 200 | 10006 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0090/section_0020/0190-0040-0090-0020.html |    19-4-902. Renumbered 19-20-902, MCA  |  |
| MTS_0190-0040-0090-0030 | 200 | 10006 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0090/section_0030/0190-0040-0090-0030.html |    19-4-903. Renumbered 19-20-903, MCA  |  |
| MTS_0190-0040-0090-0040 | 200 | 10006 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0090/section_0040/0190-0040-0090-0040.html |    19-4-904. Renumbered 19-20-904, MCA  |  |
| MTS_0190-0040-0090-0050 | 200 | 9794 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0090/section_0050/0190-0040-0090-0050.html |    19-4-905. Renumbered 19-20-905, MCA  |  |
| MTS_0190-0040-0100-0010 | 200 | 9785 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0100/section_0010/0190-0040-0100-0010.html |    19-4-1001. Renumbered 19-20-1001, MCA  |  |
| MTS_0190-0040-0100-0020 | 200 | 9788 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0100/section_0020/0190-0040-0100-0020.html |    19-4-1002. Renumbered 19-20-1002, MCA  |  |
| MTS_0190-0040-0110-0010 | 200 | 9574 | https://leg.mt.gov/bills/mca/title_0190/chapter_0040/part_0110/section_0010/0190-0040-0110-0010.html |    19-4-1101. Renumbered 19-20-1101, MCA  |  |
| MTS_0190-0050-0010-0010 | 200 | 12157 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0010/section_0010/0190-0050-0010-0010.html |    19-5-101. Definitions, MCA  |  |
| MTS_0190-0050-0010-0020 | 200 | 10433 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0010/section_0020/0190-0050-0010-0020.html |    19-5-102. Judges' retirement system established, MCA  |  |
| MTS_0190-0050-0010-0030 | 200 | 13211 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0010/section_0030/0190-0050-0010-0030.html |    19-5-103. Call of retired judges and justices and inactive vested members for |  |
| MTS_0190-0050-0010-0040 | 200 | 9948 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0010/section_0040/0190-0050-0010-0040.html |    19-5-104. Renumbered 19-2-1009, MCA  |  |
| MTS_0190-0050-0010-0050 | 200 | 10116 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0010/section_0050/0190-0050-0010-0050.html |    19-5-105. Short title, MCA  |  |
| MTS_0190-0050-0010-0060 | 200 | 10188 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0010/section_0060/0190-0050-0010-0060.html |    19-5-106. Judges' retirement system benefit policy statement, MCA  |  |
| MTS_0190-0050-0020-0010 | 200 | 9966 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0020/section_0010/0190-0050-0020-0010.html |    19-5-201. Repealed, MCA  |  |
| MTS_0190-0050-0020-0020 | 200 | 10021 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0020/section_0020/0190-0050-0020-0020.html |    19-5-202. Repealed, MCA  |  |
| MTS_0190-0050-0030-0010 | 200 | 12088 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0030/section_0010/0190-0050-0030-0010.html |    19-5-301. Membership -- inactive vested members -- inactive nonvested members |  |
| MTS_0190-0050-0030-0020 | 200 | 10329 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0030/section_0020/0190-0050-0030-0020.html |    19-5-302. Repealed, MCA  |  |
| MTS_0190-0050-0030-0030 | 200 | 10165 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0030/section_0030/0190-0050-0030-0030.html |    19-5-303. Repealed, MCA  |  |
| MTS_0190-0050-0030-0040 | 200 | 9963 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0030/section_0040/0190-0050-0030-0040.html |    19-5-304. Repealed, MCA  |  |
| MTS_0190-0050-0040-0010 | 200 | 10444 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0040/section_0010/0190-0050-0040-0010.html |    19-5-401. Payments into pension trust fund, MCA  |  |
| MTS_0190-0050-0040-0020 | 200 | 11575 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0040/section_0020/0190-0050-0040-0020.html |    19-5-402. Member's contribution, MCA  |  |
| MTS_0190-0050-0040-0030 | 200 | 10574 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0040/section_0030/0190-0050-0040-0030.html |    19-5-403. Refunds in case of resignation or discharge, MCA  |  |
| MTS_0190-0050-0040-0040 | 200 | 11847 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0040/section_0040/0190-0050-0040-0040.html |    19-5-404. State employer contribution, MCA  |  |
| MTS_0190-0050-0040-0050 | 200 | 10343 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0040/section_0050/0190-0050-0040-0050.html |    19-5-405. Repealed, MCA  |  |
| MTS_0190-0050-0040-0060 | 200 | 10100 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0040/section_0060/0190-0050-0040-0060.html |    19-5-406. Repealed, MCA  |  |
| MTS_0190-0050-0040-0070 | 200 | 10164 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0040/section_0070/0190-0050-0040-0070.html |    19-5-407. Repealed, MCA  |  |
| MTS_0190-0050-0040-0080 | 200 | 10111 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0040/section_0080/0190-0050-0040-0080.html |    19-5-408. Repealed, MCA  |  |
| MTS_0190-0050-0040-0090 | 200 | 11621 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0040/section_0090/0190-0050-0040-0090.html |    19-5-409. Application to purchase additional service, MCA  |  |
| MTS_0190-0050-0040-0100 | 200 | 12337 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0040/section_0100/0190-0050-0040-0100.html |    19-5-410. Application to purchase military service credit, MCA  |  |
| MTS_0190-0050-0040-0110 | 200 | 10245 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0040/section_0110/0190-0050-0040-0110.html |    19-5-411. Service purchase limitation, MCA  |  |
| MTS_0190-0050-0050-0010 | 200 | 10976 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0050/section_0010/0190-0050-0050-0010.html |    19-5-501. Eligibility for service retirement, MCA  |  |
| MTS_0190-0050-0050-0020 | 200 | 11413 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0050/section_0020/0190-0050-0050-0020.html |    19-5-502. Service retirement benefit, MCA  |  |
| MTS_0190-0050-0050-0030 | 200 | 11252 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0050/section_0030/0190-0050-0050-0030.html |    19-5-503. Involuntary retirement benefit, MCA  |  |
| MTS_0190-0050-0050-0040 | 200 | 9925 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0050/section_0040/0190-0050-0050-0040.html |    19-5-504. Repealed, MCA  |  |
| MTS_0190-0050-0060-0010 | 200 | 11107 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0060/section_0010/0190-0050-0060-0010.html |    19-5-601. Disability retirement benefit, MCA  |  |
| MTS_0190-0050-0060-0020 | 200 | 10147 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0060/section_0020/0190-0050-0060-0020.html |    19-5-602. Repealed, MCA  |  |
| MTS_0190-0050-0060-0030 | 200 | 9920 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0060/section_0030/0190-0050-0060-0030.html |    19-5-603. Renumbered 19-5-801, MCA  |  |
| MTS_0190-0050-0060-0040 | 200 | 9937 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0060/section_0040/0190-0050-0060-0040.html |    19-5-604. Renumbered 19-5-802, MCA  |  |
| MTS_0190-0050-0060-0050 | 200 | 9929 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0060/section_0050/0190-0050-0060-0050.html |    19-5-605. through 19-5-610 reserved, MCA  |  |
| MTS_0190-0050-0060-0110 | 200 | 9989 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0060/section_0110/0190-0050-0060-0110.html |    19-5-611. Renumbered 19-2-406, MCA  |  |
| MTS_0190-0050-0060-0120 | 200 | 11785 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0060/section_0120/0190-0050-0060-0120.html |    19-5-612. Medical examination of disability retiree -- cancellation of benefi |  |
| MTS_0190-0050-0070-0010 | 200 | 17826 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0070/section_0010/0190-0050-0070-0010.html |    19-5-701. Optional forms of benefits -- designation of contingent annuitant,  |  |
| MTS_0190-0050-0070-0020 | 200 | 10195 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0070/section_0020/0190-0050-0070-0020.html |    19-5-702. Repealed, MCA  |  |
| MTS_0190-0050-0070-0030 | 200 | 10106 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0070/section_0030/0190-0050-0070-0030.html |    19-5-703. Repealed, MCA  |  |
| MTS_0190-0050-0070-0040 | 200 | 10193 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0070/section_0040/0190-0050-0070-0040.html |    19-5-704. Repealed, MCA  |  |
| MTS_0190-0050-0070-0050 | 200 | 10115 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0070/section_0050/0190-0050-0070-0050.html |    19-5-705. Repealed, MCA  |  |
| MTS_0190-0050-0070-0060 | 200 | 9876 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0070/section_0060/0190-0050-0070-0060.html |    19-5-706. Repealed, MCA  |  |
| MTS_0190-0050-0080-0010 | 200 | 11180 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0080/section_0010/0190-0050-0080-0010.html |    19-5-801. Payments upon employment-related death, MCA  |  |
| MTS_0190-0050-0080-0020 | 200 | 13579 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0080/section_0020/0190-0050-0080-0020.html |    19-5-802. Payments upon death from other than employment-related cause, MCA  |  |
| MTS_0190-0050-0090-0010 | 200 | 12650 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0090/section_0010/0190-0050-0090-0010.html |    19-5-901. Guaranteed annual benefit adjustment, MCA  |  |
| MTS_0190-0050-0090-0020 | 200 | 12623 | https://leg.mt.gov/bills/mca/title_0190/chapter_0050/part_0090/section_0020/0190-0050-0090-0020.html |    19-5-902. Election -- guaranteed annual benefit adjustment, MCA  |  |
| MTS_0190-0060-0010-0010 | 200 | 13512 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0010/section_0010/0190-0060-0010-0010.html |    19-6-101. Definitions, MCA  |  |
| MTS_0190-0060-0010-0020 | 200 | 10540 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0010/section_0020/0190-0060-0010-0020.html |    19-6-102. Highway patrol officers' retirement system established, MCA  |  |
| MTS_0190-0060-0010-0030 | 200 | 10157 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0010/section_0030/0190-0060-0010-0030.html |    19-6-103. Repealed, MCA  |  |
| MTS_0190-0060-0010-0040 | 200 | 10154 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0010/section_0040/0190-0060-0010-0040.html |    19-6-104. Repealed, MCA  |  |
| MTS_0190-0060-0010-0050 | 200 | 10143 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0010/section_0050/0190-0060-0010-0050.html |    19-6-105. Repealed, MCA  |  |
| MTS_0190-0060-0010-0060 | 200 | 10173 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0010/section_0060/0190-0060-0010-0060.html |    19-6-106. Short title, MCA  |  |
| MTS_0190-0060-0010-0070 | 200 | 10324 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0010/section_0070/0190-0060-0010-0070.html |    19-6-107. Highway patrol officers' retirement system benefit policy statement |  |
| MTS_0190-0060-0020-0010 | 200 | 10105 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0020/section_0010/0190-0060-0020-0010.html |    19-6-201. Repealed, MCA  |  |
| MTS_0190-0060-0020-0020 | 200 | 10339 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0020/section_0020/0190-0060-0020-0020.html |    19-6-202. Repealed, MCA  |  |
| MTS_0190-0060-0020-0030 | 200 | 10271 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0020/section_0030/0190-0060-0020-0030.html |    19-6-203. Repealed, MCA  |  |
| MTS_0190-0060-0020-0040 | 200 | 9964 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0020/section_0040/0190-0060-0020-0040.html |    19-6-204. Terminated, MCA  |  |
| MTS_0190-0060-0030-0010 | 200 | 12104 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0030/section_0010/0190-0060-0030-0010.html |    19-6-301. Membership -- inactive vested members -- inactive nonvested members |  |
| MTS_0190-0060-0030-0020 | 200 | 10454 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0030/section_0020/0190-0060-0030-0020.html |    19-6-302. Repealed, MCA  |  |
| MTS_0190-0060-0030-0030 | 200 | 10304 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0030/section_0030/0190-0060-0030-0030.html |    19-6-303. Repealed, MCA  |  |
| MTS_0190-0060-0030-0040 | 200 | 9972 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0030/section_0040/0190-0060-0030-0040.html |    19-6-304. Renumbered 19-6-801, MCA  |  |
| MTS_0190-0060-0030-0050 | 200 | 9983 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0030/section_0050/0190-0060-0030-0050.html |    19-6-305. Renumbered 19-6-802, MCA  |  |
| MTS_0190-0060-0030-0060 | 200 | 9772 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0030/section_0060/0190-0060-0030-0060.html |    19-6-306. Renumbered 19-6-803, MCA  |  |
| MTS_0190-0060-0040-0010 | 200 | 10719 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0040/section_0010/0190-0060-0040-0010.html |    19-6-401. Payments into pension trust fund, MCA  |  |
| MTS_0190-0060-0040-0020 | 200 | 13826 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0040/section_0020/0190-0060-0040-0020.html |    19-6-402. Member's contribution, MCA  |  |
| MTS_0190-0060-0040-0030 | 200 | 10718 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0040/section_0030/0190-0060-0040-0030.html |    19-6-403. Refund of member's contribution, MCA  |  |
| MTS_0190-0060-0040-0040 | 200 | 13828 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0040/section_0040/0190-0060-0040-0040.html |    19-6-404. State employer contribution -- statutory appropriation, MCA  |  |
| MTS_0190-0060-0040-0050 | 200 | 10371 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0040/section_0050/0190-0060-0040-0050.html |    19-6-405. Repealed, MCA  |  |
| MTS_0190-0060-0040-0060 | 200 | 10260 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0040/section_0060/0190-0060-0040-0060.html |    19-6-406. Repealed, MCA  |  |
| MTS_0190-0060-0040-0070 | 200 | 10180 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0040/section_0070/0190-0060-0040-0070.html |    19-6-407. Repealed, MCA  |  |
| MTS_0190-0060-0040-0080 | 200 | 10260 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0040/section_0080/0190-0060-0040-0080.html |    19-6-408. Repealed, MCA  |  |
| MTS_0190-0060-0040-0090 | 200 | 10174 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0040/section_0090/0190-0060-0040-0090.html |    19-6-409. Repealed, MCA  |  |
| MTS_0190-0060-0040-0100 | 200 | 11248 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0040/section_0100/0190-0060-0040-0100.html |    19-6-410. State contribution for supplemental benefits -- statutory appropria |  |
| MTS_0190-0060-0050-0010 | 200 | 11577 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0050/section_0010/0190-0060-0050-0010.html |    19-6-501. Eligibility for service retirement benefit, MCA  |  |
| MTS_0190-0060-0050-0020 | 200 | 10736 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0050/section_0020/0190-0060-0050-0020.html |    19-6-502. Service retirement benefit, MCA  |  |
| MTS_0190-0060-0050-0030 | 200 | 11604 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0050/section_0030/0190-0060-0050-0030.html |    19-6-503. Early retirement benefit for member discontinued from service other |  |
| MTS_0190-0060-0050-0040 | 200 | 10263 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0050/section_0040/0190-0060-0050-0040.html |    19-6-504. Repealed, MCA  |  |
| MTS_0190-0060-0050-0050 | 200 | 11984 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0050/section_0050/0190-0060-0050-0050.html |    19-6-505. Payment of retirement benefits, MCA  |  |
| MTS_0190-0060-0050-0060 | 200 | 10005 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0050/section_0060/0190-0060-0050-0060.html |    19-6-506. Repealed, MCA  |  |
| MTS_0190-0060-0060-0010 | 200 | 11752 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0060/section_0010/0190-0060-0060-0010.html |    19-6-601. Disability retirement benefit, MCA  |  |
| MTS_0190-0060-0060-0020 | 200 | 10366 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0060/section_0020/0190-0060-0060-0020.html |    19-6-602. Repealed, MCA  |  |
| MTS_0190-0060-0060-0030 | 200 | 9954 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0060/section_0030/0190-0060-0060-0030.html |    19-6-603. Renumbered 19-6-901, MCA  |  |
| MTS_0190-0060-0060-0040 | 200 | 9971 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0060/section_0040/0190-0060-0060-0040.html |    19-6-604. Renumbered 19-6-902, MCA  |  |
| MTS_0190-0060-0060-0050 | 200 | 9952 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0060/section_0050/0190-0060-0060-0050.html |    19-6-605. through 19-6-610 reserved, MCA  |  |
| MTS_0190-0060-0060-0110 | 200 | 10203 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0060/section_0110/0190-0060-0060-0110.html |    19-6-611. Repealed, MCA  |  |
| MTS_0190-0060-0060-0120 | 200 | 13756 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0060/section_0120/0190-0060-0060-0120.html |    19-6-612. Medical examination of disability retiree -- cancellation of benefi |  |
| MTS_0190-0060-0070-0010 | 200 | 10061 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0070/section_0010/0190-0060-0070-0010.html |    19-6-701. Repealed, MCA  |  |
| MTS_0190-0060-0070-0020 | 200 | 10229 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0070/section_0020/0190-0060-0070-0020.html |    19-6-702. Repealed, MCA  |  |
| MTS_0190-0060-0070-0030 | 200 | 10223 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0070/section_0030/0190-0060-0070-0030.html |    19-6-703. Repealed, MCA  |  |
| MTS_0190-0060-0070-0040 | 200 | 10261 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0070/section_0040/0190-0060-0070-0040.html |    19-6-704. Repealed, MCA  |  |
| MTS_0190-0060-0070-0050 | 200 | 10286 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0070/section_0050/0190-0060-0070-0050.html |    19-6-705. Repealed, MCA  |  |
| MTS_0190-0060-0070-0060 | 200 | 10221 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0070/section_0060/0190-0060-0070-0060.html |    19-6-706. Repealed, MCA  |  |
| MTS_0190-0060-0070-0070 | 200 | 12292 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0070/section_0070/0190-0060-0070-0070.html |    19-6-707. Minimum monthly benefit, MCA  |  |
| MTS_0190-0060-0070-0080 | 200 | 10219 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0070/section_0080/0190-0060-0070-0080.html |    19-6-708. Repealed, MCA  |  |
| MTS_0190-0060-0070-0090 | 200 | 14006 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0070/section_0090/0190-0060-0070-0090.html |    19-6-709. Supplemental benefits for certain retirees, MCA  |  |
| MTS_0190-0060-0070-0100 | 200 | 13402 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0070/section_0100/0190-0060-0070-0100.html |    19-6-710. Guaranteed annual benefit adjustment, MCA  |  |
| MTS_0190-0060-0070-0110 | 200 | 13168 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0070/section_0110/0190-0060-0070-0110.html |    19-6-711. Election -- guaranteed annual benefit adjustment, MCA  |  |
| MTS_0190-0060-0070-0120 | 200 | 12062 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0070/section_0120/0190-0060-0070-0120.html |    19-6-712. Guaranteed annual benefit adjustment for employees hired after July |  |
| MTS_0190-0060-0080-0010 | 200 | 14513 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0080/section_0010/0190-0060-0080-0010.html |    19-6-801. Application to purchase military service, MCA  |  |
| MTS_0190-0060-0080-0020 | 200 | 10526 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0080/section_0020/0190-0060-0080-0020.html |    19-6-802. Repealed, MCA  |  |
| MTS_0190-0060-0080-0030 | 200 | 13008 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0080/section_0030/0190-0060-0080-0030.html |    19-6-803. Application to purchase law enforcement service performed in anothe |  |
| MTS_0190-0060-0080-0040 | 200 | 11795 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0080/section_0040/0190-0060-0080-0040.html |    19-6-804. Application to purchase additional service, MCA  |  |
| MTS_0190-0060-0080-0050 | 200 | 10564 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0080/section_0050/0190-0060-0080-0050.html |    19-6-805. Service purchase limitation, MCA  |  |
| MTS_0190-0060-0080-0060 | 200 | 9940 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0080/section_0060/0190-0060-0080-0060.html |    19-6-806. through 19-6-809 reserved, MCA  |  |
| MTS_0190-0060-0080-0100 | 200 | 12553 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0080/section_0100/0190-0060-0080-0100.html |    19-6-810. Absence because of illness or injury, MCA  |  |
| MTS_0190-0060-0090-0010 | 200 | 10982 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0090/section_0010/0190-0060-0090-0010.html |    19-6-901. Survivorship benefits -- employment-related death, MCA  |  |
| MTS_0190-0060-0090-0020 | 200 | 11136 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0090/section_0020/0190-0060-0090-0020.html |    19-6-902. Survivorship benefits -- death from other causes, MCA  |  |
| MTS_0190-0060-0090-0030 | 200 | 10765 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0090/section_0030/0190-0060-0090-0030.html |    19-6-903. Death payments in absence of survivors, MCA  |  |
| MTS_0190-0060-0100-0010 | 200 | 9980 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0100/section_0010/0190-0060-0100-0010.html |    19-6-1001. Short title, MCA  |  |
| MTS_0190-0060-0100-0020 | 200 | 11488 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0100/section_0020/0190-0060-0100-0020.html |    19-6-1002. Definitions, MCA  |  |
| MTS_0190-0060-0100-0030 | 200 | 10892 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0100/section_0030/0190-0060-0100-0030.html |    19-6-1003. Deferred retirement option plan established -- rulemaking, MCA  |  |
| MTS_0190-0060-0100-0040 | 200 | 11752 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0100/section_0040/0190-0060-0100-0040.html |    19-6-1004. Eligibility -- participation criteria -- membership status -- serv |  |
| MTS_0190-0060-0100-0050 | 200 | 12136 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0100/section_0050/0190-0060-0100-0050.html |    19-6-1005. Retirement system contributions -- benefit payments to individual  |  |
| MTS_0190-0060-0100-0060 | 200 | 11657 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0100/section_0060/0190-0060-0100-0060.html |    19-6-1006. Survivorship benefit, MCA  |  |
| MTS_0190-0060-0100-0070 | 200 | 12357 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0100/section_0070/0190-0060-0100-0070.html |    19-6-1007. Employment and benefits after DROP period, MCA  |  |
| MTS_0190-0060-0100-0080 | 200 | 11062 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0100/section_0080/0190-0060-0100-0080.html |    19-6-1008. Distribution of DROP benefit, MCA  |  |
| MTS_0190-0060-0110-0010 | 200 | 11539 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0110/section_0010/0190-0060-0110-0010.html |    19-6-1101. Reemployment of retired members -- contributions required, MCA  |  |
| MTS_0190-0060-0110-0020 | 200 | 14154 | https://leg.mt.gov/bills/mca/title_0190/chapter_0060/part_0110/section_0020/0190-0060-0110-0020.html |    19-6-1102. Refunds and benefits for reemployed retired members, MCA  |  |
| MTS_0190-0070-0010-0010 | 200 | 14306 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0010/section_0010/0190-0070-0010-0010.html |    19-7-101. Definitions, MCA  |  |
| MTS_0190-0070-0010-0020 | 200 | 10438 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0010/section_0020/0190-0070-0010-0020.html |    19-7-102. Sheriffs' retirement system established, MCA  |  |
| MTS_0190-0070-0010-0030 | 200 | 9911 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0010/section_0030/0190-0070-0010-0030.html |    19-7-103. Renumbered 19-2-905, MCA  |  |
| MTS_0190-0070-0010-0040 | 200 | 10116 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0010/section_0040/0190-0070-0010-0040.html |    19-7-104. Repealed, MCA  |  |
| MTS_0190-0070-0010-0050 | 200 | 10113 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0010/section_0050/0190-0070-0010-0050.html |    19-7-105. Short title, MCA  |  |
| MTS_0190-0070-0010-0060 | 200 | 10204 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0010/section_0060/0190-0070-0010-0060.html |    19-7-106. Sheriffs' retirement system benefit policy statement, MCA  |  |
| MTS_0190-0070-0020-0010 | 200 | 10021 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0020/section_0010/0190-0070-0020-0010.html |    19-7-201. Repealed, MCA  |  |
| MTS_0190-0070-0020-0020 | 200 | 10261 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0020/section_0020/0190-0070-0020-0020.html |    19-7-202. Repealed, MCA  |  |
| MTS_0190-0070-0020-0030 | 200 | 9934 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0020/section_0030/0190-0070-0020-0030.html |    19-7-203. Terminated, MCA  |  |
| MTS_0190-0070-0030-0010 | 200 | 14178 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0030/section_0010/0190-0070-0030-0010.html |    19-7-301. Membership -- inactive vested members -- inactive nonvested members |  |
| MTS_0190-0070-0030-0020 | 200 | 11885 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0030/section_0020/0190-0070-0030-0020.html |    19-7-302. Ineligibility for membership in public employees' retirement system |  |
| MTS_0190-0070-0030-0030 | 200 | 10237 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0030/section_0030/0190-0070-0030-0030.html |    19-7-303. Repealed, MCA  |  |
| MTS_0190-0070-0030-0040 | 200 | 10181 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0030/section_0040/0190-0070-0030-0040.html |    19-7-304. Repealed, MCA  |  |
| MTS_0190-0070-0030-0050 | 200 | 10148 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0030/section_0050/0190-0070-0030-0050.html |    19-7-305. Repealed, MCA  |  |
| MTS_0190-0070-0030-0060 | 200 | 10209 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0030/section_0060/0190-0070-0030-0060.html |    19-7-306. Repealed, MCA  |  |
| MTS_0190-0070-0030-0070 | 200 | 10197 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0030/section_0070/0190-0070-0030-0070.html |    19-7-307. Repealed, MCA  |  |
| MTS_0190-0070-0030-0080 | 200 | 9941 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0030/section_0080/0190-0070-0030-0080.html |    19-7-308. Renumbered 19-7-801, MCA  |  |
| MTS_0190-0070-0030-0090 | 200 | 9952 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0030/section_0090/0190-0070-0030-0090.html |    19-7-309. Renumbered 19-7-802, MCA  |  |
| MTS_0190-0070-0030-0100 | 200 | 9952 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0030/section_0100/0190-0070-0030-0100.html |    19-7-310. Renumbered 19-7-803, MCA  |  |
| MTS_0190-0070-0030-0110 | 200 | 9987 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0030/section_0110/0190-0070-0030-0110.html |    19-7-311. Renumbered 19-7-804, MCA  |  |
| MTS_0190-0070-0030-0120 | 200 | 10723 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0030/section_0120/0190-0070-0030-0120.html |    19-7-312. Transfer of membership -- purchase of previous service, MCA  |  |
| MTS_0190-0070-0040-0010 | 200 | 9964 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0040/section_0010/0190-0070-0040-0010.html |    19-7-401. Repealed, MCA  |  |
| MTS_0190-0070-0040-0020 | 200 | 11023 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0040/section_0020/0190-0070-0040-0020.html |    19-7-402. Sources of money in fund, MCA  |  |
| MTS_0190-0070-0040-0030 | 200 | 13017 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0040/section_0030/0190-0070-0040-0030.html |    19-7-403. Member's contributions deducted, MCA  |  |
| MTS_0190-0070-0040-0040 | 200 | 16017 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0040/section_0040/0190-0070-0040-0040.html |    19-7-404. Employer contributions, MCA  |  |
| MTS_0190-0070-0040-0050 | 200 | 10228 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0040/section_0050/0190-0070-0040-0050.html |    19-7-405. Repealed, MCA  |  |
| MTS_0190-0070-0040-0060 | 200 | 10179 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0040/section_0060/0190-0070-0040-0060.html |    19-7-406. Repealed, MCA  |  |
| MTS_0190-0070-0040-0070 | 200 | 10146 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0040/section_0070/0190-0070-0040-0070.html |    19-7-407. Repealed, MCA  |  |
| MTS_0190-0070-0040-0080 | 200 | 10179 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0040/section_0080/0190-0070-0040-0080.html |    19-7-408. Repealed, MCA  |  |
| MTS_0190-0070-0040-0090 | 200 | 10159 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0040/section_0090/0190-0070-0040-0090.html |    19-7-409. Repealed, MCA  |  |
| MTS_0190-0070-0040-0100 | 200 | 10567 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0040/section_0100/0190-0070-0040-0100.html |    19-7-410. Contributions based on total compensation when member receives disa |  |
| MTS_0190-0070-0050-0010 | 200 | 11497 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0050/section_0010/0190-0070-0050-0010.html |    19-7-501. Eligibility for service retirement, MCA  |  |
| MTS_0190-0070-0050-0020 | 200 | 10857 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0050/section_0020/0190-0070-0050-0020.html |    19-7-502. Retirement option, MCA  |  |
| MTS_0190-0070-0050-0030 | 200 | 12296 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0050/section_0030/0190-0070-0050-0030.html |    19-7-503. Service retirement benefit, MCA  |  |
| MTS_0190-0070-0050-0040 | 200 | 10093 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0050/section_0040/0190-0070-0050-0040.html |    19-7-504. Repealed, MCA  |  |
| MTS_0190-0070-0060-0010 | 200 | 11165 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0060/section_0010/0190-0070-0060-0010.html |    19-7-601. Disability retirement benefit, MCA  |  |
| MTS_0190-0070-0060-0020 | 200 | 10213 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0060/section_0020/0190-0070-0060-0020.html |    19-7-602. Repealed, MCA  |  |
| MTS_0190-0070-0060-0030 | 200 | 10139 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0060/section_0030/0190-0070-0060-0030.html |    19-7-603. Repealed, MCA  |  |
| MTS_0190-0070-0060-0040 | 200 | 9930 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0060/section_0040/0190-0070-0060-0040.html |    19-7-604. Renumbered 19-7-901, MCA  |  |
| MTS_0190-0070-0060-0050 | 200 | 9922 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0060/section_0050/0190-0070-0060-0050.html |    19-7-605. through 19-7-610 reserved, MCA  |  |
| MTS_0190-0070-0060-0110 | 200 | 10173 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0060/section_0110/0190-0070-0060-0110.html |    19-7-611. Repealed, MCA  |  |
| MTS_0190-0070-0060-0120 | 200 | 13127 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0060/section_0120/0190-0070-0060-0120.html |    19-7-612. Medical examination of disability retiree -- cancellation of benefi |  |
| MTS_0190-0070-0070-0010 | 200 | 9760 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0070/section_0010/0190-0070-0070-0010.html |    19-7-701. Renumbered 19-7-1001, MCA  |  |
| MTS_0190-0070-0070-0020 | 200 | 10225 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0070/section_0020/0190-0070-0070-0020.html |    19-7-702. Repealed, MCA  |  |
| MTS_0190-0070-0070-0030 | 200 | 10175 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0070/section_0030/0190-0070-0070-0030.html |    19-7-703. Repealed, MCA  |  |
| MTS_0190-0070-0070-0040 | 200 | 10178 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0070/section_0040/0190-0070-0070-0040.html |    19-7-704. Repealed, MCA  |  |
| MTS_0190-0070-0070-0050 | 200 | 10300 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0070/section_0050/0190-0070-0070-0050.html |    19-7-705. Repealed, MCA  |  |
| MTS_0190-0070-0070-0060 | 200 | 10178 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0070/section_0060/0190-0070-0070-0060.html |    19-7-706. Repealed, MCA  |  |
| MTS_0190-0070-0070-0070 | 200 | 10140 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0070/section_0070/0190-0070-0070-0070.html |    19-7-707. Repealed, MCA  |  |
| MTS_0190-0070-0070-0080 | 200 | 10173 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0070/section_0080/0190-0070-0070-0080.html |    19-7-708. Repealed, MCA  |  |
| MTS_0190-0070-0070-0090 | 200 | 10173 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0070/section_0090/0190-0070-0070-0090.html |    19-7-709. Repealed, MCA  |  |
| MTS_0190-0070-0070-0100 | 200 | 10201 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0070/section_0100/0190-0070-0070-0100.html |    19-7-710. Repealed, MCA  |  |
| MTS_0190-0070-0070-0110 | 200 | 13805 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0070/section_0110/0190-0070-0070-0110.html |    19-7-711. Guaranteed annual benefit adjustment, MCA  |  |
| MTS_0190-0070-0080-0010 | 200 | 15728 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0080/section_0010/0190-0070-0080-0010.html |    19-7-801. Membership in municipal police officers' retirement system prior to |  |
| MTS_0190-0070-0080-0020 | 200 | 10566 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0080/section_0020/0190-0070-0080-0020.html |    19-7-802. Repealed, MCA  |  |
| MTS_0190-0070-0080-0030 | 200 | 12490 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0080/section_0030/0190-0070-0080-0030.html |    19-7-803. Application to purchase military service, MCA  |  |
| MTS_0190-0070-0080-0040 | 200 | 11411 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0080/section_0040/0190-0070-0080-0040.html |    19-7-804. Application to purchase additional service, MCA  |  |
| MTS_0190-0070-0080-0050 | 200 | 10438 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0080/section_0050/0190-0070-0080-0050.html |    19-7-805. Service purchase limitation, MCA  |  |
| MTS_0190-0070-0080-0060 | 200 | 9882 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0080/section_0060/0190-0070-0080-0060.html |    19-7-806. through 19-7-809 reserved, MCA  |  |
| MTS_0190-0070-0080-0100 | 200 | 9895 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0080/section_0100/0190-0070-0080-0100.html |    19-7-810. Repealed, MCA  |  |
| MTS_0190-0070-0090-0010 | 200 | 11294 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0090/section_0010/0190-0070-0090-0010.html |    19-7-901. Payments in case of death before retirement, MCA  |  |
| MTS_0190-0070-0100-0010 | 200 | 17798 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0100/section_0010/0190-0070-0100-0010.html |    19-7-1001. Optional forms of benefits -- designation of contingent annuitant, |  |
| MTS_0190-0070-0110-0010 | 200 | 11634 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0110/section_0010/0190-0070-0110-0010.html |    19-7-1101. Reemployment of retired members -- contributions required, MCA  |  |
| MTS_0190-0070-0110-0020 | 200 | 13543 | https://leg.mt.gov/bills/mca/title_0190/chapter_0070/part_0110/section_0020/0190-0070-0110-0020.html |    19-7-1102. Refunds and benefits for reemployed retired members, MCA  |  |
