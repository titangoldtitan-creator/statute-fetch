| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0150-0010-0040-0060 | 200 | 12708 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0040/section_0060/0150-0010-0040-0060.html |    15-1-406. Declaratory judgment, MCA  |  |
| MTS_0150-0010-0040-0070 | 200 | 12918 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0040/section_0070/0150-0010-0040-0070.html |    15-1-407. Alternative remedy -- procedure, MCA  |  |
| MTS_0150-0010-0040-0080 | 200 | 10168 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0040/section_0080/0150-0010-0040-0080.html |    15-1-408. Alternative remedy -- judgment, MCA  |  |
| MTS_0150-0010-0040-0090 | 200 | 9244 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0040/section_0090/0150-0010-0040-0090.html |    15-1-409. Repealed, MCA  |  |
| MTS_0150-0010-0040-0100 | 200 | 8996 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0040/section_0100/0150-0010-0040-0100.html |    15-1-410. through 15-1-420 reserved, MCA  |  |
| MTS_0150-0010-0040-0210 | 200 | 9644 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0040/section_0210/0150-0010-0040-0210.html |    15-1-421. Payment of taxes by negotiable instrument, MCA  |  |
| MTS_0150-0010-0050-0010 | 200 | 9977 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0050/section_0010/0150-0010-0050-0010.html |    15-1-501. Repealed, MCA  |  |
| MTS_0150-0010-0050-0020 | 200 | 9121 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0050/section_0020/0150-0010-0050-0020.html |    15-1-502. Repealed, MCA  |  |
| MTS_0150-0010-0050-0030 | 200 | 10384 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0050/section_0030/0150-0010-0050-0030.html |    15-1-503. Refund of overpayment -- procedure, MCA  |  |
| MTS_0150-0010-0050-0040 | 200 | 11066 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0050/section_0040/0150-0010-0050-0040.html |    15-1-504. Settlement of county treasurer with department, MCA  |  |
| MTS_0150-0010-0050-0050 | 200 | 9249 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0050/section_0050/0150-0010-0050-0050.html |    15-1-505. Repealed, MCA  |  |
| MTS_0150-0010-0050-0060 | 200 | 9252 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0050/section_0060/0150-0010-0050-0060.html |    15-1-506. Repealed, MCA  |  |
| MTS_0150-0010-0050-0070 | 200 | 8860 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0050/section_0070/0150-0010-0050-0070.html |    15-1-507. through 15-1-515 reserved, MCA  |  |
| MTS_0150-0010-0050-0160 | 200 | 9105 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0050/section_0160/0150-0010-0050-0160.html |    15-1-516. Terminated, MCA  |  |
| MTS_0150-0010-0050-0170 | 200 | 8887 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0050/section_0170/0150-0010-0050-0170.html |    15-1-517. through 15-1-520 reserved, MCA  |  |
| MTS_0150-0010-0050-0210 | 200 | 9438 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0050/section_0210/0150-0010-0050-0210.html |    15-1-521. Property valuation improvement fund, MCA  |  |
| MTS_0150-0010-0060-0010 | 200 | 63250 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0060/section_0010/0150-0010-0060-0010.html |    15-1-601. Compact adopted -- text, MCA  |  |
| MTS_0150-0010-0060-0020 | 200 | 9347 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0060/section_0020/0150-0010-0060-0020.html |    15-1-602. Montana compact commissioner -- director of revenue, MCA  |  |
| MTS_0150-0010-0060-0030 | 200 | 9226 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0060/section_0030/0150-0010-0060-0030.html |    15-1-603. Alternate, MCA  |  |
| MTS_0150-0010-0060-0040 | 200 | 8890 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0060/section_0040/0150-0010-0060-0040.html |    15-1-604. Not codified, MCA  |  |
| MTS_0150-0010-0070-0010 | 200 | 12737 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0070/section_0010/0150-0010-0070-0010.html |    15-1-701. Warrant for distraint, MCA  |  |
| MTS_0150-0010-0070-0020 | 200 | 10008 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0070/section_0020/0150-0010-0070-0020.html |    15-1-702. Issuance of warrant, MCA  |  |
| MTS_0150-0010-0070-0030 | 200 | 9990 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0070/section_0030/0150-0010-0070-0030.html |    15-1-703. Emergency issuance of warrant, MCA  |  |
| MTS_0150-0010-0070-0040 | 200 | 9910 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0070/section_0040/0150-0010-0070-0040.html |    15-1-704. Filing with district court, MCA  |  |
| MTS_0150-0010-0070-0050 | 200 | 10106 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0070/section_0050/0150-0010-0070-0050.html |    15-1-705. Review, MCA  |  |
| MTS_0150-0010-0070-0060 | 200 | 10885 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0070/section_0060/0150-0010-0070-0060.html |    15-1-706. Execution upon warrant, MCA  |  |
| MTS_0150-0010-0070-0070 | 200 | 10170 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0070/section_0070/0150-0010-0070-0070.html |    15-1-707. Emergency execution upon warrant, MCA  |  |
| MTS_0150-0010-0070-0080 | 200 | 10924 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0070/section_0080/0150-0010-0070-0080.html |    15-1-708. Release of lien, MCA  |  |
| MTS_0150-0010-0070-0090 | 200 | 9285 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0070/section_0090/0150-0010-0070-0090.html |    15-1-709. Remedy not exclusive, MCA  |  |
| MTS_0150-0010-0080-0010 | 200 | 9809 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0080/section_0010/0150-0010-0080-0010.html |    15-1-801. Definitions, MCA  |  |
| MTS_0150-0010-0080-0020 | 200 | 9619 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0080/section_0020/0150-0010-0080-0020.html |    15-1-802. Taxes to be paid by electronic funds transfer -- limitation, MCA  |  |
| MTS_0150-0010-0080-0030 | 200 | 9768 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0080/section_0030/0150-0010-0080-0030.html |    15-1-803. Rules, MCA  |  |
| MTS_0150-0010-0100-0010 | 200 | 8908 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0100/section_0010/0150-0010-0100-0010.html |    15-1-1001. Terminated, MCA  |  |
| MTS_0150-0010-0100-0020 | 200 | 9114 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0100/section_0020/0150-0010-0100-0020.html |    15-1-1002. Terminated, MCA  |  |
| MTS_0150-0010-0100-0030 | 200 | 9114 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0100/section_0030/0150-0010-0100-0030.html |    15-1-1003. Terminated, MCA  |  |
| MTS_0150-0010-0100-0040 | 200 | 9114 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0100/section_0040/0150-0010-0100-0040.html |    15-1-1004. Terminated, MCA  |  |
| MTS_0150-0010-0100-0050 | 200 | 9114 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0100/section_0050/0150-0010-0100-0050.html |    15-1-1005. Terminated, MCA  |  |
| MTS_0150-0010-0100-0060 | 200 | 9114 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0100/section_0060/0150-0010-0100-0060.html |    15-1-1006. Terminated, MCA  |  |
| MTS_0150-0010-0100-0070 | 200 | 8911 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0100/section_0070/0150-0010-0100-0070.html |    15-1-1007. Terminated, MCA  |  |
| MTS_0150-0010-0230-0010 | 200 | 8921 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0230/section_0010/0150-0010-0230-0010.html |    15-1-2301. Terminated, MCA  |  |
| MTS_0150-0010-0230-0020 | 200 | 9069 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0230/section_0020/0150-0010-0230-0020.html |    15-1-2302. Terminated, MCA  |  |
| MTS_0150-0010-0230-0030 | 200 | 9069 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0230/section_0030/0150-0010-0230-0030.html |    15-1-2303. Terminated, MCA  |  |
| MTS_0150-0010-0230-0040 | 200 | 9071 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0230/section_0040/0150-0010-0230-0040.html |    15-1-2304. Terminated, MCA  |  |
| MTS_0150-0010-0230-0050 | 200 | 9071 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0230/section_0050/0150-0010-0230-0050.html |    15-1-2305. Terminated, MCA  |  |
| MTS_0150-0010-0230-0060 | 200 | 9071 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0230/section_0060/0150-0010-0230-0060.html |    15-1-2306. Terminated, MCA  |  |
| MTS_0150-0010-0230-0070 | 200 | 8868 | https://leg.mt.gov/bills/mca/title_0150/chapter_0010/part_0230/section_0070/0150-0010-0230-0070.html |    15-1-2307. Terminated, MCA  |  |
| MTS_0150-0020-0010-0010 | 200 | 9970 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0010/section_0010/0150-0020-0010-0010.html |    15-2-101. Montana tax appeal board -- appointment of members -- term of offic |  |
| MTS_0150-0020-0010-0020 | 200 | 12582 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0010/section_0020/0150-0020-0010-0020.html |    15-2-102. Qualification and compensation, MCA  |  |
| MTS_0150-0020-0010-0030 | 200 | 9953 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0010/section_0030/0150-0020-0010-0030.html |    15-2-103. Organization, quorum, sessions, MCA  |  |
| MTS_0150-0020-0010-0040 | 200 | 10053 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0010/section_0040/0150-0020-0010-0040.html |    15-2-104. Employees -- expenses -- minutes -- rules, MCA  |  |
| MTS_0150-0020-0010-0050 | 200 | 9444 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0010/section_0050/0150-0020-0010-0050.html |    15-2-105. Office, furnishings, and supplies, MCA  |  |
| MTS_0150-0020-0010-0060 | 200 | 9182 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0010/section_0060/0150-0020-0010-0060.html |    15-2-106. Seal, MCA  |  |
| MTS_0150-0020-0020-0010 | 200 | 11324 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0020/section_0010/0150-0020-0020-0010.html |    15-2-201. Powers and duties, MCA  |  |
| MTS_0150-0020-0030-0010 | 200 | 17117 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0030/section_0010/0150-0020-0030-0010.html |    15-2-301. Appeal of county tax appeal board decisions -- rulemaking, MCA  |  |
| MTS_0150-0020-0030-0020 | 200 | 12600 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0030/section_0020/0150-0020-0030-0020.html |    15-2-302. Direct appeal from department decision to Montana tax appeal board  |  |
| MTS_0150-0020-0030-0030 | 200 | 12448 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0030/section_0030/0150-0020-0030-0030.html |    15-2-303. Judicial review -- costs and attorney fees, MCA  |  |
| MTS_0150-0020-0030-0040 | 200 | 11899 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0030/section_0040/0150-0020-0030-0040.html |    15-2-304. Petition for interlocutory adjudication, MCA  |  |
| MTS_0150-0020-0030-0050 | 200 | 9817 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0030/section_0050/0150-0020-0030-0050.html |    15-2-305. Jurisdiction to make interlocutory adjudication, MCA  |  |
| MTS_0150-0020-0030-0060 | 200 | 11302 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0030/section_0060/0150-0020-0030-0060.html |    15-2-306. Board to order refund, MCA  |  |
| MTS_0150-0020-0030-0070 | 200 | 9034 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0030/section_0070/0150-0020-0030-0070.html |    15-2-307. Repealed, MCA  |  |
| MTS_0150-0020-0030-0080 | 200 | 9021 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0030/section_0080/0150-0020-0030-0080.html |    15-2-308. Repealed, MCA  |  |
| MTS_0150-0020-0030-0090 | 200 | 9021 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0030/section_0090/0150-0020-0030-0090.html |    15-2-309. Repealed, MCA  |  |
| MTS_0150-0020-0030-0100 | 200 | 8821 | https://leg.mt.gov/bills/mca/title_0150/chapter_0020/part_0030/section_0100/0150-0020-0030-0100.html |    15-2-310. Repealed, MCA  |  |
| MTS_0150-0060-0010-0010 | 200 | 9715 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0010/0150-0060-0010-0010.html |    15-6-101. Property subject to taxation -- classification, MCA  |  |
| MTS_0150-0060-0010-0020 | 200 | 9096 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0020/0150-0060-0010-0020.html |    15-6-102. Repealed, MCA  |  |
| MTS_0150-0060-0010-0030 | 200 | 9058 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0030/0150-0060-0010-0030.html |    15-6-103. Repealed, MCA  |  |
| MTS_0150-0060-0010-0040 | 200 | 9058 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0040/0150-0060-0010-0040.html |    15-6-104. Repealed, MCA  |  |
| MTS_0150-0060-0010-0050 | 200 | 9058 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0050/0150-0060-0010-0050.html |    15-6-105. Repealed, MCA  |  |
| MTS_0150-0060-0010-0060 | 200 | 9085 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0060/0150-0060-0010-0060.html |    15-6-106. Repealed, MCA  |  |
| MTS_0150-0060-0010-0070 | 200 | 9058 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0070/0150-0060-0010-0070.html |    15-6-107. Repealed, MCA  |  |
| MTS_0150-0060-0010-0080 | 200 | 9058 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0080/0150-0060-0010-0080.html |    15-6-108. Repealed, MCA  |  |
| MTS_0150-0060-0010-0090 | 200 | 9058 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0090/0150-0060-0010-0090.html |    15-6-109. Repealed, MCA  |  |
| MTS_0150-0060-0010-0100 | 200 | 9093 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0100/0150-0060-0010-0100.html |    15-6-110. Repealed, MCA  |  |
| MTS_0150-0060-0010-0110 | 200 | 9061 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0110/0150-0060-0010-0110.html |    15-6-111. Repealed, MCA  |  |
| MTS_0150-0060-0010-0120 | 200 | 9061 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0120/0150-0060-0010-0120.html |    15-6-112. Repealed, MCA  |  |
| MTS_0150-0060-0010-0130 | 200 | 9061 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0130/0150-0060-0010-0130.html |    15-6-113. Repealed, MCA  |  |
| MTS_0150-0060-0010-0140 | 200 | 9061 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0140/0150-0060-0010-0140.html |    15-6-114. Repealed, MCA  |  |
| MTS_0150-0060-0010-0150 | 200 | 9093 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0150/0150-0060-0010-0150.html |    15-6-115. Repealed, MCA  |  |
| MTS_0150-0060-0010-0160 | 200 | 9123 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0160/0150-0060-0010-0160.html |    15-6-116. Repealed, MCA  |  |
| MTS_0150-0060-0010-0170 | 200 | 9061 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0170/0150-0060-0010-0170.html |    15-6-117. Repealed, MCA  |  |
| MTS_0150-0060-0010-0180 | 200 | 9061 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0180/0150-0060-0010-0180.html |    15-6-118. Repealed, MCA  |  |
| MTS_0150-0060-0010-0190 | 200 | 9061 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0190/0150-0060-0010-0190.html |    15-6-119. Repealed, MCA  |  |
| MTS_0150-0060-0010-0200 | 200 | 9048 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0200/0150-0060-0010-0200.html |    15-6-120. Repealed, MCA  |  |
| MTS_0150-0060-0010-0210 | 200 | 9118 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0210/0150-0060-0010-0210.html |    15-6-121. Repealed, MCA  |  |
| MTS_0150-0060-0010-0220 | 200 | 9532 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0220/0150-0060-0010-0220.html |    15-6-122. Business equipment tax on business personal property, MCA  |  |
| MTS_0150-0060-0010-0230 | 200 | 8930 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0230/0150-0060-0010-0230.html |    15-6-123. through 15-6-130 reserved, MCA  |  |
| MTS_0150-0060-0010-0310 | 200 | 10579 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0310/0150-0060-0010-0310.html |    15-6-131. Class one property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0320 | 200 | 9676 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0320/0150-0060-0010-0320.html |    15-6-132. Class two property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0330 | 200 | 12301 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0330/0150-0060-0010-0330.html |    15-6-133. Class three property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0340 | 200 | 19760 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0340/0150-0060-0010-0340.html |    15-6-134. Class four property -- description -- taxable percentage -- definit |  |
| MTS_0150-0060-0010-0350 | 200 | 19217 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0350/0150-0060-0010-0350.html |    15-6-135. Class five property -- description -- taxable percentage -- exempti |  |
| MTS_0150-0060-0010-0360 | 200 | 9588 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0360/0150-0060-0010-0360.html |    15-6-136. Repealed, MCA  |  |
| MTS_0150-0060-0010-0370 | 200 | 10963 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0370/0150-0060-0010-0370.html |    15-6-137. Class seven property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0380 | 200 | 21725 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0380/0150-0060-0010-0380.html |    15-6-138. Class eight property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0390 | 200 | 9205 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0390/0150-0060-0010-0390.html |    15-6-139. Repealed, MCA  |  |
| MTS_0150-0060-0010-0400 | 200 | 9298 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0400/0150-0060-0010-0400.html |    15-6-140. Repealed, MCA  |  |
| MTS_0150-0060-0010-0410 | 200 | 14426 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0410/0150-0060-0010-0410.html |    15-6-141. Class nine property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0420 | 200 | 9273 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0420/0150-0060-0010-0420.html |    15-6-142. Repealed, MCA  |  |
| MTS_0150-0060-0010-0430 | 200 | 10792 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0430/0150-0060-0010-0430.html |    15-6-143. Class ten property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0440 | 200 | 9189 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0440/0150-0060-0010-0440.html |    15-6-144. Repealed, MCA  |  |
| MTS_0150-0060-0010-0450 | 200 | 12954 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0450/0150-0060-0010-0450.html |    15-6-145. Class twelve property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0460 | 200 | 9204 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0460/0150-0060-0010-0460.html |    15-6-146. Repealed, MCA  |  |
| MTS_0150-0060-0010-0470 | 200 | 9061 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0470/0150-0060-0010-0470.html |    15-6-147. Repealed, MCA  |  |
| MTS_0150-0060-0010-0480 | 200 | 9031 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0480/0150-0060-0010-0480.html |    15-6-148. Repealed, MCA  |  |
| MTS_0150-0060-0010-0490 | 200 | 9031 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0490/0150-0060-0010-0490.html |    15-6-149. Repealed, MCA  |  |
| MTS_0150-0060-0010-0500 | 200 | 9034 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0500/0150-0060-0010-0500.html |    15-6-150. Repealed, MCA  |  |
| MTS_0150-0060-0010-0510 | 200 | 8852 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0510/0150-0060-0010-0510.html |    15-6-151. Renumbered 15-6-191, MCA  |  |
| MTS_0150-0060-0010-0520 | 200 | 8852 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0520/0150-0060-0010-0520.html |    15-6-152. Renumbered 15-6-192, MCA  |  |
| MTS_0150-0060-0010-0530 | 200 | 9042 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0530/0150-0060-0010-0530.html |    15-6-153. Repealed, MCA  |  |
| MTS_0150-0060-0010-0540 | 200 | 9031 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0540/0150-0060-0010-0540.html |    15-6-154. Repealed, MCA  |  |
| MTS_0150-0060-0010-0550 | 200 | 9114 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0550/0150-0060-0010-0550.html |    15-6-155. Repealed, MCA  |  |
| MTS_0150-0060-0010-0560 | 200 | 21628 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0560/0150-0060-0010-0560.html |    15-6-156. Class thirteen property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0570 | 200 | 25708 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0570/0150-0060-0010-0570.html |    15-6-157. Class fourteen property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0580 | 200 | 16584 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0580/0150-0060-0010-0580.html |    15-6-158. Class fifteen property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0590 | 200 | 10779 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0590/0150-0060-0010-0590.html |    15-6-159. Class sixteen property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0600 | 200 | 8923 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0600/0150-0060-0010-0600.html |    15-6-160. and 15-6-161 reserved, MCA  |  |
| MTS_0150-0060-0010-0620 | 200 | 16180 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0620/0150-0060-0010-0620.html |    15-6-162. Class seventeen property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0630 | 200 | 13465 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0630/0150-0060-0010-0630.html |    15-6-163. Class eighteen property -- description -- taxable percentage, MCA  |  |
| MTS_0150-0060-0010-0640 | 200 | 8891 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0640/0150-0060-0010-0640.html |    15-6-164. through 15-6-190 reserved, MCA  |  |
| MTS_0150-0060-0010-0910 | 200 | 9323 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0910/0150-0060-0010-0910.html |    15-6-191. Repealed, MCA  |  |
| MTS_0150-0060-0010-0920 | 200 | 9182 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0920/0150-0060-0010-0920.html |    15-6-192. Repealed, MCA  |  |
| MTS_0150-0060-0010-0930 | 200 | 9084 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0930/0150-0060-0010-0930.html |    15-6-193. Repealed, MCA  |  |
| MTS_0150-0060-0010-0940 | 200 | 9587 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0010/section_0940/0150-0060-0010-0940.html |    15-6-194. Rules, MCA  |  |
| MTS_0150-0060-0020-0010 | 200 | 28512 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0010/0150-0060-0020-0010.html |    15-6-201. Governmental, charitable, and educational categories -- exempt prop |  |
| MTS_0150-0060-0020-0020 | 200 | 13942 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0020/0150-0060-0020-0020.html |    15-6-202. Freeport merchandise and business inventories exemption -- definiti |  |
| MTS_0150-0060-0020-0030 | 200 | 12143 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0030/0150-0060-0020-0030.html |    15-6-203. Veterans' exemptions -- clubhouse -- land -- incompetent veterans'  |  |
| MTS_0150-0060-0020-0040 | 200 | 10510 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0040/0150-0060-0020-0040.html |    15-6-204. Money and credits exemption, MCA  |  |
| MTS_0150-0060-0020-0050 | 200 | 9924 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0050/0150-0060-0020-0050.html |    15-6-205. State water conservation projects exempt, MCA  |  |
| MTS_0150-0060-0020-0060 | 200 | 10449 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0060/0150-0060-0020-0060.html |    15-6-206. Irrigation and drainage facilities -- when exempt, MCA  |  |
| MTS_0150-0060-0020-0070 | 200 | 12468 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0070/0150-0060-0020-0070.html |    15-6-207. Agricultural producer exemptions -- products -- unused beet equipme |  |
| MTS_0150-0060-0020-0080 | 200 | 11329 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0080/0150-0060-0020-0080.html |    15-6-208. Mineral exemptions -- small coal or metal mines producer -- travert |  |
| MTS_0150-0060-0020-0090 | 200 | 11361 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0090/0150-0060-0020-0090.html |    15-6-209. Community services buildings exempt, MCA  |  |
| MTS_0150-0060-0020-0100 | 200 | 9064 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0100/0150-0060-0020-0100.html |    15-6-210. Repealed, MCA  |  |
| MTS_0150-0060-0020-0110 | 200 | 9223 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0110/0150-0060-0020-0110.html |    15-6-211. Repealed, MCA  |  |
| MTS_0150-0060-0020-0120 | 200 | 9212 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0120/0150-0060-0020-0120.html |    15-6-212. Repealed, MCA  |  |
| MTS_0150-0060-0020-0130 | 200 | 9237 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0130/0150-0060-0020-0130.html |    15-6-213. Down-hole equipment in oil and gas wells exempt, MCA  |  |
| MTS_0150-0060-0020-0140 | 200 | 9171 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0140/0150-0060-0020-0140.html |    15-6-214. Terminated, MCA  |  |
| MTS_0150-0060-0020-0150 | 200 | 10170 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0150/0150-0060-0020-0150.html |    15-6-215. Exemption for motion picture and television commercial property, MC |  |
| MTS_0150-0060-0020-0160 | 200 | 11213 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0160/0150-0060-0020-0160.html |    15-6-216. Exemption of improvements made to commercial buildings to remove ba |  |
| MTS_0150-0060-0020-0170 | 200 | 10339 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0170/0150-0060-0020-0170.html |    15-6-217. Exemption for vehicle of certain health care professionals, MCA  |  |
| MTS_0150-0060-0020-0180 | 200 | 10167 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0180/0150-0060-0020-0180.html |    15-6-218. Intangible personal property exemption, MCA  |  |
| MTS_0150-0060-0020-0190 | 200 | 23416 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0190/0150-0060-0020-0190.html |    15-6-219. Personal and other property exemptions, MCA  |  |
| MTS_0150-0060-0020-0200 | 200 | 13091 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0200/0150-0060-0020-0200.html |    15-6-220. Agricultural processing facilities exemption, MCA  |  |
| MTS_0150-0060-0020-0210 | 200 | 15151 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0210/0150-0060-0020-0210.html |    15-6-221. Exemption for rental housing providing affordable housing to lower- |  |
| MTS_0150-0060-0020-0220 | 200 | 9150 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0220/0150-0060-0020-0220.html |    15-6-222. Repealed, MCA  |  |
| MTS_0150-0060-0020-0230 | 200 | 9201 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0230/0150-0060-0020-0230.html |    15-6-223. Timber exemption, MCA  |  |
| MTS_0150-0060-0020-0240 | 200 | 9813 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0240/0150-0060-0020-0240.html |    15-6-224. Nonfossil energy generation, MCA  |  |
| MTS_0150-0060-0020-0250 | 200 | 11380 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0250/0150-0060-0020-0250.html |    15-6-225. Small electrical generation equipment exemption, MCA  |  |
| MTS_0150-0060-0020-0260 | 200 | 9137 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0260/0150-0060-0020-0260.html |    15-6-226. Terminated, MCA  |  |
| MTS_0150-0060-0020-0270 | 200 | 10280 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0270/0150-0060-0020-0270.html |    15-6-227. Property on railroad land leased by nonprofit organizations, MCA  |  |
| MTS_0150-0060-0020-0280 | 200 | 11012 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0280/0150-0060-0020-0280.html |    15-6-228. Property subject to registration fee, MCA  |  |
| MTS_0150-0060-0020-0290 | 200 | 12367 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0290/0150-0060-0020-0290.html |    15-6-229. Exemption for land adjacent to transmission line right-of-way easem |  |
| MTS_0150-0060-0020-0300 | 200 | 13175 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0300/0150-0060-0020-0300.html |    15-6-230. Temporary exemption for certain tribal property -- rulemaking, MCA  |  |
| MTS_0150-0060-0020-0310 | 200 | 9056 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0310/0150-0060-0020-0310.html |    15-6-231. Terminated, MCA  |  |
| MTS_0150-0060-0020-0320 | 200 | 9082 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0320/0150-0060-0020-0320.html |    15-6-232. Terminated, MCA  |  |
| MTS_0150-0060-0020-0330 | 200 | 9069 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0330/0150-0060-0020-0330.html |    15-6-233. Terminated, MCA  |  |
| MTS_0150-0060-0020-0340 | 200 | 9311 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0340/0150-0060-0020-0340.html |    15-6-234. Duty to report change in use, MCA  |  |
| MTS_0150-0060-0020-0350 | 200 | 9645 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0350/0150-0060-0020-0350.html |    15-6-235. New property tax exemptions -- department notification to local gov |  |
| MTS_0150-0060-0020-0360 | 200 | 8846 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0360/0150-0060-0020-0360.html |    15-6-236. reserved, MCA  |  |
| MTS_0150-0060-0020-0370 | 200 | 10598 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0370/0150-0060-0020-0370.html |    15-6-237. Periodic review of exempt property -- rulemaking, MCA  |  |
| MTS_0150-0060-0020-0380 | 200 | 10548 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0380/0150-0060-0020-0380.html |    15-6-238. Public information on exempt property, MCA  |  |
| MTS_0150-0060-0020-0390 | 200 | 8825 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0390/0150-0060-0020-0390.html |    15-6-239. reserved, MCA  |  |
| MTS_0150-0060-0020-0400 | 200 | 15687 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0400/0150-0060-0020-0400.html |    15-6-240. Intangible land value property exemption -- application procedure,  |  |
| MTS_0150-0060-0020-0410 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0410/0150-0060-0020-0410.html |    15-6-241. Mobile home exemption, MCA  |  |
| MTS_0150-0060-0020-0420 | 200 | 12299 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0420/0150-0060-0020-0420.html |    15-6-242. Exemption -- abandoned housetrailer, manufactured home, or mobile h |  |
| MTS_0150-0060-0020-0430 | 200 | 10671 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0430/0150-0060-0020-0430.html |    15-6-243. Fiber optic or coaxial cable abatement -- wireless infrastructure a |  |
| MTS_0150-0060-0020-0440 | 200 | 12729 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0440/0150-0060-0020-0440.html |    15-6-244. Temporary exemption for residential subdivision development -- rule |  |
| MTS_0150-0060-0020-0450 | 200 | 11142 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0020/section_0450/0150-0060-0020-0450.html |    15-6-245. Statement of potential tax liability -- rulemaking authority, MCA  |  |
| MTS_0150-0060-0030-0010 | 200 | 16752 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0030/section_0010/0150-0060-0030-0010.html |    15-6-301. Definitions, MCA  |  |
| MTS_0150-0060-0030-0020 | 200 | 16496 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0030/section_0020/0150-0060-0030-0020.html |    15-6-302. Property tax assistance -- rulemaking, MCA  |  |
| MTS_0150-0060-0030-0030 | 200 | 8950 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0030/section_0030/0150-0060-0030-0030.html |    15-6-303. and 15-6-304 reserved, MCA  |  |
| MTS_0150-0060-0030-0050 | 200 | 14607 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0030/section_0050/0150-0060-0030-0050.html |    15-6-305. Property tax assistance program -- fixed or limited income -- infla |  |
| MTS_0150-0060-0030-0060 | 200 | 8957 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0030/section_0060/0150-0060-0030-0060.html |    15-6-306. through 15-6-310 reserved, MCA  |  |
| MTS_0150-0060-0030-0110 | 200 | 16352 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0030/section_0110/0150-0060-0030-0110.html |    15-6-311. Disabled veteran program, MCA  |  |
| MTS_0150-0060-0030-0120 | 200 | 11451 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0030/section_0120/0150-0060-0030-0120.html |    15-6-312. Time period for property tax assistance, MCA  |  |
| MTS_0150-0060-0030-0130 | 200 | 8805 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0030/section_0130/0150-0060-0030-0130.html |    15-6-313. reserved, MCA  |  |
| MTS_0150-0060-0030-0140 | 200 | 15904 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0030/section_0140/0150-0060-0030-0140.html |    15-6-314. Injured first responder program, MCA  |  |
| MTS_0150-0060-0040-0010 | 200 | 12939 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0010/0150-0060-0040-0010.html |    15-6-401. Legislative findings -- local government charters and fixed mill le |  |
| MTS_0150-0060-0040-0020 | 200 | 13391 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0020/0150-0060-0040-0020.html |    15-6-402. Definitions, MCA  |  |
| MTS_0150-0060-0040-0030 | 200 | 8963 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0030/0150-0060-0040-0030.html |    15-6-403. and 15-6-404 reserved, MCA  |  |
| MTS_0150-0060-0040-0050 | 200 | 14200 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0050/0150-0060-0040-0050.html |    15-6-405. Homestead reduced tax rate -- application -- limitations, MCA  |  |
| MTS_0150-0060-0040-0060 | 200 | 8938 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0060/0150-0060-0040-0060.html |    15-6-406. reserved, MCA  |  |
| MTS_0150-0060-0040-0070 | 200 | 10974 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0070/0150-0060-0040-0070.html |    15-6-407. Refund for failure to claim homestead reduced tax rate -- statutory |  |
| MTS_0150-0060-0040-0080 | 200 | 9059 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0080/0150-0060-0040-0080.html |    15-6-408. through 15-6-410 reserved, MCA  |  |
| MTS_0150-0060-0040-0110 | 200 | 14512 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0110/0150-0060-0040-0110.html |    15-6-411. Rental property reduced tax rate -- application -- limitations, MCA |  |
| MTS_0150-0060-0040-0120 | 200 | 9093 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0120/0150-0060-0040-0120.html |    15-6-412. through 15-6-414 reserved, MCA  |  |
| MTS_0150-0060-0040-0150 | 200 | 13613 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0150/0150-0060-0040-0150.html |    15-6-415. Homestead and rental property reduced tax rates -- improper approva |  |
| MTS_0150-0060-0040-0160 | 200 | 9047 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0160/0150-0060-0040-0160.html |    15-6-416. and 15-6-417 reserved, MCA  |  |
| MTS_0150-0060-0040-0180 | 200 | 11616 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0180/0150-0060-0040-0180.html |    15-6-418. Appeal or denial of reduced tax rate, MCA  |  |
| MTS_0150-0060-0040-0190 | 200 | 8972 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0190/0150-0060-0040-0190.html |    15-6-419. through 15-6-424 reserved, MCA  |  |
| MTS_0150-0060-0040-0250 | 200 | 8980 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0040/section_0250/0150-0060-0040-0250.html |    15-6-425. Rulemaking authority, MCA  |  |
| MTS_0150-0060-0050-0010 | 200 | 8973 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0050/section_0010/0150-0060-0050-0010.html |    15-6-501. Short title, MCA  |  |
| MTS_0150-0060-0050-0020 | 200 | 9543 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0050/section_0020/0150-0060-0050-0020.html |    15-6-502. Legislative purpose, MCA  |  |
| MTS_0150-0060-0050-0030 | 200 | 14278 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0050/section_0030/0150-0060-0050-0030.html |    15-6-503. Definitions, MCA  |  |
| MTS_0150-0060-0050-0040 | 200 | 11732 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0050/section_0040/0150-0060-0050-0040.html |    15-6-504. Petition -- approval or denial by local government -- compelling ne |  |
| MTS_0150-0060-0050-0050 | 200 | 10177 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0050/section_0050/0150-0060-0050-0050.html |    15-6-505. Projects subject to existing development laws -- preference for sen |  |
| MTS_0150-0060-0050-0060 | 200 | 13387 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0050/section_0060/0150-0060-0050-0060.html |    15-6-506. Temporary exemption for senior care and housing development project |  |
| MTS_0150-0060-0050-0070 | 200 | 9785 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0050/section_0070/0150-0060-0050-0070.html |    15-6-507. Reports to local government by tax-exempt senior care and housing s |  |
| MTS_0150-0060-0050-0080 | 200 | 9004 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0050/section_0080/0150-0060-0050-0080.html |    15-6-508. Rulemaking, MCA  |  |
| MTS_0150-0060-0070-0010 | 200 | 10970 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0070/section_0010/0150-0060-0070-0010.html |    15-6-701. Property tax assistance for primary residences, MCA  |  |
| MTS_0150-0060-0070-0020 | 200 | 12465 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0070/section_0020/0150-0060-0070-0020.html |    15-6-702. State property tax assistance account, MCA  |  |
| MTS_0150-0060-0070-0030 | 200 | 14421 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0070/section_0030/0150-0060-0070-0030.html |    15-6-703. Certification of primary residence for state property tax assistanc |  |
| MTS_0150-0060-0070-0040 | 200 | 10271 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0070/section_0040/0150-0060-0070-0040.html |    15-6-704. State property tax assistance -- penalty for false or fraudulent ap |  |
| MTS_0150-0060-0070-0050 | 200 | 11293 | https://leg.mt.gov/bills/mca/title_0150/chapter_0060/part_0070/section_0050/0150-0060-0070-0050.html |    15-6-705. Appeal of denial of certification of primary residence, MCA  |  |
| MTS_0150-0070-0010-0010 | 200 | 10683 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0010/0150-0070-0010-0010.html |    15-7-101. Classification and appraisal -- duties of department of revenue, MC |  |
| MTS_0150-0070-0010-0020 | 200 | 28131 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0020/0150-0070-0010-0020.html |    15-7-102. Notice of classification, market value, and taxable value to owners |  |
| MTS_0150-0070-0010-0030 | 200 | 13396 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0030/0150-0070-0010-0030.html |    15-7-103. Classification and appraisal -- general and uniform methods, MCA  |  |
| MTS_0150-0070-0010-0040 | 200 | 9062 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0040/0150-0070-0010-0040.html |    15-7-104. Repealed, MCA  |  |
| MTS_0150-0070-0010-0050 | 200 | 9528 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0050/0150-0070-0010-0050.html |    15-7-105. Purpose, MCA  |  |
| MTS_0150-0070-0010-0060 | 200 | 11625 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0060/0150-0070-0010-0060.html |    15-7-106. Courses of instruction, examination, and certification -- additiona |  |
| MTS_0150-0070-0010-0070 | 200 | 9880 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0070/0150-0070-0010-0070.html |    15-7-107. Certification required, MCA  |  |
| MTS_0150-0070-0010-0080 | 200 | 9213 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0080/0150-0070-0010-0080.html |    15-7-108. Land split, MCA  |  |
| MTS_0150-0070-0010-0090 | 200 | 8711 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0090/0150-0070-0010-0090.html |    15-7-109. reserved, MCA  |  |
| MTS_0150-0070-0010-0100 | 200 | 9861 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0100/0150-0070-0010-0100.html |    15-7-110. Purpose -- reappraisal cycle, MCA  |  |
| MTS_0150-0070-0010-0110 | 200 | 14414 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0110/0150-0070-0010-0110.html |    15-7-111. Periodic reappraisal of certain taxable property, MCA  |  |
| MTS_0150-0070-0010-0120 | 200 | 9466 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0120/0150-0070-0010-0120.html |    15-7-112. Equalization of valuations, MCA  |  |
| MTS_0150-0070-0010-0130 | 200 | 9344 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0130/0150-0070-0010-0130.html |    15-7-113. Program exclusive, MCA  |  |
| MTS_0150-0070-0010-0140 | 200 | 9421 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0140/0150-0070-0010-0140.html |    15-7-114. Law supplemental, MCA  |  |
| MTS_0150-0070-0010-0150 | 200 | 8812 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0150/0150-0070-0010-0150.html |    15-7-115. through 15-7-120 reserved, MCA  |  |
| MTS_0150-0070-0010-0210 | 200 | 9037 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0210/0150-0070-0010-0210.html |    15-7-121. Repealed, MCA  |  |
| MTS_0150-0070-0010-0220 | 200 | 9038 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0220/0150-0070-0010-0220.html |    15-7-122. Repealed, MCA  |  |
| MTS_0150-0070-0010-0230 | 200 | 8802 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0230/0150-0070-0010-0230.html |    15-7-123. through 15-7-130 reserved, MCA  |  |
| MTS_0150-0070-0010-0310 | 200 | 9166 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0310/0150-0070-0010-0310.html |    15-7-131. Policy, MCA  |  |
| MTS_0150-0070-0010-0320 | 200 | 9024 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0320/0150-0070-0010-0320.html |    15-7-132. Repealed, MCA  |  |
| MTS_0150-0070-0010-0330 | 200 | 9026 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0330/0150-0070-0010-0330.html |    15-7-133. Repealed, MCA  |  |
| MTS_0150-0070-0010-0340 | 200 | 9008 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0340/0150-0070-0010-0340.html |    15-7-134. Repealed, MCA  |  |
| MTS_0150-0070-0010-0350 | 200 | 8888 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0350/0150-0070-0010-0350.html |    15-7-135. and 15-7-136 reserved, MCA  |  |
| MTS_0150-0070-0010-0370 | 200 | 10242 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0370/0150-0070-0010-0370.html |    15-7-137. Department of revenue notification of new construction by local gov |  |
| MTS_0150-0070-0010-0380 | 200 | 12050 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0380/0150-0070-0010-0380.html |    15-7-138. Notice of classification and appraisal to single address for owners |  |
| MTS_0150-0070-0010-0390 | 200 | 15955 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0390/0150-0070-0010-0390.html |    15-7-139. Requirements for entry on property by property valuation staff empl |  |
| MTS_0150-0070-0010-0400 | 200 | 10424 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0400/0150-0070-0010-0400.html |    15-7-140. Notice appraisal and audit -- statement of rights, MCA  |  |
| MTS_0150-0070-0010-0410 | 200 | 10845 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0010/section_0410/0150-0070-0010-0410.html |    15-7-141. County notification of proposed valuation decrease -- meeting, MCA  |  |
| MTS_0150-0070-0020-0010 | 200 | 15755 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0010/0150-0070-0020-0010.html |    15-7-201. Legislative intent -- value of agricultural property, MCA  |  |
| MTS_0150-0070-0020-0020 | 200 | 20231 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0020/0150-0070-0020-0020.html |    15-7-202. Eligibility of land for valuation as agricultural, MCA  |  |
| MTS_0150-0070-0020-0030 | 200 | 9369 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0030/0150-0070-0020-0030.html |    15-7-203. Agricultural uses only considered in valuation, MCA  |  |
| MTS_0150-0070-0020-0040 | 200 | 9069 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0040/0150-0070-0020-0040.html |    15-7-204. Repealed, MCA  |  |
| MTS_0150-0070-0020-0050 | 200 | 9087 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0050/0150-0070-0020-0050.html |    15-7-205. Repealed, MCA  |  |
| MTS_0150-0070-0020-0060 | 200 | 9845 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0060/0150-0070-0020-0060.html |    15-7-206. Improvements on agricultural land, MCA  |  |
| MTS_0150-0070-0020-0070 | 200 | 9478 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0070/0150-0070-0020-0070.html |    15-7-207. Continuance of valuation as agricultural land, MCA  |  |
| MTS_0150-0070-0020-0080 | 200 | 9948 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0080/0150-0070-0020-0080.html |    15-7-208. Reclassification by department, MCA  |  |
| MTS_0150-0070-0020-0090 | 200 | 9806 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0090/0150-0070-0020-0090.html |    15-7-209. Reclassification by owner -- lien, MCA  |  |
| MTS_0150-0070-0020-0100 | 200 | 9620 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0100/0150-0070-0020-0100.html |    15-7-210. Tax on change of use of part of tract, MCA  |  |
| MTS_0150-0070-0020-0110 | 200 | 9089 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0110/0150-0070-0020-0110.html |    15-7-211. Repealed, MCA  |  |
| MTS_0150-0070-0020-0120 | 200 | 9416 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0120/0150-0070-0020-0120.html |    15-7-212. Tract crossing county line -- whole, MCA  |  |
| MTS_0150-0070-0020-0130 | 200 | 9074 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0130/0150-0070-0020-0130.html |    15-7-213. Repealed, MCA  |  |
| MTS_0150-0070-0020-0140 | 200 | 9033 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0140/0150-0070-0020-0140.html |    15-7-214. Repealed, MCA  |  |
| MTS_0150-0070-0020-0150 | 200 | 9064 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0150/0150-0070-0020-0150.html |    15-7-215. Repealed, MCA  |  |
| MTS_0150-0070-0020-0160 | 200 | 9145 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0160/0150-0070-0020-0160.html |    15-7-216. Repealed, MCA  |  |
| MTS_0150-0070-0020-0170 | 200 | 8825 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0170/0150-0070-0020-0170.html |    15-7-217. through 15-7-220 reserved, MCA  |  |
| MTS_0150-0070-0020-0210 | 200 | 9093 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0210/0150-0070-0020-0210.html |    15-7-221. Repealed, MCA  |  |
| MTS_0150-0070-0020-0220 | 200 | 8819 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0020/section_0220/0150-0070-0020-0220.html |    15-7-222. Terminated, MCA  |  |
| MTS_0150-0070-0030-0010 | 200 | 8829 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0030/section_0010/0150-0070-0030-0010.html |    15-7-301. Short title, MCA  |  |
| MTS_0150-0070-0030-0020 | 200 | 9170 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0030/section_0020/0150-0070-0030-0020.html |    15-7-302. Purpose, MCA  |  |
| MTS_0150-0070-0030-0030 | 200 | 10197 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0030/section_0030/0150-0070-0030-0030.html |    15-7-303. Definitions, MCA  |  |
| MTS_0150-0070-0030-0040 | 200 | 10530 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0030/section_0040/0150-0070-0030-0040.html |    15-7-304. Report of transfers -- change of ownership records, MCA  |  |
| MTS_0150-0070-0030-0050 | 200 | 10898 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0030/section_0050/0150-0070-0030-0050.html |    15-7-305. Realty transfer certificate required, MCA  |  |
| MTS_0150-0070-0030-0060 | 200 | 9149 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0030/section_0060/0150-0070-0030-0060.html |    15-7-306. Rules, MCA  |  |
| MTS_0150-0070-0030-0070 | 200 | 11652 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0030/section_0070/0150-0070-0030-0070.html |    15-7-307. Certificate -- exceptions, MCA  |  |
| MTS_0150-0070-0030-0080 | 200 | 11003 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0030/section_0080/0150-0070-0030-0080.html |    15-7-308. Disclosure of information restricted -- exceptions, MCA  |  |
| MTS_0150-0070-0030-0090 | 200 | 9794 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0030/section_0090/0150-0070-0030-0090.html |    15-7-309. Classification or assessment methods, MCA  |  |
| MTS_0150-0070-0030-0100 | 200 | 9161 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0030/section_0100/0150-0070-0030-0100.html |    15-7-310. Penalty, MCA  |  |
| MTS_0150-0070-0030-0110 | 200 | 9087 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0030/section_0110/0150-0070-0030-0110.html |    15-7-311. Costs, MCA  |  |
| MTS_0150-0070-0040-0010 | 200 | 9319 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0040/section_0010/0150-0070-0040-0010.html |    15-7-401. Purpose, MCA  |  |
| MTS_0150-0070-0040-0020 | 200 | 10719 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0040/section_0020/0150-0070-0040-0020.html |    15-7-402. Application for residential appraisal of certain land and improveme |  |
| MTS_0150-0070-0040-0030 | 200 | 10632 | https://leg.mt.gov/bills/mca/title_0150/chapter_0070/part_0040/section_0030/0150-0070-0040-0030.html |    15-7-403. Rollback tax -- computation, MCA  |  |
| MTS_0150-0080-0010-0010 | 200 | 9232 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0010/0150-0080-0010-0010.html |    15-8-101. Department responsibilities, MCA  |  |
| MTS_0150-0080-0010-0020 | 200 | 10308 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0020/0150-0080-0010-0020.html |    15-8-102. County to furnish office space -- allowable charge, MCA  |  |
| MTS_0150-0080-0010-0030 | 200 | 9335 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0030/0150-0080-0010-0030.html |    15-8-103. Repealed, MCA  |  |
| MTS_0150-0080-0010-0040 | 200 | 10625 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0040/0150-0080-0010-0040.html |    15-8-104. Department audit and review of taxable value -- costs paid by depar |  |
| MTS_0150-0080-0010-0050 | 200 | 9096 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0050/0150-0080-0010-0050.html |    15-8-105. Repealed, MCA  |  |
| MTS_0150-0080-0010-0060 | 200 | 9049 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0060/0150-0080-0010-0060.html |    15-8-106. Repealed, MCA  |  |
| MTS_0150-0080-0010-0070 | 200 | 8875 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0070/0150-0080-0010-0070.html |    15-8-107. through 15-8-110 reserved, MCA  |  |
| MTS_0150-0080-0010-0110 | 200 | 21861 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0110/0150-0080-0010-0110.html |    15-8-111. Appraisal -- market value standard -- exceptions, MCA  |  |
| MTS_0150-0080-0010-0120 | 200 | 10272 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0120/0150-0080-0010-0120.html |    15-8-112. Assessments to be made on classification and appraisal, MCA  |  |
| MTS_0150-0080-0010-0130 | 200 | 9628 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0130/0150-0080-0010-0130.html |    15-8-113. Appeal from percentage assignment, MCA  |  |
| MTS_0150-0080-0010-0140 | 200 | 9197 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0140/0150-0080-0010-0140.html |    15-8-114. Repealed, MCA  |  |
| MTS_0150-0080-0010-0150 | 200 | 10603 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0150/0150-0080-0010-0150.html |    15-8-115. Department to defend property tax appeals -- costs and judgments, M |  |
| MTS_0150-0080-0010-0160 | 200 | 8984 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0160/0150-0080-0010-0160.html |    15-8-116. through 15-8-119 reserved, MCA  |  |
| MTS_0150-0080-0010-0200 | 200 | 9880 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0010/section_0200/0150-0080-0010-0200.html |    15-8-120. Restricted access to income and expense information submitted to de |  |
| MTS_0150-0080-0020-0010 | 200 | 13038 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0020/section_0010/0150-0080-0020-0010.html |    15-8-201. General assessment day, MCA  |  |
| MTS_0150-0080-0020-0020 | 200 | 12901 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0020/section_0020/0150-0080-0020-0020.html |    15-8-202. Motor vehicle assessment by department of justice, MCA  |  |
| MTS_0150-0080-0020-0030 | 200 | 9948 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0020/section_0030/0150-0080-0020-0030.html |    15-8-203. Repealed, MCA  |  |
| MTS_0150-0080-0020-0040 | 200 | 9659 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0020/section_0040/0150-0080-0020-0040.html |    15-8-204. Supplemental assessment, MCA  |  |
| MTS_0150-0080-0020-0050 | 200 | 9708 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0020/section_0050/0150-0080-0020-0050.html |    15-8-205. Initial assessment of class four trailer, manufactured home, and mo |  |
| MTS_0150-0080-0030-0010 | 200 | 12532 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0030/section_0010/0150-0080-0030-0010.html |    15-8-301. Statement -- what to contain, MCA  |  |
| MTS_0150-0080-0030-0020 | 200 | 9347 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0030/section_0020/0150-0080-0030-0020.html |    15-8-302. Repealed, MCA  |  |
| MTS_0150-0080-0030-0030 | 200 | 9843 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0030/section_0030/0150-0080-0030-0030.html |    15-8-303. Statement to be completed and returned to department, MCA  |  |
| MTS_0150-0080-0030-0040 | 200 | 10153 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0030/section_0040/0150-0080-0030-0040.html |    15-8-304. Enforcement powers of department, MCA  |  |
| MTS_0150-0080-0030-0050 | 200 | 9287 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0030/section_0050/0150-0080-0030-0050.html |    15-8-305. Repealed, MCA  |  |
| MTS_0150-0080-0030-0060 | 200 | 9587 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0030/section_0060/0150-0080-0030-0060.html |    15-8-306. Property concealed or misrepresented, MCA  |  |
| MTS_0150-0080-0030-0070 | 200 | 10935 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0030/section_0070/0150-0080-0030-0070.html |    15-8-307. Land assessment, MCA  |  |
| MTS_0150-0080-0030-0080 | 200 | 9497 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0030/section_0080/0150-0080-0030-0080.html |    15-8-308. Assessment not illegal for informality or delay, MCA  |  |
| MTS_0150-0080-0030-0090 | 200 | 9429 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0030/section_0090/0150-0080-0030-0090.html |    15-8-309. Violation and penalty, MCA  |  |
| MTS_0150-0080-0040-0010 | 200 | 9143 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0040/section_0010/0150-0080-0040-0010.html |    15-8-401. Consigned property, MCA  |  |
| MTS_0150-0080-0040-0020 | 200 | 9383 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0040/section_0020/0150-0080-0040-0020.html |    15-8-402. Property of person, MCA  |  |
| MTS_0150-0080-0040-0030 | 200 | 9196 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0040/section_0030/0150-0080-0040-0030.html |    15-8-403. Repealed, MCA  |  |
| MTS_0150-0080-0040-0040 | 200 | 10180 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0040/section_0040/0150-0080-0040-0040.html |    15-8-404. Property of particular types of firms, MCA  |  |
| MTS_0150-0080-0040-0050 | 200 | 9626 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0040/section_0050/0150-0080-0040-0050.html |    15-8-405. Street railroads, bridges, and ferries, MCA  |  |
| MTS_0150-0080-0040-0060 | 200 | 9985 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0040/section_0060/0150-0080-0040-0060.html |    15-8-406. Assessment of public utilities in one county, MCA  |  |
| MTS_0150-0080-0040-0070 | 200 | 9526 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0040/section_0070/0150-0080-0040-0070.html |    15-8-407. Railroads, MCA  |  |
| MTS_0150-0080-0040-0080 | 200 | 9783 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0040/section_0080/0150-0080-0040-0080.html |    15-8-408. Personal property, MCA  |  |
| MTS_0150-0080-0040-0090 | 200 | 9245 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0040/section_0090/0150-0080-0040-0090.html |    15-8-409. Property not otherwise specified, MCA  |  |
| MTS_0150-0080-0050-0010 | 200 | 9658 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0050/section_0010/0150-0080-0050-0010.html |    15-8-501. Assessment of unknown or absent owners, MCA  |  |
| MTS_0150-0080-0050-0020 | 200 | 9650 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0050/section_0020/0150-0080-0050-0020.html |    15-8-502. Representative status to be designated, MCA  |  |
| MTS_0150-0080-0050-0030 | 200 | 9611 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0050/section_0030/0150-0080-0050-0030.html |    15-8-503. Undistributed property of deceased persons, MCA  |  |
| MTS_0150-0080-0050-0040 | 200 | 9552 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0050/section_0040/0150-0080-0050-0040.html |    15-8-504. Property and money in litigation, MCA  |  |
| MTS_0150-0080-0050-0050 | 200 | 8955 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0050/section_0050/0150-0080-0050-0050.html |    15-8-505. through 15-8-510 reserved, MCA  |  |
| MTS_0150-0080-0050-0110 | 200 | 10136 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0050/section_0110/0150-0080-0050-0110.html |    15-8-511. Undivided interest in common elements of condominium project -- def |  |
| MTS_0150-0080-0050-0120 | 200 | 9885 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0050/section_0120/0150-0080-0050-0120.html |    15-8-512. Common elements serving residential or commercial development, MCA  |  |
| MTS_0150-0080-0060-0010 | 200 | 13471 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0060/section_0010/0150-0080-0060-0010.html |    15-8-601. Assessment revision -- conference for review, MCA  |  |
| MTS_0150-0080-0070-0010 | 200 | 12484 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0070/section_0010/0150-0080-0070-0010.html |    15-8-701. Property tax record -- definition -- listing property in, MCA  |  |
| MTS_0150-0080-0070-0020 | 200 | 9616 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0070/section_0020/0150-0080-0070-0020.html |    15-8-702. Persons desiring to be listed, MCA  |  |
| MTS_0150-0080-0070-0030 | 200 | 9395 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0070/section_0030/0150-0080-0070-0030.html |    15-8-703. Repealed, MCA  |  |
| MTS_0150-0080-0070-0040 | 200 | 9299 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0070/section_0040/0150-0080-0070-0040.html |    15-8-704. Map book, MCA  |  |
| MTS_0150-0080-0070-0050 | 200 | 9252 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0070/section_0050/0150-0080-0070-0050.html |    15-8-705. Repealed, MCA  |  |
| MTS_0150-0080-0070-0060 | 200 | 9563 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0070/section_0060/0150-0080-0070-0060.html |    15-8-706. Repealed, MCA  |  |
| MTS_0150-0080-0070-0070 | 200 | 9978 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0070/section_0070/0150-0080-0070-0070.html |    15-8-707. Correction of defects in property tax record, MCA  |  |
| MTS_0150-0080-0070-0080 | 200 | 10132 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0070/section_0080/0150-0080-0070-0080.html |    15-8-708. Omissions in delinquent lists -- correction by publication, MCA  |  |
| MTS_0150-0080-0070-0090 | 200 | 9798 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0070/section_0090/0150-0080-0070-0090.html |    15-8-709. Statement of changes to be sent to county clerk and recorder, MCA  |  |
| MTS_0150-0080-0070-0100 | 200 | 9884 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0070/section_0100/0150-0080-0070-0100.html |    15-8-710. Property tax record prima facie evidence, MCA  |  |
| MTS_0150-0080-0070-0110 | 200 | 9957 | https://leg.mt.gov/bills/mca/title_0150/chapter_0080/part_0070/section_0110/0150-0080-0070-0110.html |    15-8-711. List of owners of multiple, undivided interests in parcel of land t |  |
| MTS_0150-0090-0010-0010 | 200 | 10558 | https://leg.mt.gov/bills/mca/title_0150/chapter_0090/part_0010/section_0010/0150-0090-0010-0010.html |    15-9-101. Department to equalize valuations -- hearing, MCA  |  |
| MTS_0150-0090-0010-0020 | 200 | 9314 | https://leg.mt.gov/bills/mca/title_0150/chapter_0090/part_0010/section_0020/0150-0090-0010-0020.html |    15-9-102. Repealed, MCA  |  |
| MTS_0150-0090-0010-0030 | 200 | 9513 | https://leg.mt.gov/bills/mca/title_0150/chapter_0090/part_0010/section_0030/0150-0090-0010-0030.html |    15-9-103. Department to use records in equalizing, MCA  |  |
| MTS_0150-0100-0010-0010 | 200 | 8961 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0010/section_0010/0150-0100-0010-0010.html |    15-10-101. Repealed, MCA  |  |
| MTS_0150-0100-0010-0020 | 200 | 9222 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0010/section_0020/0150-0100-0010-0020.html |    15-10-102. Repealed, MCA  |  |
| MTS_0150-0100-0010-0030 | 200 | 9192 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0010/section_0030/0150-0100-0010-0030.html |    15-10-103. Repealed, MCA  |  |
| MTS_0150-0100-0010-0040 | 200 | 9193 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0010/section_0040/0150-0100-0010-0040.html |    15-10-104. Repealed, MCA  |  |
| MTS_0150-0100-0010-0050 | 200 | 9062 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0010/section_0050/0150-0100-0010-0050.html |    15-10-105. Terminated, MCA  |  |
| MTS_0150-0100-0010-0060 | 200 | 9033 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0010/section_0060/0150-0100-0010-0060.html |    15-10-106. Terminated, MCA  |  |
| MTS_0150-0100-0010-0070 | 200 | 9066 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0010/section_0070/0150-0100-0010-0070.html |    15-10-107. Terminated, MCA  |  |
| MTS_0150-0100-0010-0080 | 200 | 9051 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0010/section_0080/0150-0100-0010-0080.html |    15-10-108. Terminated, MCA  |  |
| MTS_0150-0100-0010-0090 | 200 | 9313 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0010/section_0090/0150-0100-0010-0090.html |    15-10-109. Tax levy for university system, MCA  |  |
| MTS_0150-0100-0020-0010 | 200 | 9369 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0020/section_0010/0150-0100-0020-0010.html |    15-10-201. Tax levies to be made in mills and tenths and hundredths of mills, |  |
| MTS_0150-0100-0020-0020 | 200 | 10883 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0020/section_0020/0150-0100-0020-0020.html |    15-10-202. Certification of taxable values, MCA  |  |
| MTS_0150-0100-0020-0030 | 200 | 9287 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0020/section_0030/0150-0100-0020-0030.html |    15-10-203. Repealed, MCA  |  |
| MTS_0150-0100-0020-0040 | 200 | 9212 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0020/section_0040/0150-0100-0020-0040.html |    15-10-204. Repealed, MCA  |  |
| MTS_0150-0100-0020-0050 | 200 | 9200 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0020/section_0050/0150-0100-0020-0050.html |    15-10-205. Repealed, MCA  |  |
| MTS_0150-0100-0020-0060 | 200 | 9477 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0020/section_0060/0150-0100-0020-0060.html |    15-10-206. Notification of decisions of tax appeal boards, MCA  |  |
| MTS_0150-0100-0020-0070 | 200 | 9155 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0020/section_0070/0150-0100-0020-0070.html |    15-10-207. Repealed, MCA  |  |
| MTS_0150-0100-0020-0080 | 200 | 8916 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0020/section_0080/0150-0100-0020-0080.html |    15-10-208. Repealed, MCA  |  |
| MTS_0150-0100-0030-0010 | 200 | 9058 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0030/section_0010/0150-0100-0030-0010.html |    15-10-301. Repealed, MCA  |  |
| MTS_0150-0100-0030-0020 | 200 | 9262 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0030/section_0020/0150-0100-0030-0020.html |    15-10-302. Repealed, MCA  |  |
| MTS_0150-0100-0030-0030 | 200 | 9232 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0030/section_0030/0150-0100-0030-0030.html |    15-10-303. Repealed, MCA  |  |
| MTS_0150-0100-0030-0040 | 200 | 9363 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0030/section_0040/0150-0100-0030-0040.html |    15-10-304. Repealed, MCA  |  |
| MTS_0150-0100-0030-0050 | 200 | 12100 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0030/section_0050/0150-0100-0030-0050.html |    15-10-305. Clerk and recorder to report mill levy -- department to compute an |  |
| MTS_0150-0100-0030-0060 | 200 | 9612 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0030/section_0060/0150-0100-0030-0060.html |    15-10-306. Repealed, MCA  |  |
| MTS_0150-0100-0030-0070 | 200 | 9261 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0030/section_0070/0150-0100-0030-0070.html |    15-10-307. Repealed, MCA  |  |
| MTS_0150-0100-0030-0080 | 200 | 9248 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0030/section_0080/0150-0100-0030-0080.html |    15-10-308. Repealed, MCA  |  |
| MTS_0150-0100-0030-0090 | 200 | 8896 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0030/section_0090/0150-0100-0030-0090.html |    15-10-309. through 15-10-320 reserved, MCA  |  |
| MTS_0150-0100-0030-0210 | 200 | 9401 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0030/section_0210/0150-0100-0030-0210.html |    15-10-321. Limitation on levy and computation of tax -- new taxing jurisdicti |  |
| MTS_0150-0100-0040-0010 | 200 | 9722 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0040/section_0010/0150-0100-0040-0010.html |    15-10-401. Declaration of policy, MCA  |  |
| MTS_0150-0100-0040-0020 | 200 | 9689 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0040/section_0020/0150-0100-0040-0020.html |    15-10-402. Property tax limited to 1996 levels, MCA  |  |
| MTS_0150-0100-0040-0030 | 200 | 8923 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0040/section_0030/0150-0100-0040-0030.html |    15-10-403. through 15-10-405 reserved, MCA  |  |
| MTS_0150-0100-0040-0060 | 200 | 9318 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0040/section_0060/0150-0100-0040-0060.html |    15-10-406. Limitation of applicability, MCA  |  |
| MTS_0150-0100-0040-0070 | 200 | 8896 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0040/section_0070/0150-0100-0040-0070.html |    15-10-407. through 15-10-410 reserved, MCA  |  |
| MTS_0150-0100-0040-0110 | 200 | 9074 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0040/section_0110/0150-0100-0040-0110.html |    15-10-411. Repealed, MCA  |  |
| MTS_0150-0100-0040-0120 | 200 | 9696 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0040/section_0120/0150-0100-0040-0120.html |    15-10-412. Repealed, MCA  |  |
| MTS_0150-0100-0040-0130 | 200 | 8899 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0040/section_0130/0150-0100-0040-0130.html |    15-10-413. through 15-10-419 reserved, MCA  |  |
| MTS_0150-0100-0040-0200 | 200 | 24878 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0040/section_0200/0150-0100-0040-0200.html |    15-10-420. Procedure for calculating levy, MCA  |  |
| MTS_0150-0100-0040-0210 | 200 | 8909 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0040/section_0210/0150-0100-0040-0210.html |    15-10-421. through 15-10-424 reserved, MCA  |  |
| MTS_0150-0100-0040-0250 | 200 | 12859 | https://leg.mt.gov/bills/mca/title_0150/chapter_0100/part_0040/section_0250/0150-0100-0040-0250.html |    15-10-425. Mill levy election, MCA  |  |
| MTS_0150-0150-0010-0010 | 200 | 14827 | https://leg.mt.gov/bills/mca/title_0150/chapter_0150/part_0010/section_0010/0150-0150-0010-0010.html |    15-15-101. County tax appeal board -- meetings and compensation, MCA  |  |
| MTS_0150-0150-0010-0020 | 200 | 13835 | https://leg.mt.gov/bills/mca/title_0150/chapter_0150/part_0010/section_0020/0150-0150-0010-0020.html |    15-15-102. Application for reduction in valuation -- reduced tax rate -- cert |  |
| MTS_0150-0150-0010-0030 | 200 | 14965 | https://leg.mt.gov/bills/mca/title_0150/chapter_0150/part_0010/section_0030/0150-0150-0010-0030.html |    15-15-103. Examination of applicant -- failure to hear application, MCA  |  |
| MTS_0150-0150-0010-0040 | 200 | 10719 | https://leg.mt.gov/bills/mca/title_0150/chapter_0150/part_0010/section_0040/0150-0150-0010-0040.html |    15-15-104. Appeal to Montana tax appeal board, MCA  |  |
| MTS_0150-0150-0010-0050 | 200 | 9109 | https://leg.mt.gov/bills/mca/title_0150/chapter_0150/part_0010/section_0050/0150-0150-0010-0050.html |    15-15-105. Repealed, MCA  |  |
| MTS_0150-0150-0010-0060 | 200 | 8882 | https://leg.mt.gov/bills/mca/title_0150/chapter_0150/part_0010/section_0060/0150-0150-0010-0060.html |    15-15-106. Repealed, MCA  |  |
| MTS_0150-0150-0020-0010 | 200 | 12776 | https://leg.mt.gov/bills/mca/title_0150/chapter_0150/part_0020/section_0010/0150-0150-0020-0010.html |    15-15-201. Motor vehicle tax appeals -- payment and protest of local option t |  |
| MTS_0150-0160-0010-0010 | 200 | 15992 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0010/0150-0160-0010-0010.html |    15-16-101. Treasurer to publish notice -- manner of publication, MCA  |  |
| MTS_0150-0160-0010-0020 | 200 | 16180 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0020/0150-0160-0010-0020.html |    15-16-102. Time for payment -- penalty for delinquency, MCA  |  |
| MTS_0150-0160-0010-0030 | 200 | 13096 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0030/0150-0160-0010-0030.html |    15-16-103. Special improvement districts with annual interest payments -- col |  |
| MTS_0150-0160-0010-0040 | 200 | 10496 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0040/0150-0160-0010-0040.html |    15-16-104. Entry of payment -- receipt, MCA  |  |
| MTS_0150-0160-0010-0050 | 200 | 9573 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0050/0150-0160-0010-0050.html |    15-16-105. When property assessed more than once, MCA  |  |
| MTS_0150-0160-0010-0060 | 200 | 8894 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0060/0150-0160-0010-0060.html |    15-16-106. through 15-16-110 reserved, MCA  |  |
| MTS_0150-0160-0010-0110 | 200 | 9431 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0110/0150-0160-0010-0110.html |    15-16-111. Repealed, MCA  |  |
| MTS_0150-0160-0010-0120 | 200 | 9237 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0120/0150-0160-0010-0120.html |    15-16-112. Repealed, MCA  |  |
| MTS_0150-0160-0010-0130 | 200 | 9538 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0130/0150-0160-0010-0130.html |    15-16-113. Repealed, MCA  |  |
| MTS_0150-0160-0010-0140 | 200 | 9362 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0140/0150-0160-0010-0140.html |    15-16-114. Repealed, MCA  |  |
| MTS_0150-0160-0010-0150 | 200 | 9235 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0150/0150-0160-0010-0150.html |    15-16-115. Repealed, MCA  |  |
| MTS_0150-0160-0010-0160 | 200 | 9098 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0160/0150-0160-0010-0160.html |    15-16-116. Repealed, MCA  |  |
| MTS_0150-0160-0010-0170 | 200 | 9503 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0170/0150-0160-0010-0170.html |    15-16-117. Repealed, MCA  |  |
| MTS_0150-0160-0010-0180 | 200 | 10906 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0180/0150-0160-0010-0180.html |    15-16-118. Minimum tax payment -- limitation of appeal, MCA  |  |
| MTS_0150-0160-0010-0190 | 200 | 13364 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0190/0150-0160-0010-0190.html |    15-16-119. Taxation of personal property -- duty of department -- collection  |  |
| MTS_0150-0160-0010-0200 | 200 | 8834 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0200/0150-0160-0010-0200.html |    15-16-120. reserved, MCA  |  |
| MTS_0150-0160-0010-0210 | 200 | 9149 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0210/0150-0160-0010-0210.html |    15-16-121. Repealed, MCA  |  |
| MTS_0150-0160-0010-0220 | 200 | 11697 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0010/section_0220/0150-0160-0010-0220.html |    15-16-122. Alternative payment schedule for primary residences, MCA  |  |
| MTS_0150-0160-0020-0010 | 200 | 10969 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0020/section_0010/0150-0160-0020-0010.html |    15-16-201. Tax prepayment -- new industrial facilities, MCA  |  |
| MTS_0150-0160-0020-0020 | 200 | 9293 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0020/section_0020/0150-0160-0020-0020.html |    15-16-202. Repealed, MCA  |  |
| MTS_0150-0160-0020-0030 | 200 | 11095 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0020/section_0030/0150-0160-0020-0030.html |    15-16-203. Assessment of property previously exempt, MCA  |  |
| MTS_0150-0160-0030-0010 | 200 | 10476 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0030/section_0010/0150-0160-0030-0010.html |    15-16-301. Delinquent list -- list of taxes suspended or cancelled -- real pr |  |
| MTS_0150-0160-0030-0020 | 200 | 11138 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0030/section_0020/0150-0160-0030-0020.html |    15-16-302. Tabulation and transmittal of property delinquent list, MCA  |  |
| MTS_0150-0160-0030-0030 | 200 | 10037 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0030/section_0030/0150-0160-0030-0030.html |    15-16-303. Treasurer charged with delinquent taxes, MCA  |  |
| MTS_0150-0160-0030-0040 | 200 | 9334 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0030/section_0040/0150-0160-0030-0040.html |    15-16-304. Repealed, MCA  |  |
| MTS_0150-0160-0030-0050 | 200 | 9813 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0030/section_0050/0150-0160-0030-0050.html |    15-16-305. Repealed, MCA  |  |
| MTS_0150-0160-0040-0010 | 200 | 10986 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0040/section_0010/0150-0160-0040-0010.html |    15-16-401. Tax due as a judgment or lien, MCA  |  |
| MTS_0150-0160-0040-0020 | 200 | 15175 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0040/section_0020/0150-0160-0040-0020.html |    15-16-402. Tax on personal property lien on realty -- separate assessment --  |  |
| MTS_0150-0160-0040-0030 | 200 | 10249 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0040/section_0030/0150-0160-0040-0030.html |    15-16-403. Lien on real property and improvements, MCA  |  |
| MTS_0150-0160-0040-0040 | 200 | 9955 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0040/section_0040/0150-0160-0040-0040.html |    15-16-404. County lien on money of taxpayer, MCA  |  |
| MTS_0150-0160-0050-0010 | 200 | 8955 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0050/section_0010/0150-0160-0050-0010.html |    15-16-501. Repealed, MCA  |  |
| MTS_0150-0160-0050-0020 | 200 | 9234 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0050/section_0020/0150-0160-0050-0020.html |    15-16-502. Repealed, MCA  |  |
| MTS_0150-0160-0050-0030 | 200 | 9811 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0050/section_0030/0150-0160-0050-0030.html |    15-16-503. Collection by suit of personal property taxes when taxpayer moves  |  |
| MTS_0150-0160-0050-0040 | 200 | 9819 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0050/section_0040/0150-0160-0050-0040.html |    15-16-504. Evidence at trial, MCA  |  |
| MTS_0150-0160-0050-0050 | 200 | 9200 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0050/section_0050/0150-0160-0050-0050.html |    15-16-505. Repealed, MCA  |  |
| MTS_0150-0160-0050-0060 | 200 | 10523 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0050/section_0060/0150-0160-0050-0060.html |    15-16-506. Civil action to collect delinquent taxes, MCA  |  |
| MTS_0150-0160-0060-0010 | 200 | 9239 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0060/section_0010/0150-0160-0060-0010.html |    15-16-601. Repealed, MCA  |  |
| MTS_0150-0160-0060-0020 | 200 | 9662 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0060/section_0020/0150-0160-0060-0020.html |    15-16-602. Concurrent remedies, MCA  |  |
| MTS_0150-0160-0060-0030 | 200 | 12537 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0060/section_0030/0150-0160-0060-0030.html |    15-16-603. Refund of taxes -- limitations on refunds, MCA  |  |
| MTS_0150-0160-0060-0040 | 200 | 10386 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0060/section_0040/0150-0160-0060-0040.html |    15-16-604. Judicial review of tax refund denials, MCA  |  |
| MTS_0150-0160-0060-0050 | 200 | 10686 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0060/section_0050/0150-0160-0060-0050.html |    15-16-605. Payment of refunds -- exception, MCA  |  |
| MTS_0150-0160-0060-0060 | 200 | 8958 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0060/section_0060/0150-0160-0060-0060.html |    15-16-606. through 15-16-610 reserved, MCA  |  |
| MTS_0150-0160-0060-0110 | 200 | 13190 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0060/section_0110/0150-0160-0060-0110.html |    15-16-611. Reduction of property tax for property destroyed by natural disast |  |
| MTS_0150-0160-0060-0120 | 200 | 9781 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0060/section_0120/0150-0160-0060-0120.html |    15-16-612. Refund of tax paid, MCA  |  |
| MTS_0150-0160-0060-0130 | 200 | 10934 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0060/section_0130/0150-0160-0060-0130.html |    15-16-613. Refund of certain taxes paid on migratory property, MCA  |  |
| MTS_0150-0160-0070-0010 | 200 | 12031 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0070/section_0010/0150-0160-0070-0010.html |    15-16-701. List of delinquent personal property taxes and real property taxes |  |
| MTS_0150-0160-0070-0020 | 200 | 11055 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0070/section_0020/0150-0160-0070-0020.html |    15-16-702. Cancellation of taxes and obligations -- filing of lists, MCA  |  |
| MTS_0150-0160-0070-0030 | 200 | 9464 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0070/section_0030/0150-0160-0070-0030.html |    15-16-703. Adjustment of accounts after cancellation, MCA  |  |
| MTS_0150-0160-0070-0040 | 200 | 9515 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0070/section_0040/0150-0160-0070-0040.html |    15-16-704. Certain unpaid taxes uncollectible -- stricken from records, MCA  |  |
| MTS_0150-0160-0080-0010 | 200 | 9837 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0080/section_0010/0150-0160-0080-0010.html |    15-16-801. Payment of suspended delinquent property taxes, MCA  |  |
| MTS_0150-0160-0080-0020 | 200 | 9061 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0080/section_0020/0150-0160-0080-0020.html |    15-16-802. Repealed, MCA  |  |
| MTS_0150-0160-0080-0030 | 200 | 8822 | https://leg.mt.gov/bills/mca/title_0150/chapter_0160/part_0080/section_0030/0150-0160-0080-0030.html |    15-16-803. Repealed, MCA  |  |
| MTS_0150-0170-0010-0010 | 200 | 9796 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0010/0150-0170-0010-0010.html |    15-17-101. Repealed, MCA  |  |
| MTS_0150-0170-0010-0020 | 200 | 9209 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0020/0150-0170-0010-0020.html |    15-17-102. Repealed, MCA  |  |
| MTS_0150-0170-0010-0030 | 200 | 8839 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0030/0150-0170-0010-0030.html |    15-17-103. through 15-17-110 reserved, MCA  |  |
| MTS_0150-0170-0010-0110 | 200 | 9209 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0110/0150-0170-0010-0110.html |    15-17-111. Repealed, MCA  |  |
| MTS_0150-0170-0010-0120 | 200 | 9167 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0120/0150-0170-0010-0120.html |    15-17-112. Repealed, MCA  |  |
| MTS_0150-0170-0010-0130 | 200 | 9215 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0130/0150-0170-0010-0130.html |    15-17-113. Repealed, MCA  |  |
| MTS_0150-0170-0010-0140 | 200 | 8842 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0140/0150-0170-0010-0140.html |    15-17-114. through 15-17-120 reserved, MCA  |  |
| MTS_0150-0170-0010-0210 | 200 | 16414 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0210/0150-0170-0010-0210.html |    15-17-121. Definitions, MCA  |  |
| MTS_0150-0170-0010-0220 | 200 | 11436 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0220/0150-0170-0010-0220.html |    15-17-122. Notice of pending attachment of tax lien, MCA  |  |
| MTS_0150-0170-0010-0230 | 200 | 10330 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0230/0150-0170-0010-0230.html |    15-17-123. Copy of notice to be filed with county clerk -- affidavit, MCA  |  |
| MTS_0150-0170-0010-0240 | 200 | 9651 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0240/0150-0170-0010-0240.html |    15-17-124. Irregular assessment, MCA  |  |
| MTS_0150-0170-0010-0250 | 200 | 13857 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0250/0150-0170-0010-0250.html |    15-17-125. Attachment of tax lien and preparation of tax lien certificate, MC |  |
| MTS_0150-0170-0010-0260 | 200 | 8968 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0260/0150-0170-0010-0260.html |    15-17-126. through 15-17-130 reserved, MCA  |  |
| MTS_0150-0170-0010-0310 | 200 | 11943 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0010/section_0310/0150-0170-0010-0310.html |    15-17-131. Common undivided ownership interest -- separate assessment -- prop |  |
| MTS_0150-0170-0020-0010 | 200 | 9315 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0010/0150-0170-0020-0010.html |    15-17-201. Repealed, MCA  |  |
| MTS_0150-0170-0020-0020 | 200 | 9315 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0020/0150-0170-0020-0020.html |    15-17-202. Repealed, MCA  |  |
| MTS_0150-0170-0020-0030 | 200 | 9218 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0030/0150-0170-0020-0030.html |    15-17-203. Repealed, MCA  |  |
| MTS_0150-0170-0020-0040 | 200 | 9664 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0040/0150-0170-0020-0040.html |    15-17-204. Repealed, MCA  |  |
| MTS_0150-0170-0020-0050 | 200 | 9249 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0050/0150-0170-0020-0050.html |    15-17-205. Repealed, MCA  |  |
| MTS_0150-0170-0020-0060 | 200 | 9247 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0060/0150-0170-0020-0060.html |    15-17-206. Repealed, MCA  |  |
| MTS_0150-0170-0020-0070 | 200 | 9345 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0070/0150-0170-0020-0070.html |    15-17-207. Repealed, MCA  |  |
| MTS_0150-0170-0020-0080 | 200 | 9329 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0080/0150-0170-0020-0080.html |    15-17-208. Repealed, MCA  |  |
| MTS_0150-0170-0020-0090 | 200 | 8870 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0090/0150-0170-0020-0090.html |    15-17-209. and 15-17-210 reserved, MCA  |  |
| MTS_0150-0170-0020-0110 | 200 | 9125 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0110/0150-0170-0020-0110.html |    15-17-211. Repealed, MCA  |  |
| MTS_0150-0170-0020-0120 | 200 | 8893 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0120/0150-0170-0020-0120.html |    15-17-212. Renumbered 15-17-125, MCA  |  |
| MTS_0150-0170-0020-0130 | 200 | 9112 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0130/0150-0170-0020-0130.html |    15-17-213. Repealed, MCA  |  |
| MTS_0150-0170-0020-0140 | 200 | 8899 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0020/section_0140/0150-0170-0020-0140.html |    15-17-214. Repealed, MCA  |  |
| MTS_0150-0170-0030-0010 | 200 | 9011 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0010/0150-0170-0030-0010.html |    15-17-301. Repealed, MCA  |  |
| MTS_0150-0170-0030-0020 | 200 | 9120 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0020/0150-0170-0030-0020.html |    15-17-302. Repealed, MCA  |  |
| MTS_0150-0170-0030-0030 | 200 | 9604 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0030/0150-0170-0030-0030.html |    15-17-303. Repealed, MCA  |  |
| MTS_0150-0170-0030-0040 | 200 | 9269 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0040/0150-0170-0030-0040.html |    15-17-304. Repealed, MCA  |  |
| MTS_0150-0170-0030-0050 | 200 | 9287 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0050/0150-0170-0030-0050.html |    15-17-305. Repealed, MCA  |  |
| MTS_0150-0170-0030-0060 | 200 | 8887 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0060/0150-0170-0030-0060.html |    15-17-306. through 15-17-310 reserved, MCA  |  |
| MTS_0150-0170-0030-0110 | 200 | 9257 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0110/0150-0170-0030-0110.html |    15-17-311. Repealed, MCA  |  |
| MTS_0150-0170-0030-0120 | 200 | 9170 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0120/0150-0170-0030-0120.html |    15-17-312. Repealed, MCA  |  |
| MTS_0150-0170-0030-0130 | 200 | 8890 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0130/0150-0170-0030-0130.html |    15-17-313. through 15-17-315 reserved, MCA  |  |
| MTS_0150-0170-0030-0160 | 200 | 9848 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0160/0150-0170-0030-0160.html |    15-17-316. Definitions, MCA  |  |
| MTS_0150-0170-0030-0170 | 200 | 10603 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0170/0150-0170-0030-0170.html |    15-17-317. Municipality as assignee, MCA  |  |
| MTS_0150-0170-0030-0180 | 200 | 11401 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0180/0150-0170-0030-0180.html |    15-17-318. Assignment of municipality's interest, MCA  |  |
| MTS_0150-0170-0030-0190 | 200 | 10166 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0190/0150-0170-0030-0190.html |    15-17-319. Sale or lease and disposition of proceeds from lands acquired by m |  |
| MTS_0150-0170-0030-0200 | 200 | 10308 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0200/0150-0170-0030-0200.html |    15-17-320. Taxes and subsequent installments of special assessments on land a |  |
| MTS_0150-0170-0030-0210 | 200 | 9211 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0210/0150-0170-0030-0210.html |    15-17-321. Repealed, MCA  |  |
| MTS_0150-0170-0030-0220 | 200 | 9665 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0220/0150-0170-0030-0220.html |    15-17-322. Disposition of money from tax lien sale, MCA  |  |
| MTS_0150-0170-0030-0230 | 200 | 16551 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0230/0150-0170-0030-0230.html |    15-17-323. Assignment of rights -- form, MCA  |  |
| MTS_0150-0170-0030-0240 | 200 | 9630 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0240/0150-0170-0030-0240.html |    15-17-324. Assessment of property with tax lien attached, MCA  |  |
| MTS_0150-0170-0030-0250 | 200 | 9715 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0250/0150-0170-0030-0250.html |    15-17-325. Sale not voided by misnomer of ownership, MCA  |  |
| MTS_0150-0170-0030-0260 | 200 | 12389 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0030/section_0260/0150-0170-0030-0260.html |    15-17-326. Voided tax lien -- refund -- limitation on action for royalty inte |  |
| MTS_0150-0170-0090-0010 | 200 | 10040 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0090/section_0010/0150-0170-0090-0010.html |    15-17-901. Repealed, MCA  |  |
| MTS_0150-0170-0090-0020 | 200 | 9176 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0090/section_0020/0150-0170-0090-0020.html |    15-17-902. Repealed, MCA  |  |
| MTS_0150-0170-0090-0030 | 200 | 9192 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0090/section_0030/0150-0170-0090-0030.html |    15-17-903. Repealed, MCA  |  |
| MTS_0150-0170-0090-0040 | 200 | 8939 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0090/section_0040/0150-0170-0090-0040.html |    15-17-904. through 15-17-910 reserved, MCA  |  |
| MTS_0150-0170-0090-0110 | 200 | 14587 | https://leg.mt.gov/bills/mca/title_0150/chapter_0170/part_0090/section_0110/0150-0170-0090-0110.html |    15-17-911. Sale of personal property for delinquent taxes -- fee -- dispositi |  |
| MTS_0150-0180-0010-0010 | 200 | 9076 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0010/0150-0180-0010-0010.html |    15-18-101. Repealed, MCA  |  |
| MTS_0150-0180-0010-0020 | 200 | 9192 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0020/0150-0180-0010-0020.html |    15-18-102. Repealed, MCA  |  |
| MTS_0150-0180-0010-0030 | 200 | 9252 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0030/0150-0180-0010-0030.html |    15-18-103. Repealed, MCA  |  |
| MTS_0150-0180-0010-0040 | 200 | 9221 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0040/0150-0180-0010-0040.html |    15-18-104. Repealed, MCA  |  |
| MTS_0150-0180-0010-0050 | 200 | 9221 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0050/0150-0180-0010-0050.html |    15-18-105. Repealed, MCA  |  |
| MTS_0150-0180-0010-0060 | 200 | 9197 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0060/0150-0180-0010-0060.html |    15-18-106. Repealed, MCA  |  |
| MTS_0150-0180-0010-0070 | 200 | 9197 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0070/0150-0180-0010-0070.html |    15-18-107. Repealed, MCA  |  |
| MTS_0150-0180-0010-0080 | 200 | 9266 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0080/0150-0180-0010-0080.html |    15-18-108. Repealed, MCA  |  |
| MTS_0150-0180-0010-0090 | 200 | 8880 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0090/0150-0180-0010-0090.html |    15-18-109. and 15-18-110 reserved, MCA  |  |
| MTS_0150-0180-0010-0110 | 200 | 10706 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0110/0150-0180-0010-0110.html |    15-18-111. Time for redemption -- interested party, MCA  |  |
| MTS_0150-0180-0010-0120 | 200 | 11953 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0120/0150-0180-0010-0120.html |    15-18-112. Redemption from property tax lien -- lien on interest in property  |  |
| MTS_0150-0180-0010-0130 | 200 | 11765 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0130/0150-0180-0010-0130.html |    15-18-113. Treasurer to file redemptions, MCA  |  |
| MTS_0150-0180-0010-0140 | 200 | 12175 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0010/section_0140/0150-0180-0010-0140.html |    15-18-114. Distribution of redemption proceeds, MCA  |  |
| MTS_0150-0180-0020-0010 | 200 | 9041 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0010/0150-0180-0020-0010.html |    15-18-201. Repealed, MCA  |  |
| MTS_0150-0180-0020-0020 | 200 | 9403 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0020/0150-0180-0020-0020.html |    15-18-202. Repealed, MCA  |  |
| MTS_0150-0180-0020-0030 | 200 | 9156 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0030/0150-0180-0020-0030.html |    15-18-203. Repealed, MCA  |  |
| MTS_0150-0180-0020-0040 | 200 | 9238 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0040/0150-0180-0020-0040.html |    15-18-204. Repealed, MCA  |  |
| MTS_0150-0180-0020-0050 | 200 | 9337 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0050/0150-0180-0020-0050.html |    15-18-205. Repealed, MCA  |  |
| MTS_0150-0180-0020-0060 | 200 | 8900 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0060/0150-0180-0020-0060.html |    15-18-206. through 15-18-210 reserved, MCA  |  |
| MTS_0150-0180-0020-0110 | 200 | 11529 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0110/0150-0180-0020-0110.html |    15-18-211. Tax deed -- fee, MCA  |  |
| MTS_0150-0180-0020-0120 | 200 | 16848 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0120/0150-0180-0020-0120.html |    15-18-212. Notice -- proof of notice -- penalty for failure to notify, MCA  |  |
| MTS_0150-0180-0020-0130 | 200 | 13640 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0130/0150-0180-0020-0130.html |    15-18-213. Form of tax deed -- prima facie evidence, MCA  |  |
| MTS_0150-0180-0020-0140 | 200 | 10659 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0140/0150-0180-0020-0140.html |    15-18-214. Effect of deed, MCA  |  |
| MTS_0150-0180-0020-0150 | 200 | 18367 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0150/0150-0180-0020-0150.html |    15-18-215. Form of notice that tax deed may issue, MCA  |  |
| MTS_0150-0180-0020-0160 | 200 | 12178 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0160/0150-0180-0020-0160.html |    15-18-216. Form of proof of notice, MCA  |  |
| MTS_0150-0180-0020-0170 | 200 | 11353 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0170/0150-0180-0020-0170.html |    15-18-217. Form of cancellation, MCA  |  |
| MTS_0150-0180-0020-0180 | 200 | 9686 | https://leg.mt.gov/bills/mca/title_0150/chapter_0180/part_0020/section_0180/0150-0180-0020-0180.html |    15-18-218. Charge not allowed for filings or recordings made by county treasu |  |
