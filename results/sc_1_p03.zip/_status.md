| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| SC_t44c030 | 200 | 30078 | https://www.scstatehouse.gov/code/t44c030.php | Code of Laws - Title 44 - Chapter 30- - HEALTH |  |
| SC_t44c031 | 200 | 48597 | https://www.scstatehouse.gov/code/t44c031.php | Code of Laws - Title 44 - Chapter 31- - HEALTH |  |
| SC_t44c032 | 200 | 35018 | https://www.scstatehouse.gov/code/t44c032.php | Code of Laws - Title 44 - Chapter 32- - HEALTH |  |
| SC_t44c033 | 200 | 29585 | https://www.scstatehouse.gov/code/t44c033.php | Code of Laws - Title 44 - Chapter 33- - HEALTH |  |
| SC_t44c034 | 200 | 37100 | https://www.scstatehouse.gov/code/t44c034.php | Code of Laws - Title 44 - Chapter 34- - HEALTH |  |
| SC_t44c035 | 200 | 31743 | https://www.scstatehouse.gov/code/t44c035.php | Code of Laws - Title 44 - Chapter 35- - HEALTH |  |
| SC_t44c036 | 200 | 38301 | https://www.scstatehouse.gov/code/t44c036.php | Code of Laws - Title 44 - Chapter 36- - HEALTH |  |
| SC_t44c037 | 200 | 46333 | https://www.scstatehouse.gov/code/t44c037.php | Code of Laws - Title 44 - Chapter 37- - HEALTH |  |
| SC_t44c038 | 200 | 54068 | https://www.scstatehouse.gov/code/t44c038.php | Code of Laws - Title 44 - Chapter 38- - HEALTH |  |
| SC_t44c039 | 200 | 26881 | https://www.scstatehouse.gov/code/t44c039.php | Code of Laws - Title 44 - Chapter 39- - HEALTH |  |
| SC_t44c040 | 200 | 28651 | https://www.scstatehouse.gov/code/t44c040.php | Code of Laws - Title 44 - Chapter 40- - HEALTH |  |
| SC_t44c041 | 200 | 116378 | https://www.scstatehouse.gov/code/t44c041.php | Code of Laws - Title 44 - Chapter 41- - HEALTH |  |
| SC_t44c042 | 200 | 29115 | https://www.scstatehouse.gov/code/t44c042.php | Code of Laws - Title 44 - Chapter 42- - HEALTH |  |
| SC_t44c043 | 200 | 113288 | https://www.scstatehouse.gov/code/t44c043.php | Code of Laws - Title 44 - Chapter 43- - HEALTH |  |
| SC_t44c044 | 200 | 35301 | https://www.scstatehouse.gov/code/t44c044.php | Code of Laws - Title 44 - Chapter 44- - HEALTH |  |
| SC_t44c048 | 200 | 74039 | https://www.scstatehouse.gov/code/t44c048.php | Code of Laws - Title 44 - Chapter 48- - HEALTH |  |
| SC_t44c049 | 200 | 45640 | https://www.scstatehouse.gov/code/t44c049.php | Code of Laws - Title 44 - Chapter 49- - HEALTH |  |
| SC_t44c052 | 200 | 59176 | https://www.scstatehouse.gov/code/t44c052.php | Code of Laws - Title 44 - Chapter 52- - HEALTH |  |
| SC_t44c053 | 200 | 396967 | https://www.scstatehouse.gov/code/t44c053.php | Code of Laws - Title 44 - Chapter 53- - HEALTH |  |
| SC_t44c054 | 200 | 37456 | https://www.scstatehouse.gov/code/t44c054.php | Code of Laws - Title 44 - Chapter 54- - HEALTH |  |
| SC_t44c055 | 200 | 115420 | https://www.scstatehouse.gov/code/t44c055.php | Code of Laws - Title 44 - Chapter 55- - HEALTH |  |
| SC_t44c056 | 200 | 179523 | https://www.scstatehouse.gov/code/t44c056.php | Code of Laws - Title 44 - Chapter 56- - HEALTH |  |
| SC_t44c059 | 200 | 31225 | https://www.scstatehouse.gov/code/t44c059.php | Code of Laws - Title 44 - Chapter 59- - HEALTH |  |
| SC_t44c061 | 200 | 152476 | https://www.scstatehouse.gov/code/t44c061.php | Code of Laws - Title 44 - Chapter 61- - HEALTH |  |
| SC_t44c063 | 200 | 64484 | https://www.scstatehouse.gov/code/t44c063.php | Code of Laws - Title 44 - Chapter 63- - HEALTH |  |
| SC_t44c066 | 200 | 37834 | https://www.scstatehouse.gov/code/t44c066.php | Code of Laws - Title 44 - Chapter 66- - HEALTH |  |
| SC_t44c069 | 200 | 35447 | https://www.scstatehouse.gov/code/t44c069.php | Code of Laws - Title 44 - Chapter 69- - HEALTH |  |
| SC_t44c070 | 200 | 27052 | https://www.scstatehouse.gov/code/t44c070.php | Code of Laws - Title 44 - Chapter 70- - HEALTH |  |
| SC_t44c071 | 200 | 37886 | https://www.scstatehouse.gov/code/t44c071.php | Code of Laws - Title 44 - Chapter 71- - HEALTH |  |
| SC_t44c074 | 200 | 30878 | https://www.scstatehouse.gov/code/t44c074.php | Code of Laws - Title 44 - Chapter 74- - HEALTH |  |
| SC_t44c075 | 200 | 23146 | https://www.scstatehouse.gov/code/t44c075.php | Code of Laws - Title 44 - Chapter 75- - HEALTH |  |
| SC_t44c076 | 200 | 24564 | https://www.scstatehouse.gov/code/t44c076.php | Code of Laws - Title 44 - Chapter 76- - HEALTH |  |
| SC_t44c077 | 200 | 47859 | https://www.scstatehouse.gov/code/t44c077.php | Code of Laws - Title 44 - Chapter 77- - HEALTH |  |
| SC_t44c078 | 200 | 39676 | https://www.scstatehouse.gov/code/t44c078.php | Code of Laws - Title 44 - Chapter 78- - HEALTH |  |
| SC_t44c079 | 200 | 37000 | https://www.scstatehouse.gov/code/t44c079.php | Code of Laws - Title 44 - Chapter 79- - HEALTH |  |
| SC_t44c080 | 200 | 35272 | https://www.scstatehouse.gov/code/t44c080.php | Code of Laws - Title 44 - Chapter 80- - HEALTH |  |
| SC_t44c081 | 200 | 32338 | https://www.scstatehouse.gov/code/t44c081.php | Code of Laws - Title 44 - Chapter 81- - HEALTH |  |
| SC_t44c087 | 200 | 23785 | https://www.scstatehouse.gov/code/t44c087.php | Code of Laws - Title 44 - Chapter 87- - HEALTH |  |
| SC_t44c089 | 200 | 27638 | https://www.scstatehouse.gov/code/t44c089.php | Code of Laws - Title 44 - Chapter 89- - HEALTH |  |
| SC_t44c093 | 200 | 48621 | https://www.scstatehouse.gov/code/t44c093.php | Code of Laws - Title 44 - Chapter 93- - HEALTH |  |
| SC_t44c095 | 200 | 47191 | https://www.scstatehouse.gov/code/t44c095.php | Code of Laws - Title 44 - Chapter 95- - HEALTH |  |
| SC_t44c096 | 200 | 262098 | https://www.scstatehouse.gov/code/t44c096.php | Code of Laws - Title 44 - Chapter 96- - HEALTH |  |
| SC_t44c099 | 200 | 29093 | https://www.scstatehouse.gov/code/t44c099.php | Code of Laws - Title 44 - Chapter 99- - HEALTH |  |
| SC_t44c107 | 200 | 28345 | https://www.scstatehouse.gov/code/t44c107.php | Code of Laws - Title 44 - Chapter 107- - HEALTH |  |
| SC_t44c113 | 200 | 34790 | https://www.scstatehouse.gov/code/t44c113.php | Code of Laws - Title 44 - Chapter 113- - HEALTH |  |
| SC_t44c115 | 200 | 33871 | https://www.scstatehouse.gov/code/t44c115.php | Code of Laws - Title 44 - Chapter 115- - HEALTH |  |
| SC_t44c117 | 200 | 37680 | https://www.scstatehouse.gov/code/t44c117.php | Code of Laws - Title 44 - Chapter 117- - HEALTH |  |
| SC_t44c122 | 200 | 35239 | https://www.scstatehouse.gov/code/t44c122.php | Code of Laws - Title 44 - Chapter 122- - HEALTH |  |
| SC_t44c125 | 200 | 24125 | https://www.scstatehouse.gov/code/t44c125.php | Code of Laws - Title 44 - Chapter 125- - HEALTH |  |
| SC_t44c128 | 200 | 25638 | https://www.scstatehouse.gov/code/t44c128.php | Code of Laws - Title 44 - Chapter 128- - HEALTH |  |
| SC_t44c130 | 200 | 46054 | https://www.scstatehouse.gov/code/t44c130.php | Code of Laws - Title 44 - Chapter 130- - HEALTH |  |
| SC_t44c132 | 200 | 23660 | https://www.scstatehouse.gov/code/t44c132.php | Code of Laws - Title 44 - Chapter 132- - HEALTH |  |
| SC_t44c135 | 200 | 56690 | https://www.scstatehouse.gov/code/t44c135.php | Code of Laws - Title 44 - Chapter 135- - HEALTH |  |
| SC_t44c137 | 200 | 29144 | https://www.scstatehouse.gov/code/t44c137.php | Code of Laws - Title 44 - Chapter 137- - HEALTH |  |
| SC_t44c139 | 200 | 38122 | https://www.scstatehouse.gov/code/t44c139.php | Code of Laws - Title 44 - Chapter 139- - HEALTH |  |
| SC_t45c001 | 200 | 29488 | https://www.scstatehouse.gov/code/t45c001.php | Code of Laws - Title 45 - Chapter 1- - HOTELS, MOTELS, RESTAURANTS, AND BOARDING |  |
| SC_t45c002 | 200 | 38780 | https://www.scstatehouse.gov/code/t45c002.php | Code of Laws - Title 45 - Chapter 2- - HOTELS, MOTELS, RESTAURANTS, AND BOARDING |  |
| SC_t45c003 | 200 | 22354 | https://www.scstatehouse.gov/code/t45c003.php | Code of Laws - Title 45 - Chapter 3- - HOTELS, MOTELS, RESTAURANTS, AND BOARDING |  |
| SC_t45c004 | 200 | 33499 | https://www.scstatehouse.gov/code/t45c004.php | Code of Laws - Title 45 - Chapter 4- - HOTELS, MOTELS, RESTAURANTS, AND BOARDING |  |
| SC_t45c005 | 200 | 25402 | https://www.scstatehouse.gov/code/t45c005.php | Code of Laws - Title 45 - Chapter 5- - HOTELS, MOTELS, RESTAURANTS, AND BOARDING |  |
| SC_t45c007 | 200 | 23449 | https://www.scstatehouse.gov/code/t45c007.php | Code of Laws - Title 45 - Chapter 7- - HOTELS, MOTELS, RESTAURANTS, AND BOARDING |  |
| SC_t45c009 | 200 | 43508 | https://www.scstatehouse.gov/code/t45c009.php | Code of Laws - Title 45 - Chapter 9- - HOTELS, MOTELS, RESTAURANTS, AND BOARDING |  |
| SC_t46c001 | 200 | 49445 | https://www.scstatehouse.gov/code/t46c001.php | Code of Laws - Title 46 - Chapter 1- - AGRICULTURE |  |
| SC_t46c003 | 200 | 48499 | https://www.scstatehouse.gov/code/t46c003.php | Code of Laws - Title 46 - Chapter 3- - AGRICULTURE |  |
| SC_t46c005 | 200 | 24268 | https://www.scstatehouse.gov/code/t46c005.php | Code of Laws - Title 46 - Chapter 5- - AGRICULTURE |  |
| SC_t46c007 | 200 | 34070 | https://www.scstatehouse.gov/code/t46c007.php | Code of Laws - Title 46 - Chapter 7- - AGRICULTURE |  |
| SC_t46c009 | 200 | 42403 | https://www.scstatehouse.gov/code/t46c009.php | Code of Laws - Title 46 - Chapter 9- - AGRICULTURE |  |
| SC_t46c010 | 200 | 38272 | https://www.scstatehouse.gov/code/t46c010.php | Code of Laws - Title 46 - Chapter 10- - AGRICULTURE |  |
| SC_t46c011 | 200 | 47547 | https://www.scstatehouse.gov/code/t46c011.php | Code of Laws - Title 46 - Chapter 11- - AGRICULTURE |  |
| SC_t46c013 | 200 | 91193 | https://www.scstatehouse.gov/code/t46c013.php | Code of Laws - Title 46 - Chapter 13- - AGRICULTURE |  |
| SC_t46c015 | 200 | 42139 | https://www.scstatehouse.gov/code/t46c015.php | Code of Laws - Title 46 - Chapter 15- - AGRICULTURE |  |
| SC_t46c017 | 200 | 74942 | https://www.scstatehouse.gov/code/t46c017.php | Code of Laws - Title 46 - Chapter 17- - AGRICULTURE |  |
| SC_t46c019 | 200 | 33118 | https://www.scstatehouse.gov/code/t46c019.php | Code of Laws - Title 46 - Chapter 19- - AGRICULTURE |  |
| SC_t46c021 | 200 | 82769 | https://www.scstatehouse.gov/code/t46c021.php | Code of Laws - Title 46 - Chapter 21- - AGRICULTURE |  |
| SC_t46c023 | 200 | 30976 | https://www.scstatehouse.gov/code/t46c023.php | Code of Laws - Title 46 - Chapter 23- - AGRICULTURE |  |
| SC_t46c025 | 200 | 70254 | https://www.scstatehouse.gov/code/t46c025.php | Code of Laws - Title 46 - Chapter 25- - AGRICULTURE |  |
| SC_t46c026 | 200 | 39681 | https://www.scstatehouse.gov/code/t46c026.php | Code of Laws - Title 46 - Chapter 26- - AGRICULTURE |  |
| SC_t46c027 | 200 | 53461 | https://www.scstatehouse.gov/code/t46c027.php | Code of Laws - Title 46 - Chapter 27- - AGRICULTURE |  |
| SC_t46c029 | 200 | 21969 | https://www.scstatehouse.gov/code/t46c029.php | Code of Laws - Title 46 - Chapter 29- - AGRICULTURE |  |
| SC_t46c030 | 200 | 27671 | https://www.scstatehouse.gov/code/t46c030.php | Code of Laws - Title 46 - Chapter 30- - AGRICULTURE |  |
| SC_t46c031 | 200 | 34083 | https://www.scstatehouse.gov/code/t46c031.php | Code of Laws - Title 46 - Chapter 31- - AGRICULTURE |  |
| SC_t46c033 | 200 | 32349 | https://www.scstatehouse.gov/code/t46c033.php | Code of Laws - Title 46 - Chapter 33- - AGRICULTURE |  |
| SC_t46c035 | 200 | 28854 | https://www.scstatehouse.gov/code/t46c035.php | Code of Laws - Title 46 - Chapter 35- - AGRICULTURE |  |
| SC_t46c037 | 200 | 24668 | https://www.scstatehouse.gov/code/t46c037.php | Code of Laws - Title 46 - Chapter 37- - AGRICULTURE |  |
| SC_t46c039 | 200 | 32275 | https://www.scstatehouse.gov/code/t46c039.php | Code of Laws - Title 46 - Chapter 39- - AGRICULTURE |  |
| SC_t46c040 | 200 | 33905 | https://www.scstatehouse.gov/code/t46c040.php | Code of Laws - Title 46 - Chapter 40- - AGRICULTURE |  |
| SC_t46c041 | 200 | 76864 | https://www.scstatehouse.gov/code/t46c041.php | Code of Laws - Title 46 - Chapter 41- - AGRICULTURE |  |
| SC_t46c042 | 200 | 24375 | https://www.scstatehouse.gov/code/t46c042.php | Code of Laws - Title 46 - Chapter 42- - AGRICULTURE |  |
| SC_t46c045 | 200 | 32699 | https://www.scstatehouse.gov/code/t46c045.php | Code of Laws - Title 46 - Chapter 45- - AGRICULTURE |  |
| SC_t46c049 | 200 | 27634 | https://www.scstatehouse.gov/code/t46c049.php | Code of Laws - Title 46 - Chapter 49- - AGRICULTURE |  |
| SC_t46c050 | 200 | 67508 | https://www.scstatehouse.gov/code/t46c050.php | Code of Laws - Title 46 - Chapter 50- - AGRICULTURE |  |
| SC_t46c051 | 200 | 22963 | https://www.scstatehouse.gov/code/t46c051.php | Code of Laws - Title 46 - Chapter 51- - AGRICULTURE |  |
| SC_t46c053 | 200 | 25777 | https://www.scstatehouse.gov/code/t46c053.php | Code of Laws - Title 46 - Chapter 53- - AGRICULTURE |  |
| SC_t46c055 | 200 | 44155 | https://www.scstatehouse.gov/code/t46c055.php | Code of Laws - Title 46 - Chapter 55- - AGRICULTURE |  |
| SC_t46c057 | 200 | 36668 | https://www.scstatehouse.gov/code/t46c057.php | Code of Laws - Title 46 - Chapter 57- - AGRICULTURE |  |
| SC_t47c001 | 200 | 54367 | https://www.scstatehouse.gov/code/t47c001.php | Code of Laws - Title 47 - Chapter 1- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c002 | 200 | 33229 | https://www.scstatehouse.gov/code/t47c002.php | Code of Laws - Title 47 - Chapter 2- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c003 | 200 | 95123 | https://www.scstatehouse.gov/code/t47c003.php | Code of Laws - Title 47 - Chapter 3- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c004 | 200 | 49534 | https://www.scstatehouse.gov/code/t47c004.php | Code of Laws - Title 47 - Chapter 4- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c005 | 200 | 38023 | https://www.scstatehouse.gov/code/t47c005.php | Code of Laws - Title 47 - Chapter 5- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c006 | 200 | 28703 | https://www.scstatehouse.gov/code/t47c006.php | Code of Laws - Title 47 - Chapter 6- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c007 | 200 | 28990 | https://www.scstatehouse.gov/code/t47c007.php | Code of Laws - Title 47 - Chapter 7- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c009 | 200 | 47458 | https://www.scstatehouse.gov/code/t47c009.php | Code of Laws - Title 47 - Chapter 9- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c011 | 200 | 42535 | https://www.scstatehouse.gov/code/t47c011.php | Code of Laws - Title 47 - Chapter 11- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c013 | 200 | 82102 | https://www.scstatehouse.gov/code/t47c013.php | Code of Laws - Title 47 - Chapter 13- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c015 | 200 | 23505 | https://www.scstatehouse.gov/code/t47c015.php | Code of Laws - Title 47 - Chapter 15- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c017 | 200 | 58013 | https://www.scstatehouse.gov/code/t47c017.php | Code of Laws - Title 47 - Chapter 17- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c019 | 200 | 65208 | https://www.scstatehouse.gov/code/t47c019.php | Code of Laws - Title 47 - Chapter 19- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c020 | 200 | 22433 | https://www.scstatehouse.gov/code/t47c020.php | Code of Laws - Title 47 - Chapter 20- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c021 | 200 | 32748 | https://www.scstatehouse.gov/code/t47c021.php | Code of Laws - Title 47 - Chapter 21- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t47c022 | 200 | 29618 | https://www.scstatehouse.gov/code/t47c022.php | Code of Laws - Title 47 - Chapter 22- - ANIMALS, LIVESTOCK, AND POULTRY |  |
| SC_t48c001 | 200 | 101013 | https://www.scstatehouse.gov/code/t48c001.php | Code of Laws - Title 48 - Chapter 1- - ENVIRONMENTAL PROTECTION AND CONSERVATION |  |
| SC_t48c002 | 200 | 64330 | https://www.scstatehouse.gov/code/t48c002.php | Code of Laws - Title 48 - Chapter 2- - ENVIRONMENTAL PROTECTION AND CONSERVATION |  |
| SC_t48c003 | 200 | 44743 | https://www.scstatehouse.gov/code/t48c003.php | Code of Laws - Title 48 - Chapter 3- - ENVIRONMENTAL PROTECTION AND CONSERVATION |  |
| SC_t48c004 | 200 | 34105 | https://www.scstatehouse.gov/code/t48c004.php | Code of Laws - Title 48 - Chapter 4- - ENVIRONMENTAL PROTECTION AND CONSERVATION |  |
| SC_t48c005 | 200 | 53827 | https://www.scstatehouse.gov/code/t48c005.php | Code of Laws - Title 48 - Chapter 5- - ENVIRONMENTAL PROTECTION AND CONSERVATION |  |
| SC_t48c006 | 200 | 52148 | https://www.scstatehouse.gov/code/t48c006.php | Code of Laws - Title 48 - Chapter 6- - ENVIRONMENTAL PROTECTION AND CONSERVATION |  |
| SC_t48c007 | 200 | 21800 | https://www.scstatehouse.gov/code/t48c007.php | Code of Laws - Title 48 - Chapter 7- - ENVIRONMENTAL PROTECTION AND CONSERVATION |  |
| SC_t48c009 | 200 | 101770 | https://www.scstatehouse.gov/code/t48c009.php | Code of Laws - Title 48 - Chapter 9- - ENVIRONMENTAL PROTECTION AND CONSERVATION |  |
| SC_t48c011 | 200 | 70106 | https://www.scstatehouse.gov/code/t48c011.php | Code of Laws - Title 48 - Chapter 11- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c014 | 200 | 54253 | https://www.scstatehouse.gov/code/t48c014.php | Code of Laws - Title 48 - Chapter 14- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c015 | 200 | 26814 | https://www.scstatehouse.gov/code/t48c015.php | Code of Laws - Title 48 - Chapter 15- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c017 | 200 | 26070 | https://www.scstatehouse.gov/code/t48c017.php | Code of Laws - Title 48 - Chapter 17- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c018 | 200 | 34553 | https://www.scstatehouse.gov/code/t48c018.php | Code of Laws - Title 48 - Chapter 18- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c020 | 200 | 80014 | https://www.scstatehouse.gov/code/t48c020.php | Code of Laws - Title 48 - Chapter 20- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c021 | 200 | 39417 | https://www.scstatehouse.gov/code/t48c021.php | Code of Laws - Title 48 - Chapter 21- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c022 | 200 | 27746 | https://www.scstatehouse.gov/code/t48c022.php | Code of Laws - Title 48 - Chapter 22- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c023 | 200 | 71275 | https://www.scstatehouse.gov/code/t48c023.php | Code of Laws - Title 48 - Chapter 23- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c025 | 200 | 32139 | https://www.scstatehouse.gov/code/t48c025.php | Code of Laws - Title 48 - Chapter 25- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c027 | 200 | 43710 | https://www.scstatehouse.gov/code/t48c027.php | Code of Laws - Title 48 - Chapter 27- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c028 | 200 | 32984 | https://www.scstatehouse.gov/code/t48c028.php | Code of Laws - Title 48 - Chapter 28- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c029 | 200 | 24795 | https://www.scstatehouse.gov/code/t48c029.php | Code of Laws - Title 48 - Chapter 29- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c030 | 200 | 29002 | https://www.scstatehouse.gov/code/t48c030.php | Code of Laws - Title 48 - Chapter 30- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c031 | 200 | 21801 | https://www.scstatehouse.gov/code/t48c031.php | Code of Laws - Title 48 - Chapter 31- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c033 | 200 | 26853 | https://www.scstatehouse.gov/code/t48c033.php | Code of Laws - Title 48 - Chapter 33- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c034 | 200 | 26056 | https://www.scstatehouse.gov/code/t48c034.php | Code of Laws - Title 48 - Chapter 34- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c035 | 200 | 24418 | https://www.scstatehouse.gov/code/t48c035.php | Code of Laws - Title 48 - Chapter 35- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c036 | 200 | 21157 | https://www.scstatehouse.gov/code/t48c036.php | Code of Laws - Title 48 - Chapter 36- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c037 | 200 | 33940 | https://www.scstatehouse.gov/code/t48c037.php | Code of Laws - Title 48 - Chapter 37- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c039 | 200 | 157313 | https://www.scstatehouse.gov/code/t48c039.php | Code of Laws - Title 48 - Chapter 39- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c040 | 200 | 29267 | https://www.scstatehouse.gov/code/t48c040.php | Code of Laws - Title 48 - Chapter 40- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c041 | 200 | 27075 | https://www.scstatehouse.gov/code/t48c041.php | Code of Laws - Title 48 - Chapter 41- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c043 | 200 | 116230 | https://www.scstatehouse.gov/code/t48c043.php | Code of Laws - Title 48 - Chapter 43- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c044 | 200 | 22929 | https://www.scstatehouse.gov/code/t48c044.php | Code of Laws - Title 48 - Chapter 44- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c045 | 200 | 25021 | https://www.scstatehouse.gov/code/t48c045.php | Code of Laws - Title 48 - Chapter 45- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c046 | 200 | 68042 | https://www.scstatehouse.gov/code/t48c046.php | Code of Laws - Title 48 - Chapter 46- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c049 | 200 | 29394 | https://www.scstatehouse.gov/code/t48c049.php | Code of Laws - Title 48 - Chapter 49- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c052 | 200 | 84255 | https://www.scstatehouse.gov/code/t48c052.php | Code of Laws - Title 48 - Chapter 52- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c053 | 200 | 21206 | https://www.scstatehouse.gov/code/t48c053.php | Code of Laws - Title 48 - Chapter 53- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c054 | 200 | 28783 | https://www.scstatehouse.gov/code/t48c054.php | Code of Laws - Title 48 - Chapter 54- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c055 | 200 | 22556 | https://www.scstatehouse.gov/code/t48c055.php | Code of Laws - Title 48 - Chapter 55- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c056 | 200 | 47874 | https://www.scstatehouse.gov/code/t48c056.php | Code of Laws - Title 48 - Chapter 56- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c057 | 200 | 39248 | https://www.scstatehouse.gov/code/t48c057.php | Code of Laws - Title 48 - Chapter 57- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c059 | 200 | 71720 | https://www.scstatehouse.gov/code/t48c059.php | Code of Laws - Title 48 - Chapter 59- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c060 | 200 | 112951 | https://www.scstatehouse.gov/code/t48c060.php | Code of Laws - Title 48 - Chapter 60- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c061 | 200 | 26159 | https://www.scstatehouse.gov/code/t48c061.php | Code of Laws - Title 48 - Chapter 61- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t48c062 | 200 | 51221 | https://www.scstatehouse.gov/code/t48c062.php | Code of Laws - Title 48 - Chapter 62- - ENVIRONMENTAL PROTECTION AND CONSERVATIO |  |
| SC_t49c001 | 200 | 43549 | https://www.scstatehouse.gov/code/t49c001.php | Code of Laws - Title 49 - Chapter 1- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c003 | 200 | 33514 | https://www.scstatehouse.gov/code/t49c003.php | Code of Laws - Title 49 - Chapter 3- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c004 | 200 | 85515 | https://www.scstatehouse.gov/code/t49c004.php | Code of Laws - Title 49 - Chapter 4- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c005 | 200 | 44505 | https://www.scstatehouse.gov/code/t49c005.php | Code of Laws - Title 49 - Chapter 5- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c006 | 200 | 25290 | https://www.scstatehouse.gov/code/t49c006.php | Code of Laws - Title 49 - Chapter 6- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c007 | 200 | 43001 | https://www.scstatehouse.gov/code/t49c007.php | Code of Laws - Title 49 - Chapter 7- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c009 | 200 | 25507 | https://www.scstatehouse.gov/code/t49c009.php | Code of Laws - Title 49 - Chapter 9- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c011 | 200 | 42707 | https://www.scstatehouse.gov/code/t49c011.php | Code of Laws - Title 49 - Chapter 11- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c017 | 200 | 98325 | https://www.scstatehouse.gov/code/t49c017.php | Code of Laws - Title 49 - Chapter 17- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c019 | 200 | 169119 | https://www.scstatehouse.gov/code/t49c019.php | Code of Laws - Title 49 - Chapter 19- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c021 | 200 | 21227 | https://www.scstatehouse.gov/code/t49c021.php | Code of Laws - Title 49 - Chapter 21- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c023 | 200 | 40558 | https://www.scstatehouse.gov/code/t49c023.php | Code of Laws - Title 49 - Chapter 23- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c025 | 200 | 22376 | https://www.scstatehouse.gov/code/t49c025.php | Code of Laws - Title 49 - Chapter 25- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c027 | 200 | 41313 | https://www.scstatehouse.gov/code/t49c027.php | Code of Laws - Title 49 - Chapter 27- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c028 | 200 | 33677 | https://www.scstatehouse.gov/code/t49c028.php | Code of Laws - Title 49 - Chapter 28- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c029 | 200 | 50283 | https://www.scstatehouse.gov/code/t49c029.php | Code of Laws - Title 49 - Chapter 29- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c030 | 200 | 32585 | https://www.scstatehouse.gov/code/t49c030.php | Code of Laws - Title 49 - Chapter 30- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t49c033 | 200 | 25108 | https://www.scstatehouse.gov/code/t49c033.php | Code of Laws - Title 49 - Chapter 33- - WATERS, WATER RESOURCES AND DRAINAGE |  |
| SC_t50c001 | 200 | 101671 | https://www.scstatehouse.gov/code/t50c001.php | Code of Laws - Title 50 - Chapter 1- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c002 | 200 | 22819 | https://www.scstatehouse.gov/code/t50c002.php | Code of Laws - Title 50 - Chapter 2- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c003 | 200 | 74671 | https://www.scstatehouse.gov/code/t50c003.php | Code of Laws - Title 50 - Chapter 3- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c004 | 200 | 21646 | https://www.scstatehouse.gov/code/t50c004.php | Code of Laws - Title 50 - Chapter 4- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c005 | 200 | 333403 | https://www.scstatehouse.gov/code/t50c005.php | Code of Laws - Title 50 - Chapter 5- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c009 | 200 | 134866 | https://www.scstatehouse.gov/code/t50c009.php | Code of Laws - Title 50 - Chapter 9- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c011 | 200 | 313089 | https://www.scstatehouse.gov/code/t50c011.php | Code of Laws - Title 50 - Chapter 11- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c012 | 200 | 41987 | https://www.scstatehouse.gov/code/t50c012.php | Code of Laws - Title 50 - Chapter 12- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c013 | 200 | 174482 | https://www.scstatehouse.gov/code/t50c013.php | Code of Laws - Title 50 - Chapter 13- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c015 | 200 | 70887 | https://www.scstatehouse.gov/code/t50c015.php | Code of Laws - Title 50 - Chapter 15- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c016 | 200 | 26881 | https://www.scstatehouse.gov/code/t50c016.php | Code of Laws - Title 50 - Chapter 16- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c018 | 200 | 41698 | https://www.scstatehouse.gov/code/t50c018.php | Code of Laws - Title 50 - Chapter 18- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c019 | 200 | 67051 | https://www.scstatehouse.gov/code/t50c019.php | Code of Laws - Title 50 - Chapter 19- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c020 | 200 | 40631 | https://www.scstatehouse.gov/code/t50c020.php | Code of Laws - Title 50 - Chapter 20- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c021 | 200 | 130876 | https://www.scstatehouse.gov/code/t50c021.php | Code of Laws - Title 50 - Chapter 21- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c023 | 200 | 215726 | https://www.scstatehouse.gov/code/t50c023.php | Code of Laws - Title 50 - Chapter 23- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c025 | 200 | 46512 | https://www.scstatehouse.gov/code/t50c025.php | Code of Laws - Title 50 - Chapter 25- - FISH, GAME AND WATERCRAFT |  |
| SC_t50c026 | 200 | 25984 | https://www.scstatehouse.gov/code/t50c026.php | Code of Laws - Title 50 - Chapter 26- - FISH, GAME AND WATERCRAFT |  |
| SC_t51c001 | 200 | 34502 | https://www.scstatehouse.gov/code/t51c001.php | Code of Laws - Title 51 - Chapter 1- - PARKS, RECREATION, AND TOURISM |  |
| SC_t51c003 | 200 | 43762 | https://www.scstatehouse.gov/code/t51c003.php | Code of Laws - Title 51 - Chapter 3- - PARKS, RECREATION, AND TOURISM |  |
| SC_t51c007 | 200 | 27164 | https://www.scstatehouse.gov/code/t51c007.php | Code of Laws - Title 51 - Chapter 7- - PARKS, RECREATION, AND TOURISM |  |
| SC_t51c009 | 200 | 20805 | https://www.scstatehouse.gov/code/t51c009.php | Code of Laws - Title 51 - Chapter 9- - PARKS, RECREATION, AND TOURISM |  |
| SC_t51c011 | 200 | 25119 | https://www.scstatehouse.gov/code/t51c011.php | Code of Laws - Title 51 - Chapter 11- - PARKS, RECREATION, AND TOURISM |  |
| SC_t51c013 | 200 | 103369 | https://www.scstatehouse.gov/code/t51c013.php | Code of Laws - Title 51 - Chapter 13- - PARKS, RECREATION, AND TOURISM |  |
| SC_t51c015 | 200 | 48547 | https://www.scstatehouse.gov/code/t51c015.php | Code of Laws - Title 51 - Chapter 15- - PARKS, RECREATION, AND TOURISM |  |
| SC_t51c017 | 200 | 70019 | https://www.scstatehouse.gov/code/t51c017.php | Code of Laws - Title 51 - Chapter 17- - PARKS, RECREATION, AND TOURISM |  |
| SC_t51c018 | 200 | 64597 | https://www.scstatehouse.gov/code/t51c018.php | Code of Laws - Title 51 - Chapter 18- - PARKS, RECREATION, AND TOURISM |  |
| SC_t51c019 | 200 | 26021 | https://www.scstatehouse.gov/code/t51c019.php | Code of Laws - Title 51 - Chapter 19- - PARKS, RECREATION, AND TOURISM |  |
| SC_t51c022 | 200 | 26951 | https://www.scstatehouse.gov/code/t51c022.php | Code of Laws - Title 51 - Chapter 22- - PARKS, RECREATION, AND TOURISM |  |
| SC_t51c023 | 200 | 23077 | https://www.scstatehouse.gov/code/t51c023.php | Code of Laws - Title 51 - Chapter 23- - PARKS, RECREATION, AND TOURISM |  |
| SC_t52c001 | 200 | 24977 | https://www.scstatehouse.gov/code/t52c001.php | Code of Laws - Title 52 - Chapter 1- - AMUSEMENTS AND ATHLETIC CONTESTS |  |
| SC_t52c003 | 200 | 21975 | https://www.scstatehouse.gov/code/t52c003.php | Code of Laws - Title 52 - Chapter 3- - AMUSEMENTS AND ATHLETIC CONTESTS |  |
| SC_t52c005 | 200 | 31298 | https://www.scstatehouse.gov/code/t52c005.php | Code of Laws - Title 52 - Chapter 5- - AMUSEMENTS AND ATHLETIC CONTESTS |  |
| SC_t52c013 | 200 | 22703 | https://www.scstatehouse.gov/code/t52c013.php | Code of Laws - Title 52 - Chapter 13- - AMUSEMENTS AND ATHLETIC CONTESTS |  |
| SC_t52c019 | 200 | 77068 | https://www.scstatehouse.gov/code/t52c019.php | Code of Laws - Title 52 - Chapter 19- - AMUSEMENTS AND ATHLETIC CONTESTS |  |
| SC_t52c021 | 200 | 26836 | https://www.scstatehouse.gov/code/t52c021.php | Code of Laws - Title 52 - Chapter 21- - AMUSEMENTS AND ATHLETIC CONTESTS |  |
| SC_t53c001 | 200 | 47163 | https://www.scstatehouse.gov/code/t53c001.php | Code of Laws - Title 53 - Chapter 1- - SUNDAYS, HOLIDAYS, AND OTHER SPECIAL DAYS |  |
| SC_t53c003 | 200 | 75218 | https://www.scstatehouse.gov/code/t53c003.php | Code of Laws - Title 53 - Chapter 3- - SUNDAYS, HOLIDAYS, AND OTHER SPECIAL DAYS |  |
| SC_t53c005 | 200 | 26167 | https://www.scstatehouse.gov/code/t53c005.php | Code of Laws - Title 53 - Chapter 5- - SUNDAYS, HOLIDAYS, AND OTHER SPECIAL DAYS |  |
| SC_t54c001 | 200 | 23666 | https://www.scstatehouse.gov/code/t54c001.php | Code of Laws - Title 54 - Chapter 1- - PORTS AND MARITIME MATTERS |  |
| SC_t54c003 | 200 | 112962 | https://www.scstatehouse.gov/code/t54c003.php | Code of Laws - Title 54 - Chapter 3- - PORTS AND MARITIME MATTERS |  |
| SC_t54c005 | 200 | 30138 | https://www.scstatehouse.gov/code/t54c005.php | Code of Laws - Title 54 - Chapter 5- - PORTS AND MARITIME MATTERS |  |
| SC_t54c006 | 200 | 24613 | https://www.scstatehouse.gov/code/t54c006.php | Code of Laws - Title 54 - Chapter 6- - PORTS AND MARITIME MATTERS |  |
| SC_t54c007 | 200 | 110118 | https://www.scstatehouse.gov/code/t54c007.php | Code of Laws - Title 54 - Chapter 7- - PORTS AND MARITIME MATTERS |  |
| SC_t54c009 | 200 | 26606 | https://www.scstatehouse.gov/code/t54c009.php | Code of Laws - Title 54 - Chapter 9- - PORTS AND MARITIME MATTERS |  |
| SC_t54c011 | 200 | 24537 | https://www.scstatehouse.gov/code/t54c011.php | Code of Laws - Title 54 - Chapter 11- - PORTS AND MARITIME MATTERS |  |
| SC_t54c013 | 200 | 22299 | https://www.scstatehouse.gov/code/t54c013.php | Code of Laws - Title 54 - Chapter 13- - PORTS AND MARITIME MATTERS |  |
| SC_t54c015 | 200 | 70624 | https://www.scstatehouse.gov/code/t54c015.php | Code of Laws - Title 54 - Chapter 15- - PORTS AND MARITIME MATTERS |  |
| SC_t54c017 | 200 | 31874 | https://www.scstatehouse.gov/code/t54c017.php | Code of Laws - Title 54 - Chapter 17- - PORTS AND MARITIME MATTERS |  |
| SC_t55c001 | 200 | 62400 | https://www.scstatehouse.gov/code/t55c001.php | Code of Laws - Title 55 - Chapter 1- - AERONAUTICS |  |
| SC_t55c003 | 200 | 31901 | https://www.scstatehouse.gov/code/t55c003.php | Code of Laws - Title 55 - Chapter 3- - AERONAUTICS |  |
| SC_t55c005 | 200 | 55904 | https://www.scstatehouse.gov/code/t55c005.php | Code of Laws - Title 55 - Chapter 5- - AERONAUTICS |  |
| SC_t55c009 | 200 | 46940 | https://www.scstatehouse.gov/code/t55c009.php | Code of Laws - Title 55 - Chapter 9- - AERONAUTICS |  |
| SC_t55c011 | 200 | 146522 | https://www.scstatehouse.gov/code/t55c011.php | Code of Laws - Title 55 - Chapter 11- - AERONAUTICS |  |
| SC_t55c013 | 200 | 26717 | https://www.scstatehouse.gov/code/t55c013.php | Code of Laws - Title 55 - Chapter 13- - AERONAUTICS |  |
| SC_t55c015 | 200 | 45227 | https://www.scstatehouse.gov/code/t55c015.php | Code of Laws - Title 55 - Chapter 15- - AERONAUTICS |  |
| SC_t55c017 | 200 | 29969 | https://www.scstatehouse.gov/code/t55c017.php | Code of Laws - Title 55 - Chapter 17- - AERONAUTICS |  |
| SC_t56c001 | 200 | 406830 | https://www.scstatehouse.gov/code/t56c001.php | Code of Laws - Title 56 - Chapter 1- - MOTOR VEHICLES |  |
| SC_t56c002 | 200 | 52488 | https://www.scstatehouse.gov/code/t56c002.php | Code of Laws - Title 56 - Chapter 2- - MOTOR VEHICLES |  |
| SC_t56c003 | 200 | 637051 | https://www.scstatehouse.gov/code/t56c003.php | Code of Laws - Title 56 - Chapter 3- - MOTOR VEHICLES |  |
| SC_t56c005 | 200 | 706474 | https://www.scstatehouse.gov/code/t56c005.php | Code of Laws - Title 56 - Chapter 5- - MOTOR VEHICLES |  |
| SC_t56c007 | 200 | 45904 | https://www.scstatehouse.gov/code/t56c007.php | Code of Laws - Title 56 - Chapter 7- - MOTOR VEHICLES |  |
| SC_t56c009 | 200 | 87624 | https://www.scstatehouse.gov/code/t56c009.php | Code of Laws - Title 56 - Chapter 9- - MOTOR VEHICLES |  |
| SC_t56c010 | 200 | 71974 | https://www.scstatehouse.gov/code/t56c010.php | Code of Laws - Title 56 - Chapter 10- - MOTOR VEHICLES |  |
| SC_t56c011 | 200 | 36417 | https://www.scstatehouse.gov/code/t56c011.php | Code of Laws - Title 56 - Chapter 11- - MOTOR VEHICLES |  |
| SC_t56c014 | 200 | 80045 | https://www.scstatehouse.gov/code/t56c014.php | Code of Laws - Title 56 - Chapter 14- - MOTOR VEHICLES |  |
| SC_t56c015 | 200 | 150606 | https://www.scstatehouse.gov/code/t56c015.php | Code of Laws - Title 56 - Chapter 15- - MOTOR VEHICLES |  |
| SC_t56c016 | 200 | 70378 | https://www.scstatehouse.gov/code/t56c016.php | Code of Laws - Title 56 - Chapter 16- - MOTOR VEHICLES |  |
| SC_t56c017 | 200 | 20240 | https://www.scstatehouse.gov/code/t56c017.php | Code of Laws - Title 56 - Chapter 17- - MOTOR VEHICLES |  |
| SC_t56c019 | 200 | 169059 | https://www.scstatehouse.gov/code/t56c019.php | Code of Laws - Title 56 - Chapter 19- - MOTOR VEHICLES |  |
| SC_t56c021 | 200 | 27465 | https://www.scstatehouse.gov/code/t56c021.php | Code of Laws - Title 56 - Chapter 21- - MOTOR VEHICLES |  |
| SC_t56c023 | 200 | 34309 | https://www.scstatehouse.gov/code/t56c023.php | Code of Laws - Title 56 - Chapter 23- - MOTOR VEHICLES |  |
| SC_t56c025 | 200 | 24680 | https://www.scstatehouse.gov/code/t56c025.php | Code of Laws - Title 56 - Chapter 25- - MOTOR VEHICLES |  |
| SC_t56c027 | 200 | 22590 | https://www.scstatehouse.gov/code/t56c027.php | Code of Laws - Title 56 - Chapter 27- - MOTOR VEHICLES |  |
| SC_t56c028 | 200 | 33741 | https://www.scstatehouse.gov/code/t56c028.php | Code of Laws - Title 56 - Chapter 28- - MOTOR VEHICLES |  |
| SC_t56c029 | 200 | 39630 | https://www.scstatehouse.gov/code/t56c029.php | Code of Laws - Title 56 - Chapter 29- - MOTOR VEHICLES |  |
| SC_t56c031 | 200 | 32199 | https://www.scstatehouse.gov/code/t56c031.php | Code of Laws - Title 56 - Chapter 31- - MOTOR VEHICLES |  |
| SC_t56c032 | 200 | 21809 | https://www.scstatehouse.gov/code/t56c032.php | Code of Laws - Title 56 - Chapter 32- - MOTOR VEHICLES |  |
| SC_t56c035 | 200 | 31093 | https://www.scstatehouse.gov/code/t56c035.php | Code of Laws - Title 56 - Chapter 35- - MOTOR VEHICLES |  |
| SC_t56c036 | 200 | 37102 | https://www.scstatehouse.gov/code/t56c036.php | Code of Laws - Title 56 - Chapter 36- - MOTOR VEHICLES |  |
| SC_t56c037 | 200 | 43484 | https://www.scstatehouse.gov/code/t56c037.php | Code of Laws - Title 56 - Chapter 37- - MOTOR VEHICLES |  |
| SC_t57c001 | 200 | 81634 | https://www.scstatehouse.gov/code/t57c001.php | Code of Laws - Title 57 - Chapter 1- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c003 | 200 | 102241 | https://www.scstatehouse.gov/code/t57c003.php | Code of Laws - Title 57 - Chapter 3- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c005 | 200 | 205796 | https://www.scstatehouse.gov/code/t57c005.php | Code of Laws - Title 57 - Chapter 5- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c007 | 200 | 34131 | https://www.scstatehouse.gov/code/t57c007.php | Code of Laws - Title 57 - Chapter 7- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c009 | 200 | 21787 | https://www.scstatehouse.gov/code/t57c009.php | Code of Laws - Title 57 - Chapter 9- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c011 | 200 | 39535 | https://www.scstatehouse.gov/code/t57c011.php | Code of Laws - Title 57 - Chapter 11- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c013 | 200 | 36288 | https://www.scstatehouse.gov/code/t57c013.php | Code of Laws - Title 57 - Chapter 13- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c015 | 200 | 22353 | https://www.scstatehouse.gov/code/t57c015.php | Code of Laws - Title 57 - Chapter 15- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c017 | 200 | 37975 | https://www.scstatehouse.gov/code/t57c017.php | Code of Laws - Title 57 - Chapter 17- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c019 | 200 | 30157 | https://www.scstatehouse.gov/code/t57c019.php | Code of Laws - Title 57 - Chapter 19- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c021 | 200 | 40065 | https://www.scstatehouse.gov/code/t57c021.php | Code of Laws - Title 57 - Chapter 21- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c023 | 200 | 48778 | https://www.scstatehouse.gov/code/t57c023.php | Code of Laws - Title 57 - Chapter 23- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c025 | 200 | 109389 | https://www.scstatehouse.gov/code/t57c025.php | Code of Laws - Title 57 - Chapter 25- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t57c027 | 200 | 31314 | https://www.scstatehouse.gov/code/t57c027.php | Code of Laws - Title 57 - Chapter 27- - HIGHWAYS, BRIDGES AND FERRIES |  |
| SC_t58c001 | 200 | 29443 | https://www.scstatehouse.gov/code/t58c001.php | Code of Laws - Title 58 - Chapter 1- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c002 | 200 | 21614 | https://www.scstatehouse.gov/code/t58c002.php | Code of Laws - Title 58 - Chapter 2- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c003 | 200 | 147422 | https://www.scstatehouse.gov/code/t58c003.php | Code of Laws - Title 58 - Chapter 3- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c004 | 200 | 86793 | https://www.scstatehouse.gov/code/t58c004.php | Code of Laws - Title 58 - Chapter 4- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c005 | 200 | 101487 | https://www.scstatehouse.gov/code/t58c005.php | Code of Laws - Title 58 - Chapter 5- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c007 | 200 | 47984 | https://www.scstatehouse.gov/code/t58c007.php | Code of Laws - Title 58 - Chapter 7- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c009 | 200 | 296864 | https://www.scstatehouse.gov/code/t58c009.php | Code of Laws - Title 58 - Chapter 9- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c011 | 200 | 147270 | https://www.scstatehouse.gov/code/t58c011.php | Code of Laws - Title 58 - Chapter 11- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c012 | 200 | 80597 | https://www.scstatehouse.gov/code/t58c012.php | Code of Laws - Title 58 - Chapter 12- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c013 | 200 | 58381 | https://www.scstatehouse.gov/code/t58c013.php | Code of Laws - Title 58 - Chapter 13- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c015 | 200 | 100328 | https://www.scstatehouse.gov/code/t58c015.php | Code of Laws - Title 58 - Chapter 15- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c017 | 200 | 259942 | https://www.scstatehouse.gov/code/t58c017.php | Code of Laws - Title 58 - Chapter 17- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c021 | 200 | 34405 | https://www.scstatehouse.gov/code/t58c021.php | Code of Laws - Title 58 - Chapter 21- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c023 | 200 | 147606 | https://www.scstatehouse.gov/code/t58c023.php | Code of Laws - Title 58 - Chapter 23- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c025 | 200 | 49983 | https://www.scstatehouse.gov/code/t58c025.php | Code of Laws - Title 58 - Chapter 25- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c027 | 200 | 388092 | https://www.scstatehouse.gov/code/t58c027.php | Code of Laws - Title 58 - Chapter 27- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c031 | 200 | 174606 | https://www.scstatehouse.gov/code/t58c031.php | Code of Laws - Title 58 - Chapter 31- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c033 | 200 | 198536 | https://www.scstatehouse.gov/code/t58c033.php | Code of Laws - Title 58 - Chapter 33- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c034 | 200 | 27405 | https://www.scstatehouse.gov/code/t58c034.php | Code of Laws - Title 58 - Chapter 34- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c036 | 200 | 70371 | https://www.scstatehouse.gov/code/t58c036.php | Code of Laws - Title 58 - Chapter 36- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c037 | 200 | 147036 | https://www.scstatehouse.gov/code/t58c037.php | Code of Laws - Title 58 - Chapter 37- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c039 | 200 | 42515 | https://www.scstatehouse.gov/code/t58c039.php | Code of Laws - Title 58 - Chapter 39- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c040 | 200 | 36102 | https://www.scstatehouse.gov/code/t58c040.php | Code of Laws - Title 58 - Chapter 40- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c041 | 200 | 66811 | https://www.scstatehouse.gov/code/t58c041.php | Code of Laws - Title 58 - Chapter 41- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c042 | 200 | 48379 | https://www.scstatehouse.gov/code/t58c042.php | Code of Laws - Title 58 - Chapter 42- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t58c043 | 200 | 39259 | https://www.scstatehouse.gov/code/t58c043.php | Code of Laws - Title 58 - Chapter 43- - PUBLIC UTILITIES, SERVICES AND CARRIERS |  |
| SC_t59c001 | 200 | 108977 | https://www.scstatehouse.gov/code/t59c001.php | Code of Laws - Title 59 - Chapter 1- - EDUCATION |  |
| SC_t59c002 | 200 | 50071 | https://www.scstatehouse.gov/code/t59c002.php | Code of Laws - Title 59 - Chapter 2- - EDUCATION |  |
| SC_t59c003 | 200 | 35137 | https://www.scstatehouse.gov/code/t59c003.php | Code of Laws - Title 59 - Chapter 3- - EDUCATION |  |
| SC_t59c004 | 200 | 34642 | https://www.scstatehouse.gov/code/t59c004.php | Code of Laws - Title 59 - Chapter 4- - EDUCATION |  |
| SC_t59c005 | 200 | 57792 | https://www.scstatehouse.gov/code/t59c005.php | Code of Laws - Title 59 - Chapter 5- - EDUCATION |  |
| SC_t59c006 | 200 | 39394 | https://www.scstatehouse.gov/code/t59c006.php | Code of Laws - Title 59 - Chapter 6- - EDUCATION |  |
| SC_t59c007 | 200 | 24171 | https://www.scstatehouse.gov/code/t59c007.php | Code of Laws - Title 59 - Chapter 7- - EDUCATION |  |
| SC_t59c008 | 200 | 76073 | https://www.scstatehouse.gov/code/t59c008.php | Code of Laws - Title 59 - Chapter 8- - EDUCATION |  |
| SC_t59c009 | 200 | 34240 | https://www.scstatehouse.gov/code/t59c009.php | Code of Laws - Title 59 - Chapter 9- - EDUCATION |  |
| SC_t59c010 | 200 | 49556 | https://www.scstatehouse.gov/code/t59c010.php | Code of Laws - Title 59 - Chapter 10- - EDUCATION |  |
| SC_t59c011 | 200 | 39301 | https://www.scstatehouse.gov/code/t59c011.php | Code of Laws - Title 59 - Chapter 11- - EDUCATION |  |
| SC_t59c013 | 200 | 33027 | https://www.scstatehouse.gov/code/t59c013.php | Code of Laws - Title 59 - Chapter 13- - EDUCATION |  |
| SC_t59c015 | 200 | 22618 | https://www.scstatehouse.gov/code/t59c015.php | Code of Laws - Title 59 - Chapter 15- - EDUCATION |  |
| SC_t59c016 | 200 | 29805 | https://www.scstatehouse.gov/code/t59c016.php | Code of Laws - Title 59 - Chapter 16- - EDUCATION |  |
| SC_t59c017 | 200 | 55332 | https://www.scstatehouse.gov/code/t59c017.php | Code of Laws - Title 59 - Chapter 17- - EDUCATION |  |
| SC_t59c018 | 200 | 132734 | https://www.scstatehouse.gov/code/t59c018.php | Code of Laws - Title 59 - Chapter 18- - EDUCATION |  |
| SC_t59c019 | 200 | 83016 | https://www.scstatehouse.gov/code/t59c019.php | Code of Laws - Title 59 - Chapter 19- - EDUCATION |  |
| SC_t59c020 | 200 | 96597 | https://www.scstatehouse.gov/code/t59c020.php | Code of Laws - Title 59 - Chapter 20- - EDUCATION |  |
| SC_t59c021 | 200 | 80201 | https://www.scstatehouse.gov/code/t59c021.php | Code of Laws - Title 59 - Chapter 21- - EDUCATION |  |
| SC_t59c023 | 200 | 40636 | https://www.scstatehouse.gov/code/t59c023.php | Code of Laws - Title 59 - Chapter 23- - EDUCATION |  |
| SC_t59c024 | 200 | 36123 | https://www.scstatehouse.gov/code/t59c024.php | Code of Laws - Title 59 - Chapter 24- - EDUCATION |  |
| SC_t59c025 | 200 | 95472 | https://www.scstatehouse.gov/code/t59c025.php | Code of Laws - Title 59 - Chapter 25- - EDUCATION |  |
| SC_t59c026 | 200 | 80677 | https://www.scstatehouse.gov/code/t59c026.php | Code of Laws - Title 59 - Chapter 26- - EDUCATION |  |
| SC_t59c027 | 200 | 30738 | https://www.scstatehouse.gov/code/t59c027.php | Code of Laws - Title 59 - Chapter 27- - EDUCATION |  |
| SC_t59c028 | 200 | 33047 | https://www.scstatehouse.gov/code/t59c028.php | Code of Laws - Title 59 - Chapter 28- - EDUCATION |  |
| SC_t59c029 | 200 | 84828 | https://www.scstatehouse.gov/code/t59c029.php | Code of Laws - Title 59 - Chapter 29- - EDUCATION |  |
| SC_t59c031 | 200 | 56716 | https://www.scstatehouse.gov/code/t59c031.php | Code of Laws - Title 59 - Chapter 31- - EDUCATION |  |
| SC_t59c032 | 200 | 39735 | https://www.scstatehouse.gov/code/t59c032.php | Code of Laws - Title 59 - Chapter 32- - EDUCATION |  |
| SC_t59c033 | 200 | 56614 | https://www.scstatehouse.gov/code/t59c033.php | Code of Laws - Title 59 - Chapter 33- - EDUCATION |  |
| SC_t59c034 | 200 | 23467 | https://www.scstatehouse.gov/code/t59c034.php | Code of Laws - Title 59 - Chapter 34- - EDUCATION |  |
| SC_t59c035 | 200 | 21756 | https://www.scstatehouse.gov/code/t59c035.php | Code of Laws - Title 59 - Chapter 35- - EDUCATION |  |
| SC_t59c036 | 200 | 34637 | https://www.scstatehouse.gov/code/t59c036.php | Code of Laws - Title 59 - Chapter 36- - EDUCATION |  |
| SC_t59c037 | 200 | 21733 | https://www.scstatehouse.gov/code/t59c037.php | Code of Laws - Title 59 - Chapter 37- - EDUCATION |  |
| SC_t59c038 | 200 | 23373 | https://www.scstatehouse.gov/code/t59c038.php | Code of Laws - Title 59 - Chapter 38- - EDUCATION |  |
| SC_t59c039 | 200 | 46914 | https://www.scstatehouse.gov/code/t59c039.php | Code of Laws - Title 59 - Chapter 39- - EDUCATION |  |
| SC_t59c040 | 200 | 171680 | https://www.scstatehouse.gov/code/t59c040.php | Code of Laws - Title 59 - Chapter 40- - EDUCATION |  |
| SC_t59c041 | 200 | 25761 | https://www.scstatehouse.gov/code/t59c041.php | Code of Laws - Title 59 - Chapter 41- - EDUCATION |  |
| SC_t59c043 | 200 | 24378 | https://www.scstatehouse.gov/code/t59c043.php | Code of Laws - Title 59 - Chapter 43- - EDUCATION |  |
| SC_t59c044 | 200 | 22834 | https://www.scstatehouse.gov/code/t59c044.php | Code of Laws - Title 59 - Chapter 44- - EDUCATION |  |
| SC_t59c045 | 200 | 20031 | https://www.scstatehouse.gov/code/t59c045.php | Code of Laws - Title 59 - Chapter 45- - EDUCATION |  |
| SC_t59c046 | 200 | 76339 | https://www.scstatehouse.gov/code/t59c046.php | Code of Laws - Title 59 - Chapter 46- - EDUCATION |  |
| SC_t59c047 | 200 | 30090 | https://www.scstatehouse.gov/code/t59c047.php | Code of Laws - Title 59 - Chapter 47- - EDUCATION |  |
| SC_t59c048 | 200 | 27901 | https://www.scstatehouse.gov/code/t59c048.php | Code of Laws - Title 59 - Chapter 48- - EDUCATION |  |
| SC_t59c049 | 200 | 40263 | https://www.scstatehouse.gov/code/t59c049.php | Code of Laws - Title 59 - Chapter 49- - EDUCATION |  |
| SC_t59c050 | 200 | 28328 | https://www.scstatehouse.gov/code/t59c050.php | Code of Laws - Title 59 - Chapter 50- - EDUCATION |  |
| SC_t59c051 | 200 | 25061 | https://www.scstatehouse.gov/code/t59c051.php | Code of Laws - Title 59 - Chapter 51- - EDUCATION |  |
| SC_t59c053 | 200 | 238151 | https://www.scstatehouse.gov/code/t59c053.php | Code of Laws - Title 59 - Chapter 53- - EDUCATION |  |
| SC_t59c054 | 200 | 32483 | https://www.scstatehouse.gov/code/t59c054.php | Code of Laws - Title 59 - Chapter 54- - EDUCATION |  |
| SC_t59c055 | 200 | 26455 | https://www.scstatehouse.gov/code/t59c055.php | Code of Laws - Title 59 - Chapter 55- - EDUCATION |  |
| SC_t59c056 | 200 | 23003 | https://www.scstatehouse.gov/code/t59c056.php | Code of Laws - Title 59 - Chapter 56- - EDUCATION |  |
| SC_t59c057 | 200 | 23928 | https://www.scstatehouse.gov/code/t59c057.php | Code of Laws - Title 59 - Chapter 57- - EDUCATION |  |
| SC_t59c058 | 200 | 46583 | https://www.scstatehouse.gov/code/t59c058.php | Code of Laws - Title 59 - Chapter 58- - EDUCATION |  |
| SC_t59c059 | 200 | 46307 | https://www.scstatehouse.gov/code/t59c059.php | Code of Laws - Title 59 - Chapter 59- - EDUCATION |  |
| SC_t59c063 | 200 | 159055 | https://www.scstatehouse.gov/code/t59c063.php | Code of Laws - Title 59 - Chapter 63- - EDUCATION |  |
| SC_t59c065 | 200 | 46117 | https://www.scstatehouse.gov/code/t59c065.php | Code of Laws - Title 59 - Chapter 65- - EDUCATION |  |
| SC_t59c066 | 200 | 27591 | https://www.scstatehouse.gov/code/t59c066.php | Code of Laws - Title 59 - Chapter 66- - EDUCATION |  |
| SC_t59c067 | 200 | 83713 | https://www.scstatehouse.gov/code/t59c067.php | Code of Laws - Title 59 - Chapter 67- - EDUCATION |  |
| SC_t59c069 | 200 | 35060 | https://www.scstatehouse.gov/code/t59c069.php | Code of Laws - Title 59 - Chapter 69- - EDUCATION |  |
| SC_t59c071 | 200 | 58243 | https://www.scstatehouse.gov/code/t59c071.php | Code of Laws - Title 59 - Chapter 71- - EDUCATION |  |
| SC_t59c073 | 200 | 35075 | https://www.scstatehouse.gov/code/t59c073.php | Code of Laws - Title 59 - Chapter 73- - EDUCATION |  |
| SC_t59c101 | 200 | 95094 | https://www.scstatehouse.gov/code/t59c101.php | Code of Laws - Title 59 - Chapter 101- - EDUCATION |  |
| SC_t59c102 | 200 | 70873 | https://www.scstatehouse.gov/code/t59c102.php | Code of Laws - Title 59 - Chapter 102- - EDUCATION |  |
| SC_t59c103 | 200 | 67680 | https://www.scstatehouse.gov/code/t59c103.php | Code of Laws - Title 59 - Chapter 103- - EDUCATION |  |
| SC_t59c104 | 200 | 52419 | https://www.scstatehouse.gov/code/t59c104.php | Code of Laws - Title 59 - Chapter 104- - EDUCATION |  |
| SC_t59c105 | 200 | 26246 | https://www.scstatehouse.gov/code/t59c105.php | Code of Laws - Title 59 - Chapter 105- - EDUCATION |  |
| SC_t59c106 | 200 | 20932 | https://www.scstatehouse.gov/code/t59c106.php | Code of Laws - Title 59 - Chapter 106- - EDUCATION |  |
| SC_t59c107 | 200 | 45097 | https://www.scstatehouse.gov/code/t59c107.php | Code of Laws - Title 59 - Chapter 107- - EDUCATION |  |
| SC_t59c108 | 200 | 24123 | https://www.scstatehouse.gov/code/t59c108.php | Code of Laws - Title 59 - Chapter 108- - EDUCATION |  |
| SC_t59c109 | 200 | 52882 | https://www.scstatehouse.gov/code/t59c109.php | Code of Laws - Title 59 - Chapter 109- - EDUCATION |  |
| SC_t59c110 | 200 | 34116 | https://www.scstatehouse.gov/code/t59c110.php | Code of Laws - Title 59 - Chapter 110- - EDUCATION |  |
| SC_t59c111 | 200 | 48706 | https://www.scstatehouse.gov/code/t59c111.php | Code of Laws - Title 59 - Chapter 111- - EDUCATION |  |
| SC_t59c112 | 200 | 45802 | https://www.scstatehouse.gov/code/t59c112.php | Code of Laws - Title 59 - Chapter 112- - EDUCATION |  |
| SC_t59c113 | 200 | 26346 | https://www.scstatehouse.gov/code/t59c113.php | Code of Laws - Title 59 - Chapter 113- - EDUCATION |  |
| SC_t59c114 | 200 | 27664 | https://www.scstatehouse.gov/code/t59c114.php | Code of Laws - Title 59 - Chapter 114- - EDUCATION |  |
| SC_t59c115 | 200 | 45043 | https://www.scstatehouse.gov/code/t59c115.php | Code of Laws - Title 59 - Chapter 115- - EDUCATION |  |
| SC_t59c116 | 200 | 28775 | https://www.scstatehouse.gov/code/t59c116.php | Code of Laws - Title 59 - Chapter 116- - EDUCATION |  |
| SC_t59c117 | 200 | 58885 | https://www.scstatehouse.gov/code/t59c117.php | Code of Laws - Title 59 - Chapter 117- - EDUCATION |  |
| SC_t59c118 | 200 | 26631 | https://www.scstatehouse.gov/code/t59c118.php | Code of Laws - Title 59 - Chapter 118- - EDUCATION |  |
| SC_t59c119 | 200 | 98857 | https://www.scstatehouse.gov/code/t59c119.php | Code of Laws - Title 59 - Chapter 119- - EDUCATION |  |
| SC_t59c121 | 200 | 56511 | https://www.scstatehouse.gov/code/t59c121.php | Code of Laws - Title 59 - Chapter 121- - EDUCATION |  |
| SC_t59c122 | 200 | 38907 | https://www.scstatehouse.gov/code/t59c122.php | Code of Laws - Title 59 - Chapter 122- - EDUCATION |  |
| SC_t59c123 | 200 | 67752 | https://www.scstatehouse.gov/code/t59c123.php | Code of Laws - Title 59 - Chapter 123- - EDUCATION |  |
| SC_t59c125 | 200 | 82188 | https://www.scstatehouse.gov/code/t59c125.php | Code of Laws - Title 59 - Chapter 125- - EDUCATION |  |
| SC_t59c127 | 200 | 65437 | https://www.scstatehouse.gov/code/t59c127.php | Code of Laws - Title 59 - Chapter 127- - EDUCATION |  |
| SC_t59c129 | 200 | 20891 | https://www.scstatehouse.gov/code/t59c129.php | Code of Laws - Title 59 - Chapter 129- - EDUCATION |  |
| SC_t59c130 | 200 | 54641 | https://www.scstatehouse.gov/code/t59c130.php | Code of Laws - Title 59 - Chapter 130- - EDUCATION |  |
| SC_t59c131 | 200 | 35177 | https://www.scstatehouse.gov/code/t59c131.php | Code of Laws - Title 59 - Chapter 131- - EDUCATION |  |
| SC_t59c133 | 200 | 58650 | https://www.scstatehouse.gov/code/t59c133.php | Code of Laws - Title 59 - Chapter 133- - EDUCATION |  |
| SC_t59c135 | 200 | 29464 | https://www.scstatehouse.gov/code/t59c135.php | Code of Laws - Title 59 - Chapter 135- - EDUCATION |  |
| SC_t59c136 | 200 | 44267 | https://www.scstatehouse.gov/code/t59c136.php | Code of Laws - Title 59 - Chapter 136- - EDUCATION |  |
| SC_t59c139 | 200 | 38052 | https://www.scstatehouse.gov/code/t59c139.php | Code of Laws - Title 59 - Chapter 139- - EDUCATION |  |
| SC_t59c141 | 200 | 27659 | https://www.scstatehouse.gov/code/t59c141.php | Code of Laws - Title 59 - Chapter 141- - EDUCATION |  |
| SC_t59c142 | 200 | 26138 | https://www.scstatehouse.gov/code/t59c142.php | Code of Laws - Title 59 - Chapter 142- - EDUCATION |  |
| SC_t59c143 | 200 | 25551 | https://www.scstatehouse.gov/code/t59c143.php | Code of Laws - Title 59 - Chapter 143- - EDUCATION |  |
| SC_t59c144 | 200 | 29394 | https://www.scstatehouse.gov/code/t59c144.php | Code of Laws - Title 59 - Chapter 144- - EDUCATION |  |
| SC_t59c145 | 200 | 21511 | https://www.scstatehouse.gov/code/t59c145.php | Code of Laws - Title 59 - Chapter 145- - EDUCATION |  |
| SC_t59c146 | 200 | 32519 | https://www.scstatehouse.gov/code/t59c146.php | Code of Laws - Title 59 - Chapter 146- - EDUCATION |  |
| SC_t59c147 | 200 | 30870 | https://www.scstatehouse.gov/code/t59c147.php | Code of Laws - Title 59 - Chapter 147- - EDUCATION |  |
| SC_t59c149 | 200 | 45993 | https://www.scstatehouse.gov/code/t59c149.php | Code of Laws - Title 59 - Chapter 149- - EDUCATION |  |
| SC_t59c150 | 200 | 167233 | https://www.scstatehouse.gov/code/t59c150.php | Code of Laws - Title 59 - Chapter 150- - EDUCATION |  |
| SC_t59c151 | 200 | 35327 | https://www.scstatehouse.gov/code/t59c151.php | Code of Laws - Title 59 - Chapter 151- - EDUCATION |  |
| SC_t59c152 | 200 | 77444 | https://www.scstatehouse.gov/code/t59c152.php | Code of Laws - Title 59 - Chapter 152- - EDUCATION |  |
| SC_t59c153 | 200 | 39440 | https://www.scstatehouse.gov/code/t59c153.php | Code of Laws - Title 59 - Chapter 153- - EDUCATION |  |
| SC_t59c154 | 200 | 21622 | https://www.scstatehouse.gov/code/t59c154.php | Code of Laws - Title 59 - Chapter 154- - EDUCATION |  |
| SC_t59c155 | 200 | 67980 | https://www.scstatehouse.gov/code/t59c155.php | Code of Laws - Title 59 - Chapter 155- - EDUCATION |  |
| SC_t59c156 | 200 | 42458 | https://www.scstatehouse.gov/code/t59c156.php | Code of Laws - Title 59 - Chapter 156- - EDUCATION |  |
| SC_t59c158 | 200 | 35612 | https://www.scstatehouse.gov/code/t59c158.php | Code of Laws - Title 59 - Chapter 158- - EDUCATION |  |
| SC_t60c001 | 200 | 40901 | https://www.scstatehouse.gov/code/t60c001.php | Code of Laws - Title 60 - Chapter 1- - LIBRARIES, ARCHIVES, MUSEUMS, AND ARTS |  |
| SC_t60c002 | 200 | 22835 | https://www.scstatehouse.gov/code/t60c002.php | Code of Laws - Title 60 - Chapter 2- - LIBRARIES, ARCHIVES, MUSEUMS, AND ARTS |  |
| SC_t60c003 | 200 | 21010 | https://www.scstatehouse.gov/code/t60c003.php | Code of Laws - Title 60 - Chapter 3- - LIBRARIES, ARCHIVES, MUSEUMS, AND ARTS |  |
| SC_t60c004 | 200 | 22004 | https://www.scstatehouse.gov/code/t60c004.php | Code of Laws - Title 60 - Chapter 4- - LIBRARIES, ARCHIVES, MUSEUMS, AND ARTS |  |
| SC_t60c009 | 200 | 22704 | https://www.scstatehouse.gov/code/t60c009.php | Code of Laws - Title 60 - Chapter 9- - LIBRARIES, ARCHIVES, MUSEUMS, AND ARTS |  |
| SC_t60c011 | 200 | 37961 | https://www.scstatehouse.gov/code/t60c011.php | Code of Laws - Title 60 - Chapter 11- - LIBRARIES, ARCHIVES, MUSEUMS, AND ARTS |  |
| SC_t60c012 | 200 | 30136 | https://www.scstatehouse.gov/code/t60c012.php | Code of Laws - Title 60 - Chapter 12- - LIBRARIES, ARCHIVES, MUSEUMS, AND ARTS |  |
| SC_t60c013 | 200 | 28758 | https://www.scstatehouse.gov/code/t60c013.php | Code of Laws - Title 60 - Chapter 13- - LIBRARIES, ARCHIVES, MUSEUMS, AND ARTS |  |
| SC_t60c015 | 200 | 28226 | https://www.scstatehouse.gov/code/t60c015.php | Code of Laws - Title 60 - Chapter 15- - LIBRARIES, ARCHIVES, MUSEUMS, AND ARTS |  |
| SC_t60c017 | 200 | 24237 | https://www.scstatehouse.gov/code/t60c017.php | Code of Laws - Title 60 - Chapter 17- - LIBRARIES, ARCHIVES, MUSEUMS, AND ARTS |  |
| SC_t61c002 | 200 | 64702 | https://www.scstatehouse.gov/code/t61c002.php | Code of Laws - Title 61 - Chapter 2- - ALCOHOL AND ALCOHOLIC BEVERAGES |  |
| SC_t61c003 | 200 | 35278 | https://www.scstatehouse.gov/code/t61c003.php | Code of Laws - Title 61 - Chapter 3- - ALCOHOL AND ALCOHOLIC BEVERAGES |  |
| SC_t61c004 | 200 | 192535 | https://www.scstatehouse.gov/code/t61c004.php | Code of Laws - Title 61 - Chapter 4- - ALCOHOL AND ALCOHOLIC BEVERAGES |  |
| SC_t61c006 | 200 | 292682 | https://www.scstatehouse.gov/code/t61c006.php | Code of Laws - Title 61 - Chapter 6- - ALCOHOL AND ALCOHOLIC BEVERAGES |  |
| SC_t61c008 | 200 | 25811 | https://www.scstatehouse.gov/code/t61c008.php | Code of Laws - Title 61 - Chapter 8- - ALCOHOL AND ALCOHOLIC BEVERAGES |  |
| SC_t61c010 | 200 | 31822 | https://www.scstatehouse.gov/code/t61c010.php | Code of Laws - Title 61 - Chapter 10- - ALCOHOL AND ALCOHOLIC BEVERAGES |  |
| SC_t61c012 | 200 | 25379 | https://www.scstatehouse.gov/code/t61c012.php | Code of Laws - Title 61 - Chapter 12- - ALCOHOL AND ALCOHOLIC BEVERAGES |  |
| SC_t62c001 | 200 | 90330 | https://www.scstatehouse.gov/code/t62c001.php | Code of Laws - Title 62 - Article 1- - SOUTH CAROLINA PROBATE CODE |  |
| SC_t62c002 | 200 | 142249 | https://www.scstatehouse.gov/code/t62c002.php | Code of Laws - Title 62 - Article 2- - SOUTH CAROLINA PROBATE CODE |  |
| SC_t62c003 | 200 | 250507 | https://www.scstatehouse.gov/code/t62c003.php | Code of Laws - Title 62 - Article 3- - SOUTH CAROLINA PROBATE CODE |  |
| SC_t62c004 | 200 | 32258 | https://www.scstatehouse.gov/code/t62c004.php | Code of Laws - Title 62 - Article 4- - SOUTH CAROLINA PROBATE CODE |  |
| SC_t62c005 | 200 | 283269 | https://www.scstatehouse.gov/code/t62c005.php | Code of Laws - Title 62 - Article 5- - SOUTH CAROLINA PROBATE CODE |  |
| SC_t62c006 | 200 | 55582 | https://www.scstatehouse.gov/code/t62c006.php | Code of Laws - Title 62 - Article 6- - SOUTH CAROLINA PROBATE CODE |  |
| SC_t62c007 | 200 | 288053 | https://www.scstatehouse.gov/code/t62c007.php | Code of Laws - Title 62 - Article 7- - SOUTH CAROLINA PROBATE CODE |  |
| SC_t62c008 | 200 | 95783 | https://www.scstatehouse.gov/code/t62c008.php | Code of Laws - Title 62 - Article 8- - SOUTH CAROLINA PROBATE CODE |  |
| SC_t63c001 | 200 | 38650 | https://www.scstatehouse.gov/code/t63c001.php | Code of Laws - Title 63 - Chapter 1- - SOUTH CAROLINA CHILDREN'S CODE |  |
| SC_t63c003 | 200 | 92763 | https://www.scstatehouse.gov/code/t63c003.php | Code of Laws - Title 63 - Chapter 3- - SOUTH CAROLINA CHILDREN'S CODE |  |
| SC_t63c005 | 200 | 78082 | https://www.scstatehouse.gov/code/t63c005.php | Code of Laws - Title 63 - Chapter 5- - SOUTH CAROLINA CHILDREN'S CODE |  |
| SC_t63c007 | 200 | 375523 | https://www.scstatehouse.gov/code/t63c007.php | Code of Laws - Title 63 - Chapter 7- - SOUTH CAROLINA CHILDREN'S CODE |  |
| SC_t63c009 | 200 | 162383 | https://www.scstatehouse.gov/code/t63c009.php | Code of Laws - Title 63 - Chapter 9- - SOUTH CAROLINA CHILDREN'S CODE |  |
| SC_t63c011 | 200 | 207365 | https://www.scstatehouse.gov/code/t63c011.php | Code of Laws - Title 63 - Chapter 11- - SOUTH CAROLINA CHILDREN'S CODE |  |
| SC_t63c013 | 200 | 161231 | https://www.scstatehouse.gov/code/t63c013.php | Code of Laws - Title 63 - Chapter 13- - SOUTH CAROLINA CHILDREN'S CODE |  |
| SC_t63c015 | 200 | 156058 | https://www.scstatehouse.gov/code/t63c015.php | Code of Laws - Title 63 - Chapter 15- - SOUTH CAROLINA CHILDREN'S CODE |  |
| SC_t63c017 | 200 | 329620 | https://www.scstatehouse.gov/code/t63c017.php | Code of Laws - Title 63 - Chapter 17- - SOUTH CAROLINA CHILDREN'S CODE |  |
| SC_t63c019 | 200 | 259216 | https://www.scstatehouse.gov/code/t63c019.php | Code of Laws - Title 63 - Chapter 19- - SOUTH CAROLINA CHILDREN'S CODE |  |
| SC_t63c021 | 200 | 26252 | https://www.scstatehouse.gov/code/t63c021.php | Code of Laws - Title 63 - Chapter 21- - SOUTH CAROLINA CHILDREN'S CODE |  |
