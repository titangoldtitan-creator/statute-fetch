| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0020-0170-0110-0020 | 200 | 11882 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0110/section_0020/0020-0170-0110-0020.html |    2-17-1102. Definitions, MCA  |  |
| MTS_0020-0170-0110-0030 | 200 | 13108 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0110/section_0030/0020-0170-0110-0030.html |    2-17-1103. Responsibilities of department for digital government, MCA  |  |
| MTS_0020-0170-0110-0040 | 200 | 10902 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0110/section_0040/0020-0170-0110-0040.html |    2-17-1104. Rulemaking, MCA  |  |
| MTS_0020-0170-0110-0050 | 200 | 10660 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0110/section_0050/0020-0170-0110-0050.html |    2-17-1105. Repealed, MCA  |  |
| MTS_0020-0170-0120-0010 | 200 | 10638 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0120/section_0010/0020-0170-0120-0010.html |    2-17-1201. Short title, MCA  |  |
| MTS_0020-0170-0120-0020 | 200 | 12814 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0120/section_0020/0020-0170-0120-0020.html |    2-17-1202. Definitions, MCA  |  |
| MTS_0020-0170-0120-0030 | 200 | 12077 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0120/section_0030/0020-0170-0120-0030.html |    2-17-1203. Authority to use state building construction loans, MCA  |  |
| MTS_0020-0170-0120-0040 | 200 | 12004 | https://leg.mt.gov/bills/mca/title_0020/chapter_0170/part_0120/section_0040/0020-0170-0120-0040.html |    2-17-1204. Selecting lender for state building construction loan -- process,  |  |
| MTS_0020-0180-0010-0010 | 200 | 22919 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0010/0020-0180-0010-0010.html |    2-18-101. Definitions, MCA  |  |
| MTS_0020-0180-0010-0020 | 200 | 16735 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0020/0020-0180-0010-0020.html |    2-18-102. Personnel administration -- general policy setting -- oversight, MC |  |
| MTS_0020-0180-0010-0030 | 200 | 15676 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0030/0020-0180-0010-0030.html |    2-18-103. Officers and employees excepted, MCA  |  |
| MTS_0020-0180-0010-0040 | 200 | 15309 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0040/0020-0180-0010-0040.html |    2-18-104. Exemption for personal staff -- limit, MCA  |  |
| MTS_0020-0180-0010-0050 | 200 | 10908 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0050/0020-0180-0010-0050.html |    2-18-105. Repealed, MCA  |  |
| MTS_0020-0180-0010-0060 | 200 | 11655 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0060/0020-0180-0010-0060.html |    2-18-106. No limitation on legislative authority -- transfer of funds, MCA  |  |
| MTS_0020-0180-0010-0070 | 200 | 12375 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0070/0020-0180-0010-0070.html |    2-18-107. Job-sharing positions -- benefits, MCA  |  |
| MTS_0020-0180-0010-0080 | 200 | 10628 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0080/0020-0180-0010-0080.html |    2-18-108. and 2-18-109 reserved, MCA  |  |
| MTS_0020-0180-0010-0100 | 200 | 10908 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0100/0020-0180-0010-0100.html |    2-18-110. Repealed, MCA  |  |
| MTS_0020-0180-0010-0110 | 200 | 13457 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0110/0020-0180-0010-0110.html |    2-18-111. Hiring preference for residents of Indian reservations for state jo |  |
| MTS_0020-0180-0010-0120 | 200 | 10788 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0120/0020-0180-0010-0120.html |    2-18-112. through 2-18-114 reserved, MCA  |  |
| MTS_0020-0180-0010-0150 | 200 | 11960 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0150/0020-0180-0010-0150.html |    2-18-115. Exemption for certain university temporary employees -- "temporary  |  |
| MTS_0020-0180-0010-0160 | 200 | 10725 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0160/0020-0180-0010-0160.html |    2-18-116. through 2-18-119 reserved, MCA  |  |
| MTS_0020-0180-0010-0200 | 200 | 11058 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0010/section_0200/0020-0180-0010-0200.html |    2-18-120. Telework authorized and encouraged, MCA  |  |
| MTS_0020-0180-0020-0010 | 200 | 11565 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0020/section_0010/0020-0180-0020-0010.html |    2-18-201. Implementation and maintenance of broadband classification plan, MC |  |
| MTS_0020-0180-0020-0020 | 200 | 11239 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0020/section_0020/0020-0180-0020-0020.html |    2-18-202. Identification of occupations, MCA  |  |
| MTS_0020-0180-0020-0030 | 200 | 12708 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0020/section_0030/0020-0180-0020-0030.html |    2-18-203. Review of positions, MCA  |  |
| MTS_0020-0180-0020-0040 | 200 | 12024 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0020/section_0040/0020-0180-0020-0040.html |    2-18-204. Determination of number and occupations of employees in each agency |  |
| MTS_0020-0180-0020-0050 | 200 | 10957 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0020/section_0050/0020-0180-0020-0050.html |    2-18-205. Repealed, MCA  |  |
| MTS_0020-0180-0020-0060 | 200 | 11173 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0020/section_0060/0020-0180-0020-0060.html |    2-18-206. List of positions maintained, MCA  |  |
| MTS_0020-0180-0020-0070 | 200 | 10935 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0020/section_0070/0020-0180-0020-0070.html |    2-18-207. Repealed, MCA  |  |
| MTS_0020-0180-0020-0080 | 200 | 11672 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0020/section_0080/0020-0180-0020-0080.html |    2-18-208. Comparable worth, MCA  |  |
| MTS_0020-0180-0020-0090 | 200 | 10975 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0020/section_0090/0020-0180-0020-0090.html |    2-18-209. Periodic evaluation, MCA  |  |
| MTS_0020-0180-0030-0010 | 200 | 14442 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0010/0020-0180-0030-0010.html |    2-18-301. Intent of part -- rules, MCA  |  |
| MTS_0020-0180-0030-0020 | 200 | 11606 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0020/0020-0180-0030-0020.html |    2-18-302. Salary schedules maintained by department, MCA  |  |
| MTS_0020-0180-0030-0030 | 200 | 16017 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0030/0020-0180-0030-0030.html |    2-18-303. Procedures for administering broadband pay plan, MCA  |  |
| MTS_0020-0180-0030-0040 | 200 | 13757 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0040/0020-0180-0030-0040.html |    2-18-304. Longevity allowance, MCA  |  |
| MTS_0020-0180-0030-0050 | 200 | 11063 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0050/0020-0180-0030-0050.html |    2-18-305. Repealed, MCA  |  |
| MTS_0020-0180-0030-0060 | 200 | 11230 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0060/0020-0180-0030-0060.html |    2-18-306. Determination of weekly or hourly pay rate, MCA  |  |
| MTS_0020-0180-0030-0070 | 200 | 10913 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0070/0020-0180-0030-0070.html |    2-18-307. Repealed, MCA  |  |
| MTS_0020-0180-0030-0080 | 200 | 10647 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0080/0020-0180-0030-0080.html |    2-18-308. through 2-18-310 reserved, MCA  |  |
| MTS_0020-0180-0030-0110 | 200 | 11003 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0110/0020-0180-0030-0110.html |    2-18-311. Repealed, MCA  |  |
| MTS_0020-0180-0030-0120 | 200 | 11400 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0120/0020-0180-0030-0120.html |    2-18-312. Repealed, MCA  |  |
| MTS_0020-0180-0030-0130 | 200 | 11227 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0130/0020-0180-0030-0130.html |    2-18-313. Repealed, MCA  |  |
| MTS_0020-0180-0030-0140 | 200 | 11135 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0140/0020-0180-0030-0140.html |    2-18-314. Repealed, MCA  |  |
| MTS_0020-0180-0030-0150 | 200 | 11246 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0150/0020-0180-0030-0150.html |    2-18-315. Repealed, MCA  |  |
| MTS_0020-0180-0030-0160 | 200 | 10649 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0160/0020-0180-0030-0160.html |    2-18-316. through 2-18-318 reserved, MCA  |  |
| MTS_0020-0180-0030-0190 | 200 | 10857 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0190/0020-0180-0030-0190.html |    2-18-319. Terminated, MCA  |  |
| MTS_0020-0180-0030-0200 | 200 | 10640 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0030/section_0200/0020-0180-0030-0200.html |    2-18-320. Terminated, MCA  |  |
| MTS_0020-0180-0040-0010 | 200 | 11540 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0040/section_0010/0020-0180-0040-0010.html |    2-18-401. Central payroll system -- department to provide for inclusion of ag |  |
| MTS_0020-0180-0040-0020 | 200 | 11897 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0040/section_0020/0020-0180-0040-0020.html |    2-18-402. Payroll custodial fund -- department to determine disbursements and |  |
| MTS_0020-0180-0040-0030 | 200 | 11369 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0040/section_0030/0020-0180-0040-0030.html |    2-18-403. Service charges, MCA  |  |
| MTS_0020-0180-0040-0040 | 200 | 12052 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0040/section_0040/0020-0180-0040-0040.html |    2-18-404. Payroll roster -- changes certified by appointing powers, MCA  |  |
| MTS_0020-0180-0040-0050 | 200 | 12629 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0040/section_0050/0020-0180-0040-0050.html |    2-18-405. Payroll based on actual, end-of-period figures -- pay date -- chang |  |
| MTS_0020-0180-0040-0060 | 200 | 10713 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0040/section_0060/0020-0180-0040-0060.html |    2-18-406. through 2-18-410 reserved, MCA  |  |
| MTS_0020-0180-0040-0110 | 200 | 11955 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0040/section_0110/0020-0180-0040-0110.html |    2-18-411. Lost warrants -- replacement, MCA  |  |
| MTS_0020-0180-0040-0120 | 200 | 11512 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0040/section_0120/0020-0180-0040-0120.html |    2-18-412. Designation of person to receive decedent's warrants -- reissuance, |  |
| MTS_0020-0180-0050-0010 | 200 | 16565 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0050/section_0010/0020-0180-0050-0010.html |    2-18-501. Meals, lodging, and transportation of persons in state service, MCA |  |
| MTS_0020-0180-0050-0020 | 200 | 14044 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0050/section_0020/0020-0180-0050-0020.html |    2-18-502. Computation of meal allowance, MCA  |  |
| MTS_0020-0180-0050-0030 | 200 | 14624 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0050/section_0030/0020-0180-0050-0030.html |    2-18-503. Mileage -- allowance, MCA  |  |
| MTS_0020-0180-0050-0040 | 200 | 11274 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0050/section_0040/0020-0180-0050-0040.html |    2-18-504. Mileage computed by shortest traveled route, MCA  |  |
| MTS_0020-0180-0050-0050 | 200 | 10692 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0050/section_0050/0020-0180-0050-0050.html |    2-18-505. through 2-18-510 reserved, MCA  |  |
| MTS_0020-0180-0050-0110 | 200 | 11359 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0050/section_0110/0020-0180-0050-0110.html |    2-18-511. Claim for expenses, MCA  |  |
| MTS_0020-0180-0050-0120 | 200 | 11721 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0050/section_0120/0020-0180-0050-0120.html |    2-18-512. Prohibition on travel expenses for conventions -- exception, MCA  |  |
| MTS_0020-0180-0060-0010 | 200 | 20448 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0010/0020-0180-0060-0010.html |    2-18-601. Definitions, MCA  |  |
| MTS_0020-0180-0060-0020 | 200 | 11117 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0020/0020-0180-0060-0020.html |    2-18-602. Repealed, MCA  |  |
| MTS_0020-0180-0060-0030 | 200 | 15017 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0030/0020-0180-0060-0030.html |    2-18-603. Holidays -- observance when falling on employee's day off -- floati |  |
| MTS_0020-0180-0060-0040 | 200 | 11443 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0040/0020-0180-0060-0040.html |    2-18-604. Administration of rules, MCA  |  |
| MTS_0020-0180-0060-0050 | 200 | 10824 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0050/0020-0180-0060-0050.html |    2-18-605. Repealed, MCA  |  |
| MTS_0020-0180-0060-0060 | 200 | 12170 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0060/0020-0180-0060-0060.html |    2-18-606. Parental leave for state employees, MCA  |  |
| MTS_0020-0180-0060-0070 | 200 | 10638 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0070/0020-0180-0060-0070.html |    2-18-607. through 2-18-610 reserved, MCA  |  |
| MTS_0020-0180-0060-0110 | 200 | 12932 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0110/0020-0180-0060-0110.html |    2-18-611. Annual vacation leave, MCA  |  |
| MTS_0020-0180-0060-0120 | 200 | 14298 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0120/0020-0180-0060-0120.html |    2-18-612. Rate earned, MCA  |  |
| MTS_0020-0180-0060-0130 | 200 | 10864 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0130/0020-0180-0060-0130.html |    2-18-613. Repealed, MCA  |  |
| MTS_0020-0180-0060-0140 | 200 | 12109 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0140/0020-0180-0060-0140.html |    2-18-614. Military leave considered service, MCA  |  |
| MTS_0020-0180-0060-0150 | 200 | 11362 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0150/0020-0180-0060-0150.html |    2-18-615. Absence because of illness not chargeable against vacation unless e |  |
| MTS_0020-0180-0060-0160 | 200 | 11272 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0160/0020-0180-0060-0160.html |    2-18-616. Determination of vacation dates, MCA  |  |
| MTS_0020-0180-0060-0170 | 200 | 15603 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0170/0020-0180-0060-0170.html |    2-18-617. Accumulation of leave -- cash for unused -- transfer, MCA  |  |
| MTS_0020-0180-0060-0180 | 200 | 15572 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0180/0020-0180-0060-0180.html |    2-18-618. Sick leave, MCA  |  |
| MTS_0020-0180-0060-0190 | 200 | 12289 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0190/0020-0180-0060-0190.html |    2-18-619. Jury duty -- service as witness, MCA  |  |
| MTS_0020-0180-0060-0200 | 200 | 10954 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0200/0020-0180-0060-0200.html |    2-18-620. Repealed, MCA  |  |
| MTS_0020-0180-0060-0210 | 200 | 13763 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0210/0020-0180-0060-0210.html |    2-18-621. Unlawful termination -- unlawful payments, MCA  |  |
| MTS_0020-0180-0060-0220 | 200 | 11471 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0220/0020-0180-0060-0220.html |    2-18-622. Reduction in force -- severance pay and retraining allowance requir |  |
| MTS_0020-0180-0060-0230 | 200 | 10937 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0230/0020-0180-0060-0230.html |    2-18-623. Terminated, MCA  |  |
| MTS_0020-0180-0060-0240 | 200 | 15538 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0240/0020-0180-0060-0240.html |    2-18-624. Termination of volunteer emergency services provider prohibited --  |  |
| MTS_0020-0180-0060-0250 | 200 | 10651 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0250/0020-0180-0060-0250.html |    2-18-625. reserved, MCA  |  |
| MTS_0020-0180-0060-0260 | 200 | 11535 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0260/0020-0180-0060-0260.html |    2-18-626. Department of justice employees -- payment of compensation for time |  |
| MTS_0020-0180-0060-0270 | 200 | 12707 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0270/0020-0180-0060-0270.html |    2-18-627. Paid leave for disaster relief volunteer service, MCA  |  |
| MTS_0020-0180-0060-0280 | 200 | 10718 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0280/0020-0180-0060-0280.html |    2-18-628. through 2-18-640 reserved, MCA  |  |
| MTS_0020-0180-0060-0410 | 200 | 11368 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0060/section_0410/0020-0180-0060-0410.html |    2-18-641. Exemption -- employees of certain county hospitals or rest homes an |  |
| MTS_0020-0180-0070-0010 | 200 | 16262 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0070/section_0010/0020-0180-0070-0010.html |    2-18-701. Definitions, MCA  |  |
| MTS_0020-0180-0070-0020 | 200 | 15482 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0070/section_0020/0020-0180-0070-0020.html |    2-18-702. Group insurance for public employees and officers, MCA  |  |
| MTS_0020-0180-0070-0030 | 200 | 19849 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0070/section_0030/0020-0180-0070-0030.html |    2-18-703. Contributions, MCA  |  |
| MTS_0020-0180-0070-0040 | 200 | 57664 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0070/section_0040/0020-0180-0070-0040.html |    2-18-704. Mandatory provisions, MCA  |  |
| MTS_0020-0180-0070-0050 | 200 | 10867 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0070/section_0050/0020-0180-0070-0050.html |    2-18-705. Terminated, MCA  |  |
| MTS_0020-0180-0070-0060 | 200 | 10726 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0070/section_0060/0020-0180-0070-0060.html |    2-18-706. through 2-18-710 reserved, MCA  |  |
| MTS_0020-0180-0070-0110 | 200 | 12705 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0070/section_0110/0020-0180-0070-0110.html |    2-18-711. Cooperative purchasing of employee benefit services and insurance p |  |
| MTS_0020-0180-0070-0120 | 200 | 10748 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0070/section_0120/0020-0180-0070-0120.html |    2-18-712. through 2-18-714 reserved, MCA  |  |
| MTS_0020-0180-0070-0150 | 200 | 12318 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0070/section_0150/0020-0180-0070-0150.html |    2-18-715. Legislative findings and purpose, MCA  |  |
| MTS_0020-0180-0070-0160 | 200 | 16081 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0070/section_0160/0020-0180-0070-0160.html |    2-18-716. Hold harmless, MCA  |  |
| MTS_0020-0180-0070-0170 | 200 | 11593 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0070/section_0170/0020-0180-0070-0170.html |    2-18-717. Disclosures by air ambulance service, MCA  |  |
| MTS_0020-0180-0070-0180 | 200 | 12544 | https://leg.mt.gov/bills/mca/title_0020/chapter_0180/part_0070/section_0180/0020-0180-0070-0180.html |    2-18-718. Independent dispute resolution, MCA  |  |
