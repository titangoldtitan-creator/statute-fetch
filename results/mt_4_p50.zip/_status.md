| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0370-0760-0010-0070 | 200 | 10012 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0070/0370-0760-0010-0070.html |    37-76-107. Repealed, MCA  |  |
| MTS_0370-0760-0010-0080 | 200 | 10012 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0080/0370-0760-0010-0080.html |    37-76-108. Repealed, MCA  |  |
| MTS_0370-0760-0010-0090 | 200 | 10063 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0090/0370-0760-0010-0090.html |    37-76-109. Repealed, MCA  |  |
| MTS_0370-0760-0010-0100 | 200 | 9834 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0100/0370-0760-0010-0100.html |    37-76-110. through 37-76-112 reserved, MCA  |  |
| MTS_0370-0760-0010-0130 | 200 | 10031 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0130/0370-0760-0010-0130.html |    37-76-113. Repealed, MCA  |  |
| MTS_0370-0760-0010-0140 | 200 | 10013 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0140/0370-0760-0010-0140.html |    37-76-114. Repealed, MCA  |  |
| MTS_0370-0760-0010-0150 | 200 | 10013 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0150/0370-0760-0010-0150.html |    37-76-115. Repealed, MCA  |  |
| MTS_0370-0760-0010-0160 | 200 | 10013 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0160/0370-0760-0010-0160.html |    37-76-116. Repealed, MCA  |  |
| MTS_0370-0760-0010-0170 | 200 | 10013 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0170/0370-0760-0010-0170.html |    37-76-117. Repealed, MCA  |  |
| MTS_0370-0760-0010-0180 | 200 | 10013 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0180/0370-0760-0010-0180.html |    37-76-118. Repealed, MCA  |  |
| MTS_0370-0760-0010-0190 | 200 | 10013 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0190/0370-0760-0010-0190.html |    37-76-119. Repealed, MCA  |  |
| MTS_0370-0760-0010-0200 | 200 | 10013 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0200/0370-0760-0010-0200.html |    37-76-120. Repealed, MCA  |  |
| MTS_0370-0760-0010-0210 | 200 | 10013 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0210/0370-0760-0010-0210.html |    37-76-121. Repealed, MCA  |  |
| MTS_0370-0760-0010-0220 | 200 | 10013 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0220/0370-0760-0010-0220.html |    37-76-122. Repealed, MCA  |  |
| MTS_0370-0760-0010-0230 | 200 | 9812 | https://leg.mt.gov/bills/mca/title_0370/chapter_0760/part_0010/section_0230/0370-0760-0010-0230.html |    37-76-123. Repealed, MCA  |  |
| MTS_0370-0770-0010-0010 | 200 | 11456 | https://leg.mt.gov/bills/mca/title_0370/chapter_0770/part_0010/section_0010/0370-0770-0010-0010.html |    37-77-101. Definitions, MCA  |  |
| MTS_0370-0770-0010-0020 | 200 | 11231 | https://leg.mt.gov/bills/mca/title_0370/chapter_0770/part_0010/section_0020/0370-0770-0010-0020.html |    37-77-102. License requirements, MCA  |  |
| MTS_0370-0770-0010-0030 | 200 | 10425 | https://leg.mt.gov/bills/mca/title_0370/chapter_0770/part_0010/section_0030/0370-0770-0010-0030.html |    37-77-103. Exemptions, MCA  |  |
| MTS_0370-0770-0010-0040 | 200 | 9854 | https://leg.mt.gov/bills/mca/title_0370/chapter_0770/part_0010/section_0040/0370-0770-0010-0040.html |    37-77-104. Rulemaking, MCA  |  |
| MTS_0370-0780-0010-0010 | 200 | 10257 | https://leg.mt.gov/bills/mca/title_0370/chapter_0780/part_0010/section_0010/0370-0780-0010-0010.html |    37-78-101. Purpose, MCA  |  |
| MTS_0370-0780-0010-0020 | 200 | 10369 | https://leg.mt.gov/bills/mca/title_0370/chapter_0780/part_0010/section_0020/0370-0780-0010-0020.html |    37-78-102. Definitions, MCA  |  |
| MTS_0370-0780-0020-0010 | 200 | 11268 | https://leg.mt.gov/bills/mca/title_0370/chapter_0780/part_0020/section_0010/0370-0780-0020-0010.html |    37-78-201. Duties of board -- rulemaking authority, MCA  |  |
| MTS_0390-0010-0010-0010 | 200 | 10411 | https://leg.mt.gov/bills/mca/title_0390/chapter_0010/part_0010/section_0010/0390-0010-0010-0010.html |    39-1-101. Definitions, MCA  |  |
| MTS_0390-0010-0010-0020 | 200 | 11141 | https://leg.mt.gov/bills/mca/title_0390/chapter_0010/part_0010/section_0020/0390-0010-0010-0020.html |    39-1-102. Duties of department, MCA  |  |
| MTS_0390-0010-0010-0030 | 200 | 10946 | https://leg.mt.gov/bills/mca/title_0390/chapter_0010/part_0010/section_0030/0390-0010-0010-0030.html |    39-1-103. Powers of department, MCA  |  |
| MTS_0390-0010-0010-0040 | 200 | 10652 | https://leg.mt.gov/bills/mca/title_0390/chapter_0010/part_0010/section_0040/0390-0010-0010-0040.html |    39-1-104. Cooperation with federal government, MCA  |  |
| MTS_0390-0010-0010-0050 | 200 | 9776 | https://leg.mt.gov/bills/mca/title_0390/chapter_0010/part_0010/section_0050/0390-0010-0010-0050.html |    39-1-105. Terminated, MCA  |  |
| MTS_0390-0020-0010-0010 | 200 | 10082 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0010/section_0010/0390-0020-0010-0010.html |    39-2-101. Employment defined, MCA  |  |
| MTS_0390-0020-0010-0020 | 200 | 10440 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0010/section_0020/0390-0020-0010-0020.html |    39-2-102. What belongs to employer, MCA  |  |
| MTS_0390-0020-0010-0030 | 200 | 10325 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0010/section_0030/0390-0020-0010-0030.html |    39-2-103. Confidential employment, MCA  |  |
| MTS_0390-0020-0010-0040 | 200 | 11305 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0010/section_0040/0390-0020-0010-0040.html |    39-2-104. Mandatory leave of absence for employees holding public office, MCA |  |
| MTS_0390-0020-0010-0050 | 200 | 11952 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0010/section_0050/0390-0020-0010-0050.html |    39-2-105. Employer requirements -- employees -- public office, MCA  |  |
| MTS_0390-0020-0020-0010 | 200 | 11093 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0010/0390-0020-0020-0010.html |    39-2-201. Seats for employees, MCA  |  |
| MTS_0390-0020-0020-0020 | 200 | 9801 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0020/0390-0020-0020-0020.html |    39-2-202. through 39-2-204 reserved, MCA  |  |
| MTS_0390-0020-0020-0050 | 200 | 10236 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0050/0390-0020-0020-0050.html |    39-2-205. Short title, MCA  |  |
| MTS_0390-0020-0020-0060 | 200 | 14538 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0060/0390-0020-0020-0060.html |    39-2-206. Definitions, MCA  |  |
| MTS_0390-0020-0020-0070 | 200 | 17047 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0070/0390-0020-0020-0070.html |    39-2-207. Qualified testing program, MCA  |  |
| MTS_0390-0020-0020-0080 | 200 | 13549 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0080/0390-0020-0020-0080.html |    39-2-208. Qualified testing program -- allowable types -- procedures, MCA  |  |
| MTS_0390-0020-0020-0090 | 200 | 10786 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0090/0390-0020-0020-0090.html |    39-2-209. Employee's right of rebuttal, MCA  |  |
| MTS_0390-0020-0020-0100 | 200 | 10643 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0100/0390-0020-0020-0100.html |    39-2-210. Limitation on adverse action, MCA  |  |
| MTS_0390-0020-0020-0110 | 200 | 11289 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0110/0390-0020-0020-0110.html |    39-2-211. Confidentiality of results, MCA  |  |
| MTS_0390-0020-0020-0120 | 200 | 9884 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0120/0390-0020-0020-0120.html |    39-2-212. through 39-2-214 reserved, MCA  |  |
| MTS_0390-0020-0020-0150 | 200 | 11864 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0150/0390-0020-0020-0150.html |    39-2-215. Public employer policy on support of women and breastfeeding -- unl |  |
| MTS_0390-0020-0020-0160 | 200 | 10819 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0160/0390-0020-0020-0160.html |    39-2-216. Private place for nursing mothers, MCA  |  |
| MTS_0390-0020-0020-0170 | 200 | 10885 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0170/0390-0020-0020-0170.html |    39-2-217. Break time for nursing mothers, MCA  |  |
| MTS_0390-0020-0020-0180 | 200 | 9851 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0180/0390-0020-0020-0180.html |    39-2-218. through 39-2-220 reserved, MCA  |  |
| MTS_0390-0020-0020-0210 | 200 | 13623 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0020/section_0210/0390-0020-0020-0210.html |    39-2-221. Reporting of violence against health care employee, MCA  |  |
| MTS_0390-0020-0030-0010 | 200 | 11526 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0030/section_0010/0390-0020-0030-0010.html |    39-2-301. Unlawful for employer to require employee to pay cost of medical ex |  |
| MTS_0390-0020-0030-0020 | 200 | 10618 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0030/section_0020/0390-0020-0030-0020.html |    39-2-302. Discharge or layoff of employee because of attachment or garnishmen |  |
| MTS_0390-0020-0030-0030 | 200 | 11977 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0030/section_0030/0390-0020-0030-0030.html |    39-2-303. Deception as to character of employment, conditions of work, or exi |  |
| MTS_0390-0020-0030-0040 | 200 | 10592 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0030/section_0040/0390-0020-0030-0040.html |    39-2-304. Lie detector tests prohibited, MCA  |  |
| MTS_0390-0020-0030-0050 | 200 | 10864 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0030/section_0050/0390-0020-0030-0050.html |    39-2-305. Employment of aliens not lawfully authorized to accept employment p |  |
| MTS_0390-0020-0030-0060 | 200 | 11108 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0030/section_0060/0390-0020-0030-0060.html |    39-2-306. Employment of persons under 18 years of age as bartenders prohibite |  |
| MTS_0390-0020-0030-0070 | 200 | 17544 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0030/section_0070/0390-0020-0030-0070.html |    39-2-307. Employer access limited regarding personal social media account of  |  |
| MTS_0390-0020-0030-0080 | 200 | 14862 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0030/section_0080/0390-0020-0030-0080.html |    39-2-308. Termination of volunteer emergency services provider prohibited --  |  |
| MTS_0390-0020-0030-0090 | 200 | 9954 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0030/section_0090/0390-0020-0030-0090.html |    39-2-309. through 39-2-312 reserved, MCA  |  |
| MTS_0390-0020-0030-0130 | 200 | 13366 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0030/section_0130/0390-0020-0030-0130.html |    39-2-313. Discrimination prohibited for use of lawful product during nonworki |  |
| MTS_0390-0020-0030-0140 | 200 | 10748 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0030/section_0140/0390-0020-0030-0140.html |    39-2-314. Civil action limitation, MCA  |  |
| MTS_0390-0020-0040-0010 | 200 | 11331 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0040/section_0010/0390-0020-0040-0010.html |    39-2-401. Duties of gratuitous employee, MCA  |  |
| MTS_0390-0020-0040-0020 | 200 | 10437 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0040/section_0020/0390-0020-0040-0020.html |    39-2-402. Duties of employee for reward, MCA  |  |
| MTS_0390-0020-0040-0030 | 200 | 10488 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0040/section_0030/0390-0020-0040-0030.html |    39-2-403. Duties of employee for own benefit, MCA  |  |
| MTS_0390-0020-0040-0040 | 200 | 10505 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0040/section_0040/0390-0020-0040-0040.html |    39-2-404. Employee shall obey employer, MCA  |  |
| MTS_0390-0020-0040-0050 | 200 | 10461 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0040/section_0050/0390-0020-0040-0050.html |    39-2-405. Employee shall conform to usage, MCA  |  |
| MTS_0390-0020-0040-0060 | 200 | 10832 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0040/section_0060/0390-0020-0040-0060.html |    39-2-406. Degree of skill required, MCA  |  |
| MTS_0390-0020-0040-0070 | 200 | 10494 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0040/section_0070/0390-0020-0040-0070.html |    39-2-407. Duty to account, MCA  |  |
| MTS_0390-0020-0040-0080 | 200 | 10745 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0040/section_0080/0390-0020-0040-0080.html |    39-2-408. Duty of employee regarding items received on account of employer, M |  |
| MTS_0390-0020-0040-0090 | 200 | 10584 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0040/section_0090/0390-0020-0040-0090.html |    39-2-409. Preference to be given to employer's business, MCA  |  |
| MTS_0390-0020-0040-0100 | 200 | 10520 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0040/section_0100/0390-0020-0040-0100.html |    39-2-410. Responsibility of employee for substitute, MCA  |  |
| MTS_0390-0020-0040-0110 | 200 | 10235 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0040/section_0110/0390-0020-0040-0110.html |    39-2-411. Surviving employee, MCA  |  |
| MTS_0390-0020-0050-0010 | 200 | 10526 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0050/section_0010/0390-0020-0050-0010.html |    39-2-501. Termination of employment generally, MCA  |  |
| MTS_0390-0020-0050-0020 | 200 | 11498 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0050/section_0020/0390-0020-0050-0020.html |    39-2-502. Termination by death or incapacity of employer, MCA  |  |
| MTS_0390-0020-0050-0030 | 200 | 10212 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0050/section_0030/0390-0020-0050-0030.html |    39-2-503. Repealed, MCA  |  |
| MTS_0390-0020-0050-0040 | 200 | 10113 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0050/section_0040/0390-0020-0050-0040.html |    39-2-504. Repealed, MCA  |  |
| MTS_0390-0020-0050-0050 | 200 | 9922 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0050/section_0050/0390-0020-0050-0050.html |    39-2-505. Repealed, MCA  |  |
| MTS_0390-0020-0060-0010 | 200 | 10153 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0060/section_0010/0390-0020-0060-0010.html |    39-2-601. Servant defined, MCA  |  |
| MTS_0390-0020-0060-0020 | 200 | 10893 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0060/section_0020/0390-0020-0060-0020.html |    39-2-602. Term of hiring, MCA  |  |
| MTS_0390-0020-0060-0030 | 200 | 10317 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0060/section_0030/0390-0020-0060-0030.html |    39-2-603. Renewal of hiring, MCA  |  |
| MTS_0390-0020-0060-0040 | 200 | 10297 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0060/section_0040/0390-0020-0060-0040.html |    39-2-604. Time of service, MCA  |  |
| MTS_0390-0020-0060-0050 | 200 | 10520 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0060/section_0050/0390-0020-0060-0050.html |    39-2-605. Servant to pay over without demand, MCA  |  |
| MTS_0390-0020-0060-0060 | 200 | 10687 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0060/section_0060/0390-0020-0060-0060.html |    39-2-606. When servant may be discharged, MCA  |  |
| MTS_0390-0020-0070-0010 | 200 | 11353 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0070/section_0010/0390-0020-0070-0010.html |    39-2-701. Indemnification of employee, MCA  |  |
| MTS_0390-0020-0070-0020 | 200 | 10607 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0070/section_0020/0390-0020-0070-0020.html |    39-2-702. Liability of employee for negligence, MCA  |  |
| MTS_0390-0020-0070-0030 | 200 | 10523 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0070/section_0030/0390-0020-0070-0030.html |    39-2-703. Repealed, MCA  |  |
| MTS_0390-0020-0070-0040 | 200 | 10327 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0070/section_0040/0390-0020-0070-0040.html |    39-2-704. Repealed, MCA  |  |
| MTS_0390-0020-0070-0050 | 200 | 10847 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0070/section_0050/0390-0020-0070-0050.html |    39-2-705. Contract discharging employer liability for negligence void, MCA  |  |
| MTS_0390-0020-0070-0060 | 200 | 9972 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0070/section_0060/0390-0020-0070-0060.html |    39-2-706. through 39-2-709 reserved, MCA  |  |
| MTS_0390-0020-0070-0100 | 200 | 11229 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0070/section_0100/0390-0020-0070-0100.html |    39-2-710. Legal protections in relation to employing individuals with crimina |  |
| MTS_0390-0020-0080-0010 | 200 | 11441 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0080/section_0010/0390-0020-0080-0010.html |    39-2-801. Employee to be furnished on demand with reason for discharge, MCA  |  |
| MTS_0390-0020-0080-0020 | 200 | 10966 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0080/section_0020/0390-0020-0080-0020.html |    39-2-802. Protection of discharged employees, MCA  |  |
| MTS_0390-0020-0080-0030 | 200 | 11049 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0080/section_0030/0390-0020-0080-0030.html |    39-2-803. Blacklisting prohibited, MCA  |  |
| MTS_0390-0020-0080-0040 | 200 | 10253 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0080/section_0040/0390-0020-0080-0040.html |    39-2-804. Violation of part a misdemeanor, MCA  |  |
| MTS_0390-0020-0090-0010 | 200 | 9792 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0090/section_0010/0390-0020-0090-0010.html |    39-2-901. Short title, MCA  |  |
| MTS_0390-0020-0090-0020 | 200 | 10225 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0090/section_0020/0390-0020-0090-0020.html |    39-2-902. Purpose, MCA  |  |
| MTS_0390-0020-0090-0030 | 200 | 13333 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0090/section_0030/0390-0020-0090-0030.html |    39-2-903. Definitions, MCA  |  |
| MTS_0390-0020-0090-0040 | 200 | 11507 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0090/section_0040/0390-0020-0090-0040.html |    39-2-904. Elements of wrongful discharge, MCA  |  |
| MTS_0390-0020-0090-0050 | 200 | 12031 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0090/section_0050/0390-0020-0090-0050.html |    39-2-905. Remedies, MCA  |  |
| MTS_0390-0020-0090-0060 | 200 | 9804 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0090/section_0060/0390-0020-0090-0060.html |    39-2-906. through 39-2-909 reserved, MCA  |  |
| MTS_0390-0020-0090-0100 | 200 | 10883 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0090/section_0100/0390-0020-0090-0100.html |    39-2-910. Probationary period, MCA  |  |
| MTS_0390-0020-0090-0110 | 200 | 12780 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0090/section_0110/0390-0020-0090-0110.html |    39-2-911. Limitation of actions, MCA  |  |
| MTS_0390-0020-0090-0120 | 200 | 11348 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0090/section_0120/0390-0020-0090-0120.html |    39-2-912. Exemptions, MCA  |  |
| MTS_0390-0020-0090-0130 | 200 | 10147 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0090/section_0130/0390-0020-0090-0130.html |    39-2-913. Preemption of common-law remedies, MCA  |  |
| MTS_0390-0020-0090-0140 | 200 | 11940 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0090/section_0140/0390-0020-0090-0140.html |    39-2-914. Arbitration, MCA  |  |
| MTS_0390-0020-0090-0150 | 200 | 10117 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0090/section_0150/0390-0020-0090-0150.html |    39-2-915. Effect of rejection of offer to arbitrate, MCA  |  |
| MTS_0390-0020-0100-0010 | 200 | 9912 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0100/section_0010/0390-0020-0100-0010.html |    39-2-1001. Purpose, MCA  |  |
| MTS_0390-0020-0100-0020 | 200 | 10962 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0100/section_0020/0390-0020-0100-0020.html |    39-2-1002. Definitions, MCA  |  |
| MTS_0390-0020-0100-0030 | 200 | 11349 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0100/section_0030/0390-0020-0100-0030.html |    39-2-1003. Requirements for closure or retrenchment, MCA  |  |
| MTS_0390-0020-0100-0040 | 200 | 10025 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0100/section_0040/0390-0020-0100-0040.html |    39-2-1004. Adoption of rules, MCA  |  |
| MTS_0390-0020-0150-0010 | 200 | 11099 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0150/section_0010/0390-0020-0150-0010.html |    39-2-1501. Definitions, MCA  |  |
| MTS_0390-0020-0150-0020 | 200 | 13159 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0150/section_0020/0390-0020-0150-0020.html |    39-2-1502. Employer requirement of microchip implantation prohibited -- use w |  |
| MTS_0390-0020-0150-0030 | 200 | 10043 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0150/section_0030/0390-0020-0150-0030.html |    39-2-1503. Government requirement of microchip prohibited, MCA  |  |
| MTS_0390-0020-0160-0010 | 200 | 9822 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0160/section_0010/0390-0020-0160-0010.html |    39-2-1601. Short title, MCA  |  |
| MTS_0390-0020-0160-0020 | 200 | 11905 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0160/section_0020/0390-0020-0160-0020.html |    39-2-1602. Definitions, MCA  |  |
| MTS_0390-0020-0160-0030 | 200 | 11003 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0160/section_0030/0390-0020-0160-0030.html |    39-2-1603. Employer verification of employee, MCA  |  |
| MTS_0390-0020-0160-0040 | 200 | 11325 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0160/section_0040/0390-0020-0160-0040.html |    39-2-1604. Enforcement -- investigations -- rulemaking -- enforcement without |  |
| MTS_0390-0020-0160-0050 | 200 | 11704 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0160/section_0050/0390-0020-0160-0050.html |    39-2-1605. Books, records, and payrolls open to inspection -- penalty for ref |  |
| MTS_0390-0020-0160-0060 | 200 | 12083 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0160/section_0060/0390-0020-0160-0060.html |    39-2-1606. Civil penalties for violation, MCA  |  |
| MTS_0390-0020-0160-0070 | 200 | 10447 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0160/section_0070/0390-0020-0160-0070.html |    39-2-1607. Interpretation as fully consistent with federal immigration and la |  |
| MTS_0390-0020-0160-0080 | 200 | 11050 | https://leg.mt.gov/bills/mca/title_0390/chapter_0020/part_0160/section_0080/0390-0020-0160-0080.html |    39-2-1608. Lawful employment enforcement fund, MCA  |  |
| MTS_0390-0030-0010-0010 | 200 | 10497 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0010/section_0010/0390-0030-0010-0010.html |    39-3-101. Employer to furnish itemized statement of deductions, MCA  |  |
| MTS_0390-0030-0010-0020 | 200 | 10509 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0010/section_0020/0390-0030-0010-0020.html |    39-3-102. Compensation of employee dismissed for cause, MCA  |  |
| MTS_0390-0030-0010-0030 | 200 | 10586 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0010/section_0030/0390-0030-0010-0030.html |    39-3-103. Compensation of employee leaving for cause, MCA  |  |
| MTS_0390-0030-0010-0040 | 200 | 10764 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0010/section_0040/0390-0030-0010-0040.html |    39-3-104. Equal pay for women for equivalent service, MCA  |  |
| MTS_0390-0030-0020-0010 | 200 | 12367 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0010/0390-0030-0020-0010.html |    39-3-201. Definitions, MCA  |  |
| MTS_0390-0030-0020-0020 | 200 | 10238 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0020/0390-0030-0020-0020.html |    39-3-202. Rulemaking power of commissioner, MCA  |  |
| MTS_0390-0030-0020-0030 | 200 | 11327 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0030/0390-0030-0020-0030.html |    39-3-203. Employer to notify employee on written demand as to rate of wages a |  |
| MTS_0390-0030-0020-0040 | 200 | 12220 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0040/0390-0030-0020-0040.html |    39-3-204. Payment of wages generally, MCA  |  |
| MTS_0390-0030-0020-0050 | 200 | 12982 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0050/0390-0030-0020-0050.html |    39-3-205. Payment of wages when employee separated from employment prior to p |  |
| MTS_0390-0030-0020-0060 | 200 | 10990 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0060/0390-0030-0020-0060.html |    39-3-206. Penalty for failure to pay wages at times specified in law, MCA  |  |
| MTS_0390-0030-0020-0070 | 200 | 11325 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0070/0390-0030-0020-0070.html |    39-3-207. Period within which employee may recover wages and penalties, MCA  |  |
| MTS_0390-0030-0020-0080 | 200 | 10699 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0080/0390-0030-0020-0080.html |    39-3-208. Contracts in violation of part void, MCA  |  |
| MTS_0390-0030-0020-0090 | 200 | 10784 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0090/0390-0030-0020-0090.html |    39-3-209. Commissioner of labor to investigate violations and institute actio |  |
| MTS_0390-0030-0020-0100 | 200 | 11385 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0100/0390-0030-0020-0100.html |    39-3-210. Investigative powers of commissioner of labor, MCA  |  |
| MTS_0390-0030-0020-0110 | 200 | 10696 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0110/0390-0030-0020-0110.html |    39-3-211. Commissioner of labor to take wage assignments, MCA  |  |
| MTS_0390-0030-0020-0120 | 200 | 11181 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0120/0390-0030-0020-0120.html |    39-3-212. Court enforcement of administrative decision, MCA  |  |
| MTS_0390-0030-0020-0130 | 200 | 11262 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0130/0390-0030-0020-0130.html |    39-3-213. Disposition of wages, MCA  |  |
| MTS_0390-0030-0020-0140 | 200 | 11149 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0140/0390-0030-0020-0140.html |    39-3-214. Court costs and attorney fees, MCA  |  |
| MTS_0390-0030-0020-0150 | 200 | 10463 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0150/0390-0030-0020-0150.html |    39-3-215. Authority of county attorney, MCA  |  |
| MTS_0390-0030-0020-0160 | 200 | 11967 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0160/0390-0030-0020-0160.html |    39-3-216. Mediation -- hearing, MCA  |  |
| MTS_0390-0030-0020-0170 | 200 | 10038 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0170/0390-0030-0020-0170.html |    39-3-217. Repealed, MCA  |  |
| MTS_0390-0030-0020-0180 | 200 | 11956 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0020/section_0180/0390-0030-0020-0180.html |    39-3-218. Tip pools allowed -- requirements -- prohibitions -- compulsory cha |  |
| MTS_0390-0030-0030-0010 | 200 | 9881 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0030/section_0010/0390-0030-0030-0010.html |    39-3-301. Short title, MCA  |  |
| MTS_0390-0030-0030-0020 | 200 | 10275 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0030/section_0020/0390-0030-0030-0020.html |    39-3-302. Purpose, MCA  |  |
| MTS_0390-0030-0030-0030 | 200 | 10658 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0030/section_0030/0390-0030-0030-0030.html |    39-3-303. Reciprocal agreements for collection of wages, MCA  |  |
| MTS_0390-0030-0030-0040 | 200 | 10995 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0030/section_0040/0390-0030-0030-0040.html |    39-3-304. Actions in other states for collections of claims -- assignments fo |  |
| MTS_0390-0030-0030-0050 | 200 | 11065 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0030/section_0050/0390-0030-0030-0050.html |    39-3-305. Claims assigned by other states -- actions -- collection, MCA  |  |
| MTS_0390-0030-0030-0060 | 200 | 10048 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0030/section_0060/0390-0030-0030-0060.html |    39-3-306. Limitations, MCA  |  |
| MTS_0390-0030-0040-0010 | 200 | 10558 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0040/section_0010/0390-0030-0040-0010.html |    39-3-401. Declaration of policy, MCA  |  |
| MTS_0390-0030-0040-0020 | 200 | 13246 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0040/section_0020/0390-0030-0040-0020.html |    39-3-402. Definitions, MCA  |  |
| MTS_0390-0030-0040-0030 | 200 | 10137 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0040/section_0030/0390-0030-0040-0030.html |    39-3-403. Rulemaking authority, MCA  |  |
| MTS_0390-0030-0040-0040 | 200 | 11732 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0040/section_0040/0390-0030-0040-0040.html |    39-3-404. Minimum wage, MCA  |  |
| MTS_0390-0030-0040-0050 | 200 | 11339 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0040/section_0050/0390-0030-0040-0050.html |    39-3-405. Overtime compensation, MCA  |  |
| MTS_0390-0030-0040-0060 | 200 | 26503 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0040/section_0060/0390-0030-0040-0060.html |    39-3-406. Exclusions, MCA  |  |
| MTS_0390-0030-0040-0070 | 200 | 10397 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0040/section_0070/0390-0030-0040-0070.html |    39-3-407. Enforcement, MCA  |  |
| MTS_0390-0030-0040-0080 | 200 | 11125 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0040/section_0080/0390-0030-0040-0080.html |    39-3-408. Provisions cumulative, MCA  |  |
| MTS_0390-0030-0040-0090 | 200 | 12038 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0040/section_0090/0390-0030-0040-0090.html |    39-3-409. Adoption of minimum wage rates -- exception, MCA  |  |
| MTS_0390-0030-0040-0100 | 200 | 9819 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0040/section_0100/0390-0030-0040-0100.html |    39-3-410. Repealed, MCA  |  |
| MTS_0390-0030-0050-0010 | 200 | 10821 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0010/0390-0030-0050-0010.html |    39-3-501. Certain laws extended to certain employers in mineral and oil indus |  |
| MTS_0390-0030-0050-0020 | 200 | 11472 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0020/0390-0030-0050-0020.html |    39-3-502. Operator to file statement -- penalty for failure to file, MCA  |  |
| MTS_0390-0030-0050-0030 | 200 | 11132 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0030/0390-0030-0050-0030.html |    39-3-503. Report of violations to county attorney by commissioner, MCA  |  |
| MTS_0390-0030-0050-0040 | 200 | 10567 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0040/0390-0030-0050-0040.html |    39-3-504. Report of violations directly to county attorney by employee, MCA  |  |
| MTS_0390-0030-0050-0050 | 200 | 10886 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0050/0390-0030-0050-0050.html |    39-3-505. County attorney to notify commissioner of violation reported direct |  |
| MTS_0390-0030-0050-0060 | 200 | 10919 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0060/0390-0030-0050-0060.html |    39-3-506. County attorney to file complaint in district court on belief of vi |  |
| MTS_0390-0030-0050-0070 | 200 | 10589 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0070/0390-0030-0050-0070.html |    39-3-507. Prayer for relief, MCA  |  |
| MTS_0390-0030-0050-0080 | 200 | 11476 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0080/0390-0030-0050-0080.html |    39-3-508. Summons -- service of process, MCA  |  |
| MTS_0390-0030-0050-0090 | 200 | 11408 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0090/0390-0030-0050-0090.html |    39-3-509. Hearing on complaint -- court order to pay wages due or appear and  |  |
| MTS_0390-0030-0050-0100 | 200 | 11426 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0100/0390-0030-0050-0100.html |    39-3-510. Show cause hearing -- restraining order until bond furnished, MCA  |  |
| MTS_0390-0030-0050-0110 | 200 | 11140 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0110/0390-0030-0050-0110.html |    39-3-511. Bond requirements, MCA  |  |
| MTS_0390-0030-0050-0120 | 200 | 10984 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0120/0390-0030-0050-0120.html |    39-3-512. Enjoining further operations if bond not filed, MCA  |  |
| MTS_0390-0030-0050-0130 | 200 | 10462 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0130/0390-0030-0050-0130.html |    39-3-513. Costs of proceeding, MCA  |  |
| MTS_0390-0030-0050-0140 | 200 | 10410 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0140/0390-0030-0050-0140.html |    39-3-514. Punishment of employer for contempt, MCA  |  |
| MTS_0390-0030-0050-0150 | 200 | 10615 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0150/0390-0030-0050-0150.html |    39-3-515. Publication of notice of court order, MCA  |  |
| MTS_0390-0030-0050-0160 | 200 | 10574 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0160/0390-0030-0050-0160.html |    39-3-516. Review of court order by supreme court, MCA  |  |
| MTS_0390-0030-0050-0170 | 200 | 10318 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0170/0390-0030-0050-0170.html |    39-3-517. Suit on bond, MCA  |  |
| MTS_0390-0030-0050-0180 | 200 | 10500 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0180/0390-0030-0050-0180.html |    39-3-518. Attorney's fee for suit on bond, MCA  |  |
| MTS_0390-0030-0050-0190 | 200 | 10964 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0190/0390-0030-0050-0190.html |    39-3-519. Clarification as to construction and applicability of part, MCA  |  |
| MTS_0390-0030-0050-0200 | 200 | 10141 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0050/section_0200/0390-0030-0050-0200.html |    39-3-520. Remedy cumulative, MCA  |  |
| MTS_0390-0030-0060-0010 | 200 | 9863 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0060/section_0010/0390-0030-0060-0010.html |    39-3-601. Repealed, MCA  |  |
| MTS_0390-0030-0060-0020 | 200 | 10190 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0060/section_0020/0390-0030-0060-0020.html |    39-3-602. Repealed, MCA  |  |
| MTS_0390-0030-0060-0030 | 200 | 10192 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0060/section_0030/0390-0030-0060-0030.html |    39-3-603. Repealed, MCA  |  |
| MTS_0390-0030-0060-0040 | 200 | 10413 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0060/section_0040/0390-0030-0060-0040.html |    39-3-604. Repealed, MCA  |  |
| MTS_0390-0030-0060-0050 | 200 | 10197 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0060/section_0050/0390-0030-0060-0050.html |    39-3-605. Repealed, MCA  |  |
| MTS_0390-0030-0060-0060 | 200 | 10104 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0060/section_0060/0390-0030-0060-0060.html |    39-3-606. Repealed, MCA  |  |
| MTS_0390-0030-0060-0070 | 200 | 10097 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0060/section_0070/0390-0030-0060-0070.html |    39-3-607. Repealed, MCA  |  |
| MTS_0390-0030-0060-0080 | 200 | 9928 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0060/section_0080/0390-0030-0060-0080.html |    39-3-608. Repealed, MCA  |  |
| MTS_0390-0030-0070-0010 | 200 | 9975 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0070/section_0010/0390-0030-0070-0010.html |    39-3-701. Repealed, MCA  |  |
| MTS_0390-0030-0070-0020 | 200 | 10060 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0070/section_0020/0390-0030-0070-0020.html |    39-3-702. Repealed, MCA  |  |
| MTS_0390-0030-0070-0030 | 200 | 10100 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0070/section_0030/0390-0030-0070-0030.html |    39-3-703. Repealed, MCA  |  |
| MTS_0390-0030-0070-0040 | 200 | 10063 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0070/section_0040/0390-0030-0070-0040.html |    39-3-704. Repealed, MCA  |  |
| MTS_0390-0030-0070-0050 | 200 | 10092 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0070/section_0050/0390-0030-0070-0050.html |    39-3-705. Repealed, MCA  |  |
| MTS_0390-0030-0070-0060 | 200 | 9895 | https://leg.mt.gov/bills/mca/title_0390/chapter_0030/part_0070/section_0060/0390-0030-0070-0060.html |    39-3-706. Repealed, MCA  |  |
| MTS_0390-0040-0010-0010 | 200 | 11598 | https://leg.mt.gov/bills/mca/title_0390/chapter_0040/part_0010/section_0010/0390-0040-0010-0010.html |    39-4-101. Hoisting engineers, MCA  |  |
| MTS_0390-0040-0010-0020 | 200 | 12735 | https://leg.mt.gov/bills/mca/title_0390/chapter_0040/part_0010/section_0020/0390-0040-0010-0020.html |    39-4-102. Drivers and attendants of motor buses, MCA  |  |
| MTS_0390-0040-0010-0030 | 200 | 12429 | https://leg.mt.gov/bills/mca/title_0390/chapter_0040/part_0010/section_0030/0390-0040-0010-0030.html |    39-4-103. Underground miners and smelter workers, MCA  |  |
| MTS_0390-0040-0010-0040 | 200 | 11526 | https://leg.mt.gov/bills/mca/title_0390/chapter_0040/part_0010/section_0040/0390-0040-0010-0040.html |    39-4-104. Strip mining, MCA  |  |
| MTS_0390-0040-0010-0050 | 200 | 11609 | https://leg.mt.gov/bills/mca/title_0390/chapter_0040/part_0010/section_0050/0390-0040-0010-0050.html |    39-4-105. Retail stores, MCA  |  |
| MTS_0390-0040-0010-0060 | 200 | 11563 | https://leg.mt.gov/bills/mca/title_0390/chapter_0040/part_0010/section_0060/0390-0040-0010-0060.html |    39-4-106. Telephone operators, MCA  |  |
| MTS_0390-0040-0010-0070 | 200 | 13056 | https://leg.mt.gov/bills/mca/title_0390/chapter_0040/part_0010/section_0070/0390-0040-0010-0070.html |    39-4-107. State and municipal governments and school districts, MCA  |  |
| MTS_0390-0040-0010-0080 | 200 | 10666 | https://leg.mt.gov/bills/mca/title_0390/chapter_0040/part_0010/section_0080/0390-0040-0010-0080.html |    39-4-108. Repealed, MCA  |  |
| MTS_0390-0040-0010-0090 | 200 | 11630 | https://leg.mt.gov/bills/mca/title_0390/chapter_0040/part_0010/section_0090/0390-0040-0010-0090.html |    39-4-109. Cement plants and quarries, MCA  |  |
| MTS_0390-0040-0010-0100 | 200 | 11045 | https://leg.mt.gov/bills/mca/title_0390/chapter_0040/part_0010/section_0100/0390-0040-0010-0100.html |    39-4-110. Sugar refineries, MCA  |  |
| MTS_0390-0040-0010-0110 | 200 | 11629 | https://leg.mt.gov/bills/mca/title_0390/chapter_0040/part_0010/section_0110/0390-0040-0010-0110.html |    39-4-111. Restaurants, MCA  |  |
| MTS_0390-0040-0010-0120 | 200 | 12034 | https://leg.mt.gov/bills/mca/title_0390/chapter_0040/part_0010/section_0120/0390-0040-0010-0120.html |    39-4-112. Persons employed about public amusements, MCA  |  |
| MTS_0390-0050-0010-0010 | 200 | 9800 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0010/section_0010/0390-0050-0010-0010.html |    39-5-101. Repealed, MCA  |  |
| MTS_0390-0050-0010-0020 | 200 | 10127 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0010/section_0020/0390-0050-0010-0020.html |    39-5-102. Repealed, MCA  |  |
| MTS_0390-0050-0010-0030 | 200 | 10037 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0010/section_0030/0390-0050-0010-0030.html |    39-5-103. Repealed, MCA  |  |
| MTS_0390-0050-0010-0040 | 200 | 10007 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0010/section_0040/0390-0050-0010-0040.html |    39-5-104. Repealed, MCA  |  |
| MTS_0390-0050-0010-0050 | 200 | 9807 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0010/section_0050/0390-0050-0010-0050.html |    39-5-105. Repealed, MCA  |  |
| MTS_0390-0050-0020-0010 | 200 | 9773 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0020/section_0010/0390-0050-0020-0010.html |    39-5-201. Repealed, MCA  |  |
| MTS_0390-0050-0020-0020 | 200 | 10040 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0020/section_0020/0390-0050-0020-0020.html |    39-5-202. Repealed, MCA  |  |
| MTS_0390-0050-0020-0030 | 200 | 10008 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0020/section_0030/0390-0050-0020-0030.html |    39-5-203. Repealed, MCA  |  |
| MTS_0390-0050-0020-0040 | 200 | 10008 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0020/section_0040/0390-0050-0020-0040.html |    39-5-204. Repealed, MCA  |  |
| MTS_0390-0050-0020-0050 | 200 | 10011 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0020/section_0050/0390-0050-0020-0050.html |    39-5-205. Repealed, MCA  |  |
| MTS_0390-0050-0020-0060 | 200 | 10038 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0020/section_0060/0390-0050-0020-0060.html |    39-5-206. Repealed, MCA  |  |
| MTS_0390-0050-0020-0070 | 200 | 9980 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0020/section_0070/0390-0050-0020-0070.html |    39-5-207. Repealed, MCA  |  |
| MTS_0390-0050-0020-0080 | 200 | 9977 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0020/section_0080/0390-0050-0020-0080.html |    39-5-208. Repealed, MCA  |  |
| MTS_0390-0050-0020-0090 | 200 | 9808 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0020/section_0090/0390-0050-0020-0090.html |    39-5-209. Repealed, MCA  |  |
| MTS_0390-0050-0030-0010 | 200 | 9933 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0030/section_0010/0390-0050-0030-0010.html |    39-5-301. Repealed, MCA  |  |
| MTS_0390-0050-0030-0020 | 200 | 10099 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0030/section_0020/0390-0050-0030-0020.html |    39-5-302. Repealed, MCA  |  |
| MTS_0390-0050-0030-0030 | 200 | 10198 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0030/section_0030/0390-0050-0030-0030.html |    39-5-303. Repealed, MCA  |  |
| MTS_0390-0050-0030-0040 | 200 | 10103 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0030/section_0040/0390-0050-0030-0040.html |    39-5-304. Repealed, MCA  |  |
| MTS_0390-0050-0030-0050 | 200 | 10103 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0030/section_0050/0390-0050-0030-0050.html |    39-5-305. Repealed, MCA  |  |
| MTS_0390-0050-0030-0060 | 200 | 10103 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0030/section_0060/0390-0050-0030-0060.html |    39-5-306. Repealed, MCA  |  |
| MTS_0390-0050-0030-0070 | 200 | 10130 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0030/section_0070/0390-0050-0030-0070.html |    39-5-307. Repealed, MCA  |  |
| MTS_0390-0050-0030-0080 | 200 | 10309 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0030/section_0080/0390-0050-0030-0080.html |    39-5-308. Repealed, MCA  |  |
| MTS_0390-0050-0030-0090 | 200 | 10120 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0030/section_0090/0390-0050-0030-0090.html |    39-5-309. Repealed, MCA  |  |
| MTS_0390-0050-0030-0100 | 200 | 10134 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0030/section_0100/0390-0050-0030-0100.html |    39-5-310. Repealed, MCA  |  |
| MTS_0390-0050-0030-0110 | 200 | 10286 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0030/section_0110/0390-0050-0030-0110.html |    39-5-311. Repealed, MCA  |  |
| MTS_0390-0050-0030-0120 | 200 | 9903 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0030/section_0120/0390-0050-0030-0120.html |    39-5-312. Repealed, MCA  |  |
| MTS_0390-0050-0040-0010 | 200 | 9985 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0040/section_0010/0390-0050-0040-0010.html |    39-5-401. Repealed, MCA  |  |
| MTS_0390-0050-0040-0020 | 200 | 10085 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0040/section_0020/0390-0050-0040-0020.html |    39-5-402. Repealed, MCA  |  |
| MTS_0390-0050-0040-0030 | 200 | 10103 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0040/section_0030/0390-0050-0040-0030.html |    39-5-403. Repealed, MCA  |  |
| MTS_0390-0050-0040-0040 | 200 | 10072 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0040/section_0040/0390-0050-0040-0040.html |    39-5-404. Repealed, MCA  |  |
| MTS_0390-0050-0040-0050 | 200 | 10072 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0040/section_0050/0390-0050-0040-0050.html |    39-5-405. Repealed, MCA  |  |
| MTS_0390-0050-0040-0060 | 200 | 9840 | https://leg.mt.gov/bills/mca/title_0390/chapter_0050/part_0040/section_0060/0390-0050-0040-0060.html |    39-5-406. Repealed, MCA  |  |
| MTS_0390-0060-0010-0010 | 200 | 13208 | https://leg.mt.gov/bills/mca/title_0390/chapter_0060/part_0010/section_0010/0390-0060-0010-0010.html |    39-6-101. Duties of department -- definitions, MCA  |  |
| MTS_0390-0060-0010-0020 | 200 | 10952 | https://leg.mt.gov/bills/mca/title_0390/chapter_0060/part_0010/section_0020/0390-0060-0010-0020.html |    39-6-102. Powers of department, MCA  |  |
| MTS_0390-0060-0010-0030 | 200 | 10794 | https://leg.mt.gov/bills/mca/title_0390/chapter_0060/part_0010/section_0030/0390-0060-0010-0030.html |    39-6-103. Responsibilities of state and local boards responsible for vocation |  |
| MTS_0390-0060-0010-0040 | 200 | 11559 | https://leg.mt.gov/bills/mca/title_0390/chapter_0060/part_0010/section_0040/0390-0060-0010-0040.html |    39-6-104. Local and state joint apprenticeship committees, MCA  |  |
| MTS_0390-0060-0010-0050 | 200 | 10871 | https://leg.mt.gov/bills/mca/title_0390/chapter_0060/part_0010/section_0050/0390-0060-0010-0050.html |    39-6-105. Apprenticeship agreements, MCA  |  |
| MTS_0390-0060-0010-0060 | 200 | 13293 | https://leg.mt.gov/bills/mca/title_0390/chapter_0060/part_0010/section_0060/0390-0060-0010-0060.html |    39-6-106. Contents of apprenticeship agreements -- credit for prior training  |  |
| MTS_0390-0060-0010-0070 | 200 | 10393 | https://leg.mt.gov/bills/mca/title_0390/chapter_0060/part_0010/section_0070/0390-0060-0010-0070.html |    39-6-107. Participation in program voluntary, MCA  |  |
| MTS_0390-0060-0010-0080 | 200 | 12033 | https://leg.mt.gov/bills/mca/title_0390/chapter_0060/part_0010/section_0080/0390-0060-0010-0080.html |    39-6-108. Apprentice wage rate, MCA  |  |
| MTS_0390-0060-0010-0090 | 200 | 13826 | https://leg.mt.gov/bills/mca/title_0390/chapter_0060/part_0010/section_0090/0390-0060-0010-0090.html |    39-6-109. Employer apprenticeship tax credit -- increased credit for employin |  |
| MTS_0390-0070-0010-0010 | 200 | 10063 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0010/section_0010/0390-0070-0010-0010.html |    39-7-101. Legislative policy, MCA  |  |
| MTS_0390-0070-0010-0020 | 200 | 10338 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0010/section_0020/0390-0070-0010-0020.html |    39-7-102. Rules of procedure and practice, MCA  |  |
| MTS_0390-0070-0010-0030 | 200 | 12042 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0010/section_0030/0390-0070-0010-0030.html |    39-7-103. Duties of department, MCA  |  |
| MTS_0390-0070-0010-0040 | 200 | 10342 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0010/section_0040/0390-0070-0010-0040.html |    39-7-104. Department to work in close cooperation with commission for human r |  |
| MTS_0390-0070-0020-0010 | 200 | 9853 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0020/section_0010/0390-0070-0020-0010.html |    39-7-201. Repealed, MCA  |  |
| MTS_0390-0070-0020-0020 | 200 | 10067 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0020/section_0020/0390-0070-0020-0020.html |    39-7-202. Repealed, MCA  |  |
| MTS_0390-0070-0020-0030 | 200 | 9854 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0020/section_0030/0390-0070-0020-0030.html |    39-7-203. Renumbered 49-2-310, MCA  |  |
| MTS_0390-0070-0020-0040 | 200 | 9854 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0020/section_0040/0390-0070-0020-0040.html |    39-7-204. Renumbered 49-2-311, MCA  |  |
| MTS_0390-0070-0020-0050 | 200 | 10073 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0020/section_0050/0390-0070-0020-0050.html |    39-7-205. Repealed, MCA  |  |
| MTS_0390-0070-0020-0060 | 200 | 10056 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0020/section_0060/0390-0070-0020-0060.html |    39-7-206. Repealed, MCA  |  |
| MTS_0390-0070-0020-0070 | 200 | 10062 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0020/section_0070/0390-0070-0020-0070.html |    39-7-207. Repealed, MCA  |  |
| MTS_0390-0070-0020-0080 | 200 | 10056 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0020/section_0080/0390-0070-0020-0080.html |    39-7-208. Repealed, MCA  |  |
| MTS_0390-0070-0020-0090 | 200 | 9823 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0020/section_0090/0390-0070-0020-0090.html |    39-7-209. Repealed, MCA  |  |
| MTS_0390-0070-0030-0010 | 200 | 9761 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0030/section_0010/0390-0070-0030-0010.html |    39-7-301. Short title, MCA  |  |
| MTS_0390-0070-0030-0020 | 200 | 10117 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0030/section_0020/0390-0070-0030-0020.html |    39-7-302. Purpose, MCA  |  |
| MTS_0390-0070-0030-0030 | 200 | 11836 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0030/section_0030/0390-0070-0030-0030.html |    39-7-303. Definitions, MCA  |  |
| MTS_0390-0070-0030-0040 | 200 | 10748 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0030/section_0040/0390-0070-0030-0040.html |    39-7-304. Multipurpose service programs for displaced homemakers -- administr |  |
| MTS_0390-0070-0030-0050 | 200 | 12547 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0030/section_0050/0390-0070-0030-0050.html |    39-7-305. Programs to aid displaced homemakers, MCA  |  |
| MTS_0390-0070-0030-0060 | 200 | 10856 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0030/section_0060/0390-0070-0030-0060.html |    39-7-306. Rulemaking duties of commissioner, MCA  |  |
| MTS_0390-0070-0030-0070 | 200 | 10527 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0030/section_0070/0390-0070-0030-0070.html |    39-7-307. Acceptance of funds by administrator of local program, MCA  |  |
| MTS_0390-0070-0030-0080 | 200 | 10789 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0030/section_0080/0390-0070-0030-0080.html |    39-7-308. Evaluation of multipurpose service programs -- reports to the commi |  |
| MTS_0390-0070-0030-0090 | 200 | 10226 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0030/section_0090/0390-0070-0030-0090.html |    39-7-309. Staff of service programs, MCA  |  |
| MTS_0390-0070-0030-0100 | 200 | 10047 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0030/section_0100/0390-0070-0030-0100.html |    39-7-310. Partial funding from local community, MCA  |  |
| MTS_0390-0070-0060-0010 | 200 | 9884 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0060/section_0010/0390-0070-0060-0010.html |    39-7-601. Repealed, MCA  |  |
| MTS_0390-0070-0060-0020 | 200 | 10087 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0060/section_0020/0390-0070-0060-0020.html |    39-7-602. Repealed, MCA  |  |
| MTS_0390-0070-0060-0030 | 200 | 10118 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0060/section_0030/0390-0070-0060-0030.html |    39-7-603. Repealed, MCA  |  |
| MTS_0390-0070-0060-0040 | 200 | 10118 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0060/section_0040/0390-0070-0060-0040.html |    39-7-604. Repealed, MCA  |  |
| MTS_0390-0070-0060-0050 | 200 | 10118 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0060/section_0050/0390-0070-0060-0050.html |    39-7-605. Repealed, MCA  |  |
| MTS_0390-0070-0060-0060 | 200 | 9918 | https://leg.mt.gov/bills/mca/title_0390/chapter_0070/part_0060/section_0060/0390-0070-0060-0060.html |    39-7-606. Repealed, MCA  |  |
| MTS_0390-0080-0010-0010 | 200 | 10271 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0010/section_0010/0390-0080-0010-0010.html |    39-8-101. Short title -- purpose, MCA  |  |
| MTS_0390-0080-0010-0020 | 200 | 15899 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0010/section_0020/0390-0080-0010-0020.html |    39-8-102. Definitions, MCA  |  |
| MTS_0390-0080-0020-0010 | 200 | 10992 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0020/section_0010/0390-0080-0020-0010.html |    39-8-201. License required -- exemption -- rulemaking authority, MCA  |  |
| MTS_0390-0080-0020-0020 | 200 | 19824 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0020/section_0020/0390-0080-0020-0020.html |    39-8-202. Initial license application -- application fee -- standards -- prov |  |
| MTS_0390-0080-0020-0030 | 200 | 14370 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0020/section_0030/0390-0080-0020-0030.html |    39-8-203. Denial of license application or renewal -- hearing, MCA  |  |
| MTS_0390-0080-0020-0040 | 200 | 11365 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0020/section_0040/0390-0080-0020-0040.html |    39-8-204. License renewal, MCA  |  |
| MTS_0390-0080-0020-0050 | 200 | 10606 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0020/section_0050/0390-0080-0020-0050.html |    39-8-205. Renewal fees, MCA  |  |
| MTS_0390-0080-0020-0060 | 200 | 12833 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0020/section_0060/0390-0080-0020-0060.html |    39-8-206. License suspension, revocation, or nonrenewal, MCA  |  |
| MTS_0390-0080-0020-0070 | 200 | 24760 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0020/section_0070/0390-0080-0020-0070.html |    39-8-207. Requirements of licensee, MCA  |  |
| MTS_0390-0080-0030-0010 | 200 | 11821 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0030/section_0010/0390-0080-0030-0010.html |    39-8-301. Deceptive practices prohibited, MCA  |  |
| MTS_0390-0080-0030-0020 | 200 | 12088 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0030/section_0020/0390-0080-0030-0020.html |    39-8-302. Disciplinary action against licensee -- penalties, MCA  |  |
| MTS_0390-0080-0030-0030 | 200 | 10670 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0030/section_0030/0390-0080-0030-0030.html |    39-8-303. Practice without license -- investigation of complaint -- injunctio |  |
| MTS_0390-0080-0030-0040 | 200 | 10544 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0030/section_0040/0390-0080-0030-0040.html |    39-8-304. Violation of injunction -- penalty, MCA  |  |
| MTS_0390-0080-0030-0050 | 200 | 10829 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0030/section_0050/0390-0080-0030-0050.html |    39-8-305. Investigations -- audits -- reviews, MCA  |  |
| MTS_0390-0080-0040-0010 | 200 | 10882 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0040/section_0010/0390-0080-0040-0010.html |    39-8-401. Disclosure of information, MCA  |  |
| MTS_0390-0080-0040-0020 | 200 | 10934 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0040/section_0020/0390-0080-0040-0020.html |    39-8-402. Other law, MCA  |  |
| MTS_0390-0080-0040-0030 | 200 | 11685 | https://leg.mt.gov/bills/mca/title_0390/chapter_0080/part_0040/section_0030/0390-0080-0040-0030.html |    39-8-403. Workers' compensation insurer requirements, MCA  |  |
| MTS_0390-0090-0010-0010 | 200 | 9823 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0010/section_0010/0390-0090-0010-0010.html |    39-9-101. Repealed, MCA  |  |
| MTS_0390-0090-0010-0020 | 200 | 10026 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0010/section_0020/0390-0090-0010-0020.html |    39-9-102. Repealed, MCA  |  |
| MTS_0390-0090-0010-0030 | 200 | 9765 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0010/section_0030/0390-0090-0010-0030.html |    39-9-103. Repealed, MCA  |  |
| MTS_0390-0090-0020-0010 | 200 | 9850 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0020/section_0010/0390-0090-0020-0010.html |    39-9-201. Repealed, MCA  |  |
| MTS_0390-0090-0020-0020 | 200 | 10028 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0020/section_0020/0390-0090-0020-0020.html |    39-9-202. Repealed, MCA  |  |
| MTS_0390-0090-0020-0030 | 200 | 10028 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0020/section_0030/0390-0090-0020-0030.html |    39-9-203. Repealed, MCA  |  |
| MTS_0390-0090-0020-0040 | 200 | 10034 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0020/section_0040/0390-0090-0020-0040.html |    39-9-204. Repealed, MCA  |  |
| MTS_0390-0090-0020-0050 | 200 | 9816 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0020/section_0050/0390-0090-0020-0050.html |    39-9-205. Renumbered 37-45-205, MCA  |  |
| MTS_0390-0090-0020-0060 | 200 | 10096 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0020/section_0060/0390-0090-0020-0060.html |    39-9-206. Repealed, MCA  |  |
| MTS_0390-0090-0020-0070 | 200 | 10070 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0020/section_0070/0390-0090-0020-0070.html |    39-9-207. Repealed, MCA  |  |
| MTS_0390-0090-0020-0080 | 200 | 9856 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0020/section_0080/0390-0090-0020-0080.html |    39-9-208. through 39-9-210 reserved, MCA  |  |
| MTS_0390-0090-0020-0110 | 200 | 9833 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0020/section_0110/0390-0090-0020-0110.html |    39-9-211. Renumbered 37-45-104, MCA  |  |
| MTS_0390-0090-0020-0120 | 200 | 10003 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0020/section_0120/0390-0090-0020-0120.html |    39-9-212. Repealed, MCA  |  |
| MTS_0390-0090-0020-0130 | 200 | 9864 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0020/section_0130/0390-0090-0020-0130.html |    39-9-213. Repealed, MCA  |  |
| MTS_0390-0090-0030-0010 | 200 | 9863 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0030/section_0010/0390-0090-0030-0010.html |    39-9-301. Repealed, MCA  |  |
| MTS_0390-0090-0030-0020 | 200 | 10047 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0030/section_0020/0390-0090-0030-0020.html |    39-9-302. Repealed, MCA  |  |
| MTS_0390-0090-0030-0030 | 200 | 10084 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0030/section_0030/0390-0090-0030-0030.html |    39-9-303. Repealed, MCA  |  |
| MTS_0390-0090-0030-0040 | 200 | 9634 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0030/section_0040/0390-0090-0030-0040.html |    39-9-304. Renumbered 37-45-204, MCA  |  |
| MTS_0390-0090-0040-0010 | 200 | 9874 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0040/section_0010/0390-0090-0040-0010.html |    39-9-401. Repealed, MCA  |  |
| MTS_0390-0090-0040-0020 | 200 | 10020 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0040/section_0020/0390-0090-0040-0020.html |    39-9-402. Repealed, MCA  |  |
| MTS_0390-0090-0040-0030 | 200 | 10071 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0040/section_0030/0390-0090-0040-0030.html |    39-9-403. Repealed, MCA  |  |
| MTS_0390-0090-0040-0040 | 200 | 10020 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0040/section_0040/0390-0090-0040-0040.html |    39-9-404. Repealed, MCA  |  |
| MTS_0390-0090-0040-0050 | 200 | 10020 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0040/section_0050/0390-0090-0040-0050.html |    39-9-405. Repealed, MCA  |  |
| MTS_0390-0090-0040-0060 | 200 | 10020 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0040/section_0060/0390-0090-0040-0060.html |    39-9-406. Repealed, MCA  |  |
| MTS_0390-0090-0040-0070 | 200 | 10020 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0040/section_0070/0390-0090-0040-0070.html |    39-9-407. Repealed, MCA  |  |
| MTS_0390-0090-0040-0080 | 200 | 10020 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0040/section_0080/0390-0090-0040-0080.html |    39-9-408. Repealed, MCA  |  |
| MTS_0390-0090-0040-0090 | 200 | 10020 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0040/section_0090/0390-0090-0040-0090.html |    39-9-409. Repealed, MCA  |  |
| MTS_0390-0090-0040-0100 | 200 | 9820 | https://leg.mt.gov/bills/mca/title_0390/chapter_0090/part_0040/section_0100/0390-0090-0040-0100.html |    39-9-410. Repealed, MCA  |  |
| MTS_0390-0100-0010-0010 | 200 | 9874 | https://leg.mt.gov/bills/mca/title_0390/chapter_0100/part_0010/section_0010/0390-0100-0010-0010.html |    39-10-101. Terminated, MCA  |  |
| MTS_0390-0100-0010-0020 | 200 | 10080 | https://leg.mt.gov/bills/mca/title_0390/chapter_0100/part_0010/section_0020/0390-0100-0010-0020.html |    39-10-102. Terminated, MCA  |  |
| MTS_0390-0100-0010-0030 | 200 | 10080 | https://leg.mt.gov/bills/mca/title_0390/chapter_0100/part_0010/section_0030/0390-0100-0010-0030.html |    39-10-103. Terminated, MCA  |  |
| MTS_0390-0100-0010-0040 | 200 | 10080 | https://leg.mt.gov/bills/mca/title_0390/chapter_0100/part_0010/section_0040/0390-0100-0010-0040.html |    39-10-104. Terminated, MCA  |  |
| MTS_0390-0100-0010-0050 | 200 | 10080 | https://leg.mt.gov/bills/mca/title_0390/chapter_0100/part_0010/section_0050/0390-0100-0010-0050.html |    39-10-105. Terminated, MCA  |  |
| MTS_0390-0100-0010-0060 | 200 | 9877 | https://leg.mt.gov/bills/mca/title_0390/chapter_0100/part_0010/section_0060/0390-0100-0010-0060.html |    39-10-106. Terminated, MCA  |  |
| MTS_0390-0100-0020-0010 | 200 | 9837 | https://leg.mt.gov/bills/mca/title_0390/chapter_0100/part_0020/section_0010/0390-0100-0020-0010.html |    39-10-201. Terminated, MCA  |  |
| MTS_0390-0100-0020-0020 | 200 | 10043 | https://leg.mt.gov/bills/mca/title_0390/chapter_0100/part_0020/section_0020/0390-0100-0020-0020.html |    39-10-202. Terminated, MCA  |  |
| MTS_0390-0100-0020-0030 | 200 | 10043 | https://leg.mt.gov/bills/mca/title_0390/chapter_0100/part_0020/section_0030/0390-0100-0020-0030.html |    39-10-203. Terminated, MCA  |  |
| MTS_0390-0100-0020-0040 | 200 | 10043 | https://leg.mt.gov/bills/mca/title_0390/chapter_0100/part_0020/section_0040/0390-0100-0020-0040.html |    39-10-204. Terminated, MCA  |  |
| MTS_0390-0100-0020-0050 | 200 | 10043 | https://leg.mt.gov/bills/mca/title_0390/chapter_0100/part_0020/section_0050/0390-0100-0020-0050.html |    39-10-205. Terminated, MCA  |  |
| MTS_0390-0100-0020-0060 | 200 | 9840 | https://leg.mt.gov/bills/mca/title_0390/chapter_0100/part_0020/section_0060/0390-0100-0020-0060.html |    39-10-206. Terminated, MCA  |  |
| MTS_0390-0110-0010-0010 | 200 | 9810 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0010/section_0010/0390-0110-0010-0010.html |    39-11-101. Short title, MCA  |  |
| MTS_0390-0110-0010-0020 | 200 | 10533 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0010/section_0020/0390-0110-0010-0020.html |    39-11-102. Purpose, MCA  |  |
| MTS_0390-0110-0010-0030 | 200 | 16875 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0010/section_0030/0390-0110-0010-0030.html |    39-11-103. Definitions, MCA  |  |
| MTS_0390-0110-0020-0010 | 200 | 9903 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0020/section_0010/0390-0110-0020-0010.html |    39-11-201. Repealed, MCA  |  |
| MTS_0390-0110-0020-0020 | 200 | 18884 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0020/section_0020/0390-0110-0020-0020.html |    39-11-202. Primary sector business workforce training grants -- eligibility,  |  |
| MTS_0390-0110-0020-0030 | 200 | 10044 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0020/section_0030/0390-0110-0020-0030.html |    39-11-203. Repealed, MCA  |  |
| MTS_0390-0110-0020-0040 | 200 | 10020 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0020/section_0040/0390-0110-0020-0040.html |    39-11-204. Repealed, MCA  |  |
| MTS_0390-0110-0020-0050 | 200 | 11399 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0020/section_0050/0390-0110-0020-0050.html |    39-11-205. Primary sector business training account, MCA  |  |
| MTS_0390-0110-0020-0060 | 200 | 10071 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0020/section_0060/0390-0110-0020-0060.html |    39-11-206. Exemption from environmental review, MCA  |  |
| MTS_0390-0110-0030-0010 | 200 | 9917 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0030/section_0010/0390-0110-0030-0010.html |    39-11-301. Terminated, MCA  |  |
| MTS_0390-0110-0030-0020 | 200 | 10123 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0030/section_0020/0390-0110-0030-0020.html |    39-11-302. Terminated, MCA  |  |
| MTS_0390-0110-0030-0030 | 200 | 10123 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0030/section_0030/0390-0110-0030-0030.html |    39-11-303. Terminated, MCA  |  |
| MTS_0390-0110-0030-0040 | 200 | 10123 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0030/section_0040/0390-0110-0030-0040.html |    39-11-304. Terminated, MCA  |  |
| MTS_0390-0110-0030-0050 | 200 | 10123 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0030/section_0050/0390-0110-0030-0050.html |    39-11-305. Terminated, MCA  |  |
| MTS_0390-0110-0030-0060 | 200 | 10123 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0030/section_0060/0390-0110-0030-0060.html |    39-11-306. Terminated, MCA  |  |
| MTS_0390-0110-0030-0070 | 200 | 9920 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0030/section_0070/0390-0110-0030-0070.html |    39-11-307. Terminated, MCA  |  |
| MTS_0390-0110-0040-0010 | 200 | 9695 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0040/section_0010/0390-0110-0040-0010.html |    39-11-401. through 39-11-403 reserved, MCA  |  |
| MTS_0390-0110-0040-0040 | 200 | 19506 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0040/section_0040/0390-0110-0040-0040.html |    39-11-404. Employer job growth incentive tax credit -- administration, MCA  |  |
| MTS_0390-0110-0050-0010 | 200 | 13908 | https://leg.mt.gov/bills/mca/title_0390/chapter_0110/part_0050/section_0010/0390-0110-0050-0010.html |    39-11-501. Office of reentry services -- purpose -- duties --collaboration -- |  |
| MTS_0390-0120-0010-0010 | 200 | 12597 | https://leg.mt.gov/bills/mca/title_0390/chapter_0120/part_0010/section_0010/0390-0120-0010-0010.html |    39-12-101. Montana HELP Act workforce development -- legislative findings --  |  |
| MTS_0390-0120-0010-0020 | 200 | 10784 | https://leg.mt.gov/bills/mca/title_0390/chapter_0120/part_0010/section_0020/0390-0120-0010-0020.html |    39-12-102. Definitions, MCA  |  |
| MTS_0390-0120-0010-0030 | 200 | 16126 | https://leg.mt.gov/bills/mca/title_0390/chapter_0120/part_0010/section_0030/0390-0120-0010-0030.html |    39-12-103. Montana HELP Act workforce development -- participation, MCA  |  |
| MTS_0390-0120-0010-0040 | 200 | 9885 | https://leg.mt.gov/bills/mca/title_0390/chapter_0120/part_0010/section_0040/0390-0120-0010-0040.html |    39-12-104. and 39-12-105 reserved, MCA  |  |
| MTS_0390-0120-0010-0060 | 200 | 11871 | https://leg.mt.gov/bills/mca/title_0390/chapter_0120/part_0010/section_0060/0390-0120-0010-0060.html |    39-12-106. Montana HELP Act employer grant program, MCA  |  |
| MTS_0390-0120-0010-0070 | 200 | 10481 | https://leg.mt.gov/bills/mca/title_0390/chapter_0120/part_0010/section_0070/0390-0120-0010-0070.html |    39-12-107. Rulemaking authority, MCA  |  |
| MTS_0390-0290-0010-0010 | 200 | 17556 | https://leg.mt.gov/bills/mca/title_0390/chapter_0290/part_0010/section_0010/0390-0290-0010-0010.html |    39-29-101. Definitions, MCA  |  |
| MTS_0390-0290-0010-0020 | 200 | 13541 | https://leg.mt.gov/bills/mca/title_0390/chapter_0290/part_0010/section_0020/0390-0290-0010-0020.html |    39-29-102. Point preference or alternative preference in initial hiring for c |  |
| MTS_0390-0290-0010-0030 | 200 | 11548 | https://leg.mt.gov/bills/mca/title_0390/chapter_0290/part_0010/section_0030/0390-0290-0010-0030.html |    39-29-103. Notice and claim of preference, MCA  |  |
| MTS_0390-0290-0010-0040 | 200 | 13358 | https://leg.mt.gov/bills/mca/title_0390/chapter_0290/part_0010/section_0040/0390-0290-0010-0040.html |    39-29-104. Enforcement of preference, MCA  |  |
| MTS_0390-0290-0010-0050 | 200 | 9811 | https://leg.mt.gov/bills/mca/title_0390/chapter_0290/part_0010/section_0050/0390-0290-0010-0050.html |    39-29-105. through 39-29-110 reserved, MCA  |  |
| MTS_0390-0290-0010-0110 | 200 | 11272 | https://leg.mt.gov/bills/mca/title_0390/chapter_0290/part_0010/section_0110/0390-0290-0010-0110.html |    39-29-111. Retention during reduction in force, MCA  |  |
| MTS_0390-0290-0010-0120 | 200 | 10073 | https://leg.mt.gov/bills/mca/title_0390/chapter_0290/part_0010/section_0120/0390-0290-0010-0120.html |    39-29-112. Adoption of rules, MCA  |  |
| MTS_0390-0290-0020-0010 | 200 | 9858 | https://leg.mt.gov/bills/mca/title_0390/chapter_0290/part_0020/section_0010/0390-0290-0020-0010.html |    39-29-201. Short title, MCA  |  |
| MTS_0390-0290-0020-0020 | 200 | 10487 | https://leg.mt.gov/bills/mca/title_0390/chapter_0290/part_0020/section_0020/0390-0290-0020-0020.html |    39-29-202. Legislative intent -- interpretation, MCA  |  |
| MTS_0390-0290-0020-0030 | 200 | 10419 | https://leg.mt.gov/bills/mca/title_0390/chapter_0290/part_0020/section_0030/0390-0290-0020-0030.html |    39-29-203. Veteran hiring preference for private employers authorized -- defi |  |
| MTS_0390-0300-0010-0010 | 200 | 9896 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0010/section_0010/0390-0300-0010-0010.html |    39-30-101. Short title, MCA  |  |
| MTS_0390-0300-0010-0020 | 200 | 10205 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0010/section_0020/0390-0300-0010-0020.html |    39-30-102. Purposes, MCA  |  |
| MTS_0390-0300-0010-0030 | 200 | 17644 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0010/section_0030/0390-0300-0010-0030.html |    39-30-103. Definitions, MCA  |  |
| MTS_0390-0300-0010-0040 | 200 | 9805 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0010/section_0040/0390-0300-0010-0040.html |    39-30-104. and 39-30-105 reserved, MCA  |  |
| MTS_0390-0300-0010-0060 | 200 | 10432 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0010/section_0060/0390-0300-0010-0060.html |    39-30-106. Adoption of rules, MCA  |  |
| MTS_0390-0300-0010-0070 | 200 | 10506 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0010/section_0070/0390-0300-0010-0070.html |    39-30-107. Certification of persons with disabilities, MCA  |  |
| MTS_0390-0300-0010-0080 | 200 | 10109 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0010/section_0080/0390-0300-0010-0080.html |    39-30-108. No application if conflict with federal law, MCA  |  |
| MTS_0390-0300-0020-0010 | 200 | 12244 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0020/section_0010/0390-0300-0020-0010.html |    39-30-201. Employment preference in initial hiring, MCA  |  |
| MTS_0390-0300-0020-0020 | 200 | 11171 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0020/section_0020/0390-0300-0020-0020.html |    39-30-202. Eligibility requirements, MCA  |  |
| MTS_0390-0300-0020-0030 | 200 | 10328 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0020/section_0030/0390-0300-0020-0030.html |    39-30-203. Duration of preference, MCA  |  |
| MTS_0390-0300-0020-0040 | 200 | 9835 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0020/section_0040/0390-0300-0020-0040.html |    39-30-204. and 39-30-205 reserved, MCA  |  |
| MTS_0390-0300-0020-0060 | 200 | 11023 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0020/section_0060/0390-0300-0020-0060.html |    39-30-206. Notice and claim of preference, MCA  |  |
| MTS_0390-0300-0020-0070 | 200 | 13057 | https://leg.mt.gov/bills/mca/title_0390/chapter_0300/part_0020/section_0070/0390-0300-0020-0070.html |    39-30-207. Enforcement of preference, MCA  |  |
| MTS_0390-0310-0010-0010 | 200 | 10040 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0010/section_0010/0390-0310-0010-0010.html |    39-31-101. Policy, MCA  |  |
| MTS_0390-0310-0010-0020 | 200 | 10407 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0010/section_0020/0390-0310-0010-0020.html |    39-31-102. Chapter not limit on legislative authority, MCA  |  |
| MTS_0390-0310-0010-0030 | 200 | 16506 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0010/section_0030/0390-0310-0010-0030.html |    39-31-103. Definitions, MCA  |  |
| MTS_0390-0310-0010-0040 | 200 | 10117 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0010/section_0040/0390-0310-0010-0040.html |    39-31-104. Rules, MCA  |  |
| MTS_0390-0310-0010-0050 | 200 | 10507 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0010/section_0050/0390-0310-0010-0050.html |    39-31-105. Administrative procedure act applicable -- conduct of hearing, MCA |  |
| MTS_0390-0310-0010-0060 | 200 | 11022 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0010/section_0060/0390-0310-0010-0060.html |    39-31-106. Board authorized to subpoena witnesses and administer oaths, MCA  |  |
| MTS_0390-0310-0010-0070 | 200 | 10477 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0010/section_0070/0390-0310-0010-0070.html |    39-31-107. Service of subpoenas, notices of hearing, and other process, MCA  |  |
| MTS_0390-0310-0010-0080 | 200 | 10468 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0010/section_0080/0390-0310-0010-0080.html |    39-31-108. Counsel for public parties to litigation, MCA  |  |
| MTS_0390-0310-0010-0090 | 200 | 10155 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0010/section_0090/0390-0310-0010-0090.html |    39-31-109. Existing collective bargaining agreements not affected, MCA  |  |
| MTS_0390-0310-0020-0010 | 200 | 10715 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0020/section_0010/0390-0310-0020-0010.html |    39-31-201. Public employees protected in right of self-organization, MCA  |  |
| MTS_0390-0310-0020-0020 | 200 | 12378 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0020/section_0020/0390-0310-0020-0020.html |    39-31-202. Board to determine appropriate bargaining unit -- factors to be co |  |
| MTS_0390-0310-0020-0030 | 200 | 10631 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0020/section_0030/0390-0310-0020-0030.html |    39-31-203. Deduction of dues from employee's pay, MCA  |  |
| MTS_0390-0310-0020-0040 | 200 | 10370 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0020/section_0040/0390-0310-0020-0040.html |    39-31-204. Repealed, MCA  |  |
| MTS_0390-0310-0020-0050 | 200 | 10905 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0020/section_0050/0390-0310-0020-0050.html |    39-31-205. Designated labor organizations to represent employees without disc |  |
| MTS_0390-0310-0020-0060 | 200 | 11865 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0020/section_0060/0390-0310-0020-0060.html |    39-31-206. Labor organization to guarantee certain rights and safeguards prio |  |
| MTS_0390-0310-0020-0070 | 200 | 11983 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0020/section_0070/0390-0310-0020-0070.html |    39-31-207. Petition on representation question -- investigation by board -- h |  |
| MTS_0390-0310-0020-0080 | 200 | 11999 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0020/section_0080/0390-0310-0020-0080.html |    39-31-208. Representation election at direction of board, MCA  |  |
| MTS_0390-0310-0020-0090 | 200 | 10611 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0020/section_0090/0390-0310-0020-0090.html |    39-31-209. Consent election, MCA  |  |
| MTS_0390-0310-0020-0100 | 200 | 10659 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0020/section_0100/0390-0310-0020-0100.html |    39-31-210. Election in 12-month period following valid election prohibited, M |  |
| MTS_0390-0310-0020-0110 | 200 | 10750 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0020/section_0110/0390-0310-0020-0110.html |    39-31-211. Labor organizations representing employees of the board to be unaf |  |
| MTS_0390-0310-0030-0010 | 200 | 10248 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0030/section_0010/0390-0310-0030-0010.html |    39-31-301. Representative of public employer, MCA  |  |
| MTS_0390-0310-0030-0020 | 200 | 11182 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0030/section_0020/0390-0310-0030-0020.html |    39-31-302. Participation by student representative when public employer is bo |  |
| MTS_0390-0310-0030-0030 | 200 | 11419 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0030/section_0030/0390-0310-0030-0030.html |    39-31-303. Management rights of public employers, MCA  |  |
| MTS_0390-0310-0030-0040 | 200 | 10363 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0030/section_0040/0390-0310-0030-0040.html |    39-31-304. Negotiable items for school districts, MCA  |  |
| MTS_0390-0310-0030-0050 | 200 | 11767 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0030/section_0050/0390-0310-0030-0050.html |    39-31-305. Duty to bargain collectively -- good faith, MCA  |  |
| MTS_0390-0310-0030-0060 | 200 | 12161 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0030/section_0060/0390-0310-0030-0060.html |    39-31-306. Collective bargaining agreements, MCA  |  |
| MTS_0390-0310-0030-0070 | 200 | 10366 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0030/section_0070/0390-0310-0030-0070.html |    39-31-307. Mediation of disputes, MCA  |  |
| MTS_0390-0310-0030-0080 | 200 | 11315 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0030/section_0080/0390-0310-0030-0080.html |    39-31-308. Initiation of factfinding -- designation of fact finder, MCA  |  |
| MTS_0390-0310-0030-0090 | 200 | 11940 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0030/section_0090/0390-0310-0030-0090.html |    39-31-309. Factfinding proceedings, MCA  |  |
| MTS_0390-0310-0030-0100 | 200 | 10798 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0030/section_0100/0390-0310-0030-0100.html |    39-31-310. Submission of issues to arbitration, MCA  |  |
| MTS_0390-0310-0030-0110 | 200 | 10438 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0030/section_0110/0390-0310-0030-0110.html |    39-31-311. Training of fact finders and arbitrators, MCA  |  |
| MTS_0390-0310-0030-0120 | 200 | 10147 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0030/section_0120/0390-0310-0030-0120.html |    39-31-312. Nonnegotiable items for state prison, MCA  |  |
| MTS_0390-0310-0040-0010 | 200 | 11536 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0040/section_0010/0390-0310-0040-0010.html |    39-31-401. Unfair labor practices of public employer, MCA  |  |
| MTS_0390-0310-0040-0020 | 200 | 11294 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0040/section_0020/0390-0310-0040-0020.html |    39-31-402. Unfair labor practices of labor organization, MCA  |  |
| MTS_0390-0310-0040-0030 | 200 | 10502 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0040/section_0030/0390-0310-0040-0030.html |    39-31-403. Remedies for unfair labor practices, MCA  |  |
| MTS_0390-0310-0040-0040 | 200 | 10708 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0040/section_0040/0390-0310-0040-0040.html |    39-31-404. Six-month limitation on unfair labor practice complaint -- excepti |  |
| MTS_0390-0310-0040-0050 | 200 | 13125 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0040/section_0050/0390-0310-0040-0050.html |    39-31-405. Unfair labor practice complaint -- investigation -- notice of hear |  |
| MTS_0390-0310-0040-0060 | 200 | 13439 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0040/section_0060/0390-0310-0040-0060.html |    39-31-406. Hearing on complaint -- findings -- order, MCA  |  |
| MTS_0390-0310-0040-0070 | 200 | 10255 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0040/section_0070/0390-0310-0040-0070.html |    39-31-407. Amendment of complaint, MCA  |  |
| MTS_0390-0310-0040-0080 | 200 | 10406 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0040/section_0080/0390-0310-0040-0080.html |    39-31-408. Modification by board of findings and order, MCA  |  |
| MTS_0390-0310-0040-0090 | 200 | 12368 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0040/section_0090/0390-0310-0040-0090.html |    39-31-409. Court enforcement and review of board order, MCA  |  |
| MTS_0390-0310-0050-0010 | 200 | 11128 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0050/section_0010/0390-0310-0050-0010.html |    39-31-501. Strikes by police officers prohibited, MCA  |  |
| MTS_0390-0310-0050-0020 | 200 | 12598 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0050/section_0020/0390-0310-0050-0020.html |    39-31-502. Mediation of disputes, MCA  |  |
| MTS_0390-0310-0050-0030 | 200 | 10956 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0050/section_0030/0390-0310-0050-0030.html |    39-31-503. Binding arbitration -- policy, MCA  |  |
| MTS_0390-0310-0050-0040 | 200 | 14794 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0050/section_0040/0390-0310-0050-0040.html |    39-31-504. Selection of arbitrator -- procedure -- cost sharing, MCA  |  |
| MTS_0390-0310-0050-0050 | 200 | 10475 | https://leg.mt.gov/bills/mca/title_0390/chapter_0310/part_0050/section_0050/0390-0310-0050-0050.html |    39-31-505. Arbitration decision final, MCA  |  |
| MTS_0390-0320-0010-0010 | 200 | 10191 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0010/0390-0320-0010-0010.html |    39-32-101. Purpose of chapter, MCA  |  |
| MTS_0390-0320-0010-0020 | 200 | 11678 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0020/0390-0320-0010-0020.html |    39-32-102. Definitions, MCA  |  |
| MTS_0390-0320-0010-0030 | 200 | 10058 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0030/0390-0320-0010-0030.html |    39-32-103. Rules, MCA  |  |
| MTS_0390-0320-0010-0040 | 200 | 10494 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0040/0390-0320-0010-0040.html |    39-32-104. Hearings for determination of appropriate unit, MCA  |  |
| MTS_0390-0320-0010-0050 | 200 | 11498 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0050/0390-0320-0010-0050.html |    39-32-105. General classifications for health care facilities and appropriate |  |
| MTS_0390-0320-0010-0060 | 200 | 11179 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0060/0390-0320-0010-0060.html |    39-32-106. Determination of appropriate bargaining unit, MCA  |  |
| MTS_0390-0320-0010-0070 | 200 | 10006 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0070/0390-0320-0010-0070.html |    39-32-107. Repealed, MCA  |  |
| MTS_0390-0320-0010-0080 | 200 | 9984 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0080/0390-0320-0010-0080.html |    39-32-108. Repealed, MCA  |  |
| MTS_0390-0320-0010-0090 | 200 | 12963 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0090/0390-0320-0010-0090.html |    39-32-109. Unfair labor practices, MCA  |  |
| MTS_0390-0320-0010-0100 | 200 | 10585 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0100/0390-0320-0010-0100.html |    39-32-110. Unlawful strikes, MCA  |  |
| MTS_0390-0320-0010-0110 | 200 | 10028 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0110/0390-0320-0010-0110.html |    39-32-111. Repealed, MCA  |  |
| MTS_0390-0320-0010-0120 | 200 | 10430 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0120/0390-0320-0010-0120.html |    39-32-112. Adjudication of unfair labor practices complaints by board, MCA  |  |
| MTS_0390-0320-0010-0130 | 200 | 10460 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0130/0390-0320-0010-0130.html |    39-32-113. Representation questions decided by board, MCA  |  |
| MTS_0390-0320-0010-0140 | 200 | 10258 | https://leg.mt.gov/bills/mca/title_0390/chapter_0320/part_0010/section_0140/0390-0320-0010-0140.html |    39-32-114. Subpoena power of board, MCA  |  |
| MTS_0390-0330-0010-0010 | 200 | 10301 | https://leg.mt.gov/bills/mca/title_0390/chapter_0330/part_0010/section_0010/0390-0330-0010-0010.html |    39-33-101. Intent of part, MCA  |  |
| MTS_0390-0330-0010-0020 | 200 | 10325 | https://leg.mt.gov/bills/mca/title_0390/chapter_0330/part_0010/section_0020/0390-0330-0010-0020.html |    39-33-102. Immediate family defined, MCA  |  |
| MTS_0390-0330-0010-0030 | 200 | 10455 | https://leg.mt.gov/bills/mca/title_0390/chapter_0330/part_0010/section_0030/0390-0330-0010-0030.html |    39-33-103. Unfair labor practice, MCA  |  |
| MTS_0390-0330-0010-0040 | 200 | 10334 | https://leg.mt.gov/bills/mca/title_0390/chapter_0330/part_0010/section_0040/0390-0330-0010-0040.html |    39-33-104. Beer and liquor establishment excepted, MCA  |  |
| MTS_0390-0330-0010-0050 | 200 | 10010 | https://leg.mt.gov/bills/mca/title_0390/chapter_0330/part_0010/section_0050/0390-0330-0010-0050.html |    39-33-105. Violation, MCA  |  |
| MTS_0390-0330-0020-0010 | 200 | 10259 | https://leg.mt.gov/bills/mca/title_0390/chapter_0330/part_0020/section_0010/0390-0330-0020-0010.html |    39-33-201. Recruitment of strikebreakers by third parties, MCA  |  |
| MTS_0390-0330-0020-0020 | 200 | 10806 | https://leg.mt.gov/bills/mca/title_0390/chapter_0330/part_0020/section_0020/0390-0330-0020-0020.html |    39-33-202. Professional strikebreakers prohibited, MCA  |  |
| MTS_0390-0330-0020-0030 | 200 | 10489 | https://leg.mt.gov/bills/mca/title_0390/chapter_0330/part_0020/section_0030/0390-0330-0020-0030.html |    39-33-203. Agreements to procure strikebreakers prohibited, MCA  |  |
| MTS_0390-0330-0020-0040 | 200 | 10567 | https://leg.mt.gov/bills/mca/title_0390/chapter_0330/part_0020/section_0040/0390-0330-0020-0040.html |    39-33-204. Advertising for strikebreakers restricted, MCA  |  |
| MTS_0390-0330-0020-0050 | 200 | 10510 | https://leg.mt.gov/bills/mca/title_0390/chapter_0330/part_0020/section_0050/0390-0330-0020-0050.html |    39-33-205. Penalties, MCA  |  |
| MTS_0390-0340-0010-0010 | 200 | 10685 | https://leg.mt.gov/bills/mca/title_0390/chapter_0340/part_0010/section_0010/0390-0340-0010-0010.html |    39-34-101. Arbitration between firefighters and public employers, MCA  |  |
| MTS_0390-0340-0010-0020 | 200 | 10541 | https://leg.mt.gov/bills/mca/title_0390/chapter_0340/part_0010/section_0020/0390-0340-0010-0020.html |    39-34-102. Designation of arbitrator, MCA  |  |
| MTS_0390-0340-0010-0030 | 200 | 12339 | https://leg.mt.gov/bills/mca/title_0390/chapter_0340/part_0010/section_0030/0390-0340-0010-0030.html |    39-34-103. Powers and duties of arbitrator for firefighters and public employ |  |
| MTS_0390-0340-0010-0040 | 200 | 10283 | https://leg.mt.gov/bills/mca/title_0390/chapter_0340/part_0010/section_0040/0390-0340-0010-0040.html |    39-34-104. Collective bargaining permitted during arbitration, MCA  |  |
| MTS_0390-0340-0010-0050 | 200 | 10069 | https://leg.mt.gov/bills/mca/title_0390/chapter_0340/part_0010/section_0050/0390-0340-0010-0050.html |    39-34-105. Strikes limited, MCA  |  |
| MTS_0390-0340-0010-0060 | 200 | 9872 | https://leg.mt.gov/bills/mca/title_0390/chapter_0340/part_0010/section_0060/0390-0340-0010-0060.html |    39-34-106. Cost of arbitration, MCA  |  |
| MTS_0390-0510-0010-0010 | 200 | 9830 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0010/section_0010/0390-0510-0010-0010.html |    39-51-101. Short title, MCA  |  |
| MTS_0390-0510-0010-0020 | 200 | 11663 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0010/section_0020/0390-0510-0010-0020.html |    39-51-102. Declaration of state public policy, MCA  |  |
| MTS_0390-0510-0010-0030 | 200 | 11410 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0010/section_0030/0390-0510-0010-0030.html |    39-51-103. Nonliability of state -- right to benefits subject to provisions o |  |
| MTS_0390-0510-0010-0040 | 200 | 10610 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0010/section_0040/0390-0510-0010-0040.html |    39-51-104. Chapter to become inoperative if federal act becomes inoperative,  |  |
| MTS_0390-0510-0010-0050 | 200 | 10968 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0010/section_0050/0390-0510-0010-0050.html |    39-51-105. Disbursement of funds if federal act becomes inoperative, MCA  |  |
| MTS_0390-0510-0010-0060 | 200 | 10399 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0010/section_0060/0390-0510-0010-0060.html |    39-51-106. Approval by secretary of labor required for chapter to have effect |  |
| MTS_0390-0510-0010-0070 | 200 | 9818 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0010/section_0070/0390-0510-0010-0070.html |    39-51-107. through 39-51-109 reserved, MCA  |  |
| MTS_0390-0510-0010-0100 | 200 | 10127 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0010/section_0100/0390-0510-0010-0100.html |    39-51-110. Collateral estoppel, MCA  |  |
| MTS_0390-0510-0020-0010 | 200 | 30963 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0020/section_0010/0390-0510-0020-0010.html |    39-51-201. General definitions, MCA  |  |
| MTS_0390-0510-0020-0020 | 200 | 13373 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0020/section_0020/0390-0510-0020-0020.html |    39-51-202. Employer defined, MCA  |  |
| MTS_0390-0510-0020-0030 | 200 | 17115 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0020/section_0030/0390-0510-0020-0030.html |    39-51-203. Employment defined, MCA  |  |
| MTS_0390-0510-0020-0040 | 200 | 27352 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0020/section_0040/0390-0510-0020-0040.html |    39-51-204. Exclusions from definition of employment, MCA  |  |
| MTS_0390-0510-0020-0050 | 200 | 13623 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0020/section_0050/0390-0510-0020-0050.html |    39-51-205. Agricultural labor defined, MCA  |  |
| MTS_0390-0510-0020-0060 | 200 | 13486 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0020/section_0060/0390-0510-0020-0060.html |    39-51-206. Agricultural labor -- who treated as employer of member of crew fu |  |
| MTS_0390-0510-0020-0070 | 200 | 10563 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0020/section_0070/0390-0510-0020-0070.html |    39-51-207. Treatment of limited liability companies, MCA  |  |
| MTS_0390-0510-0030-0010 | 200 | 14003 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0030/section_0010/0390-0510-0030-0010.html |    39-51-301. Administration -- duties and powers of department -- duties and po |  |
| MTS_0390-0510-0030-0020 | 200 | 10376 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0030/section_0020/0390-0510-0030-0020.html |    39-51-302. Administrative rules, MCA  |  |
| MTS_0390-0510-0030-0030 | 200 | 10533 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0030/section_0030/0390-0510-0030-0030.html |    39-51-303. Publication and distribution of materials, MCA  |  |
| MTS_0390-0510-0030-0040 | 200 | 10957 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0030/section_0040/0390-0510-0030-0040.html |    39-51-304. Personnel -- criminal record background check, MCA  |  |
| MTS_0390-0510-0030-0050 | 200 | 10845 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0030/section_0050/0390-0510-0030-0050.html |    39-51-305. Department to appoint appeals referees, MCA  |  |
| MTS_0390-0510-0030-0060 | 200 | 10129 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0030/section_0060/0390-0510-0030-0060.html |    39-51-306. Repealed, MCA  |  |
| MTS_0390-0510-0030-0070 | 200 | 12004 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0030/section_0070/0390-0510-0030-0070.html |    39-51-307. Department to create employment service, MCA  |  |
| MTS_0390-0510-0030-0080 | 200 | 11473 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0030/section_0080/0390-0510-0030-0080.html |    39-51-308. Acquisition and disposition of property by department, MCA  |  |
| MTS_0390-0510-0030-0090 | 200 | 11018 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0030/section_0090/0390-0510-0030-0090.html |    39-51-309. Representation of department and state in court, MCA  |  |
| MTS_0390-0510-0030-0100 | 200 | 10067 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0030/section_0100/0390-0510-0030-0100.html |    39-51-310. Function of board, MCA  |  |
| MTS_0390-0510-0040-0010 | 200 | 12111 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0040/section_0010/0390-0510-0040-0010.html |    39-51-401. Unemployment insurance fund -- establishment and control, MCA  |  |
| MTS_0390-0510-0040-0020 | 200 | 12444 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0040/section_0020/0390-0510-0040-0020.html |    39-51-402. Unemployment insurance fund -- custodian -- accounts and deposits, |  |
| MTS_0390-0510-0040-0030 | 200 | 13117 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0040/section_0030/0390-0510-0040-0030.html |    39-51-403. Money to be requisitioned from unemployment trust fund solely for  |  |
| MTS_0390-0510-0040-0040 | 200 | 15142 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0040/section_0040/0390-0510-0040-0040.html |    39-51-404. Special administrative funds, MCA  |  |
| MTS_0390-0510-0040-0050 | 200 | 10159 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0040/section_0050/0390-0510-0040-0050.html |    39-51-405. Repealed, MCA  |  |
| MTS_0390-0510-0040-0060 | 200 | 13558 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0040/section_0060/0390-0510-0040-0060.html |    39-51-406. Unemployment insurance administration account, MCA  |  |
| MTS_0390-0510-0040-0070 | 200 | 10818 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0040/section_0070/0390-0510-0040-0070.html |    39-51-407. Reimbursement of fund by state, MCA  |  |
| MTS_0390-0510-0040-0080 | 200 | 11935 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0040/section_0080/0390-0510-0040-0080.html |    39-51-408. Advances from federal unemployment trust fund, MCA  |  |
| MTS_0390-0510-0040-0090 | 200 | 13617 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0040/section_0090/0390-0510-0040-0090.html |    39-51-409. Employment security account, MCA  |  |
| MTS_0390-0510-0050-0010 | 200 | 12231 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0050/section_0010/0390-0510-0050-0010.html |    39-51-501. State-federal cooperation, MCA  |  |
| MTS_0390-0510-0050-0020 | 200 | 11320 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0050/section_0020/0390-0510-0050-0020.html |    39-51-502. Cooperation with other agencies, MCA  |  |
| MTS_0390-0510-0050-0030 | 200 | 11119 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0050/section_0030/0390-0510-0050-0030.html |    39-51-503. Agreements with railroad retirement board, MCA  |  |
| MTS_0390-0510-0050-0040 | 200 | 13488 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0050/section_0040/0390-0510-0050-0040.html |    39-51-504. Reciprocal benefit arrangements, MCA  |  |
| MTS_0390-0510-0050-0050 | 200 | 10377 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0050/section_0050/0390-0510-0050-0050.html |    39-51-505. Access to governmental records, MCA  |  |
| MTS_0390-0510-0060-0010 | 200 | 10547 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0060/section_0010/0390-0510-0060-0010.html |    39-51-601. Department to maintain wage record, MCA  |  |
| MTS_0390-0510-0060-0020 | 200 | 11031 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0060/section_0020/0390-0510-0060-0020.html |    39-51-602. Method to be used by department in keeping wage records, MCA  |  |
| MTS_0390-0510-0060-0030 | 200 | 13322 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0060/section_0030/0390-0510-0060-0030.html |    39-51-603. Employing unit to keep records and make reports -- confidentiality |  |
| MTS_0390-0510-0060-0040 | 200 | 10147 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0060/section_0040/0390-0510-0060-0040.html |    39-51-604. Repealed, MCA  |  |
| MTS_0390-0510-0060-0050 | 200 | 12885 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0060/section_0050/0390-0510-0060-0050.html |    39-51-605. Employing unit responsibility to respond to department requests fo |  |
| MTS_0390-0510-0070-0010 | 200 | 9708 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0070/section_0010/0390-0510-0070-0010.html |    39-51-701. Short title, MCA  |  |
| MTS_0390-0510-0070-0020 | 200 | 9953 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0070/section_0020/0390-0510-0070-0020.html |    39-51-702. Purpose, MCA  |  |
| MTS_0390-0510-0070-0030 | 200 | 9899 | https://leg.mt.gov/bills/mca/title_0390/chapter_0510/part_0070/section_0030/0390-0510-0070-0030.html |    39-51-703. Repealed, MCA  |  |
