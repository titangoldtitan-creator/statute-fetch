| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| RIS_19_19-35_19-35-6 | 200 | 4888 | https://webserver.rilegislature.gov/Statutes/TITLE19/19-35/19-35-6.htm |  |  |
| RIS_19_19-35_19-35-7 | 200 | 6394 | https://webserver.rilegislature.gov/Statutes/TITLE19/19-35/19-35-7.htm |  |  |
| RIS_19_19-35_19-35-8 | 200 | 4360 | https://webserver.rilegislature.gov/Statutes/TITLE19/19-35/19-35-8.htm |  |  |
| RIS_19_19-35_19-35-9 | 200 | 5374 | https://webserver.rilegislature.gov/Statutes/TITLE19/19-35/19-35-9.htm |  |  |
| RIS_19_19-35_19-35-10 | 200 | 4171 | https://webserver.rilegislature.gov/Statutes/TITLE19/19-35/19-35-10.htm |  |  |
| RIS_19_19-35_19-35-11 | 200 | 5330 | https://webserver.rilegislature.gov/Statutes/TITLE19/19-35/19-35-11.htm |  |  |
| RIS_19_19-35_19-35-12 | 200 | 5878 | https://webserver.rilegislature.gov/Statutes/TITLE19/19-35/19-35-12.htm |  |  |
| RIS_19_19-35_19-35-13 | 200 | 4708 | https://webserver.rilegislature.gov/Statutes/TITLE19/19-35/19-35-13.htm |  |  |
| RIS_19_19-35_19-35-14 | 200 | 4275 | https://webserver.rilegislature.gov/Statutes/TITLE19/19-35/19-35-14.htm |  |  |
| RIS_19_19-35_19-35-15 | 200 | 4063 | https://webserver.rilegislature.gov/Statutes/TITLE19/19-35/19-35-15.htm |  |  |
| RIS_19_19-35_19-35-16 | 200 | 4642 | https://webserver.rilegislature.gov/Statutes/TITLE19/19-35/19-35-16.htm |  |  |
| RIS_19_19-35_19-35-17 | 200 | 4147 | https://webserver.rilegislature.gov/Statutes/TITLE19/19-35/19-35-17.htm |  |  |
| RIS_2_2-2_2-2-1 | 200 | 4100 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-2/2-2-1.htm |  |  |
| RIS_2_2-2_2-2-2 | 200 | 4301 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-2/2-2-2.htm |  |  |
| RIS_2_2-3_2-3-1 | 200 | 5652 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-3/2-3-1.htm |  |  |
| RIS_2_2-3_2-3-2 | 200 | 4287 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-3/2-3-2.htm |  |  |
| RIS_2_2-3_2-3-3 | 200 | 4280 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-3/2-3-3.htm |  |  |
| RIS_2_2-3_2-3-4 | 200 | 4874 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-3/2-3-4.htm |  |  |
| RIS_2_2-3_2-3-5 | 200 | 4101 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-3/2-3-5.htm |  |  |
| RIS_2_2-3_2-3-6 | 200 | 5566 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-3/2-3-6.htm |  |  |
| RIS_2_2-3_2-3-7 | 200 | 4416 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-3/2-3-7.htm |  |  |
| RIS_2_2-3_2-3-8 | 200 | 5229 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-3/2-3-8.htm |  |  |
| RIS_2_2-3_2-3-9 | 200 | 4439 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-3/2-3-9.htm |  |  |
| RIS_2_2-3_2-3-10 | 200 | 5263 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-3/2-3-10.htm |  |  |
| RIS_2_2-3_2-3-11 | 200 | 4028 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-3/2-3-11.htm |  |  |
| RIS_2_2-4_2-4-1 | 200 | 5583 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-1.htm |  |  |
| RIS_2_2-4_2-4-2 | 200 | 6252 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-2.htm |  |  |
| RIS_2_2-4_2-4-3 | 200 | 7304 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-3.htm |  |  |
| RIS_2_2-4_2-4-3.1 | 200 | 9493 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-3.1.htm |  |  |
| RIS_2_2-4_2-4-4 | 200 | 5017 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-4.htm |  |  |
| RIS_2_2-4_2-4-5 | 200 | 5342 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-5.htm |  |  |
| RIS_2_2-4_2-4-6 | 200 | 15033 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-6.htm |  |  |
| RIS_2_2-4_2-4-7 | 200 | 4588 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-7.htm |  |  |
| RIS_2_2-4_2-4-8 | 200 | 6524 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-8.htm |  |  |
| RIS_2_2-4_2-4-9 | 200 | 7046 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-9.htm |  |  |
| RIS_2_2-4_2-4-10 | 200 | 3823 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-10.htm |  | render-thin 232 |
| RIS_2_2-4_2-4-11 | 200 | 4912 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-11.htm |  |  |
| RIS_2_2-4_2-4-12 | 200 | 12665 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-12.htm |  |  |
| RIS_2_2-4_2-4-13 | 200 | 4512 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-13.htm |  |  |
| RIS_2_2-4_2-4-14 | 200 | 4106 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-14.htm |  |  |
| RIS_2_2-4_2-4-15 | 200 | 4847 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-15.htm |  |  |
| RIS_2_2-4_2-4-16 | 200 | 4317 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-16.htm |  |  |
| RIS_2_2-4_2-4-17 | 200 | 3823 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-17.htm |  | render-thin 232 |
| RIS_2_2-4_2-4-18 | 200 | 4253 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-18.htm |  |  |
| RIS_2_2-4_2-4-19 | 200 | 4097 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-19.htm |  |  |
| RIS_2_2-4_2-4-20 | 200 | 3822 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-4/2-4-20.htm |  | render-thin 231 |
| RIS_2_2-5_2-5-1 | 200 | 4543 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-5/2-5-1.htm |  |  |
| RIS_2_2-5_2-5-2 | 200 | 4466 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-5/2-5-2.htm |  |  |
| RIS_2_2-5_2-5-3 | 200 | 5386 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-5/2-5-3.htm |  |  |
| RIS_2_2-5_2-5-4 | 200 | 4747 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-5/2-5-4.htm |  |  |
| RIS_2_2-5_2-5-5 | 200 | 5175 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-5/2-5-5.htm |  |  |
| RIS_2_2-5_2-5-6 | 200 | 4034 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-5/2-5-6.htm |  |  |
| RIS_2_2-5_2-5-7 | 200 | 4333 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-5/2-5-7.htm |  |  |
| RIS_2_2-6_2-6-1 | 200 | 3842 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-6/2-6-1.htm |  | render-thin 224 |
| RIS_2_2-6_2-6-2 | 200 | 10240 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-6/2-6-2.htm |  |  |
| RIS_2_2-6_2-6-3 | 200 | 13486 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-6/2-6-3.htm |  |  |
| RIS_2_2-6_2-6-4 | 200 | 8585 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-6/2-6-4.htm |  |  |
| RIS_2_2-6_2-6-5 | 200 | 4322 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-6/2-6-5.htm |  |  |
| RIS_2_2-6_2-6-6 | 200 | 5494 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-6/2-6-6.htm |  |  |
| RIS_2_2-6_2-6-7 | 200 | 9719 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-6/2-6-7.htm |  |  |
| RIS_2_2-6_2-6-8 | 200 | 4603 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-6/2-6-8.htm |  |  |
| RIS_2_2-6_2-6-9 | 200 | 4127 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-6/2-6-9.htm |  |  |
| RIS_2_2-6_2-6-10 | 200 | 5398 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-6/2-6-10.htm |  |  |
| RIS_2_2-6_2-6-11 | 200 | 3626 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-6/2-6-11.htm |  | render-thin 117 |
| RIS_2_2-7_2-7-1 | 200 | 3843 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-1.htm |  | render-thin 225 |
| RIS_2_2-7_2-7-2 | 200 | 3939 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-2.htm |  | render-thin 299 |
| RIS_2_2-7_2-7-3 | 200 | 13580 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-3.htm |  |  |
| RIS_2_2-7_2-7-4 | 200 | 6828 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-4.htm |  |  |
| RIS_2_2-7_2-7-5 | 200 | 4615 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-5.htm |  |  |
| RIS_2_2-7_2-7-6 | 200 | 7651 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-6.htm |  |  |
| RIS_2_2-7_2-7-7 | 200 | 5627 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-7.htm |  |  |
| RIS_2_2-7_2-7-8 | 200 | 6085 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-8.htm |  |  |
| RIS_2_2-7_2-7-9 | 200 | 4312 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-9.htm |  |  |
| RIS_2_2-7_2-7-10 | 200 | 4955 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-10.htm |  |  |
| RIS_2_2-7_2-7-11 | 200 | 4627 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-11.htm |  |  |
| RIS_2_2-7_2-7-12 | 200 | 4074 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-12.htm |  |  |
| RIS_2_2-7_2-7-13 | 200 | 4153 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-13.htm |  |  |
| RIS_2_2-7_2-7-14 | 200 | 4131 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-14.htm |  |  |
| RIS_2_2-7_2-7-15 | 200 | 4425 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-15.htm |  |  |
| RIS_2_2-7_2-7-16 | 200 | 4636 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-16.htm |  |  |
| RIS_2_2-7_2-7-17 | 200 | 4748 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-17.htm |  |  |
| RIS_2_2-7_2-7-18 | 200 | 6046 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-18.htm |  |  |
| RIS_2_2-7_2-7-19 | 200 | 4245 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-19.htm |  |  |
| RIS_2_2-7_2-7-20 | 200 | 4217 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-20.htm |  |  |
| RIS_2_2-7_2-7-21 | 200 | 3626 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-7/2-7-21.htm |  | render-thin 117 |
| RIS_2_2-8_2-8-1 | 200 | 3631 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-8/2-8-1.htm |  | render-thin 122 |
| RIS_2_2-9_2-9-1 | 200 | 3661 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-9/2-9-1.htm |  | render-thin 154 |
| RIS_2_2-9_2-9-3 | 200 | 4373 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-9/2-9-3.htm |  |  |
| RIS_2_2-9_2-9-4 | 200 | 4658 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-9/2-9-4.htm |  |  |
| RIS_2_2-9_2-9-5 | 200 | 4596 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-9/2-9-5.htm |  |  |
| RIS_2_2-9_2-9-6 | 200 | 4432 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-9/2-9-6.htm |  |  |
| RIS_2_2-9_2-9-7 | 200 | 3661 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-9/2-9-7.htm |  | render-thin 154 |
| RIS_2_2-10_2-10-1 | 200 | 4682 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-1.htm |  |  |
| RIS_2_2-10_2-10-2 | 200 | 4264 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-2.htm |  |  |
| RIS_2_2-10_2-10-3 | 200 | 5121 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-3.htm |  |  |
| RIS_2_2-10_2-10-3.1 | 200 | 4379 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-3.1.htm |  |  |
| RIS_2_2-10_2-10-4 | 200 | 7861 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-4.htm |  |  |
| RIS_2_2-10_2-10-5 | 200 | 5854 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-5.htm |  |  |
| RIS_2_2-10_2-10-6 | 200 | 4335 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-6.htm |  |  |
| RIS_2_2-10_2-10-7 | 200 | 3843 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-7.htm |  | render-thin 251 |
| RIS_2_2-10_2-10-8 | 200 | 4349 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-8.htm |  |  |
| RIS_2_2-10_2-10-9 | 200 | 4250 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-9.htm |  |  |
| RIS_2_2-10_2-10-10 | 200 | 3634 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-10.htm |  | render-thin 127 |
| RIS_2_2-10_2-10-11 | 200 | 4446 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-11.htm |  |  |
| RIS_2_2-10_2-10-12 | 200 | 4716 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-12.htm |  |  |
| RIS_2_2-10_2-10-13 | 200 | 4741 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-10/2-10-13.htm |  |  |
| RIS_2_2-11_2-11-1 | 200 | 5896 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-11/2-11-1.htm |  |  |
| RIS_2_2-11_2-11-2 | 200 | 6367 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-11/2-11-2.htm |  |  |
| RIS_2_2-11_2-11-3 | 200 | 5094 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-11/2-11-3.htm |  |  |
| RIS_2_2-11_2-11-4 | 200 | 4245 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-11/2-11-4.htm |  |  |
| RIS_2_2-11_2-11-5 | 200 | 4529 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-11/2-11-5.htm |  |  |
| RIS_2_2-11_2-11-6 | 200 | 5089 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-11/2-11-6.htm |  |  |
| RIS_2_2-11_2-11-7 | 200 | 4394 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-11/2-11-7.htm |  |  |
| RIS_2_2-11_2-11-8 | 200 | 4003 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-11/2-11-8.htm |  |  |
| RIS_2_2-11_2-11-9 | 200 | 4155 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-11/2-11-9.htm |  |  |
| RIS_2_2-11_2-11-10 | 200 | 3941 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-11/2-11-10.htm |  |  |
| RIS_2_2-11_2-11-11 | 200 | 4325 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-11/2-11-11.htm |  |  |
| RIS_2_2-12_2-12-1 | 200 | 5900 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-1.htm |  |  |
| RIS_2_2-12_2-12-2 | 200 | 4545 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-2.htm |  |  |
| RIS_2_2-12_2-12-3 | 200 | 6526 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-3.htm |  |  |
| RIS_2_2-12_2-12-4 | 200 | 4575 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-4.htm |  |  |
| RIS_2_2-12_2-12-5 | 200 | 4115 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-5.htm |  |  |
| RIS_2_2-12_2-12-6 | 200 | 5132 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-6.htm |  |  |
| RIS_2_2-12_2-12-7 | 200 | 6082 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-7.htm |  |  |
| RIS_2_2-12_2-12-8 | 200 | 4134 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-8.htm |  |  |
| RIS_2_2-12_2-12-9 | 200 | 5981 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-9.htm |  |  |
| RIS_2_2-12_2-12-10 | 200 | 5748 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-10.htm |  |  |
| RIS_2_2-12_2-12-11 | 200 | 5009 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-11.htm |  |  |
| RIS_2_2-12_2-12-12 | 200 | 4063 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-12.htm |  |  |
| RIS_2_2-12_2-12-13 | 200 | 5424 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-13.htm |  |  |
| RIS_2_2-12_2-12-14 | 200 | 4392 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-14.htm |  |  |
| RIS_2_2-12_2-12-15 | 200 | 5536 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-15.htm |  |  |
| RIS_2_2-12_2-12-16 | 200 | 4707 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-16.htm |  |  |
| RIS_2_2-12_2-12-17 | 200 | 4147 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-17.htm |  |  |
| RIS_2_2-12_2-12-18 | 200 | 4196 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-18.htm |  |  |
| RIS_2_2-12_2-12-19 | 200 | 4561 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-19.htm |  |  |
| RIS_2_2-12_2-12-20 | 200 | 4385 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-20.htm |  |  |
| RIS_2_2-12_2-12-21 | 200 | 5433 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-12/2-12-21.htm |  |  |
| RIS_2_2-13_2-13-1 | 200 | 22796 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-13/2-13-1.htm |  |  |
| RIS_2_2-13_2-13-2 | 200 | 4338 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-13/2-13-2.htm |  |  |
| RIS_2_2-13_2-13-3 | 200 | 4369 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-13/2-13-3.htm |  |  |
| RIS_2_2-13_2-13-4 | 200 | 4584 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-13/2-13-4.htm |  |  |
| RIS_2_2-13_2-13-5 | 200 | 4360 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-13/2-13-5.htm |  |  |
| RIS_2_2-13_2-13-6 | 200 | 4721 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-13/2-13-6.htm |  |  |
| RIS_2_2-13_2-13-7 | 200 | 4381 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-13/2-13-7.htm |  |  |
| RIS_2_2-13_2-13-8 | 200 | 4205 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-13/2-13-8.htm |  |  |
| RIS_2_2-13_2-13-9 | 200 | 4594 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-13/2-13-9.htm |  |  |
| RIS_2_2-13_2-13-10 | 200 | 4305 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-13/2-13-10.htm |  |  |
| RIS_2_2-14_2-14-1 | 200 | 4002 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-14/2-14-1.htm |  |  |
| RIS_2_2-14_2-14-2 | 200 | 4703 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-14/2-14-2.htm |  |  |
| RIS_2_2-14_2-14-3 | 200 | 4980 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-14/2-14-3.htm |  |  |
| RIS_2_2-14_2-14-4 | 200 | 4165 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-14/2-14-4.htm |  |  |
| RIS_2_2-14_2-14-5 | 200 | 5674 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-14/2-14-5.htm |  |  |
| RIS_2_2-14_2-14-6 | 200 | 4464 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-14/2-14-6.htm |  |  |
| RIS_2_2-14_2-14-7 | 200 | 4375 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-14/2-14-7.htm |  |  |
| RIS_2_2-14_2-14-8 | 200 | 5598 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-14/2-14-8.htm |  |  |
| RIS_2_2-14_2-14-9 | 200 | 4262 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-14/2-14-9.htm |  |  |
| RIS_2_2-14_2-14-10 | 200 | 4487 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-14/2-14-10.htm |  |  |
| RIS_2_2-14_2-14-11 | 200 | 4447 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-14/2-14-11.htm |  |  |
| RIS_2_2-14_2-14-12 | 200 | 4042 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-14/2-14-12.htm |  |  |
| RIS_2_2-15_2-15-1 | 200 | 5076 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-1.htm |  |  |
| RIS_2_2-15_2-15-2 | 200 | 5496 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-2.htm |  |  |
| RIS_2_2-15_2-15-3 | 200 | 4453 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-3.htm |  |  |
| RIS_2_2-15_2-15-4 | 200 | 4501 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-4.htm |  |  |
| RIS_2_2-15_2-15-5 | 200 | 4663 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-5.htm |  |  |
| RIS_2_2-15_2-15-5.1 | 200 | 4854 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-5.1.htm |  |  |
| RIS_2_2-15_2-15-6 | 200 | 5141 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-6.htm |  |  |
| RIS_2_2-15_2-15-7 | 200 | 6200 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-7.htm |  |  |
| RIS_2_2-15_2-15-8 | 200 | 7221 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-8.htm |  |  |
| RIS_2_2-15_2-15-9 | 200 | 4520 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-9.htm |  |  |
| RIS_2_2-15_2-15-10 | 200 | 4437 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-10.htm |  |  |
| RIS_2_2-15_2-15-11 | 200 | 4695 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-11.htm |  |  |
| RIS_2_2-15_2-15-12 | 200 | 4743 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-12.htm |  |  |
| RIS_2_2-15_2-15-13 | 200 | 4467 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-13.htm |  |  |
| RIS_2_2-15_2-15-14 | 200 | 4308 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-14.htm |  |  |
| RIS_2_2-15_2-15-15 | 200 | 4106 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-15.htm |  |  |
| RIS_2_2-15_2-15-16 | 200 | 4058 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-16.htm |  |  |
| RIS_2_2-15_2-15-17 | 200 | 4047 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-15/2-15-17.htm |  |  |
| RIS_2_2-16_2-16-1 | 200 | 3914 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-1.htm |  | render-thin 273 |
| RIS_2_2-16_2-16-2 | 200 | 6213 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-2.htm |  |  |
| RIS_2_2-16_2-16-3 | 200 | 9360 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-3.htm |  |  |
| RIS_2_2-16_2-16-4 | 200 | 4368 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-4.htm |  |  |
| RIS_2_2-16_2-16-5 | 200 | 3975 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-5.htm |  |  |
| RIS_2_2-16_2-16-6 | 200 | 5548 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-6.htm |  |  |
| RIS_2_2-16_2-16-7 | 200 | 4451 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-7.htm |  |  |
| RIS_2_2-16_2-16-8 | 200 | 4618 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-8.htm |  |  |
| RIS_2_2-16_2-16-9 | 200 | 4415 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-9.htm |  |  |
| RIS_2_2-16_2-16-10 | 200 | 4791 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-10.htm |  |  |
| RIS_2_2-16_2-16-11 | 200 | 4179 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-11.htm |  |  |
| RIS_2_2-16_2-16-12 | 200 | 4107 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-12.htm |  |  |
| RIS_2_2-16_2-16-13 | 200 | 4041 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16/2-16-13.htm |  |  |
| RIS_2_2-16.1_2-16.1-1 | 200 | 3885 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16.1/2-16.1-1.htm |  | render-thin 266 |
| RIS_2_2-16.1_2-16.1-2 | 200 | 34999 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16.1/2-16.1-2.htm |  |  |
| RIS_2_2-16.1_2-16.1-3 | 200 | 4036 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16.1/2-16.1-3.htm |  |  |
| RIS_2_2-16.1_2-16.1-4 | 200 | 3982 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16.1/2-16.1-4.htm |  |  |
| RIS_2_2-16.1_2-16.1-5 | 200 | 4066 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16.1/2-16.1-5.htm |  |  |
| RIS_2_2-16.1_2-16.1-6 | 200 | 4262 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16.1/2-16.1-6.htm |  |  |
| RIS_2_2-16.1_2-16.1-7 | 200 | 4260 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16.1/2-16.1-7.htm |  |  |
| RIS_2_2-16.1_2-16.1-8 | 200 | 3965 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-16.1/2-16.1-8.htm |  |  |
| RIS_2_2-18_2-18-1 | 200 | 3637 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18/2-18-1.htm |  | render-thin 128 |
| RIS_2_2-18_2-18-9 | 200 | 5412 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18/2-18-9.htm |  |  |
| RIS_2_2-18_2-18-10 | 200 | 4216 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18/2-18-10.htm |  |  |
| RIS_2_2-18_2-18-11 | 200 | 4338 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18/2-18-11.htm |  |  |
| RIS_2_2-18_2-18-12 | 200 | 4283 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18/2-18-12.htm |  |  |
| RIS_2_2-18_2-18-13 | 200 | 4479 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18/2-18-13.htm |  |  |
| RIS_2_2-18_2-18-14 | 200 | 3640 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18/2-18-14.htm |  | render-thin 131 |
| RIS_2_2-18.1_2-18.1-1 | 200 | 3903 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-1.htm |  | render-thin 284 |
| RIS_2_2-18.1_2-18.1-2 | 200 | 11035 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-2.htm |  |  |
| RIS_2_2-18.1_2-18.1-3 | 200 | 4642 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-3.htm |  |  |
| RIS_2_2-18.1_2-18.1-4 | 200 | 4480 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-4.htm |  |  |
| RIS_2_2-18.1_2-18.1-5 | 200 | 4212 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-5.htm |  |  |
| RIS_2_2-18.1_2-18.1-6 | 200 | 5389 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-6.htm |  |  |
| RIS_2_2-18.1_2-18.1-7 | 200 | 4446 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-7.htm |  |  |
| RIS_2_2-18.1_2-18.1-8 | 200 | 4289 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-8.htm |  |  |
| RIS_2_2-18.1_2-18.1-9 | 200 | 5450 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-9.htm |  |  |
| RIS_2_2-18.1_2-18.1-10 | 200 | 4869 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-10.htm |  |  |
| RIS_2_2-18.1_2-18.1-11 | 200 | 5084 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-11.htm |  |  |
| RIS_2_2-18.1_2-18.1-12 | 200 | 4217 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-12.htm |  |  |
| RIS_2_2-18.1_2-18.1-13 | 200 | 3992 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-13.htm |  |  |
| RIS_2_2-18.1_2-18.1-14 | 200 | 5480 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-14.htm |  |  |
| RIS_2_2-18.1_2-18.1-15 | 200 | 4904 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-15.htm |  |  |
| RIS_2_2-18.1_2-18.1-16 | 200 | 4549 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-16.htm |  |  |
| RIS_2_2-18.1_2-18.1-17 | 200 | 4268 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-17.htm |  |  |
| RIS_2_2-18.1_2-18.1-18 | 200 | 5034 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-18.htm |  |  |
| RIS_2_2-18.1_2-18.1-19 | 200 | 5050 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-19.htm |  |  |
| RIS_2_2-18.1_2-18.1-20 | 200 | 4482 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-20.htm |  |  |
| RIS_2_2-18.1_2-18.1-21 | 200 | 4188 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-21.htm |  |  |
| RIS_2_2-18.1_2-18.1-22 | 200 | 4193 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-22.htm |  |  |
| RIS_2_2-18.1_2-18.1-23 | 200 | 4136 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-23.htm |  |  |
| RIS_2_2-18.1_2-18.1-24 | 200 | 4584 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-24.htm |  |  |
| RIS_2_2-18.1_2-18.1-24.1 | 200 | 5043 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-24.1.htm |  |  |
| RIS_2_2-18.1_2-18.1-25 | 200 | 4362 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-25.htm |  |  |
| RIS_2_2-18.1_2-18.1-26 | 200 | 5270 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-26.htm |  |  |
| RIS_2_2-18.1_2-18.1-27 | 200 | 4369 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-27.htm |  |  |
| RIS_2_2-18.1_2-18.1-28 | 200 | 4062 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-18.1/2-18.1-28.htm |  |  |
| RIS_2_2-19_2-19-1 | 200 | 4550 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-19/2-19-1.htm |  |  |
| RIS_2_2-19_2-19-2 | 200 | 4522 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-19/2-19-2.htm |  |  |
| RIS_2_2-19_2-19-3 | 200 | 4753 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-19/2-19-3.htm |  |  |
| RIS_2_2-19_2-19-4 | 200 | 4239 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-19/2-19-4.htm |  |  |
| RIS_2_2-19_2-19-4.1 | 200 | 5876 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-19/2-19-4.1.htm |  |  |
| RIS_2_2-19_2-19-4.2 | 200 | 5543 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-19/2-19-4.2.htm |  |  |
| RIS_2_2-19_2-19-5 | 200 | 4154 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-19/2-19-5.htm |  |  |
| RIS_2_2-20_2-20-1 | 200 | 4488 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-1.htm |  |  |
| RIS_2_2-20_2-20-2 | 200 | 4278 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-2.htm |  |  |
| RIS_2_2-20_2-20-3 | 200 | 4299 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-3.htm |  |  |
| RIS_2_2-20_2-20-4 | 200 | 4161 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-4.htm |  |  |
| RIS_2_2-20_2-20-5 | 200 | 4172 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-5.htm |  |  |
| RIS_2_2-20_2-20-6 | 200 | 4251 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-6.htm |  |  |
| RIS_2_2-20_2-20-7 | 200 | 4444 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-7.htm |  |  |
| RIS_2_2-20_2-20-8 | 200 | 4348 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-8.htm |  |  |
| RIS_2_2-20_2-20-9 | 200 | 4172 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-9.htm |  |  |
| RIS_2_2-20_2-20-10 | 200 | 4218 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-10.htm |  |  |
| RIS_2_2-20_2-20-11 | 200 | 4176 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-11.htm |  |  |
| RIS_2_2-20_2-20-12 | 200 | 4134 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-12.htm |  |  |
| RIS_2_2-20_2-20-13 | 200 | 4056 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-13.htm |  |  |
| RIS_2_2-20_2-20-14 | 200 | 4955 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-14.htm |  |  |
| RIS_2_2-20_2-20-15 | 200 | 5559 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-15.htm |  |  |
| RIS_2_2-20_2-20-16 | 200 | 4397 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-16.htm |  |  |
| RIS_2_2-20_2-20-17 | 200 | 4261 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-17.htm |  |  |
| RIS_2_2-20_2-20-18 | 200 | 4340 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-18.htm |  |  |
| RIS_2_2-20_2-20-19 | 200 | 4305 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-19.htm |  |  |
| RIS_2_2-20_2-20-20 | 200 | 4166 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-20.htm |  |  |
| RIS_2_2-20_2-20-21 | 200 | 4090 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-21.htm |  |  |
| RIS_2_2-20_2-20-22 | 200 | 4778 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-22.htm |  |  |
| RIS_2_2-20_2-20-23 | 200 | 4422 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-23.htm |  |  |
| RIS_2_2-20_2-20-24 | 200 | 4037 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-24.htm |  |  |
| RIS_2_2-20_2-20-25 | 200 | 4618 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-25.htm |  |  |
| RIS_2_2-20_2-20-26 | 200 | 4355 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-26.htm |  |  |
| RIS_2_2-20_2-20-27 | 200 | 4091 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-27.htm |  |  |
| RIS_2_2-20_2-20-28 | 200 | 4642 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-28.htm |  |  |
| RIS_2_2-20_2-20-29 | 200 | 4174 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-29.htm |  |  |
| RIS_2_2-20_2-20-30 | 200 | 4224 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-30.htm |  |  |
| RIS_2_2-20_2-20-31 | 200 | 4198 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-31.htm |  |  |
| RIS_2_2-20_2-20-32 | 200 | 4180 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-32.htm |  |  |
| RIS_2_2-20_2-20-33 | 200 | 4460 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-33.htm |  |  |
| RIS_2_2-20_2-20-34 | 200 | 4226 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-34.htm |  |  |
| RIS_2_2-20_2-20-35 | 200 | 4043 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-20/2-20-35.htm |  |  |
| RIS_2_2-21_2-21-1 | 200 | 3862 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-21/2-21-1.htm |  | render-thin 244 |
| RIS_2_2-21_2-21-2 | 200 | 3950 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-21/2-21-2.htm |  |  |
| RIS_2_2-21_2-21-3 | 200 | 6985 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-21/2-21-3.htm |  |  |
| RIS_2_2-21_2-21-4 | 200 | 8135 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-21/2-21-4.htm |  |  |
| RIS_2_2-21_2-21-5 | 200 | 4203 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-21/2-21-5.htm |  |  |
| RIS_2_2-21_2-21-6 | 200 | 5216 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-21/2-21-6.htm |  |  |
| RIS_2_2-21_2-21-7 | 200 | 5001 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-21/2-21-7.htm |  |  |
| RIS_2_2-21_2-21-8 | 200 | 5121 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-21/2-21-8.htm |  |  |
| RIS_2_2-21_2-21-9 | 200 | 4672 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-21/2-21-9.htm |  |  |
| RIS_2_2-21_2-21-10 | 200 | 4518 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-21/2-21-10.htm |  |  |
| RIS_2_2-21_2-21-11 | 200 | 4140 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-21/2-21-11.htm |  |  |
| RIS_2_2-22_2-22-1 | 200 | 3833 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-1.htm |  | render-thin 215 |
| RIS_2_2-22_2-22-2 | 200 | 3936 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-2.htm |  |  |
| RIS_2_2-22_2-22-3 | 200 | 8412 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-3.htm |  |  |
| RIS_2_2-22_2-22-4 | 200 | 7914 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-4.htm |  |  |
| RIS_2_2-22_2-22-5 | 200 | 7634 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-5.htm |  |  |
| RIS_2_2-22_2-22-6 | 200 | 5135 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-6.htm |  |  |
| RIS_2_2-22_2-22-7 | 200 | 6823 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-7.htm |  |  |
| RIS_2_2-22_2-22-8 | 200 | 5070 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-8.htm |  |  |
| RIS_2_2-22_2-22-9 | 200 | 4640 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-9.htm |  |  |
| RIS_2_2-22_2-22-10 | 200 | 5272 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-10.htm |  |  |
| RIS_2_2-22_2-22-11 | 200 | 4729 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-11.htm |  |  |
| RIS_2_2-22_2-22-12 | 200 | 4851 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-12.htm |  |  |
| RIS_2_2-22_2-22-13 | 200 | 4601 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-13.htm |  |  |
| RIS_2_2-22_2-22-14 | 200 | 4231 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-14.htm |  |  |
| RIS_2_2-22_2-22-15 | 200 | 4407 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-15.htm |  |  |
| RIS_2_2-22_2-22-16 | 200 | 4067 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-22/2-22-16.htm |  |  |
| RIS_2_2-23_2-23-1 | 200 | 3835 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23/2-23-1.htm |  | render-thin 217 |
| RIS_2_2-23_2-23-2 | 200 | 4836 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23/2-23-2.htm |  |  |
| RIS_2_2-23_2-23-3 | 200 | 4049 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23/2-23-3.htm |  |  |
| RIS_2_2-23_2-23-4 | 200 | 5672 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23/2-23-4.htm |  |  |
| RIS_2_2-23_2-23-5 | 200 | 5474 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23/2-23-5.htm |  |  |
| RIS_2_2-23_2-23-6 | 200 | 4130 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23/2-23-6.htm |  |  |
| RIS_2_2-23_2-23-7 | 200 | 4271 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23/2-23-7.htm |  |  |
| RIS_2_2-23.1_2-23.1-1 | 200 | 4811 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.1/2-23.1-1.htm |  |  |
| RIS_2_2-23.1_2-23.1-2 | 200 | 3989 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.1/2-23.1-2.htm |  |  |
| RIS_2_2-23.1_2-23.1-3 | 200 | 5222 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.1/2-23.1-3.htm |  |  |
| RIS_2_2-23.1_2-23.1-4 | 200 | 4868 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.1/2-23.1-4.htm |  |  |
| RIS_2_2-23.1_2-23.1-5 | 200 | 4515 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.1/2-23.1-5.htm |  |  |
| RIS_2_2-23.1_2-23.1-6 | 200 | 5171 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.1/2-23.1-6.htm |  |  |
| RIS_2_2-23.1_2-23.1-7 | 200 | 4085 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.1/2-23.1-7.htm |  |  |
| RIS_2_2-23.1_2-23.1-8 | 200 | 4090 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.1/2-23.1-8.htm |  |  |
| RIS_2_2-23.1_2-23.1-9 | 200 | 4240 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.1/2-23.1-9.htm |  |  |
| RIS_2_2-23.2_2-23.2-1 | 200 | 4271 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.2/2-23.2-1.htm |  |  |
| RIS_2_2-23.2_2-23.2-2 | 200 | 4576 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.2/2-23.2-2.htm |  |  |
| RIS_2_2-23.2_2-23.2-3 | 200 | 4437 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.2/2-23.2-3.htm |  |  |
| RIS_2_2-23.2_2-23.2-4 | 200 | 5402 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.2/2-23.2-4.htm |  |  |
| RIS_2_2-23.2_2-23.2-5 | 200 | 4003 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.2/2-23.2-5.htm |  |  |
| RIS_2_2-23.2_2-23.2-6 | 200 | 4319 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-23.2/2-23.2-6.htm |  |  |
| RIS_2_2-24_2-24-1 | 200 | 54396 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-24/2-24-1.htm |  |  |
| RIS_2_2-25_2-25-1 | 200 | 3956 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-25/2-25-1.htm |  |  |
| RIS_2_2-25_2-25-2 | 200 | 5820 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-25/2-25-2.htm |  |  |
| RIS_2_2-25_2-25-3 | 200 | 4912 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-25/2-25-3.htm |  |  |
| RIS_2_2-25_2-25-4 | 200 | 4466 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-25/2-25-4.htm |  |  |
| RIS_2_2-25_2-25-5 | 200 | 5203 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-25/2-25-5.htm |  |  |
| RIS_2_2-25_2-25-6 | 200 | 4787 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-25/2-25-6.htm |  |  |
| RIS_2_2-25_2-25-7 | 200 | 5699 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-25/2-25-7.htm |  |  |
| RIS_2_2-25_2-25-8 | 200 | 5245 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-25/2-25-8.htm |  |  |
| RIS_2_2-25_2-25-9 | 200 | 3965 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-25/2-25-9.htm |  |  |
| RIS_2_2-26_2-26-1 | 200 | 3911 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-26/2-26-1.htm |  | render-thin 291 |
| RIS_2_2-26_2-26-2 | 200 | 5641 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-26/2-26-2.htm |  |  |
| RIS_2_2-26_2-26-3 | 200 | 8467 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-26/2-26-3.htm |  |  |
| RIS_2_2-26_2-26-4 | 200 | 4286 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-26/2-26-4.htm |  |  |
| RIS_2_2-26_2-26-5 | 200 | 13668 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-26/2-26-5.htm |  |  |
| RIS_2_2-26_2-26-6 | 200 | 5787 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-26/2-26-6.htm |  |  |
| RIS_2_2-26_2-26-7 | 200 | 4673 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-26/2-26-7.htm |  |  |
| RIS_2_2-26_2-26-8 | 200 | 4114 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-26/2-26-8.htm |  |  |
| RIS_2_2-26_2-26-9 | 200 | 5507 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-26/2-26-9.htm |  |  |
| RIS_2_2-26_2-26-10 | 200 | 5875 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-26/2-26-10.htm |  |  |
| RIS_2_2-27_2-27-1 | 200 | 7861 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-27/2-27-1.htm |  |  |
| RIS_2_2-27_2-27-2 | 200 | 6004 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-27/2-27-2.htm |  |  |
| RIS_2_2-27_2-27-3 | 200 | 8305 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-27/2-27-3.htm |  |  |
| RIS_2_2-27_2-27-4 | 200 | 5056 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-27/2-27-4.htm |  |  |
| RIS_2_2-27_2-27-5 | 200 | 4680 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-27/2-27-5.htm |  |  |
| RIS_2_2-27_2-27-6 | 200 | 4734 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-27/2-27-6.htm |  |  |
| RIS_2_2-27_2-27-7 | 200 | 4652 | https://webserver.rilegislature.gov/Statutes/TITLE2/2-27/2-27-7.htm |  |  |
| RIS_20_20-1_20-1-1 | 200 | 4938 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-1.htm |  |  |
| RIS_20_20-1_20-1-2 | 200 | 4121 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-2.htm |  |  |
| RIS_20_20-1_20-1-3 | 200 | 8802 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-3.htm |  |  |
| RIS_20_20-1_20-1-4 | 200 | 3964 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-4.htm |  |  |
| RIS_20_20-1_20-1-5 | 200 | 4206 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-5.htm |  |  |
| RIS_20_20-1_20-1-5.1 | 200 | 4260 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-5.1.htm |  |  |
| RIS_20_20-1_20-1-6 | 200 | 4212 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-6.htm |  |  |
| RIS_20_20-1_20-1-7 | 200 | 4283 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-7.htm |  |  |
| RIS_20_20-1_20-1-8 | 200 | 10829 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-8.htm |  |  |
| RIS_20_20-1_20-1-8.1 | 200 | 5960 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-8.1.htm |  |  |
| RIS_20_20-1_20-1-9 | 200 | 4675 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-9.htm |  |  |
| RIS_20_20-1_20-1-10 | 200 | 5024 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-10.htm |  |  |
| RIS_20_20-1_20-1-11 | 200 | 3950 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-11.htm |  |  |
| RIS_20_20-1_20-1-12 | 200 | 5804 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-12.htm |  |  |
| RIS_20_20-1_20-1-12.1 | 200 | 5120 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-12.1.htm |  |  |
| RIS_20_20-1_20-1-13 | 200 | 4252 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-13.htm |  |  |
| RIS_20_20-1_20-1-14 | 200 | 4308 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-14.htm |  |  |
| RIS_20_20-1_20-1-15 | 200 | 4110 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-15.htm |  |  |
| RIS_20_20-1_20-1-16 | 200 | 5614 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-16.htm |  |  |
| RIS_20_20-1_20-1-17 | 200 | 3966 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-17.htm |  |  |
| RIS_20_20-1_20-1-18 | 200 | 4829 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-18.htm |  |  |
| RIS_20_20-1_20-1-19 | 200 | 4777 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-19.htm |  |  |
| RIS_20_20-1_20-1-20 | 200 | 4296 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-20.htm |  |  |
| RIS_20_20-1_20-1-21 | 200 | 5962 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-21.htm |  |  |
| RIS_20_20-1_20-1-22 | 200 | 4466 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-22.htm |  |  |
| RIS_20_20-1_20-1-23 | 200 | 3610 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-23.htm |  | render-thin 103 |
| RIS_20_20-1_20-1-24 | 200 | 4508 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-24.htm |  |  |
| RIS_20_20-1_20-1-25 | 200 | 4628 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-25.htm |  |  |
| RIS_20_20-1_20-1-26 | 200 | 5028 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-26.htm |  |  |
| RIS_20_20-1_20-1-27 | 200 | 4642 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-27.htm |  |  |
| RIS_20_20-1_20-1-28 | 200 | 4671 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-28.htm |  |  |
| RIS_20_20-1_20-1-29 | 200 | 6319 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-29.htm |  |  |
| RIS_20_20-1_20-1-30 | 200 | 4352 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-1/20-1-30.htm |  |  |
| RIS_20_20-2_20-2-1 | 200 | 4796 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-1.htm |  |  |
| RIS_20_20-2_20-2-1.1 | 200 | 3930 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-1.1.htm |  |  |
| RIS_20_20-2_20-2-2 | 200 | 4992 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-2.htm |  |  |
| RIS_20_20-2_20-2-2.1 | 200 | 3902 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-2.1.htm |  | render-thin 266 |
| RIS_20_20-2_20-2-3 | 200 | 5143 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-3.htm |  |  |
| RIS_20_20-2_20-2-4 | 200 | 4674 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-4.htm |  |  |
| RIS_20_20-2_20-2-4.1 | 200 | 4796 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-4.1.htm |  |  |
| RIS_20_20-2_20-2-5 | 200 | 4740 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-5.htm |  |  |
| RIS_20_20-2_20-2-6 | 200 | 4866 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-6.htm |  |  |
| RIS_20_20-2_20-2-7 | 200 | 4643 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-7.htm |  |  |
| RIS_20_20-2_20-2-7.1 | 200 | 3836 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-7.1.htm |  | render-thin 245 |
| RIS_20_20-2_20-2-8 | 200 | 4482 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-8.htm |  |  |
| RIS_20_20-2_20-2-9 | 200 | 4543 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-9.htm |  |  |
| RIS_20_20-2_20-2-10 | 200 | 3901 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-10.htm |  | render-thin 265 |
| RIS_20_20-2_20-2-11 | 200 | 4087 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-11.htm |  |  |
| RIS_20_20-2_20-2-12 | 200 | 4435 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-12.htm |  |  |
| RIS_20_20-2_20-2-13 | 200 | 4253 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-13.htm |  |  |
| RIS_20_20-2_20-2-14 | 200 | 4045 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-14.htm |  |  |
| RIS_20_20-2_20-2-15 | 200 | 4886 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-15.htm |  |  |
| RIS_20_20-2_20-2-16 | 200 | 5517 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-16.htm |  |  |
| RIS_20_20-2_20-2-16.1 | 200 | 3882 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-16.1.htm |  | render-thin 246 |
| RIS_20_20-2_20-2-17 | 200 | 4396 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-17.htm |  |  |
| RIS_20_20-2_20-2-18 | 200 | 4508 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-18.htm |  |  |
| RIS_20_20-2_20-2-18.1 | 200 | 5143 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-18.1.htm |  |  |
| RIS_20_20-2_20-2-18.2 | 200 | 4021 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-18.2.htm |  |  |
| RIS_20_20-2_20-2-18.3 | 200 | 4735 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-18.3.htm |  |  |
| RIS_20_20-2_20-2-19 | 200 | 3931 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-19.htm |  | render-thin 295 |
| RIS_20_20-2_20-2-20 | 200 | 3877 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-20.htm |  | render-thin 284 |
| RIS_20_20-2_20-2-21 | 200 | 3825 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-21.htm |  | render-thin 234 |
| RIS_20_20-2_20-2-22 | 200 | 5252 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-22.htm |  |  |
| RIS_20_20-2_20-2-23 | 200 | 3825 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-23.htm |  | render-thin 234 |
| RIS_20_20-2_20-2-24 | 200 | 4267 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-24.htm |  |  |
| RIS_20_20-2_20-2-25 | 200 | 3851 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-25.htm |  | render-thin 259 |
| RIS_20_20-2_20-2-26 | 200 | 3850 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-26.htm |  | render-thin 258 |
| RIS_20_20-2_20-2-26.1 | 200 | 3855 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-26.1.htm |  | render-thin 263 |
| RIS_20_20-2_20-2-27 | 200 | 3917 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-27.htm |  |  |
| RIS_20_20-2_20-2-27.1 | 200 | 5758 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-27.1.htm |  |  |
| RIS_20_20-2_20-2-27.2 | 200 | 3778 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-27.2.htm |  | render-thin 203 |
| RIS_20_20-2_20-2-28 | 200 | 3850 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-28.htm |  | render-thin 258 |
| RIS_20_20-2_20-2-28.1 | 200 | 3829 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-28.1.htm |  | render-thin 238 |
| RIS_20_20-2_20-2-28.2 | 200 | 6266 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-28.2.htm |  |  |
| RIS_20_20-2_20-2-29 | 200 | 4139 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-29.htm |  |  |
| RIS_20_20-2_20-2-30 | 200 | 4474 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-30.htm |  |  |
| RIS_20_20-2_20-2-31 | 200 | 9558 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-31.htm |  |  |
| RIS_20_20-2_20-2-32 | 200 | 4392 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-32.htm |  |  |
| RIS_20_20-2_20-2-33 | 200 | 4237 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-33.htm |  |  |
| RIS_20_20-2_20-2-34 | 200 | 4245 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-34.htm |  |  |
| RIS_20_20-2_20-2-35 | 200 | 4395 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-35.htm |  |  |
| RIS_20_20-2_20-2-36 | 200 | 4078 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-36.htm |  |  |
| RIS_20_20-2_20-2-37 | 200 | 4531 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-37.htm |  |  |
| RIS_20_20-2_20-2-38 | 200 | 4113 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-38.htm |  |  |
| RIS_20_20-2_20-2-38.1 | 200 | 4274 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-38.1.htm |  |  |
| RIS_20_20-2_20-2-39 | 200 | 4261 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-39.htm |  |  |
| RIS_20_20-2_20-2-40 | 200 | 4498 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-40.htm |  |  |
| RIS_20_20-2_20-2-41 | 200 | 4143 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-41.htm |  |  |
| RIS_20_20-2_20-2-42 | 200 | 4416 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-42.htm |  |  |
| RIS_20_20-2_20-2-43 | 200 | 4186 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-43.htm |  |  |
| RIS_20_20-2_20-2-44 | 200 | 4268 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-44.htm |  |  |
| RIS_20_20-2_20-2-45 | 200 | 6290 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-45.htm |  |  |
| RIS_20_20-2_20-2-46 | 200 | 4413 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2/20-2-46.htm |  |  |
| RIS_20_20-2.1_20-2.1-1 | 200 | 6026 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-1.htm |  |  |
| RIS_20_20-2.1_20-2.1-2 | 200 | 8013 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-2.htm |  |  |
| RIS_20_20-2.1_20-2.1-3 | 200 | 7620 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-3.htm |  |  |
| RIS_20_20-2.1_20-2.1-4 | 200 | 14681 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-4.htm |  |  |
| RIS_20_20-2.1_20-2.1-5 | 200 | 16554 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-5.htm |  |  |
| RIS_20_20-2.1_20-2.1-6 | 200 | 10443 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-6.htm |  |  |
| RIS_20_20-2.1_20-2.1-7 | 200 | 8336 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-7.htm |  |  |
| RIS_20_20-2.1_20-2.1-8 | 200 | 7944 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-8.htm |  |  |
| RIS_20_20-2.1_20-2.1-9 | 200 | 14662 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-9.htm |  |  |
| RIS_20_20-2.1_20-2.1-10 | 200 | 3879 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-10.htm |  | render-thin 288 |
| RIS_20_20-2.1_20-2.1-11 | 200 | 3879 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-11.htm |  | render-thin 288 |
| RIS_20_20-2.1_20-2.1-12 | 200 | 3923 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-12.htm |  |  |
| RIS_20_20-2.1_20-2.1-13 | 200 | 3969 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.1/20-2.1-13.htm |  |  |
| RIS_20_20-2.2_20-2.2-1 | 200 | 8147 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.2/20-2.2-1.htm |  |  |
| RIS_20_20-2.2_20-2.2-2 | 200 | 5081 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.2/20-2.2-2.htm |  |  |
| RIS_20_20-2.2_20-2.2-3 | 200 | 5806 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.2/20-2.2-3.htm |  |  |
| RIS_20_20-2.2_20-2.2-4 | 200 | 4888 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.2/20-2.2-4.htm |  |  |
| RIS_20_20-2.2_20-2.2-5 | 200 | 4757 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.2/20-2.2-5.htm |  |  |
| RIS_20_20-2.2_20-2.2-6 | 200 | 5795 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.2/20-2.2-6.htm |  |  |
| RIS_20_20-2.2_20-2.2-7 | 200 | 4700 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.2/20-2.2-7.htm |  |  |
| RIS_20_20-2.2_20-2.2-8 | 200 | 4508 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.2/20-2.2-8.htm |  |  |
| RIS_20_20-2.2_20-2.2-9 | 200 | 5319 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.2/20-2.2-9.htm |  |  |
| RIS_20_20-2.2_20-2.2-10 | 200 | 5385 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.2/20-2.2-10.htm |  |  |
| RIS_20_20-2.2_20-2.2-11 | 200 | 4002 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-2.2/20-2.2-11.htm |  |  |
| RIS_20_20-3_20-3-1 | 200 | 6203 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3/20-3-1.htm |  |  |
| RIS_20_20-3_20-3-2 | 200 | 7756 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3/20-3-2.htm |  |  |
| RIS_20_20-3_20-3-3 | 200 | 3869 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3/20-3-3.htm |  | render-thin 278 |
| RIS_20_20-3_20-3-4 | 200 | 3936 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3/20-3-4.htm |  |  |
| RIS_20_20-3_20-3-5 | 200 | 4220 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3/20-3-5.htm |  |  |
| RIS_20_20-3_20-3-6 | 200 | 3869 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3/20-3-6.htm |  | render-thin 278 |
| RIS_20_20-3_20-3-7 | 200 | 3934 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3/20-3-7.htm |  |  |
| RIS_20_20-3_20-3-8 | 200 | 4044 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3/20-3-8.htm |  |  |
| RIS_20_20-3.1_20-3.1-1 | 200 | 3937 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3.1/20-3.1-1.htm |  | render-thin 297 |
| RIS_20_20-3.1_20-3.1-2 | 200 | 3810 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3.1/20-3.1-2.htm |  | render-thin 235 |
| RIS_20_20-3.1_20-3.1-3 | 200 | 3810 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3.1/20-3.1-3.htm |  | render-thin 235 |
| RIS_20_20-3.1_20-3.1-4 | 200 | 3810 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3.1/20-3.1-4.htm |  | render-thin 235 |
| RIS_20_20-3.1_20-3.1-5 | 200 | 3810 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3.1/20-3.1-5.htm |  | render-thin 235 |
| RIS_20_20-3.1_20-3.1-6 | 200 | 4439 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3.1/20-3.1-6.htm |  |  |
| RIS_20_20-3.1_20-3.1-7 | 200 | 7385 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3.1/20-3.1-7.htm |  |  |
| RIS_20_20-3.1_20-3.1-8 | 200 | 3810 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3.1/20-3.1-8.htm |  | render-thin 235 |
| RIS_20_20-3.1_20-3.1-9 | 200 | 3810 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3.1/20-3.1-9.htm |  | render-thin 235 |
| RIS_20_20-3.2_20-3.2-1 | 200 | 3952 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3.2/20-3.2-1.htm |  |  |
| RIS_20_20-3.2_20-3.2-2 | 200 | 6020 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3.2/20-3.2-2.htm |  |  |
| RIS_20_20-3.2_20-3.2-3 | 200 | 5713 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-3.2/20-3.2-3.htm |  |  |
| RIS_20_20-4_20-4-1 | 200 | 5438 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-1.htm |  |  |
| RIS_20_20-4_20-4-1.1 | 200 | 3819 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-1.1.htm |  | render-thin 229 |
| RIS_20_20-4_20-4-1.2 | 200 | 3911 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-1.2.htm |  |  |
| RIS_20_20-4_20-4-1.3 | 200 | 3810 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-1.3.htm |  | render-thin 220 |
| RIS_20_20-4_20-4-2 | 200 | 4498 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-2.htm |  |  |
| RIS_20_20-4_20-4-3 | 200 | 4901 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-3.htm |  |  |
| RIS_20_20-4_20-4-4 | 200 | 4453 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-4.htm |  |  |
| RIS_20_20-4_20-4-5 | 200 | 5462 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-5.htm |  |  |
| RIS_20_20-4_20-4-6 | 200 | 3844 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-6.htm |  | render-thin 253 |
| RIS_20_20-4_20-4-7 | 200 | 4875 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-7.htm |  |  |
