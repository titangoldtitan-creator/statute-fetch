| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0500-0740-0020-0010 | 200 | 9358 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0010/0500-0740-0020-0010.html |    50-74-201. State boiler inspectors, MCA  |  |
| MTS_0500-0740-0020-0020 | 200 | 10245 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0020/0500-0740-0020-0020.html |    50-74-202. Special boiler inspectors, MCA  |  |
| MTS_0500-0740-0020-0030 | 200 | 9369 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0030/0500-0740-0020-0030.html |    50-74-203. Repealed, MCA  |  |
| MTS_0500-0740-0020-0040 | 200 | 9917 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0040/0500-0740-0020-0040.html |    50-74-204. Joint or separate inspection authorized -- inspectors to certify i |  |
| MTS_0500-0740-0020-0050 | 200 | 9974 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0050/0500-0740-0020-0050.html |    50-74-205. Purchaser to receive certificate of inspection, MCA  |  |
| MTS_0500-0740-0020-0060 | 200 | 10252 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0060/0500-0740-0020-0060.html |    50-74-206. Boiler to be inspected prior to use -- duty of notification, MCA  |  |
| MTS_0500-0740-0020-0070 | 200 | 10060 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0070/0500-0740-0020-0070.html |    50-74-207. Boiler opened for repair subject to inspection -- duty of notifica |  |
| MTS_0500-0740-0020-0080 | 200 | 10296 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0080/0500-0740-0020-0080.html |    50-74-208. Penalty for operation without certificate or failure to give notic |  |
| MTS_0500-0740-0020-0090 | 200 | 12368 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0090/0500-0740-0020-0090.html |    50-74-209. Required inspection intervals -- failure to comply with safety sta |  |
| MTS_0500-0740-0020-0100 | 200 | 9565 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0100/0500-0740-0020-0100.html |    50-74-210. Duty to permit inspection, MCA  |  |
| MTS_0500-0740-0020-0110 | 200 | 9778 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0110/0500-0740-0020-0110.html |    50-74-211. Inspector to notify department of refused access, MCA  |  |
| MTS_0500-0740-0020-0120 | 200 | 9794 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0120/0500-0740-0020-0120.html |    50-74-212. Payment of costs resulting from refused access, MCA  |  |
| MTS_0500-0740-0020-0130 | 200 | 9930 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0130/0500-0740-0020-0130.html |    50-74-213. Failure to comply with department directed access a misdemeanor, M |  |
| MTS_0500-0740-0020-0140 | 200 | 9788 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0140/0500-0740-0020-0140.html |    50-74-214. Engineer to assist in inspection, MCA  |  |
| MTS_0500-0740-0020-0150 | 200 | 11405 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0150/0500-0740-0020-0150.html |    50-74-215. Interior and exterior examination of boiler, MCA  |  |
| MTS_0500-0740-0020-0160 | 200 | 9847 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0160/0500-0740-0020-0160.html |    50-74-216. Hydrostatic pressure test, MCA  |  |
| MTS_0500-0740-0020-0170 | 200 | 10298 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0170/0500-0740-0020-0170.html |    50-74-217. Other inspection requirements, MCA  |  |
| MTS_0500-0740-0020-0180 | 200 | 11237 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0180/0500-0740-0020-0180.html |    50-74-218. Safe working pressure, MCA  |  |
| MTS_0500-0740-0020-0190 | 200 | 9460 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0020/section_0190/0500-0740-0020-0190.html |    50-74-219. Repealed, MCA  |  |
| MTS_0500-0740-0030-0010 | 200 | 9627 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0010/0500-0740-0030-0010.html |    50-74-301. License required to operate boilers and steam engines, MCA  |  |
| MTS_0500-0740-0030-0020 | 200 | 9664 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0020/0500-0740-0030-0020.html |    50-74-302. General requirements for licensure, MCA  |  |
| MTS_0500-0740-0030-0030 | 200 | 12502 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0030/0500-0740-0030-0030.html |    50-74-303. Engineer's license classifications, MCA  |  |
| MTS_0500-0740-0030-0040 | 200 | 16712 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0040/0500-0740-0030-0040.html |    50-74-304. Requirements for engineer's license, MCA  |  |
| MTS_0500-0740-0030-0050 | 200 | 11364 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0050/0500-0740-0030-0050.html |    50-74-305. Exceptions to requirements for engineer's license, MCA  |  |
| MTS_0500-0740-0030-0060 | 200 | 11050 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0060/0500-0740-0030-0060.html |    50-74-306. Traction licenses -- application without examination from other st |  |
| MTS_0500-0740-0030-0070 | 200 | 10759 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0070/0500-0740-0030-0070.html |    50-74-307. Requirements for traction licenses, MCA  |  |
| MTS_0500-0740-0030-0080 | 200 | 9797 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0080/0500-0740-0030-0080.html |    50-74-308. Waiver of experience requirement for traction licenses, MCA  |  |
| MTS_0500-0740-0030-0090 | 200 | 9502 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0090/0500-0740-0030-0090.html |    50-74-309. Repealed, MCA  |  |
| MTS_0500-0740-0030-0100 | 200 | 9460 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0100/0500-0740-0030-0100.html |    50-74-310. Repealed, MCA  |  |
| MTS_0500-0740-0030-0110 | 200 | 9763 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0110/0500-0740-0030-0110.html |    50-74-311. Waiting period before reexamination permitted, MCA  |  |
| MTS_0500-0740-0030-0120 | 200 | 11494 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0120/0500-0740-0030-0120.html |    50-74-312. Review of license rejection -- waiting period, MCA  |  |
| MTS_0500-0740-0030-0130 | 200 | 9369 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0130/0500-0740-0030-0130.html |    50-74-313. Repealed, MCA  |  |
| MTS_0500-0740-0030-0140 | 200 | 9350 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0140/0500-0740-0030-0140.html |    50-74-314. Repealed, MCA  |  |
| MTS_0500-0740-0030-0150 | 200 | 10572 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0150/0500-0740-0030-0150.html |    50-74-315. Unlawful to operate boiler or steam engine without license, MCA  |  |
| MTS_0500-0740-0030-0160 | 200 | 9787 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0160/0500-0740-0030-0160.html |    50-74-316. Unlawful to employ unlicensed operator, MCA  |  |
| MTS_0500-0740-0030-0170 | 200 | 10431 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0170/0500-0740-0030-0170.html |    50-74-317. When unlicensed person may operate, MCA  |  |
| MTS_0500-0740-0030-0180 | 200 | 10128 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0180/0500-0740-0030-0180.html |    50-74-318. Qualifications of boiler inspectors -- fees for inspections, MCA  |  |
| MTS_0500-0740-0030-0190 | 200 | 8840 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0190/0500-0740-0030-0190.html |    50-74-319. reserved, MCA  |  |
| MTS_0500-0740-0030-0200 | 200 | 9464 | https://leg.mt.gov/bills/mca/title_0500/chapter_0740/part_0030/section_0200/0500-0740-0030-0200.html |    50-74-320. Examinations -- fees -- third parties, MCA  |  |
| MTS_0500-0750-0010-0010 | 200 | 9111 | https://leg.mt.gov/bills/mca/title_0500/chapter_0750/part_0010/section_0010/0500-0750-0010-0010.html |    50-75-101. Repealed, MCA  |  |
| MTS_0500-0750-0010-0020 | 200 | 9315 | https://leg.mt.gov/bills/mca/title_0500/chapter_0750/part_0010/section_0020/0500-0750-0010-0020.html |    50-75-102. Repealed, MCA  |  |
| MTS_0500-0750-0010-0030 | 200 | 9285 | https://leg.mt.gov/bills/mca/title_0500/chapter_0750/part_0010/section_0030/0500-0750-0010-0030.html |    50-75-103. Repealed, MCA  |  |
| MTS_0500-0750-0010-0040 | 200 | 9291 | https://leg.mt.gov/bills/mca/title_0500/chapter_0750/part_0010/section_0040/0500-0750-0010-0040.html |    50-75-104. Repealed, MCA  |  |
| MTS_0500-0750-0010-0050 | 200 | 9322 | https://leg.mt.gov/bills/mca/title_0500/chapter_0750/part_0010/section_0050/0500-0750-0010-0050.html |    50-75-105. Repealed, MCA  |  |
| MTS_0500-0750-0010-0060 | 200 | 9285 | https://leg.mt.gov/bills/mca/title_0500/chapter_0750/part_0010/section_0060/0500-0750-0010-0060.html |    50-75-106. Repealed, MCA  |  |
| MTS_0500-0750-0010-0070 | 200 | 9152 | https://leg.mt.gov/bills/mca/title_0500/chapter_0750/part_0010/section_0070/0500-0750-0010-0070.html |    50-75-107. Repealed, MCA  |  |
| MTS_0500-0760-0010-0010 | 200 | 10552 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0010/0500-0760-0010-0010.html |    50-76-101. When chapter not to apply, MCA  |  |
| MTS_0500-0760-0010-0020 | 200 | 10990 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0020/0500-0760-0010-0020.html |    50-76-102. Hoisting engine license required, MCA  |  |
| MTS_0500-0760-0010-0030 | 200 | 13234 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0030/0500-0760-0010-0030.html |    50-76-103. Crane and hoist license required, MCA  |  |
| MTS_0500-0760-0010-0040 | 200 | 10189 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0040/0500-0760-0010-0040.html |    50-76-104. Application, examination, and fee for license, MCA  |  |
| MTS_0500-0760-0010-0050 | 200 | 9359 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0050/0500-0760-0010-0050.html |    50-76-105. Repealed, MCA  |  |
| MTS_0500-0760-0010-0060 | 200 | 9328 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0060/0500-0760-0010-0060.html |    50-76-106. Repealed, MCA  |  |
| MTS_0500-0760-0010-0070 | 200 | 9751 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0070/0500-0760-0010-0070.html |    50-76-107. Scope of license, MCA  |  |
| MTS_0500-0760-0010-0080 | 200 | 9628 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0080/0500-0760-0010-0080.html |    50-76-108. Renewal of application by rejected candidate, MCA  |  |
| MTS_0500-0760-0010-0090 | 200 | 10354 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0090/0500-0760-0010-0090.html |    50-76-109. Violation of chapter -- misdemeanor, MCA  |  |
| MTS_0500-0760-0010-0100 | 200 | 10223 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0100/0500-0760-0010-0100.html |    50-76-110. Crane inspector -- qualifications -- inspections, MCA  |  |
| MTS_0500-0760-0010-0110 | 200 | 10202 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0110/0500-0760-0010-0110.html |    50-76-111. Definitions, MCA  |  |
| MTS_0500-0760-0010-0120 | 200 | 10631 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0120/0500-0760-0010-0120.html |    50-76-112. Rulemaking authority, MCA  |  |
| MTS_0500-0760-0010-0130 | 200 | 10054 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0130/0500-0760-0010-0130.html |    50-76-113. Recognition of national certification, MCA  |  |
| MTS_0500-0760-0010-0140 | 200 | 11100 | https://leg.mt.gov/bills/mca/title_0500/chapter_0760/part_0010/section_0140/0500-0760-0010-0140.html |    50-76-114. Failure of licensee to have possession of license or proof of lice |  |
| MTS_0500-0770-0010-0010 | 200 | 10703 | https://leg.mt.gov/bills/mca/title_0500/chapter_0770/part_0010/section_0010/0500-0770-0010-0010.html |    50-77-101. Scaffolds -- definition -- safety practices -- liability, MCA  |  |
| MTS_0500-0770-0010-0020 | 200 | 10734 | https://leg.mt.gov/bills/mca/title_0500/chapter_0770/part_0010/section_0020/0500-0770-0010-0020.html |    50-77-102. Temporary floors for protection of workers, MCA  |  |
| MTS_0500-0770-0010-0030 | 200 | 9663 | https://leg.mt.gov/bills/mca/title_0500/chapter_0770/part_0010/section_0030/0500-0770-0010-0030.html |    50-77-103. Planking above scaffolds, MCA  |  |
| MTS_0500-0770-0010-0040 | 200 | 9650 | https://leg.mt.gov/bills/mca/title_0500/chapter_0770/part_0010/section_0040/0500-0770-0010-0040.html |    50-77-104. Guarding of stairways and other openings, MCA  |  |
| MTS_0500-0770-0010-0050 | 200 | 9442 | https://leg.mt.gov/bills/mca/title_0500/chapter_0770/part_0010/section_0050/0500-0770-0010-0050.html |    50-77-105. Temporary toilets, MCA  |  |
| MTS_0500-0770-0010-0060 | 200 | 9220 | https://leg.mt.gov/bills/mca/title_0500/chapter_0770/part_0010/section_0060/0500-0770-0010-0060.html |    50-77-106. Repealed, MCA  |  |
| MTS_0500-0770-0010-0070 | 200 | 9134 | https://leg.mt.gov/bills/mca/title_0500/chapter_0770/part_0010/section_0070/0500-0770-0010-0070.html |    50-77-107. Penalty for violation, MCA  |  |
| MTS_0500-0780-0010-0010 | 200 | 8970 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0010/section_0010/0500-0780-0010-0010.html |    50-78-101. Short title, MCA  |  |
| MTS_0500-0780-0010-0020 | 200 | 15132 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0010/section_0020/0500-0780-0010-0020.html |    50-78-102. Definitions, MCA  |  |
| MTS_0500-0780-0010-0030 | 200 | 13729 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0010/section_0030/0500-0780-0010-0030.html |    50-78-103. Applicability -- exemptions, MCA  |  |
| MTS_0500-0780-0010-0040 | 200 | 9414 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0010/section_0040/0500-0780-0010-0040.html |    50-78-104. Relationship to OSHA standard, MCA  |  |
| MTS_0500-0780-0020-0010 | 200 | 9085 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0020/section_0010/0500-0780-0020-0010.html |    50-78-201. Notice to employees, MCA  |  |
| MTS_0500-0780-0020-0020 | 200 | 10739 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0020/section_0020/0500-0780-0020-0020.html |    50-78-202. Workplace chemical list, MCA  |  |
| MTS_0500-0780-0020-0030 | 200 | 10254 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0020/section_0030/0500-0780-0020-0030.html |    50-78-203. Material safety data sheets, MCA  |  |
| MTS_0500-0780-0020-0040 | 200 | 11150 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0020/section_0040/0500-0780-0020-0040.html |    50-78-204. Employee rights, MCA  |  |
| MTS_0500-0780-0020-0050 | 200 | 12167 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0020/section_0050/0500-0780-0020-0050.html |    50-78-205. Trade secret confidentiality, MCA  |  |
| MTS_0500-0780-0020-0060 | 200 | 9374 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0020/section_0060/0500-0780-0020-0060.html |    50-78-206. Labels, MCA  |  |
| MTS_0500-0780-0030-0010 | 200 | 11325 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0030/section_0010/0500-0780-0030-0010.html |    50-78-301. Emergency and community information, MCA  |  |
| MTS_0500-0780-0030-0020 | 200 | 9040 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0030/section_0020/0500-0780-0030-0020.html |    50-78-302. through 50-78-304 reserved, MCA  |  |
| MTS_0500-0780-0030-0050 | 200 | 10657 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0030/section_0050/0500-0780-0030-0050.html |    50-78-305. Employee education program, MCA  |  |
| MTS_0500-0780-0030-0060 | 200 | 10045 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0030/section_0060/0500-0780-0030-0060.html |    50-78-306. Departmental information program, MCA  |  |
| MTS_0500-0780-0040-0010 | 200 | 9670 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0040/section_0010/0500-0780-0040-0010.html |    50-78-401. No effect on other duties or liabilities, MCA  |  |
| MTS_0500-0780-0040-0020 | 200 | 11598 | https://leg.mt.gov/bills/mca/title_0500/chapter_0780/part_0040/section_0020/0500-0780-0040-0020.html |    50-78-402. Complaints, investigation, and penalties, MCA  |  |
| MTS_0500-0790-0010-0010 | 200 | 9711 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0010/section_0010/0500-0790-0010-0010.html |    50-79-101. Policy, MCA  |  |
| MTS_0500-0790-0010-0020 | 200 | 10209 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0010/section_0020/0500-0790-0010-0020.html |    50-79-102. Purpose, MCA  |  |
| MTS_0500-0790-0010-0030 | 200 | 13822 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0010/section_0030/0500-0790-0010-0030.html |    50-79-103. Definitions, MCA  |  |
| MTS_0500-0790-0010-0040 | 200 | 11110 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0010/section_0040/0500-0790-0010-0040.html |    50-79-104. Exemptions -- sources, diagnosis, and therapy, MCA  |  |
| MTS_0500-0790-0010-0050 | 200 | 9645 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0010/section_0050/0500-0790-0010-0050.html |    50-79-105. Conflicting laws, MCA  |  |
| MTS_0500-0790-0010-0060 | 200 | 9577 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0010/section_0060/0500-0790-0010-0060.html |    50-79-106. Confidentiality -- trade secrets, MCA  |  |
| MTS_0500-0790-0010-0070 | 200 | 9914 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0010/section_0070/0500-0790-0010-0070.html |    50-79-107. Inspections, MCA  |  |
| MTS_0500-0790-0010-0080 | 200 | 9970 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0010/section_0080/0500-0790-0010-0080.html |    50-79-108. Inspection agreements and training programs, MCA  |  |
| MTS_0500-0790-0020-0010 | 200 | 12701 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0020/section_0010/0500-0790-0020-0010.html |    50-79-201. State radiation control agency, MCA  |  |
| MTS_0500-0790-0020-0020 | 200 | 12536 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0020/section_0020/0500-0790-0020-0020.html |    50-79-202. Licensing and registration, MCA  |  |
| MTS_0500-0790-0020-0030 | 200 | 10093 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0020/section_0030/0500-0790-0020-0030.html |    50-79-203. Federal-state agreements, MCA  |  |
| MTS_0500-0790-0020-0040 | 200 | 10399 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0020/section_0040/0500-0790-0020-0040.html |    50-79-204. Records, MCA  |  |
| MTS_0500-0790-0030-0010 | 200 | 9545 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0030/section_0010/0500-0790-0030-0010.html |    50-79-301. Definition, MCA  |  |
| MTS_0500-0790-0030-0020 | 200 | 10767 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0030/section_0020/0500-0790-0030-0020.html |    50-79-302. Disposal of large quantities of radioactive material prohibited -- |  |
| MTS_0500-0790-0030-0030 | 200 | 9923 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0030/section_0030/0500-0790-0030-0030.html |    50-79-303. Penalty, MCA  |  |
| MTS_0500-0790-0030-0040 | 200 | 9334 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0030/section_0040/0500-0790-0030-0040.html |    50-79-304. Policy, MCA  |  |
| MTS_0500-0790-0040-0010 | 200 | 9595 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0040/section_0010/0500-0790-0040-0010.html |    50-79-401. Administrative hearings, MCA  |  |
| MTS_0500-0790-0040-0020 | 200 | 9696 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0040/section_0020/0500-0790-0040-0020.html |    50-79-402. Emergency impoundment of materials, MCA  |  |
| MTS_0500-0790-0040-0030 | 200 | 10124 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0040/section_0030/0500-0790-0040-0030.html |    50-79-403. Emergency orders and rules, MCA  |  |
| MTS_0500-0790-0040-0040 | 200 | 10299 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0040/section_0040/0500-0790-0040-0040.html |    50-79-404. Prohibited activity, MCA  |  |
| MTS_0500-0790-0040-0050 | 200 | 9599 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0040/section_0050/0500-0790-0040-0050.html |    50-79-405. Penalty, MCA  |  |
| MTS_0500-0790-0040-0060 | 200 | 9643 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0040/section_0060/0500-0790-0040-0060.html |    50-79-406. Injunctions, MCA  |  |
| MTS_0500-0790-0040-0070 | 200 | 10300 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0040/section_0070/0500-0790-0040-0070.html |    50-79-407. Civil penalties -- deposit in general fund -- injunctions not barr |  |
| MTS_0500-0790-0040-0080 | 200 | 9050 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0040/section_0080/0500-0790-0040-0080.html |    50-79-408. and 50-79-409 reserved, MCA  |  |
| MTS_0500-0790-0040-0100 | 200 | 12520 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0040/section_0100/0500-0790-0040-0100.html |    50-79-410. State regulations no more stringent than federal regulations or gu |  |
| MTS_0500-0790-0050-0010 | 200 | 22039 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0050/section_0010/0500-0790-0050-0010.html |    50-79-501. Northwest Interstate Compact on Low-Level Radioactive Waste Manage |  |
| MTS_0500-0790-0050-0020 | 200 | 10312 | https://leg.mt.gov/bills/mca/title_0500/chapter_0790/part_0050/section_0020/0500-0790-0050-0020.html |    50-79-502. Administration of compact -- fees, MCA  |  |
| MTS_0520-0010-0010-0010 | 200 | 9515 | https://leg.mt.gov/bills/mca/title_0520/chapter_0010/part_0010/section_0010/0520-0010-0010-0010.html |    52-1-101. Purpose, MCA  |  |
| MTS_0520-0010-0010-0020 | 200 | 9702 | https://leg.mt.gov/bills/mca/title_0520/chapter_0010/part_0010/section_0020/0520-0010-0010-0020.html |    52-1-102. Definitions, MCA  |  |
| MTS_0520-0010-0010-0030 | 200 | 13145 | https://leg.mt.gov/bills/mca/title_0520/chapter_0010/part_0010/section_0030/0520-0010-0010-0030.html |    52-1-103. Powers and duties of department, MCA  |  |
| MTS_0520-0010-0010-0040 | 200 | 10621 | https://leg.mt.gov/bills/mca/title_0520/chapter_0010/part_0010/section_0040/0520-0010-0010-0040.html |    52-1-104. Department authorized to provide and set standards for supplementar |  |
| MTS_0520-0010-0010-0050 | 200 | 9108 | https://leg.mt.gov/bills/mca/title_0520/chapter_0010/part_0010/section_0050/0520-0010-0010-0050.html |    52-1-105. Repealed, MCA  |  |
| MTS_0520-0010-0010-0060 | 200 | 8837 | https://leg.mt.gov/bills/mca/title_0520/chapter_0010/part_0010/section_0060/0520-0010-0010-0060.html |    52-1-106. through 52-1-109 reserved, MCA  |  |
| MTS_0520-0010-0010-0100 | 200 | 8935 | https://leg.mt.gov/bills/mca/title_0520/chapter_0010/part_0010/section_0100/0520-0010-0010-0100.html |    52-1-110. Repealed, MCA  |  |
| MTS_0520-0010-0020-0010 | 200 | 9083 | https://leg.mt.gov/bills/mca/title_0520/chapter_0010/part_0020/section_0010/0520-0010-0020-0010.html |    52-1-201. Local service areas, MCA  |  |
| MTS_0520-0010-0020-0020 | 200 | 9098 | https://leg.mt.gov/bills/mca/title_0520/chapter_0010/part_0020/section_0020/0520-0010-0020-0020.html |    52-1-202. Repealed, MCA  |  |
| MTS_0520-0010-0020-0030 | 200 | 8887 | https://leg.mt.gov/bills/mca/title_0520/chapter_0010/part_0020/section_0030/0520-0010-0020-0030.html |    52-1-203. Repealed, MCA  |  |
| MTS_0520-0020-0010-0010 | 200 | 10087 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0010/0520-0020-0010-0010.html |    52-2-101. Definitions, MCA  |  |
| MTS_0520-0020-0010-0020 | 200 | 10323 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0020/0520-0020-0010-0020.html |    52-2-102. Recognition of parental control of children -- placement with exten |  |
| MTS_0520-0020-0010-0030 | 200 | 9027 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0030/0520-0020-0010-0030.html |    52-2-103. through 52-2-109 reserved, MCA  |  |
| MTS_0520-0020-0010-0100 | 200 | 9895 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0100/0520-0020-0010-0100.html |    52-2-110. Department to oversee federal funds supporting legal services for c |  |
| MTS_0520-0020-0010-0110 | 200 | 10516 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0110/0520-0020-0010-0110.html |    52-2-111. Administrative duties of department, MCA  |  |
| MTS_0520-0020-0010-0120 | 200 | 10137 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0120/0520-0020-0010-0120.html |    52-2-112. Duty to strengthen child welfare services, MCA  |  |
| MTS_0520-0020-0010-0130 | 200 | 10613 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0130/0520-0020-0010-0130.html |    52-2-113. Child rehabilitation -- duties of department, MCA  |  |
| MTS_0520-0020-0010-0140 | 200 | 9595 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0140/0520-0020-0010-0140.html |    52-2-114. Department to supervise importation and exportation of children, MC |  |
| MTS_0520-0020-0010-0150 | 200 | 9739 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0150/0520-0020-0010-0150.html |    52-2-115. Department to accept custody of children, MCA  |  |
| MTS_0520-0020-0010-0160 | 200 | 9796 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0160/0520-0020-0010-0160.html |    52-2-116. Department to assist other agencies, MCA  |  |
| MTS_0520-0020-0010-0170 | 200 | 10997 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0170/0520-0020-0010-0170.html |    52-2-117. Indian child welfare specialist, MCA  |  |
| MTS_0520-0020-0010-0180 | 200 | 9272 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0180/0520-0020-0010-0180.html |    52-2-118. Repealed, MCA  |  |
| MTS_0520-0020-0010-0190 | 200 | 8920 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0190/0520-0020-0010-0190.html |    52-2-119. and 52-2-120 reserved, MCA  |  |
| MTS_0520-0020-0010-0210 | 200 | 10261 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0010/section_0210/0520-0020-0010-0210.html |    52-2-121. Development of state permanent placement policy and plan, MCA  |  |
| MTS_0520-0020-0020-0010 | 200 | 9004 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0020/section_0010/0520-0020-0020-0010.html |    52-2-201. Purpose, MCA  |  |
| MTS_0520-0020-0020-0020 | 200 | 10936 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0020/section_0020/0520-0020-0020-0020.html |    52-2-202. Definitions, MCA  |  |
| MTS_0520-0020-0020-0030 | 200 | 12619 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0020/section_0030/0520-0020-0020-0030.html |    52-2-203. Cooperative agreement regarding children's services, MCA  |  |
| MTS_0520-0020-0020-0040 | 200 | 9031 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0020/section_0040/0520-0020-0020-0040.html |    52-2-204. through 52-2-210 reserved, MCA  |  |
| MTS_0520-0020-0020-0110 | 200 | 15993 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0020/section_0110/0520-0020-0020-0110.html |    52-2-211. County or regional interdisciplinary child information and school s |  |
| MTS_0520-0020-0030-0010 | 200 | 11162 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0030/section_0010/0520-0020-0030-0010.html |    52-2-301. State policy, MCA  |  |
| MTS_0520-0020-0030-0020 | 200 | 13998 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0030/section_0020/0520-0020-0030-0020.html |    52-2-302. Definitions, MCA  |  |
| MTS_0520-0020-0030-0030 | 200 | 12056 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0030/section_0030/0520-0020-0030-0030.html |    52-2-303. Children's system of care planning committee -- membership -- admin |  |
| MTS_0520-0020-0030-0040 | 200 | 17277 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0030/section_0040/0520-0020-0030-0040.html |    52-2-304. Committee duties, MCA  |  |
| MTS_0520-0020-0030-0050 | 200 | 10816 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0030/section_0050/0520-0020-0030-0050.html |    52-2-305. Repealed, MCA  |  |
| MTS_0520-0020-0030-0060 | 200 | 10808 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0030/section_0060/0520-0020-0030-0060.html |    52-2-306. Repealed, MCA  |  |
| MTS_0520-0020-0030-0070 | 200 | 10810 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0030/section_0070/0520-0020-0030-0070.html |    52-2-307. Repealed, MCA  |  |
| MTS_0520-0020-0030-0080 | 200 | 11106 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0030/section_0080/0520-0020-0030-0080.html |    52-2-308. Rulemaking, MCA  |  |
| MTS_0520-0020-0030-0090 | 200 | 12423 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0030/section_0090/0520-0020-0030-0090.html |    52-2-309. Children's system of care account, MCA  |  |
| MTS_0520-0020-0030-0100 | 200 | 16309 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0030/section_0100/0520-0020-0030-0100.html |    52-2-310. Development and use of qualified provider pools -- circumstances re |  |
| MTS_0520-0020-0030-0110 | 200 | 12778 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0030/section_0110/0520-0020-0030-0110.html |    52-2-311. Out-of-state placement monitoring and reporting, MCA  |  |
| MTS_0520-0020-0040-0010 | 200 | 10886 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0040/section_0010/0520-0020-0040-0010.html |    52-2-401. Repealed, MCA  |  |
| MTS_0520-0020-0040-0020 | 200 | 10960 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0040/section_0020/0520-0020-0040-0020.html |    52-2-402. Repealed, MCA  |  |
| MTS_0520-0020-0040-0030 | 200 | 11029 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0040/section_0030/0520-0020-0040-0030.html |    52-2-403. Repealed, MCA  |  |
| MTS_0520-0020-0040-0040 | 200 | 11029 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0040/section_0040/0520-0020-0040-0040.html |    52-2-404. Repealed, MCA  |  |
| MTS_0520-0020-0040-0050 | 200 | 11157 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0040/section_0050/0520-0020-0040-0050.html |    52-2-405. Repealed, MCA  |  |
| MTS_0520-0020-0040-0060 | 200 | 11022 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0040/section_0060/0520-0020-0040-0060.html |    52-2-406. Repealed, MCA  |  |
| MTS_0520-0020-0040-0070 | 200 | 10791 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0040/section_0070/0520-0020-0040-0070.html |    52-2-407. Repealed, MCA  |  |
| MTS_0520-0020-0050-0010 | 200 | 10438 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0010/0520-0020-0050-0010.html |    52-2-501. Renumbered 42-10-101, MCA  |  |
| MTS_0520-0020-0050-0020 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0020/0520-0020-0050-0020.html |    52-2-502. Renumbered 42-10-102, MCA  |  |
| MTS_0520-0020-0050-0030 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0030/0520-0020-0050-0030.html |    52-2-503. Renumbered 42-10-103, MCA  |  |
| MTS_0520-0020-0050-0040 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0040/0520-0020-0050-0040.html |    52-2-504. Renumbered 42-10-104, MCA  |  |
| MTS_0520-0020-0050-0050 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0050/0520-0020-0050-0050.html |    52-2-505. Renumbered 42-10-105, MCA  |  |
| MTS_0520-0020-0050-0060 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0060/0520-0020-0050-0060.html |    52-2-506. Renumbered 42-10-106, MCA  |  |
| MTS_0520-0020-0050-0070 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0070/0520-0020-0050-0070.html |    52-2-507. Renumbered 42-10-107, MCA  |  |
| MTS_0520-0020-0050-0080 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0080/0520-0020-0050-0080.html |    52-2-508. Renumbered 42-10-108, MCA  |  |
| MTS_0520-0020-0050-0090 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0090/0520-0020-0050-0090.html |    52-2-509. Renumbered 42-10-109, MCA  |  |
| MTS_0520-0020-0050-0100 | 200 | 10658 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0100/0520-0020-0050-0100.html |    52-2-510. Renumbered 42-10-110, MCA  |  |
| MTS_0520-0020-0050-0110 | 200 | 10643 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0110/0520-0020-0050-0110.html |    52-2-511. through 52-2-520 reserved, MCA  |  |
| MTS_0520-0020-0050-0210 | 200 | 10658 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0210/0520-0020-0050-0210.html |    52-2-521. Renumbered 42-10-121, MCA  |  |
| MTS_0520-0020-0050-0220 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0220/0520-0020-0050-0220.html |    52-2-522. Renumbered 42-10-122, MCA  |  |
| MTS_0520-0020-0050-0230 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0230/0520-0020-0050-0230.html |    52-2-523. Renumbered 42-10-123, MCA  |  |
| MTS_0520-0020-0050-0240 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0240/0520-0020-0050-0240.html |    52-2-524. Renumbered 42-10-124, MCA  |  |
| MTS_0520-0020-0050-0250 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0250/0520-0020-0050-0250.html |    52-2-525. Renumbered 42-10-125, MCA  |  |
| MTS_0520-0020-0050-0260 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0260/0520-0020-0050-0260.html |    52-2-526. Renumbered 42-10-126, MCA  |  |
| MTS_0520-0020-0050-0270 | 200 | 10653 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0270/0520-0020-0050-0270.html |    52-2-527. Renumbered 42-10-127, MCA  |  |
| MTS_0520-0020-0050-0280 | 200 | 10441 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0050/section_0280/0520-0020-0050-0280.html |    52-2-528. Renumbered 42-10-128, MCA  |  |
| MTS_0520-0020-0060-0010 | 200 | 11500 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0010/0520-0020-0060-0010.html |    52-2-601. Establishment of substitute care for youth, MCA  |  |
| MTS_0520-0020-0060-0020 | 200 | 16775 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0020/0520-0020-0060-0020.html |    52-2-602. Definitions, MCA  |  |
| MTS_0520-0020-0060-0030 | 200 | 16033 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0030/0520-0020-0060-0030.html |    52-2-603. Powers and duties of department, MCA  |  |
| MTS_0520-0020-0060-0040 | 200 | 12023 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0040/0520-0020-0060-0040.html |    52-2-604. Transfer of custody to private agency -- reports, MCA  |  |
| MTS_0520-0020-0060-0050 | 200 | 10729 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0050/0520-0020-0060-0050.html |    52-2-605. through 52-2-610 reserved, MCA  |  |
| MTS_0520-0020-0060-0110 | 200 | 12953 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0110/0520-0020-0060-0110.html |    52-2-611. Payment for support of youth in need of care, youth in need of inte |  |
| MTS_0520-0020-0060-0120 | 200 | 11817 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0120/0520-0020-0060-0120.html |    52-2-612. Debt to state by natural or adoptive parents -- limitations, MCA  |  |
| MTS_0520-0020-0060-0130 | 200 | 10730 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0130/0520-0020-0060-0130.html |    52-2-613. through 52-2-615 reserved, MCA  |  |
| MTS_0520-0020-0060-0160 | 200 | 11659 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0160/0520-0020-0060-0160.html |    52-2-616. Power of nonprofit corporations to establish homes and to receive f |  |
| MTS_0520-0020-0060-0170 | 200 | 12463 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0170/0520-0020-0060-0170.html |    52-2-617. Governmental contracts with nonprofit organizations, MCA  |  |
| MTS_0520-0020-0060-0180 | 200 | 10652 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0180/0520-0020-0060-0180.html |    52-2-618. through 52-2-620 reserved, MCA  |  |
| MTS_0520-0020-0060-0210 | 200 | 12270 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0210/0520-0020-0060-0210.html |    52-2-621. License required, MCA  |  |
| MTS_0520-0020-0060-0220 | 200 | 12989 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0220/0520-0020-0060-0220.html |    52-2-622. Issuance of license -- authority of issuing agency -- rules, MCA  |  |
| MTS_0520-0020-0060-0230 | 200 | 11539 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0230/0520-0020-0060-0230.html |    52-2-623. Penalty for failure to obtain license, MCA  |  |
| MTS_0520-0020-0060-0240 | 200 | 10634 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0240/0520-0020-0060-0240.html |    52-2-624. through 52-2-626 reserved, MCA  |  |
| MTS_0520-0020-0060-0270 | 200 | 12115 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0270/0520-0020-0060-0270.html |    52-2-627. Respite care, MCA  |  |
| MTS_0520-0020-0060-0280 | 200 | 11780 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0280/0520-0020-0060-0280.html |    52-2-628. Respite care providers -- recruitment, training, and employment --  |  |
| MTS_0520-0020-0060-0290 | 200 | 15818 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0290/0520-0020-0060-0290.html |    52-2-629. Fee waivers for government documents provided to former foster chil |  |
| MTS_0520-0020-0060-0300 | 200 | 11922 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0060/section_0300/0520-0020-0060-0300.html |    52-2-630. Reimbursement of waived fees -- authorization to utilize federal fu |  |
| MTS_0520-0020-0070-0010 | 200 | 10548 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0010/0520-0020-0070-0010.html |    52-2-701. Short title, MCA  |  |
| MTS_0520-0020-0070-0020 | 200 | 13371 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0020/0520-0020-0070-0020.html |    52-2-702. Purpose -- findings, MCA  |  |
| MTS_0520-0020-0070-0030 | 200 | 17225 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0030/0520-0020-0070-0030.html |    52-2-703. Definitions, MCA  |  |
| MTS_0520-0020-0070-0040 | 200 | 13619 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0040/0520-0020-0070-0040.html |    52-2-704. Duties of department, MCA  |  |
| MTS_0520-0020-0070-0050 | 200 | 10766 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0050/0520-0020-0070-0050.html |    52-2-705. Repealed, MCA  |  |
| MTS_0520-0020-0070-0060 | 200 | 10586 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0060/0520-0020-0070-0060.html |    52-2-706. through 52-2-709 reserved, MCA  |  |
| MTS_0520-0020-0070-0100 | 200 | 14525 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0100/0520-0020-0070-0100.html |    52-2-710. At-home infant care program -- definition, MCA  |  |
| MTS_0520-0020-0070-0110 | 200 | 15099 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0110/0520-0020-0070-0110.html |    52-2-711. Resource and referral and day-care improvement grant program, MCA  |  |
| MTS_0520-0020-0070-0120 | 200 | 10810 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0120/0520-0020-0070-0120.html |    52-2-712. Repealed, MCA  |  |
| MTS_0520-0020-0070-0130 | 200 | 11326 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0130/0520-0020-0070-0130.html |    52-2-713. Payments for eligible children, MCA  |  |
| MTS_0520-0020-0070-0140 | 200 | 11153 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0140/0520-0020-0070-0140.html |    52-2-714. Best beginnings child care scholarship program, MCA  |  |
| MTS_0520-0020-0070-0150 | 200 | 11331 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0150/0520-0020-0070-0150.html |    52-2-715. Family income eligibility requirements, MCA  |  |
| MTS_0520-0020-0070-0160 | 200 | 10922 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0160/0520-0020-0070-0160.html |    52-2-716. Copayment requirements, MCA  |  |
| MTS_0520-0020-0070-0170 | 200 | 10665 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0170/0520-0020-0070-0170.html |    52-2-717. through 52-2-720 reserved, MCA  |  |
| MTS_0520-0020-0070-0210 | 200 | 14179 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0210/0520-0020-0070-0210.html |    52-2-721. License required -- registration required -- term of license or reg |  |
| MTS_0520-0020-0070-0220 | 200 | 12158 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0220/0520-0020-0070-0220.html |    52-2-722. Application for a license or registration certificate, MCA  |  |
| MTS_0520-0020-0070-0230 | 200 | 13331 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0230/0520-0020-0070-0230.html |    52-2-723. Requirements for licensure, MCA  |  |
| MTS_0520-0020-0070-0240 | 200 | 12132 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0240/0520-0020-0070-0240.html |    52-2-724. Provisional license -- provisional registration certificate, MCA  |  |
| MTS_0520-0020-0070-0250 | 200 | 11529 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0250/0520-0020-0070-0250.html |    52-2-725. Renewal license -- registration certificate, MCA  |  |
| MTS_0520-0020-0070-0260 | 200 | 12584 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0260/0520-0020-0070-0260.html |    52-2-726. Denial, cancellation, reduction, revocation, and nonrenewal of lice |  |
| MTS_0520-0020-0070-0270 | 200 | 10676 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0270/0520-0020-0070-0270.html |    52-2-727. through 52-2-730 reserved, MCA  |  |
| MTS_0520-0020-0070-0310 | 200 | 12604 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0310/0520-0020-0070-0310.html |    52-2-731. Standards for day care, MCA  |  |
| MTS_0520-0020-0070-0320 | 200 | 11819 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0320/0520-0020-0070-0320.html |    52-2-732. Licensees or registrants to maintain records, furnish reports, and  |  |
| MTS_0520-0020-0070-0330 | 200 | 13824 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0330/0520-0020-0070-0330.html |    52-2-733. Periodic visits to facilities by department -- investigations -- co |  |
| MTS_0520-0020-0070-0340 | 200 | 11896 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0340/0520-0020-0070-0340.html |    52-2-734. Fire safety -- certification required, MCA  |  |
| MTS_0520-0020-0070-0350 | 200 | 13013 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0350/0520-0020-0070-0350.html |    52-2-735. Health protection -- certification required, MCA  |  |
| MTS_0520-0020-0070-0360 | 200 | 17325 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0360/0520-0020-0070-0360.html |    52-2-736. Prohibition against administering medicine without authorization -- |  |
| MTS_0520-0020-0070-0370 | 200 | 11082 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0370/0520-0020-0070-0370.html |    52-2-737. Group day-care home -- staffing requirement, MCA  |  |
| MTS_0520-0020-0070-0380 | 200 | 10599 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0380/0520-0020-0070-0380.html |    52-2-738. through 52-2-740 reserved, MCA  |  |
| MTS_0520-0020-0070-0410 | 200 | 12609 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0070/section_0410/0520-0020-0070-0410.html |    52-2-741. Penalty -- remedies, MCA  |  |
| MTS_0520-0020-0080-0010 | 200 | 10893 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0080/section_0010/0520-0020-0080-0010.html |    52-2-801. Purpose, MCA  |  |
| MTS_0520-0020-0080-0020 | 200 | 14183 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0080/section_0020/0520-0020-0080-0020.html |    52-2-802. Definitions, MCA  |  |
| MTS_0520-0020-0080-0030 | 200 | 11926 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0080/section_0030/0520-0020-0080-0030.html |    52-2-803. Duties of department, MCA  |  |
| MTS_0520-0020-0080-0040 | 200 | 12037 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0080/section_0040/0520-0020-0080-0040.html |    52-2-804. License required -- term of license -- fees, MCA  |  |
| MTS_0520-0020-0080-0050 | 200 | 14777 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0080/section_0050/0520-0020-0080-0050.html |    52-2-805. Requirements for licensure -- restrictions -- rulemaking, MCA  |  |
| MTS_0520-0020-0080-0060 | 200 | 11192 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0080/section_0060/0520-0020-0080-0060.html |    52-2-806. Provisional license, MCA  |  |
| MTS_0520-0020-0080-0070 | 200 | 11094 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0080/section_0070/0520-0020-0080-0070.html |    52-2-807. Renewal license, MCA  |  |
| MTS_0520-0020-0080-0080 | 200 | 12327 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0080/section_0080/0520-0020-0080-0080.html |    52-2-808. Denial, cancellation, reduction, revocation, and nonrenewal of lice |  |
| MTS_0520-0020-0080-0090 | 200 | 11748 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0080/section_0090/0520-0020-0080-0090.html |    52-2-809. Licensees and applicants to maintain records, furnish reports, and  |  |
| MTS_0520-0020-0080-0100 | 200 | 13025 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0080/section_0100/0520-0020-0080-0100.html |    52-2-810. Periodic visits to facilities by department -- investigations -- co |  |
| MTS_0520-0020-0080-0110 | 200 | 12308 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0080/section_0110/0520-0020-0080-0110.html |    52-2-811. Penalty -- remedies, MCA  |  |
| MTS_0520-0020-0090-0010 | 200 | 17163 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0090/section_0010/0520-0020-0090-0010.html |    52-2-901. Evaluation and assessment of language development in deaf and hard- |  |
| MTS_0520-0020-0090-0020 | 200 | 12115 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0090/section_0020/0520-0020-0090-0020.html |    52-2-902. Definitions, MCA  |  |
| MTS_0520-0020-0090-0030 | 200 | 15564 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0090/section_0030/0520-0020-0090-0030.html |    52-2-903. Parent resource on language developmental milestones -- criteria -- |  |
| MTS_0520-0020-0090-0040 | 200 | 10660 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0090/section_0040/0520-0020-0090-0040.html |    52-2-904. Terminated, MCA  |  |
| MTS_0520-0020-0100-0010 | 200 | 13197 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0100/section_0010/0520-0020-0100-0010.html |    52-2-1001. Montana early childhood account board, MCA  |  |
| MTS_0520-0020-0100-0020 | 200 | 12189 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0100/section_0020/0520-0020-0100-0020.html |    52-2-1002. Montana early childhood account -- nonsupplantation of funds, MCA  |  |
| MTS_0520-0020-0100-0030 | 200 | 14730 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0100/section_0030/0520-0020-0100-0030.html |    52-2-1003. Eligible uses of Montana early childhood account, MCA  |  |
| MTS_0520-0020-0100-0040 | 200 | 11662 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0100/section_0040/0520-0020-0100-0040.html |    52-2-1004. Gifts and grants to programs, MCA  |  |
| MTS_0520-0020-0100-0050 | 200 | 12249 | https://leg.mt.gov/bills/mca/title_0520/chapter_0020/part_0100/section_0050/0520-0020-0100-0050.html |    52-2-1005. Program costs -- annual report, MCA  |  |
| MTS_0520-0030-0010-0010 | 200 | 12284 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0010/section_0010/0520-0030-0010-0010.html |    52-3-101. Functions of department of public health and human services, MCA  |  |
| MTS_0520-0030-0010-0020 | 200 | 11552 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0010/section_0020/0520-0030-0010-0020.html |    52-3-102. Grants and gifts to department, MCA  |  |
| MTS_0520-0030-0010-0030 | 200 | 12325 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0010/section_0030/0520-0030-0010-0030.html |    52-3-103. Designation of area agencies, MCA  |  |
| MTS_0520-0030-0010-0040 | 200 | 10584 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0010/section_0040/0520-0030-0010-0040.html |    52-3-104. through 52-3-110 reserved, MCA  |  |
| MTS_0520-0030-0010-0110 | 200 | 10979 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0010/section_0110/0520-0030-0010-0110.html |    52-3-111. Repealed, MCA  |  |
| MTS_0520-0030-0010-0120 | 200 | 10582 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0010/section_0120/0520-0030-0010-0120.html |    52-3-112. through 52-3-114 reserved, MCA  |  |
| MTS_0520-0030-0010-0150 | 200 | 12339 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0010/section_0150/0520-0030-0010-0150.html |    52-3-115. Older Montanans trust fund, MCA  |  |
| MTS_0520-0030-0020-0010 | 200 | 10676 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0020/section_0010/0520-0030-0020-0010.html |    52-3-201. Short title, MCA  |  |
| MTS_0520-0030-0020-0020 | 200 | 11835 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0020/section_0020/0520-0030-0020-0020.html |    52-3-202. Definitions, MCA  |  |
| MTS_0520-0030-0020-0030 | 200 | 11121 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0020/section_0030/0520-0030-0020-0030.html |    52-3-203. Purpose, MCA  |  |
| MTS_0520-0030-0020-0040 | 200 | 11067 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0020/section_0040/0520-0030-0020-0040.html |    52-3-204. Duties of department, MCA  |  |
| MTS_0520-0030-0020-0050 | 200 | 11094 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0020/section_0050/0520-0030-0020-0050.html |    52-3-205. Departmental authority, MCA  |  |
| MTS_0520-0030-0020-0060 | 200 | 11055 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0020/section_0060/0520-0030-0020-0060.html |    52-3-206. Annual reports, MCA  |  |
| MTS_0520-0030-0020-0070 | 200 | 11655 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0020/section_0070/0520-0030-0020-0070.html |    52-3-207. Protective services not creating guardianship or conservatorship, M |  |
| MTS_0520-0030-0030-0010 | 200 | 10761 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0030/section_0010/0520-0030-0030-0010.html |    52-3-301. Repealed, MCA  |  |
| MTS_0520-0030-0030-0020 | 200 | 11058 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0030/section_0020/0520-0030-0030-0020.html |    52-3-302. Repealed, MCA  |  |
| MTS_0520-0030-0030-0030 | 200 | 11057 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0030/section_0030/0520-0030-0030-0030.html |    52-3-303. Repealed, MCA  |  |
| MTS_0520-0030-0030-0040 | 200 | 11057 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0030/section_0040/0520-0030-0030-0040.html |    52-3-304. Repealed, MCA  |  |
| MTS_0520-0030-0030-0050 | 200 | 11012 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0030/section_0050/0520-0030-0030-0050.html |    52-3-305. Repealed, MCA  |  |
| MTS_0520-0030-0030-0060 | 200 | 10618 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0030/section_0060/0520-0030-0030-0060.html |    52-3-306. through 52-3-310 reserved, MCA  |  |
| MTS_0520-0030-0030-0110 | 200 | 10948 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0030/section_0110/0520-0030-0030-0110.html |    52-3-311. Repealed, MCA  |  |
| MTS_0520-0030-0030-0120 | 200 | 10931 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0030/section_0120/0520-0030-0030-0120.html |    52-3-312. Repealed, MCA  |  |
| MTS_0520-0030-0030-0130 | 200 | 10931 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0030/section_0130/0520-0030-0030-0130.html |    52-3-313. Repealed, MCA  |  |
| MTS_0520-0030-0030-0140 | 200 | 10731 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0030/section_0140/0520-0030-0030-0140.html |    52-3-314. Repealed, MCA  |  |
| MTS_0520-0030-0040-0010 | 200 | 11864 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0040/section_0010/0520-0030-0040-0010.html |    52-3-401. Definitions, MCA  |  |
| MTS_0520-0030-0040-0020 | 200 | 11181 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0040/section_0020/0520-0030-0040-0020.html |    52-3-402. Purpose, MCA  |  |
| MTS_0520-0030-0040-0030 | 200 | 10891 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0040/section_0030/0520-0030-0040-0030.html |    52-3-403. Repealed, MCA  |  |
| MTS_0520-0030-0040-0040 | 200 | 10970 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0040/section_0040/0520-0030-0040-0040.html |    52-3-404. State plan on aging, MCA  |  |
| MTS_0520-0030-0040-0050 | 200 | 11511 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0040/section_0050/0520-0030-0040-0050.html |    52-3-405. Designation of planning and service areas, MCA  |  |
| MTS_0520-0030-0040-0060 | 200 | 10987 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0040/section_0060/0520-0030-0040-0060.html |    52-3-406. Departmental rules, MCA  |  |
| MTS_0520-0030-0040-0070 | 200 | 10596 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0040/section_0070/0520-0030-0040-0070.html |    52-3-407. through 52-3-409 reserved, MCA  |  |
| MTS_0520-0030-0040-0100 | 200 | 11782 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0040/section_0100/0520-0030-0040-0100.html |    52-3-410. Achieving accountability, MCA  |  |
| MTS_0520-0030-0050-0010 | 200 | 10714 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0050/section_0010/0520-0030-0050-0010.html |    52-3-501. Short title, MCA  |  |
| MTS_0520-0030-0050-0020 | 200 | 11429 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0050/section_0020/0520-0030-0050-0020.html |    52-3-502. Definitions, MCA  |  |
| MTS_0520-0030-0050-0030 | 200 | 12817 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0050/section_0030/0520-0030-0050-0030.html |    52-3-503. Purpose and policy, MCA  |  |
| MTS_0520-0030-0050-0040 | 200 | 12409 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0050/section_0040/0520-0030-0050-0040.html |    52-3-504. Services to be provided, MCA  |  |
| MTS_0520-0030-0050-0050 | 200 | 11187 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0050/section_0050/0520-0030-0050-0050.html |    52-3-505. Role of department, MCA  |  |
| MTS_0520-0030-0050-0060 | 200 | 11028 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0050/section_0060/0520-0030-0050-0060.html |    52-3-506. Coordination with federal legislation, MCA  |  |
| MTS_0520-0030-0060-0010 | 200 | 11517 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0060/section_0010/0520-0030-0060-0010.html |    52-3-601. Purpose, MCA  |  |
| MTS_0520-0030-0060-0020 | 200 | 11834 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0060/section_0020/0520-0030-0060-0020.html |    52-3-602. Definitions, MCA  |  |
| MTS_0520-0030-0060-0030 | 200 | 11902 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0060/section_0030/0520-0030-0060-0030.html |    52-3-603. Office of legal and long-term care ombudsman services, MCA  |  |
| MTS_0520-0030-0060-0040 | 200 | 12147 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0060/section_0040/0520-0030-0060-0040.html |    52-3-604. Access to long-term care facilities, MCA  |  |
| MTS_0520-0030-0060-0050 | 200 | 11832 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0060/section_0050/0520-0030-0060-0050.html |    52-3-605. Enforcement of access, MCA  |  |
| MTS_0520-0030-0080-0010 | 200 | 10814 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0010/0520-0030-0080-0010.html |    52-3-801. Short title, MCA  |  |
| MTS_0520-0030-0080-0020 | 200 | 11471 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0020/0520-0030-0080-0020.html |    52-3-802. Legislative findings and purpose, MCA  |  |
| MTS_0520-0030-0080-0030 | 200 | 17506 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0030/0520-0030-0080-0030.html |    52-3-803. Definitions, MCA  |  |
| MTS_0520-0030-0080-0040 | 200 | 14306 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0040/0520-0030-0080-0040.html |    52-3-804. Duties of department, MCA  |  |
| MTS_0520-0030-0080-0050 | 200 | 12547 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0050/0520-0030-0080-0050.html |    52-3-805. Adult protective service teams, MCA  |  |
| MTS_0520-0030-0080-0060 | 200 | 10675 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0060/0520-0030-0080-0060.html |    52-3-806. through 52-3-810 reserved, MCA  |  |
| MTS_0520-0030-0080-0110 | 200 | 15916 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0110/0520-0030-0080-0110.html |    52-3-811. Reports, MCA  |  |
| MTS_0520-0030-0080-0120 | 200 | 12568 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0120/0520-0030-0080-0120.html |    52-3-812. Content of report, MCA  |  |
| MTS_0520-0030-0080-0130 | 200 | 18559 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0130/0520-0030-0080-0130.html |    52-3-813. Confidentiality, MCA  |  |
| MTS_0520-0030-0080-0140 | 200 | 12069 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0140/0520-0030-0080-0140.html |    52-3-814. Immunity from civil and criminal liability, MCA  |  |
| MTS_0520-0030-0080-0150 | 200 | 13237 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0150/0520-0030-0080-0150.html |    52-3-815. Evidence of abuse, sexual abuse, neglect, or exploitation to be gat |  |
| MTS_0520-0030-0080-0160 | 200 | 16261 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0160/0520-0030-0080-0160.html |    52-3-816. County attorney duties -- report to attorney general and legislatur |  |
| MTS_0520-0030-0080-0170 | 200 | 12412 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0170/0520-0030-0080-0170.html |    52-3-817. Department report to attorney general, MCA  |  |
| MTS_0520-0030-0080-0180 | 200 | 10700 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0180/0520-0030-0080-0180.html |    52-3-818. through 52-3-820 reserved, MCA  |  |
| MTS_0520-0030-0080-0210 | 200 | 11624 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0210/0520-0030-0080-0210.html |    52-3-821. Admissibility of evidence, MCA  |  |
| MTS_0520-0030-0080-0220 | 200 | 10671 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0220/0520-0030-0080-0220.html |    52-3-822. through 52-3-824 reserved, MCA  |  |
| MTS_0520-0030-0080-0250 | 200 | 11060 | https://leg.mt.gov/bills/mca/title_0520/chapter_0030/part_0080/section_0250/0520-0030-0080-0250.html |    52-3-825. Repealed, MCA  |  |
| MTS_0520-0040-0010-0010 | 200 | 10871 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0010/section_0010/0520-0040-0010-0010.html |    52-4-101. Repealed, MCA  |  |
| MTS_0520-0040-0010-0020 | 200 | 11105 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0010/section_0020/0520-0040-0010-0020.html |    52-4-102. Repealed, MCA  |  |
| MTS_0520-0040-0010-0030 | 200 | 11104 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0010/section_0030/0520-0040-0010-0030.html |    52-4-103. Repealed, MCA  |  |
| MTS_0520-0040-0010-0040 | 200 | 11105 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0010/section_0040/0520-0040-0010-0040.html |    52-4-104. Repealed, MCA  |  |
| MTS_0520-0040-0010-0050 | 200 | 11073 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0010/section_0050/0520-0040-0010-0050.html |    52-4-105. Repealed, MCA  |  |
| MTS_0520-0040-0010-0060 | 200 | 11042 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0010/section_0060/0520-0040-0010-0060.html |    52-4-106. Repealed, MCA  |  |
| MTS_0520-0040-0010-0070 | 200 | 11075 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0010/section_0070/0520-0040-0010-0070.html |    52-4-107. Repealed, MCA  |  |
| MTS_0520-0040-0010-0080 | 200 | 11079 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0010/section_0080/0520-0040-0010-0080.html |    52-4-108. Repealed, MCA  |  |
| MTS_0520-0040-0010-0090 | 200 | 10592 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0010/section_0090/0520-0040-0010-0090.html |    52-4-109. reserved, MCA  |  |
| MTS_0520-0040-0010-0100 | 200 | 10843 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0010/section_0100/0520-0040-0010-0100.html |    52-4-110. Repealed, MCA  |  |
| MTS_0520-0040-0020-0010 | 200 | 11537 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0020/section_0010/0520-0040-0020-0010.html |    52-4-201. Purpose, MCA  |  |
| MTS_0520-0040-0020-0020 | 200 | 12736 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0020/section_0020/0520-0040-0020-0020.html |    52-4-202. Definitions, MCA  |  |
| MTS_0520-0040-0020-0030 | 200 | 12545 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0020/section_0030/0520-0040-0020-0030.html |    52-4-203. Licensing, MCA  |  |
| MTS_0520-0040-0020-0040 | 200 | 12180 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0020/section_0040/0520-0040-0020-0040.html |    52-4-204. Health and safety standards, MCA  |  |
| MTS_0520-0040-0020-0050 | 200 | 11457 | https://leg.mt.gov/bills/mca/title_0520/chapter_0040/part_0020/section_0050/0520-0040-0020-0050.html |    52-4-205. Rulemaking, MCA  |  |
| MTS_0520-0050-0010-0010 | 200 | 12328 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0010/0520-0050-0010-0010.html |    52-5-101. Establishment of correctional facilities -- prohibitions -- definit |  |
| MTS_0520-0050-0010-0020 | 200 | 12177 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0020/0520-0050-0010-0020.html |    52-5-102. Control and management of youth correctional facilities, MCA  |  |
| MTS_0520-0050-0010-0030 | 200 | 11922 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0030/0520-0050-0010-0030.html |    52-5-103. Cooperative agreements for services with governing body of Indian t |  |
| MTS_0520-0050-0010-0040 | 200 | 11079 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0040/0520-0050-0010-0040.html |    52-5-104. Repealed, MCA  |  |
| MTS_0520-0050-0010-0050 | 200 | 11561 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0050/0520-0050-0010-0050.html |    52-5-105. Superintendents to manage facilities, MCA  |  |
| MTS_0520-0050-0010-0060 | 200 | 11251 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0060/0520-0050-0010-0060.html |    52-5-106. Curricula at facilities, MCA  |  |
| MTS_0520-0050-0010-0070 | 200 | 11315 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0070/0520-0050-0010-0070.html |    52-5-107. Maximum age of commitment, MCA  |  |
| MTS_0520-0050-0010-0080 | 200 | 12189 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0080/0520-0050-0010-0080.html |    52-5-108. Medical examination before admission -- records required to accompa |  |
| MTS_0520-0050-0010-0090 | 200 | 14296 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0090/0520-0050-0010-0090.html |    52-5-109. Transportation costs -- arrangement for transportation, MCA  |  |
| MTS_0520-0050-0010-0100 | 200 | 11628 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0100/0520-0050-0010-0100.html |    52-5-110. Transfer of child to other facility or institution, MCA  |  |
| MTS_0520-0050-0010-0110 | 200 | 14427 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0110/0520-0050-0010-0110.html |    52-5-111. Commutation of sentence to state prison facility and transfer of pr |  |
| MTS_0520-0050-0010-0120 | 200 | 12266 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0120/0520-0050-0010-0120.html |    52-5-112. University aid to residents of schools, MCA  |  |
| MTS_0520-0050-0010-0130 | 200 | 12086 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0130/0520-0050-0010-0130.html |    52-5-113. Publication of information to facilitate return of youth leaving co |  |
| MTS_0520-0050-0010-0140 | 200 | 12469 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0140/0520-0050-0010-0140.html |    52-5-114. Penalty for aiding resident in leaving or not returning to correcti |  |
| MTS_0520-0050-0010-0150 | 200 | 10650 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0150/0520-0050-0010-0150.html |    52-5-115. through 52-5-119 reserved, MCA  |  |
| MTS_0520-0050-0010-0200 | 200 | 12146 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0200/0520-0050-0010-0200.html |    52-5-120. Youth industries programs, MCA  |  |
| MTS_0520-0050-0010-0210 | 200 | 11820 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0210/0520-0050-0010-0210.html |    52-5-121. Rulemaking authority, MCA  |  |
| MTS_0520-0050-0010-0220 | 200 | 10573 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0220/0520-0050-0010-0220.html |    52-5-122. through 52-5-124 reserved, MCA  |  |
| MTS_0520-0050-0010-0250 | 200 | 10916 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0250/0520-0050-0010-0250.html |    52-5-125. Repealed, MCA  |  |
| MTS_0520-0050-0010-0260 | 200 | 12352 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0260/0520-0050-0010-0260.html |    52-5-126. Conditional release agreement, MCA  |  |
| MTS_0520-0050-0010-0270 | 200 | 12021 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0270/0520-0050-0010-0270.html |    52-5-127. Control over youth placed on conditional release, MCA  |  |
| MTS_0520-0050-0010-0280 | 200 | 12252 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0280/0520-0050-0010-0280.html |    52-5-128. Detention of youth who violates conditional release or escapes from |  |
| MTS_0520-0050-0010-0290 | 200 | 11391 | https://leg.mt.gov/bills/mca/title_0520/chapter_0050/part_0010/section_0290/0520-0050-0010-0290.html |    52-5-129. Repealed, MCA  |  |
| MTS_0520-0060-0010-0010 | 200 | 10858 | https://leg.mt.gov/bills/mca/title_0520/chapter_0060/part_0010/section_0010/0520-0060-0010-0010.html |    52-6-101. Repealed, MCA  |  |
| MTS_0520-0060-0010-0020 | 200 | 11061 | https://leg.mt.gov/bills/mca/title_0520/chapter_0060/part_0010/section_0020/0520-0060-0010-0020.html |    52-6-102. Repealed, MCA  |  |
| MTS_0520-0060-0010-0030 | 200 | 11093 | https://leg.mt.gov/bills/mca/title_0520/chapter_0060/part_0010/section_0030/0520-0060-0010-0030.html |    52-6-103. Repealed, MCA  |  |
| MTS_0520-0060-0010-0040 | 200 | 11092 | https://leg.mt.gov/bills/mca/title_0520/chapter_0060/part_0010/section_0040/0520-0060-0010-0040.html |    52-6-104. Repealed, MCA  |  |
| MTS_0520-0060-0010-0050 | 200 | 10985 | https://leg.mt.gov/bills/mca/title_0520/chapter_0060/part_0010/section_0050/0520-0060-0010-0050.html |    52-6-105. Repealed, MCA  |  |
| MTS_0520-0070-0010-0010 | 200 | 12575 | https://leg.mt.gov/bills/mca/title_0520/chapter_0070/part_0010/section_0010/0520-0070-0010-0010.html |    52-7-101. Child abuse and neglect prevention program, MCA  |  |
| MTS_0520-0070-0010-0020 | 200 | 12226 | https://leg.mt.gov/bills/mca/title_0520/chapter_0070/part_0010/section_0020/0520-0070-0010-0020.html |    52-7-102. Children's trust fund account -- nonsupplantation of funds, MCA  |  |
| MTS_0520-0070-0010-0030 | 200 | 11382 | https://leg.mt.gov/bills/mca/title_0520/chapter_0070/part_0010/section_0030/0520-0070-0010-0030.html |    52-7-103. Gifts and grants to program, MCA  |  |
| MTS_0520-0070-0010-0040 | 200 | 11427 | https://leg.mt.gov/bills/mca/title_0520/chapter_0070/part_0010/section_0040/0520-0070-0010-0040.html |    52-7-104. Program costs, MCA  |  |
| MTS_0520-0070-0010-0050 | 200 | 11890 | https://leg.mt.gov/bills/mca/title_0520/chapter_0070/part_0010/section_0050/0520-0070-0010-0050.html |    52-7-105. Endowment for children, MCA  |  |
| MTS_0520-0080-0010-0010 | 200 | 11859 | https://leg.mt.gov/bills/mca/title_0520/chapter_0080/part_0010/section_0010/0520-0080-0010-0010.html |    52-8-101. Definitions, MCA  |  |
| MTS_0520-0080-0010-0020 | 200 | 11620 | https://leg.mt.gov/bills/mca/title_0520/chapter_0080/part_0010/section_0020/0520-0080-0010-0020.html |    52-8-102. General duties of department, MCA  |  |
| MTS_0520-0080-0010-0030 | 200 | 13288 | https://leg.mt.gov/bills/mca/title_0520/chapter_0080/part_0010/section_0030/0520-0080-0010-0030.html |    52-8-103. License required -- exception -- term of license -- no fee charged, |  |
| MTS_0520-0080-0010-0040 | 200 | 13776 | https://leg.mt.gov/bills/mca/title_0520/chapter_0080/part_0010/section_0040/0520-0080-0010-0040.html |    52-8-104. Requirements for licensure, MCA  |  |
| MTS_0520-0080-0010-0050 | 200 | 10625 | https://leg.mt.gov/bills/mca/title_0520/chapter_0080/part_0010/section_0050/0520-0080-0010-0050.html |    52-8-105. and 52-8-106 reserved, MCA  |  |
| MTS_0520-0080-0010-0070 | 200 | 11957 | https://leg.mt.gov/bills/mca/title_0520/chapter_0080/part_0010/section_0070/0520-0080-0010-0070.html |    52-8-107. Investigation of agencies -- cancellation of licenses, MCA  |  |
| MTS_0520-0080-0010-0080 | 200 | 11842 | https://leg.mt.gov/bills/mca/title_0520/chapter_0080/part_0010/section_0080/0520-0080-0010-0080.html |    52-8-108. Violation a misdemeanor -- penalty, MCA  |  |
| MTS_0530-0010-0010-0010 | 200 | 10852 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0010/section_0010/0530-0010-0010-0010.html |    53-1-101. Repealed, MCA  |  |
| MTS_0530-0010-0010-0020 | 200 | 12147 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0010/section_0020/0530-0010-0010-0020.html |    53-1-102. Removal of patients from state custodial institutions or correction |  |
| MTS_0530-0010-0010-0030 | 200 | 12201 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0010/section_0030/0530-0010-0010-0030.html |    53-1-103. Distribution of alcoholic beverages or drugs to patients at state c |  |
| MTS_0530-0010-0010-0040 | 200 | 12707 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0010/section_0040/0530-0010-0010-0040.html |    53-1-104. Release of arsonist -- notification of department of justice, MCA  |  |
| MTS_0530-0010-0010-0050 | 200 | 11755 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0010/section_0050/0530-0010-0010-0050.html |    53-1-105. Disposition of contraband in correctional institution, MCA  |  |
| MTS_0530-0010-0010-0060 | 200 | 11560 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0010/section_0060/0530-0010-0010-0060.html |    53-1-106. Exchange of offenders under treaty, MCA  |  |
| MTS_0530-0010-0010-0070 | 200 | 22643 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0010/section_0070/0530-0010-0010-0070.html |    53-1-107. Inmate financial transactions and trust account system, MCA  |  |
| MTS_0530-0010-0010-0080 | 200 | 12450 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0010/section_0080/0530-0010-0010-0080.html |    53-1-108. Inmate financial disclosure and account monitoring, MCA  |  |
| MTS_0530-0010-0010-0090 | 200 | 12829 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0010/section_0090/0530-0010-0010-0090.html |    53-1-109. Facility resident and prison inmate welfare account, MCA  |  |
| MTS_0530-0010-0010-0100 | 200 | 13910 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0010/section_0100/0530-0010-0010-0100.html |    53-1-110. Disposition of inmate trust account funds and tangible personal pro |  |
| MTS_0530-0010-0020-0010 | 200 | 11807 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0010/0530-0010-0020-0010.html |    53-1-201. Purpose of department of corrections, MCA  |  |
| MTS_0530-0010-0020-0020 | 200 | 16065 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0020/0530-0010-0020-0020.html |    53-1-202. Department of corrections, MCA  |  |
| MTS_0530-0010-0020-0030 | 200 | 22712 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0030/0530-0010-0020-0030.html |    53-1-203. Powers and duties of department of corrections, MCA  |  |
| MTS_0530-0010-0020-0040 | 200 | 11432 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0040/0530-0010-0020-0040.html |    53-1-204. Responsibility of warden and superintendents of institutions, MCA  |  |
| MTS_0530-0010-0020-0050 | 200 | 10985 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0050/0530-0010-0020-0050.html |    53-1-205. Repealed, MCA  |  |
| MTS_0530-0010-0020-0060 | 200 | 12030 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0060/0530-0010-0020-0060.html |    53-1-206. Participation by institutions in research programs, MCA  |  |
| MTS_0530-0010-0020-0070 | 200 | 11953 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0070/0530-0010-0020-0070.html |    53-1-207. Authorization of inmate labor for designated construction projects  |  |
| MTS_0530-0010-0020-0080 | 200 | 11438 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0080/0530-0010-0020-0080.html |    53-1-208. Payment to Powell County, MCA  |  |
| MTS_0530-0010-0020-0090 | 200 | 11096 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0090/0530-0010-0020-0090.html |    53-1-209. Allowed purpose, MCA  |  |
| MTS_0530-0010-0020-0100 | 200 | 11697 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0100/0530-0010-0020-0100.html |    53-1-210. Transfer of property -- allowed purpose, MCA  |  |
| MTS_0530-0010-0020-0110 | 200 | 14758 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0110/0530-0010-0020-0110.html |    53-1-211. Quality assurance unit -- program standards -- evaluation -- cooper |  |
| MTS_0530-0010-0020-0120 | 200 | 10856 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0120/0530-0010-0020-0120.html |    53-1-212. and 53-1-213 reserved, MCA  |  |
| MTS_0530-0010-0020-0140 | 200 | 14340 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0140/0530-0010-0020-0140.html |    53-1-214. Educational aid to wrongfully convicted persons exonerated by postc |  |
| MTS_0530-0010-0020-0150 | 200 | 10954 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0150/0530-0010-0020-0150.html |    53-1-215. Terminated, MCA  |  |
| MTS_0530-0010-0020-0160 | 200 | 10672 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0160/0530-0010-0020-0160.html |    53-1-216. Renumbered 5-5-235, MCA  |  |
| MTS_0530-0010-0020-0170 | 200 | 10879 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0020/section_0170/0530-0010-0020-0170.html |    53-1-217. Recidivism, MCA  |  |
| MTS_0530-0010-0030-0010 | 200 | 11022 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0030/section_0010/0530-0010-0030-0010.html |    53-1-301. Repealed, MCA  |  |
| MTS_0530-0010-0030-0020 | 200 | 11104 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0030/section_0020/0530-0010-0030-0020.html |    53-1-302. Repealed, MCA  |  |
| MTS_0530-0010-0030-0030 | 200 | 11001 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0030/section_0030/0530-0010-0030-0030.html |    53-1-303. Repealed, MCA  |  |
| MTS_0530-0010-0030-0040 | 200 | 10778 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0030/section_0040/0530-0010-0030-0040.html |    53-1-304. Repealed, MCA  |  |
| MTS_0530-0010-0040-0010 | 200 | 16308 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0010/0530-0010-0040-0010.html |    53-1-401. Definitions, MCA  |  |
| MTS_0530-0010-0040-0020 | 200 | 13724 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0020/0530-0010-0040-0020.html |    53-1-402. Residents and financially responsible persons liable for cost of ca |  |
| MTS_0530-0010-0040-0030 | 200 | 11323 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0030/0530-0010-0040-0030.html |    53-1-403. Rules, MCA  |  |
| MTS_0530-0010-0040-0040 | 200 | 11749 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0040/0530-0010-0040-0040.html |    53-1-404. Department to review and establish per diem charge, MCA  |  |
| MTS_0530-0010-0040-0050 | 200 | 18477 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0050/0530-0010-0040-0050.html |    53-1-405. Monthly payment amount, MCA  |  |
| MTS_0530-0010-0040-0060 | 200 | 15682 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0060/0530-0010-0040-0060.html |    53-1-406. Investigation of ability to pay, MCA  |  |
| MTS_0530-0010-0040-0070 | 200 | 11587 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0070/0530-0010-0040-0070.html |    53-1-407. Appeal of determination of ability to pay, MCA  |  |
| MTS_0530-0010-0040-0080 | 200 | 13304 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0080/0530-0010-0040-0080.html |    53-1-408. Periodic review by department of ability to pay, MCA  |  |
| MTS_0530-0010-0040-0090 | 200 | 13137 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0090/0530-0010-0040-0090.html |    53-1-409. Limitations on liability of resident or financially responsible per |  |
| MTS_0530-0010-0040-0100 | 200 | 11662 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0100/0530-0010-0040-0100.html |    53-1-410. Nonpayment not grounds for discharge, MCA  |  |
| MTS_0530-0010-0040-0110 | 200 | 12189 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0110/0530-0010-0040-0110.html |    53-1-411. Collections from residents and financially responsible persons, MCA |  |
| MTS_0530-0010-0040-0120 | 200 | 12975 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0120/0530-0010-0040-0120.html |    53-1-412. Collections from estates, MCA  |  |
| MTS_0530-0010-0040-0130 | 200 | 12364 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0130/0530-0010-0040-0130.html |    53-1-413. Deposit of payments and collections, MCA  |  |
| MTS_0530-0010-0040-0140 | 200 | 12988 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0040/section_0140/0530-0010-0040-0140.html |    53-1-414. Automatic assignment of resident's resources from third party, MCA  |  |
| MTS_0530-0010-0050-0010 | 200 | 12489 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0050/section_0010/0530-0010-0050-0010.html |    53-1-501. Rates for residential community correctional program board, room, a |  |
| MTS_0530-0010-0050-0020 | 200 | 11828 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0050/section_0020/0530-0010-0050-0020.html |    53-1-502. Rates for board, room, and ancillary services charged to correction |  |
| MTS_0530-0010-0060-0010 | 200 | 11809 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0060/section_0010/0530-0010-0060-0010.html |    53-1-601. Purpose of department of public health and human services, MCA  |  |
| MTS_0530-0010-0060-0020 | 200 | 13502 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0060/section_0020/0530-0010-0060-0020.html |    53-1-602. Department of public health and human services, MCA  |  |
| MTS_0530-0010-0060-0030 | 200 | 12947 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0060/section_0030/0530-0010-0060-0030.html |    53-1-603. Powers and duties of department of public health and human services |  |
| MTS_0530-0010-0060-0040 | 200 | 11389 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0060/section_0040/0530-0010-0060-0040.html |    53-1-604. Responsibility of superintendents of institutions, MCA  |  |
| MTS_0530-0010-0060-0050 | 200 | 10791 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0060/section_0050/0530-0010-0060-0050.html |    53-1-605. through 53-1-609 reserved, MCA  |  |
| MTS_0530-0010-0060-0100 | 200 | 11773 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0060/section_0100/0530-0010-0060-0100.html |    53-1-610. Refinancing by department, MCA  |  |
| MTS_0530-0010-0060-0110 | 200 | 13346 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0060/section_0110/0530-0010-0060-0110.html |    53-1-611. Evaluation of proposed medicaid block grant and acceptance of grant |  |
| MTS_0530-0010-0060-0120 | 200 | 12557 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0060/section_0120/0530-0010-0060-0120.html |    53-1-612. Use of funding obtained by refinancing, MCA  |  |
| MTS_0530-0010-0070-0010 | 200 | 12816 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0070/section_0010/0530-0010-0070-0010.html |    53-1-701. Findings -- purpose, MCA  |  |
| MTS_0530-0010-0070-0020 | 200 | 11100 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0070/section_0020/0530-0010-0070-0020.html |    53-1-702. Statewide 2-1-1 system, MCA  |  |
| MTS_0530-0010-0070-0030 | 200 | 11746 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0070/section_0030/0530-0010-0070-0030.html |    53-1-703. Definitions, MCA  |  |
| MTS_0530-0010-0070-0040 | 200 | 10887 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0070/section_0040/0530-0010-0070-0040.html |    53-1-704. Repealed, MCA  |  |
| MTS_0530-0010-0070-0050 | 200 | 11922 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0070/section_0050/0530-0010-0070-0050.html |    53-1-705. New public information services -- state agencies, MCA  |  |
| MTS_0530-0010-0070-0060 | 200 | 10726 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0070/section_0060/0530-0010-0070-0060.html |    53-1-706. through 53-1-709 reserved, MCA  |  |
| MTS_0530-0010-0070-0100 | 200 | 12370 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0070/section_0100/0530-0010-0070-0100.html |    53-1-710. Approved 2-1-1 service providers, MCA  |  |
| MTS_0530-0010-0070-0110 | 200 | 12773 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0070/section_0110/0530-0010-0070-0110.html |    53-1-711. Scope of 2-1-1 service, MCA  |  |
| MTS_0530-0010-0070-0120 | 200 | 11548 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0070/section_0120/0530-0010-0070-0120.html |    53-1-712. State special revenue fund 2-1-1 account, MCA  |  |
| MTS_0530-0010-0070-0130 | 200 | 12654 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0070/section_0130/0530-0010-0070-0130.html |    53-1-713. Eligible activities, MCA  |  |
| MTS_0530-0010-0070-0140 | 200 | 10655 | https://leg.mt.gov/bills/mca/title_0530/chapter_0010/part_0070/section_0140/0530-0010-0070-0140.html |    53-1-714. Repealed, MCA  |  |
| MTS_0530-0020-0010-0010 | 200 | 13055 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0010/section_0010/0530-0020-0010-0010.html |    53-2-101. Definitions, MCA  |  |
| MTS_0530-0020-0010-0020 | 200 | 11372 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0010/section_0020/0530-0020-0010-0020.html |    53-2-102. State treasurer to receive funds, MCA  |  |
| MTS_0530-0020-0010-0030 | 200 | 11540 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0010/section_0030/0530-0020-0010-0030.html |    53-2-103. Records and reports, MCA  |  |
| MTS_0530-0020-0010-0040 | 200 | 11221 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0010/section_0040/0530-0020-0010-0040.html |    53-2-104. Audit of public assistance records, MCA  |  |
| MTS_0530-0020-0010-0050 | 200 | 11897 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0010/section_0050/0530-0020-0010-0050.html |    53-2-105. Misuse of public assistance information unlawful, MCA  |  |
| MTS_0530-0020-0010-0060 | 200 | 11809 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0010/section_0060/0530-0020-0010-0060.html |    53-2-106. Penalty for misuse of public assistance information, MCA  |  |
| MTS_0530-0020-0010-0070 | 200 | 11617 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0010/section_0070/0530-0020-0010-0070.html |    53-2-107. Fraudulent obtaining of public assistance treated as theft, MCA  |  |
| MTS_0530-0020-0010-0080 | 200 | 13390 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0010/section_0080/0530-0020-0010-0080.html |    53-2-108. Overpayment of assistance -- department errors involving food stamp |  |
| MTS_0530-0020-0010-0090 | 200 | 11633 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0010/section_0090/0530-0020-0010-0090.html |    53-2-109. Recipients to report changes in factors affecting eligibility, MCA  |  |
| MTS_0530-0020-0010-0100 | 200 | 11440 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0010/section_0100/0530-0020-0010-0100.html |    53-2-110. Payment of debts to department, MCA  |  |
| MTS_0530-0020-0010-0110 | 200 | 12595 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0010/section_0110/0530-0020-0010-0110.html |    53-2-111. Coordination of certain workforce development programs -- requireme |  |
| MTS_0530-0020-0010-0120 | 200 | 11748 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0010/section_0120/0530-0020-0010-0120.html |    53-2-112. Department of public health and human services to investigate repor |  |
| MTS_0530-0020-0020-0010 | 200 | 14751 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0010/0530-0020-0020-0010.html |    53-2-201. Powers and duties of department, MCA  |  |
| MTS_0530-0020-0020-0020 | 200 | 11515 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0020/0530-0020-0020-0020.html |    53-2-202. Attorney general to act as legal adviser to department, MCA  |  |
| MTS_0530-0020-0020-0030 | 200 | 11375 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0030/0530-0020-0020-0030.html |    53-2-203. Department to supervise public assistance personnel, MCA  |  |
| MTS_0530-0020-0020-0040 | 200 | 10834 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0040/0530-0020-0020-0040.html |    53-2-204. Renumbered 52-1-104, MCA  |  |
| MTS_0530-0020-0020-0050 | 200 | 11830 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0050/0530-0020-0020-0050.html |    53-2-205. Department authorized to establish and collect social services fees |  |
| MTS_0530-0020-0020-0060 | 200 | 11747 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0060/0530-0020-0020-0060.html |    53-2-206. Department to act as agent of federal government, MCA  |  |
| MTS_0530-0020-0020-0070 | 200 | 11834 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0070/0530-0020-0020-0070.html |    53-2-207. Power of department in administering state and federal funds, MCA  |  |
| MTS_0530-0020-0020-0080 | 200 | 11017 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0080/0530-0020-0020-0080.html |    53-2-208. Terminated, MCA  |  |
| MTS_0530-0020-0020-0090 | 200 | 14905 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0090/0530-0020-0020-0090.html |    53-2-209. Olmstead plan -- stakeholder involvement -- elements, MCA  |  |
| MTS_0530-0020-0020-0100 | 200 | 10684 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0100/0530-0020-0020-0100.html |    53-2-210. reserved, MCA  |  |
| MTS_0530-0020-0020-0110 | 200 | 14150 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0110/0530-0020-0020-0110.html |    53-2-211. Department to share eligibility data, MCA  |  |
| MTS_0530-0020-0020-0120 | 200 | 14805 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0120/0530-0020-0020-0120.html |    53-2-212. Rate adequacy -- plan for collection of data -- reports, MCA  |  |
| MTS_0530-0020-0020-0130 | 200 | 10785 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0130/0530-0020-0020-0130.html |    53-2-213. and 53-2-214 reserved, MCA  |  |
| MTS_0530-0020-0020-0150 | 200 | 32007 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0150/0530-0020-0020-0150.html |    53-2-215. Social Security Act section 1115 waiver, MCA  |  |
| MTS_0530-0020-0020-0160 | 200 | 10943 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0160/0530-0020-0020-0160.html |    53-2-216. Repealed, MCA  |  |
| MTS_0530-0020-0020-0170 | 200 | 10712 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0020/section_0170/0530-0020-0020-0170.html |    53-2-217. Repealed, MCA  |  |
| MTS_0530-0020-0030-0010 | 200 | 11456 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0010/0530-0020-0030-0010.html |    53-2-301. Local offices of public assistance to be established by department, |  |
| MTS_0530-0020-0030-0020 | 200 | 11099 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0020/0530-0020-0030-0020.html |    53-2-302. Repealed, MCA  |  |
| MTS_0530-0020-0030-0030 | 200 | 11005 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0030/0530-0020-0030-0030.html |    53-2-303. Repealed, MCA  |  |
| MTS_0530-0020-0030-0040 | 200 | 11617 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0040/0530-0020-0030-0040.html |    53-2-304. Staff of public assistance program, MCA  |  |
| MTS_0530-0020-0030-0050 | 200 | 11654 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0050/0530-0020-0030-0050.html |    53-2-305. Local offices of public assistance under supervision of department, |  |
| MTS_0530-0020-0030-0060 | 200 | 11133 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0060/0530-0020-0030-0060.html |    53-2-306. Repealed, MCA  |  |
| MTS_0530-0020-0030-0070 | 200 | 11079 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0070/0530-0020-0030-0070.html |    53-2-307. Repealed, MCA  |  |
| MTS_0530-0020-0030-0080 | 200 | 10902 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0080/0530-0020-0030-0080.html |    53-2-308. Repealed, MCA  |  |
| MTS_0530-0020-0030-0090 | 200 | 11242 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0090/0530-0020-0030-0090.html |    53-2-309. Repealed, MCA  |  |
| MTS_0530-0020-0030-0100 | 200 | 11259 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0100/0530-0020-0030-0100.html |    53-2-310. Repealed, MCA  |  |
| MTS_0530-0020-0030-0110 | 200 | 10691 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0110/0530-0020-0030-0110.html |    53-2-311. through 53-2-320 reserved, MCA  |  |
| MTS_0530-0020-0030-0210 | 200 | 11174 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0210/0530-0020-0030-0210.html |    53-2-321. Repealed, MCA  |  |
| MTS_0530-0020-0030-0220 | 200 | 11452 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0220/0530-0020-0030-0220.html |    53-2-322. Repealed, MCA  |  |
| MTS_0530-0020-0030-0230 | 200 | 11102 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0030/section_0230/0530-0020-0030-0230.html |    53-2-323. Repealed, MCA  |  |
| MTS_0530-0020-0040-0010 | 200 | 10757 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0040/section_0010/0530-0020-0040-0010.html |    53-2-401. Repealed, MCA  |  |
| MTS_0530-0020-0040-0020 | 200 | 10960 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0040/section_0020/0530-0020-0040-0020.html |    53-2-402. Repealed, MCA  |  |
| MTS_0530-0020-0040-0030 | 200 | 11007 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0040/section_0030/0530-0020-0040-0030.html |    53-2-403. Repealed, MCA  |  |
| MTS_0530-0020-0040-0040 | 200 | 10992 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0040/section_0040/0530-0020-0040-0040.html |    53-2-404. Repealed, MCA  |  |
| MTS_0530-0020-0040-0050 | 200 | 10960 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0040/section_0050/0530-0020-0040-0050.html |    53-2-405. Repealed, MCA  |  |
| MTS_0530-0020-0040-0060 | 200 | 10928 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0040/section_0060/0530-0020-0040-0060.html |    53-2-406. Repealed, MCA  |  |
| MTS_0530-0020-0040-0070 | 200 | 10960 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0040/section_0070/0530-0020-0040-0070.html |    53-2-407. Repealed, MCA  |  |
| MTS_0530-0020-0040-0080 | 200 | 10760 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0040/section_0080/0530-0020-0040-0080.html |    53-2-408. Repealed, MCA  |  |
| MTS_0530-0020-0050-0010 | 200 | 12291 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0050/section_0010/0530-0020-0050-0010.html |    53-2-501. Investigations and enforcement actions by department of justice, MC |  |
| MTS_0530-0020-0050-0020 | 200 | 11432 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0050/section_0020/0530-0020-0050-0020.html |    53-2-502. Cooperation of governmental agencies with department of justice, MC |  |
| MTS_0530-0020-0050-0030 | 200 | 12010 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0050/section_0030/0530-0020-0050-0030.html |    53-2-503. Information made available to department of justice, MCA  |  |
| MTS_0530-0020-0050-0040 | 200 | 12302 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0050/section_0040/0530-0020-0050-0040.html |    53-2-504. Unauthorized disclosure of information obtained in department of ju |  |
| MTS_0530-0020-0050-0050 | 200 | 10968 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0050/section_0050/0530-0020-0050-0050.html |    53-2-505. Rulemaking authority of department of justice, MCA  |  |
| MTS_0530-0020-0060-0010 | 200 | 10928 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0010/0530-0020-0060-0010.html |    53-2-601. Repealed, MCA  |  |
| MTS_0530-0020-0060-0020 | 200 | 11403 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0020/0530-0020-0060-0020.html |    53-2-602. Grants based on need, MCA  |  |
| MTS_0530-0020-0060-0030 | 200 | 11976 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0030/0530-0020-0060-0030.html |    53-2-603. Award of public assistance after eligibility determination, MCA  |  |
| MTS_0530-0020-0060-0040 | 200 | 11046 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0040/0530-0020-0060-0040.html |    53-2-604. Repealed, MCA  |  |
| MTS_0530-0020-0060-0050 | 200 | 11114 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0050/0530-0020-0060-0050.html |    53-2-605. Repealed, MCA  |  |
| MTS_0530-0020-0060-0060 | 200 | 12642 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0060/0530-0020-0060-0060.html |    53-2-606. Right of appeal, MCA  |  |
| MTS_0530-0020-0060-0070 | 200 | 11952 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0070/0530-0020-0060-0070.html |    53-2-607. Assistance not assignable or subject to legal process -- exceptions |  |
| MTS_0530-0020-0060-0080 | 200 | 12581 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0080/0530-0020-0060-0080.html |    53-2-608. Method of issuing assistance grants, MCA  |  |
| MTS_0530-0020-0060-0090 | 200 | 11599 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0090/0530-0020-0060-0090.html |    53-2-609. Revocation of assistance, MCA  |  |
| MTS_0530-0020-0060-0100 | 200 | 11812 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0100/0530-0020-0060-0100.html |    53-2-610. Repealed, MCA  |  |
| MTS_0530-0020-0060-0110 | 200 | 11255 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0110/0530-0020-0060-0110.html |    53-2-611. Repealed, MCA  |  |
| MTS_0530-0020-0060-0120 | 200 | 21883 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0120/0530-0020-0060-0120.html |    53-2-612. Lien of department upon third-party recoveries, MCA  |  |
| MTS_0530-0020-0060-0130 | 200 | 17214 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0060/section_0130/0530-0020-0060-0130.html |    53-2-613. Application for assistance -- assignment of support rights, MCA  |  |
| MTS_0530-0020-0070-0010 | 200 | 10711 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0070/section_0010/0530-0020-0070-0010.html |    53-2-701. Repealed, MCA  |  |
| MTS_0530-0020-0070-0020 | 200 | 10914 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0070/section_0020/0530-0020-0070-0020.html |    53-2-702. Repealed, MCA  |  |
| MTS_0530-0020-0070-0030 | 200 | 10914 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0070/section_0030/0530-0020-0070-0030.html |    53-2-703. Repealed, MCA  |  |
| MTS_0530-0020-0070-0040 | 200 | 10914 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0070/section_0040/0530-0020-0070-0040.html |    53-2-704. Repealed, MCA  |  |
| MTS_0530-0020-0070-0050 | 200 | 10914 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0070/section_0050/0530-0020-0070-0050.html |    53-2-705. Repealed, MCA  |  |
| MTS_0530-0020-0070-0060 | 200 | 10946 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0070/section_0060/0530-0020-0070-0060.html |    53-2-706. Repealed, MCA  |  |
| MTS_0530-0020-0070-0070 | 200 | 10914 | https://leg.mt.gov/bills/mca/title_0530/chapter_0020/part_0070/section_0070/0530-0020-0070-0070.html |    53-2-707. Repealed, MCA  |  |
