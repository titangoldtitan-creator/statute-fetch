| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| RIS_20_20-4_20-4-8 | 200 | 4165 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-8.htm |  |  |
| RIS_20_20-4_20-4-9 | 200 | 4314 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-9.htm |  |  |
| RIS_20_20-4_20-4-10 | 200 | 4564 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-10.htm |  |  |
| RIS_20_20-4_20-4-11 | 200 | 3826 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-11.htm |  | render-thin 235 |
| RIS_20_20-4_20-4-12 | 200 | 5851 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-12.htm |  |  |
| RIS_20_20-4_20-4-13 | 200 | 4292 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-13.htm |  |  |
| RIS_20_20-4_20-4-14 | 200 | 8445 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4/20-4-14.htm |  |  |
| RIS_20_20-4.1_20-4.1-1 | 200 | 4995 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4.1/20-4.1-1.htm |  |  |
| RIS_20_20-4.1_20-4.1-2 | 200 | 3971 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4.1/20-4.1-2.htm |  |  |
| RIS_20_20-4.1_20-4.1-3 | 200 | 4740 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-4.1/20-4.1-3.htm |  |  |
| RIS_20_20-5_20-5-1 | 200 | 4263 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-1.htm |  |  |
| RIS_20_20-5_20-5-2 | 200 | 4339 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-2.htm |  |  |
| RIS_20_20-5_20-5-3 | 200 | 4488 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-3.htm |  |  |
| RIS_20_20-5_20-5-4 | 200 | 4615 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-4.htm |  |  |
| RIS_20_20-5_20-5-5 | 200 | 7336 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-5.htm |  |  |
| RIS_20_20-5_20-5-6 | 200 | 4540 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-6.htm |  |  |
| RIS_20_20-5_20-5-7 | 200 | 4021 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-7.htm |  |  |
| RIS_20_20-5_20-5-8 | 200 | 4377 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-8.htm |  |  |
| RIS_20_20-5_20-5-9 | 200 | 4537 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-9.htm |  |  |
| RIS_20_20-5_20-5-10 | 200 | 4433 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-10.htm |  |  |
| RIS_20_20-5_20-5-11 | 200 | 4229 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-11.htm |  |  |
| RIS_20_20-5_20-5-12 | 200 | 4258 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-12.htm |  |  |
| RIS_20_20-5_20-5-13 | 200 | 4720 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-13.htm |  |  |
| RIS_20_20-5_20-5-14 | 200 | 4929 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-14.htm |  |  |
| RIS_20_20-5_20-5-15 | 200 | 5421 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-15.htm |  |  |
| RIS_20_20-5_20-5-16 | 200 | 4168 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-16.htm |  |  |
| RIS_20_20-5_20-5-17 | 200 | 4077 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-17.htm |  |  |
| RIS_20_20-5_20-5-18 | 200 | 4160 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-18.htm |  |  |
| RIS_20_20-5_20-5-19 | 200 | 4380 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-19.htm |  |  |
| RIS_20_20-5_20-5-20 | 200 | 4276 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-20.htm |  |  |
| RIS_20_20-5_20-5-21 | 200 | 4081 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-21.htm |  |  |
| RIS_20_20-5_20-5-22 | 200 | 4109 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-5/20-5-22.htm |  |  |
| RIS_20_20-6_20-6-1 | 200 | 4381 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-1.htm |  |  |
| RIS_20_20-6_20-6-2 | 200 | 4502 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-2.htm |  |  |
| RIS_20_20-6_20-6-3 | 200 | 4471 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-3.htm |  |  |
| RIS_20_20-6_20-6-4 | 200 | 4265 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-4.htm |  |  |
| RIS_20_20-6_20-6-5 | 200 | 4143 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-5.htm |  |  |
| RIS_20_20-6_20-6-6 | 200 | 4226 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-6.htm |  |  |
| RIS_20_20-6_20-6-7 | 200 | 6709 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-7.htm |  |  |
| RIS_20_20-6_20-6-8 | 200 | 4372 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-8.htm |  |  |
| RIS_20_20-6_20-6-9 | 200 | 4264 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-9.htm |  |  |
| RIS_20_20-6_20-6-10 | 200 | 4787 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-10.htm |  |  |
| RIS_20_20-6_20-6-11 | 200 | 6811 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-11.htm |  |  |
| RIS_20_20-6_20-6-12 | 200 | 4466 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-12.htm |  |  |
| RIS_20_20-6_20-6-13 | 200 | 5107 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-13.htm |  |  |
| RIS_20_20-6_20-6-14 | 200 | 4144 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-14.htm |  |  |
| RIS_20_20-6_20-6-15 | 200 | 4206 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-15.htm |  |  |
| RIS_20_20-6_20-6-16 | 200 | 4152 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-16.htm |  |  |
| RIS_20_20-6_20-6-17 | 200 | 4418 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-17.htm |  |  |
| RIS_20_20-6_20-6-18 | 200 | 4219 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-18.htm |  |  |
| RIS_20_20-6_20-6-19 | 200 | 4330 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-19.htm |  |  |
| RIS_20_20-6_20-6-20 | 200 | 4126 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-20.htm |  |  |
| RIS_20_20-6_20-6-21 | 200 | 3988 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-21.htm |  |  |
| RIS_20_20-6_20-6-22 | 200 | 4007 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-22.htm |  |  |
| RIS_20_20-6_20-6-23 | 200 | 4364 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-23.htm |  |  |
| RIS_20_20-6_20-6-24 | 200 | 3850 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-24.htm |  | render-thin 258 |
| RIS_20_20-6_20-6-25 | 200 | 4624 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-25.htm |  |  |
| RIS_20_20-6_20-6-26 | 200 | 4226 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-26.htm |  |  |
| RIS_20_20-6_20-6-27 | 200 | 4016 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-27.htm |  |  |
| RIS_20_20-6_20-6-28 | 200 | 4390 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-28.htm |  |  |
| RIS_20_20-6_20-6-29 | 200 | 4114 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-29.htm |  |  |
| RIS_20_20-6_20-6-30 | 200 | 4334 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-6/20-6-30.htm |  |  |
| RIS_20_20-7_20-7-1 | 200 | 4352 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-1.htm |  |  |
| RIS_20_20-7_20-7-2 | 200 | 4052 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-2.htm |  |  |
| RIS_20_20-7_20-7-3 | 200 | 4049 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-3.htm |  |  |
| RIS_20_20-7_20-7-4 | 200 | 4170 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-4.htm |  |  |
| RIS_20_20-7_20-7-5 | 200 | 4253 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-5.htm |  |  |
| RIS_20_20-7_20-7-5.1 | 200 | 3830 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-5.1.htm |  | render-thin 240 |
| RIS_20_20-7_20-7-6 | 200 | 4387 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-6.htm |  |  |
| RIS_20_20-7_20-7-7 | 200 | 6299 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-7.htm |  |  |
| RIS_20_20-7_20-7-7.1 | 200 | 7158 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-7.1.htm |  |  |
| RIS_20_20-7_20-7-8 | 200 | 4229 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-8.htm |  |  |
| RIS_20_20-7_20-7-9 | 200 | 4395 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-9.htm |  |  |
| RIS_20_20-7_20-7-10 | 200 | 6690 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-10.htm |  |  |
| RIS_20_20-7_20-7-11 | 200 | 6946 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-11.htm |  |  |
| RIS_20_20-7_20-7-11.1 | 200 | 7557 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-11.1.htm |  |  |
| RIS_20_20-7_20-7-12 | 200 | 4513 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-12.htm |  |  |
| RIS_20_20-7_20-7-12.1 | 200 | 4894 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-12.1.htm |  |  |
| RIS_20_20-7_20-7-13 | 200 | 4682 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-13.htm |  |  |
| RIS_20_20-7_20-7-14 | 200 | 5557 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-14.htm |  |  |
| RIS_20_20-7_20-7-15 | 200 | 4320 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-15.htm |  |  |
| RIS_20_20-7_20-7-16 | 200 | 4374 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-16.htm |  |  |
| RIS_20_20-7_20-7-17 | 200 | 3934 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-7/20-7-17.htm |  |  |
| RIS_20_20-8_20-8-1 | 200 | 18794 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8/20-8-1.htm |  |  |
| RIS_20_20-8_20-8-2 | 200 | 6250 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8/20-8-2.htm |  |  |
| RIS_20_20-8_20-8-3 | 200 | 5825 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8/20-8-3.htm |  |  |
| RIS_20_20-8_20-8-4 | 200 | 4440 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8/20-8-4.htm |  |  |
| RIS_20_20-8_20-8-5 | 200 | 4250 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8/20-8-5.htm |  |  |
| RIS_20_20-8_20-8-6 | 200 | 3934 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8/20-8-6.htm |  | render-thin 297 |
| RIS_20_20-8_20-8-7 | 200 | 5017 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8/20-8-7.htm |  |  |
| RIS_20_20-8_20-8-8 | 200 | 4353 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8/20-8-8.htm |  |  |
| RIS_20_20-8_20-8-9 | 200 | 4541 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8/20-8-9.htm |  |  |
| RIS_20_20-8_20-8-10 | 200 | 4237 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8/20-8-10.htm |  |  |
| RIS_20_20-8_20-8-11 | 200 | 4279 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8/20-8-11.htm |  |  |
| RIS_20_20-8_20-8-12 | 200 | 4212 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8/20-8-12.htm |  |  |
| RIS_20_20-8.1_20-8.1-1 | 200 | 6138 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-1.htm |  |  |
| RIS_20_20-8.1_20-8.1-2 | 200 | 4054 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-2.htm |  |  |
| RIS_20_20-8.1_20-8.1-2.1 | 200 | 4328 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-2.1.htm |  |  |
| RIS_20_20-8.1_20-8.1-3 | 200 | 5271 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-3.htm |  |  |
| RIS_20_20-8.1_20-8.1-4 | 200 | 4470 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-4.htm |  |  |
| RIS_20_20-8.1_20-8.1-5 | 200 | 4693 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-5.htm |  |  |
| RIS_20_20-8.1_20-8.1-6 | 200 | 4351 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-6.htm |  |  |
| RIS_20_20-8.1_20-8.1-7 | 200 | 4636 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-7.htm |  |  |
| RIS_20_20-8.1_20-8.1-8 | 200 | 4170 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-8.htm |  |  |
| RIS_20_20-8.1_20-8.1-9 | 200 | 4633 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-9.htm |  |  |
| RIS_20_20-8.1_20-8.1-10 | 200 | 4440 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-10.htm |  |  |
| RIS_20_20-8.1_20-8.1-11 | 200 | 4752 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-11.htm |  |  |
| RIS_20_20-8.1_20-8.1-12 | 200 | 3805 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-8.1/20-8.1-12.htm |  | render-thin 215 |
| RIS_20_20-9_20-9-1 | 200 | 4825 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-9/20-9-1.htm |  |  |
| RIS_20_20-9_20-9-2 | 200 | 4196 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-9/20-9-2.htm |  |  |
| RIS_20_20-9_20-9-3 | 200 | 5018 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-9/20-9-3.htm |  |  |
| RIS_20_20-9_20-9-4 | 200 | 4215 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-9/20-9-4.htm |  |  |
| RIS_20_20-9_20-9-5 | 200 | 3973 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-9/20-9-5.htm |  |  |
| RIS_20_20-10_20-10-1 | 200 | 5517 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-1.htm |  |  |
| RIS_20_20-10_20-10-1.1 | 200 | 5063 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-1.1.htm |  |  |
| RIS_20_20-10_20-10-1.2 | 200 | 4709 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-1.2.htm |  |  |
| RIS_20_20-10_20-10-2 | 200 | 4643 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-2.htm |  |  |
| RIS_20_20-10_20-10-3 | 200 | 4860 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-3.htm |  |  |
| RIS_20_20-10_20-10-3.1 | 200 | 3964 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-3.1.htm |  |  |
| RIS_20_20-10_20-10-4 | 200 | 5191 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-4.htm |  |  |
| RIS_20_20-10_20-10-5 | 200 | 5286 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-5.htm |  |  |
| RIS_20_20-10_20-10-6 | 200 | 5668 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-6.htm |  |  |
| RIS_20_20-10_20-10-7 | 200 | 4004 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-7.htm |  |  |
| RIS_20_20-10_20-10-8 | 200 | 4100 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-8.htm |  |  |
| RIS_20_20-10_20-10-9 | 200 | 4944 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-9.htm |  |  |
| RIS_20_20-10_20-10-10 | 200 | 3954 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-10.htm |  |  |
| RIS_20_20-10_20-10-11 | 200 | 4068 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-11.htm |  |  |
| RIS_20_20-10_20-10-12 | 200 | 6042 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-12.htm |  |  |
| RIS_20_20-10_20-10-13 | 200 | 4017 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-13.htm |  |  |
| RIS_20_20-10_20-10-13.1 | 200 | 5626 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-13.1.htm |  |  |
| RIS_20_20-10_20-10-14 | 200 | 5015 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-14.htm |  |  |
| RIS_20_20-10_20-10-15 | 200 | 4009 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-15.htm |  |  |
| RIS_20_20-10_20-10-16 | 200 | 5074 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-16.htm |  |  |
| RIS_20_20-10_20-10-16.1 | 200 | 4403 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-16.1.htm |  |  |
| RIS_20_20-10_20-10-17 | 200 | 5452 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-17.htm |  |  |
| RIS_20_20-10_20-10-18 | 200 | 4412 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-10/20-10-18.htm |  |  |
| RIS_20_20-11_20-11-1 | 200 | 4533 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-1.htm |  |  |
| RIS_20_20-11_20-11-2 | 200 | 4232 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-2.htm |  |  |
| RIS_20_20-11_20-11-3 | 200 | 4881 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-3.htm |  |  |
| RIS_20_20-11_20-11-4 | 200 | 4128 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-4.htm |  |  |
| RIS_20_20-11_20-11-5 | 200 | 4188 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-5.htm |  |  |
| RIS_20_20-11_20-11-6 | 200 | 4428 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-6.htm |  |  |
| RIS_20_20-11_20-11-7 | 200 | 4510 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-7.htm |  |  |
| RIS_20_20-11_20-11-8 | 200 | 4326 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-8.htm |  |  |
| RIS_20_20-11_20-11-9 | 200 | 4462 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-9.htm |  |  |
| RIS_20_20-11_20-11-10 | 200 | 4218 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-10.htm |  |  |
| RIS_20_20-11_20-11-11 | 200 | 3626 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-11.htm |  | render-thin 117 |
| RIS_20_20-11_20-11-20 | 200 | 4190 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-20.htm |  |  |
| RIS_20_20-11_20-11-21 | 200 | 4011 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-11/20-11-21.htm |  |  |
| RIS_20_20-12_20-12-1 | 200 | 4314 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-12/20-12-1.htm |  |  |
| RIS_20_20-12_20-12-2 | 200 | 4214 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-12/20-12-2.htm |  |  |
| RIS_20_20-12_20-12-3 | 200 | 4297 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-12/20-12-3.htm |  |  |
| RIS_20_20-12_20-12-4 | 200 | 4298 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-12/20-12-4.htm |  |  |
| RIS_20_20-12_20-12-5 | 200 | 4280 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-12/20-12-5.htm |  |  |
| RIS_20_20-12_20-12-6 | 200 | 4294 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-12/20-12-6.htm |  |  |
| RIS_20_20-12_20-12-7 | 200 | 4279 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-12/20-12-7.htm |  |  |
| RIS_20_20-12_20-12-8 | 200 | 3925 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-12/20-12-8.htm |  | render-thin 289 |
| RIS_20_20-13_20-13-1 | 200 | 4740 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-1.htm |  |  |
| RIS_20_20-13_20-13-2 | 200 | 5116 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-2.htm |  |  |
| RIS_20_20-13_20-13-2.1 | 200 | 4265 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-2.1.htm |  |  |
| RIS_20_20-13_20-13-3 | 200 | 4100 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-3.htm |  |  |
| RIS_20_20-13_20-13-4 | 200 | 5202 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-4.htm |  |  |
| RIS_20_20-13_20-13-5 | 200 | 6653 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-5.htm |  |  |
| RIS_20_20-13_20-13-6 | 200 | 4144 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-6.htm |  |  |
| RIS_20_20-13_20-13-7 | 200 | 4264 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-7.htm |  |  |
| RIS_20_20-13_20-13-8 | 200 | 5297 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-8.htm |  |  |
| RIS_20_20-13_20-13-9 | 200 | 3956 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-9.htm |  |  |
| RIS_20_20-13_20-13-10 | 200 | 4179 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-10.htm |  |  |
| RIS_20_20-13_20-13-11 | 200 | 3980 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-11.htm |  |  |
| RIS_20_20-13_20-13-12 | 200 | 4384 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-12.htm |  |  |
| RIS_20_20-13_20-13-13 | 200 | 4737 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-13.htm |  |  |
| RIS_20_20-13_20-13-14 | 200 | 4207 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-14.htm |  |  |
| RIS_20_20-13_20-13-15 | 200 | 4151 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-15.htm |  |  |
| RIS_20_20-13_20-13-16 | 200 | 6179 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-16.htm |  |  |
| RIS_20_20-13_20-13-17 | 200 | 4803 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-17.htm |  |  |
| RIS_20_20-13_20-13-18 | 200 | 5528 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-13/20-13-18.htm |  |  |
| RIS_20_20-14_20-14-1 | 200 | 4819 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-14/20-14-1.htm |  |  |
| RIS_20_20-14_20-14-1.1 | 200 | 4817 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-14/20-14-1.1.htm |  |  |
| RIS_20_20-14_20-14-2 | 200 | 4031 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-14/20-14-2.htm |  |  |
| RIS_20_20-14_20-14-3 | 200 | 4000 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-14/20-14-3.htm |  |  |
| RIS_20_20-14_20-14-4 | 200 | 4151 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-14/20-14-4.htm |  |  |
| RIS_20_20-14_20-14-5 | 200 | 4417 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-14/20-14-5.htm |  |  |
| RIS_20_20-14_20-14-6 | 200 | 3888 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-14/20-14-6.htm |  | render-thin 252 |
| RIS_20_20-14_20-14-7 | 200 | 5965 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-14/20-14-7.htm |  |  |
| RIS_20_20-14_20-14-8 | 200 | 4108 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-14/20-14-8.htm |  |  |
| RIS_20_20-14_20-14-8.1 | 200 | 4117 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-14/20-14-8.1.htm |  |  |
| RIS_20_20-14_20-14-9 | 200 | 4744 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-14/20-14-9.htm |  |  |
| RIS_20_20-15_20-15-1 | 200 | 7260 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-15/20-15-1.htm |  |  |
| RIS_20_20-15_20-15-2 | 200 | 5708 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-15/20-15-2.htm |  |  |
| RIS_20_20-15_20-15-3 | 200 | 6713 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-15/20-15-3.htm |  |  |
| RIS_20_20-15_20-15-4 | 200 | 4737 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-15/20-15-4.htm |  |  |
| RIS_20_20-15_20-15-5 | 200 | 4713 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-15/20-15-5.htm |  |  |
| RIS_20_20-15_20-15-6 | 200 | 3982 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-15/20-15-6.htm |  |  |
| RIS_20_20-15_20-15-7 | 200 | 4422 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-15/20-15-7.htm |  |  |
| RIS_20_20-15_20-15-8 | 200 | 4026 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-15/20-15-8.htm |  |  |
| RIS_20_20-15_20-15-9 | 200 | 4423 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-15/20-15-9.htm |  |  |
| RIS_20_20-16_20-16-1 | 200 | 4669 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-1.htm |  |  |
| RIS_20_20-16_20-16-2 | 200 | 4760 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-2.htm |  |  |
| RIS_20_20-16_20-16-3 | 200 | 4268 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-3.htm |  |  |
| RIS_20_20-16_20-16-4 | 200 | 4374 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-4.htm |  |  |
| RIS_20_20-16_20-16-5 | 200 | 4049 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-5.htm |  |  |
| RIS_20_20-16_20-16-6 | 200 | 4107 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-6.htm |  |  |
| RIS_20_20-16_20-16-7 | 200 | 4716 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-7.htm |  |  |
| RIS_20_20-16_20-16-8 | 200 | 5206 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-8.htm |  |  |
| RIS_20_20-16_20-16-9 | 200 | 4461 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-9.htm |  |  |
| RIS_20_20-16_20-16-10 | 200 | 4218 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-10.htm |  |  |
| RIS_20_20-16_20-16-11 | 200 | 3974 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-11.htm |  |  |
| RIS_20_20-16_20-16-12 | 200 | 4195 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-12.htm |  |  |
| RIS_20_20-16_20-16-13 | 200 | 4185 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-13.htm |  |  |
| RIS_20_20-16_20-16-14 | 200 | 3811 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-14.htm |  | render-thin 221 |
| RIS_20_20-16_20-16-15 | 200 | 3811 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-15.htm |  | render-thin 221 |
| RIS_20_20-16_20-16-16 | 200 | 4457 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-16.htm |  |  |
| RIS_20_20-16_20-16-17 | 200 | 4205 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-17.htm |  |  |
| RIS_20_20-16_20-16-18 | 200 | 4354 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-16/20-16-18.htm |  |  |
| RIS_20_20-17_20-17-1 | 200 | 4562 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-17/20-17-1.htm |  |  |
| RIS_20_20-17_20-17-2 | 200 | 5076 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-17/20-17-2.htm |  |  |
| RIS_20_20-17_20-17-3 | 200 | 4025 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-17/20-17-3.htm |  |  |
| RIS_20_20-17_20-17-4 | 200 | 4056 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-17/20-17-4.htm |  |  |
| RIS_20_20-17_20-17-5 | 200 | 4509 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-17/20-17-5.htm |  |  |
| RIS_20_20-17_20-17-6 | 200 | 4208 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-17/20-17-6.htm |  |  |
| RIS_20_20-17_20-17-7 | 200 | 4380 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-17/20-17-7.htm |  |  |
| RIS_20_20-17_20-17-8 | 200 | 4316 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-17/20-17-8.htm |  |  |
| RIS_20_20-17_20-17-9 | 200 | 4076 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-17/20-17-9.htm |  |  |
| RIS_20_20-17_20-17-10 | 200 | 4391 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-17/20-17-10.htm |  |  |
| RIS_20_20-17_20-17-11 | 200 | 4099 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-17/20-17-11.htm |  |  |
| RIS_20_20-18_20-18-1 | 200 | 4500 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-18/20-18-1.htm |  |  |
| RIS_20_20-18_20-18-2 | 200 | 4598 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-18/20-18-2.htm |  |  |
| RIS_20_20-18_20-18-3 | 200 | 5030 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-18/20-18-3.htm |  |  |
| RIS_20_20-18.1_20-18.1-1 | 200 | 6466 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-18.1/20-18.1-1.htm |  |  |
| RIS_20_20-18.1_20-18.1-2 | 200 | 4921 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-18.1/20-18.1-2.htm |  |  |
| RIS_20_20-18.1_20-18.1-3 | 200 | 5160 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-18.1/20-18.1-3.htm |  |  |
| RIS_20_20-19_20-19-1 | 200 | 3996 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-19/20-19-1.htm |  |  |
| RIS_20_20-19_20-19-2 | 200 | 5459 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-19/20-19-2.htm |  |  |
| RIS_20_20-19_20-19-3 | 200 | 3971 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-19/20-19-3.htm |  |  |
| RIS_20_20-19_20-19-4 | 200 | 4217 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-19/20-19-4.htm |  |  |
| RIS_20_20-20_20-20-1 | 200 | 3638 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-20/20-20-1.htm |  | render-thin 129 |
| RIS_20_20-21_20-21-1 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-21/20-21-1.htm |  | render-thin 113 |
| RIS_20_20-22_20-22-1 | 200 | 3610 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-22/20-22-1.htm |  | render-thin 101 |
| RIS_20_20-23_20-23-1 | 200 | 3845 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-23/20-23-1.htm |  | render-thin 254 |
| RIS_20_20-24_20-24-1 | 200 | 3621 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-24/20-24-1.htm |  | render-thin 112 |
| RIS_20_20-25_20-25-1 | 200 | 3634 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-25/20-25-1.htm |  | render-thin 125 |
| RIS_20_20-26_20-26-1 | 200 | 3624 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-26/20-26-1.htm |  | render-thin 117 |
| RIS_20_20-27_20-27-1 | 200 | 3620 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-27/20-27-1.htm |  | render-thin 111 |
| RIS_20_20-28_20-28-1 | 200 | 3617 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-28/20-28-1.htm |  | render-thin 108 |
| RIS_20_20-29_20-29-1 | 200 | 3609 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-29/20-29-1.htm |  | render-thin 100 |
| RIS_20_20-30_20-30-1 | 200 | 3616 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-30/20-30-1.htm |  | render-thin 107 |
| RIS_20_20-31_20-31-1 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-31/20-31-1.htm |  | render-thin 113 |
| RIS_20_20-32_20-32-1 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-32/20-32-1.htm |  | render-thin 113 |
| RIS_20_20-33_20-33-1 | 200 | 3615 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-33/20-33-1.htm |  | render-thin 106 |
| RIS_20_20-34_20-34-1 | 200 | 3630 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-34/20-34-1.htm |  | render-thin 121 |
| RIS_20_20-35_20-35-1 | 200 | 3638 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-35/20-35-1.htm |  | render-thin 129 |
| RIS_20_20-36_20-36-1 | 200 | 3903 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-36/20-36-1.htm |  |  |
| RIS_20_20-37_20-37-1 | 200 | 4576 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-37/20-37-1.htm |  |  |
| RIS_20_20-37_20-37-2 | 200 | 5204 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-37/20-37-2.htm |  |  |
| RIS_20_20-37_20-37-3 | 200 | 5117 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-37/20-37-3.htm |  |  |
| RIS_20_20-37_20-37-4 | 200 | 5147 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-37/20-37-4.htm |  |  |
| RIS_20_20-37_20-37-5 | 200 | 4038 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-37/20-37-5.htm |  |  |
| RIS_20_20-38_20-38-1 | 200 | 3962 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-38/20-38-1.htm |  |  |
| RIS_20_20-38_20-38-2 | 200 | 4361 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-38/20-38-2.htm |  |  |
| RIS_20_20-38_20-38-3 | 200 | 6374 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-38/20-38-3.htm |  |  |
| RIS_20_20-38_20-38-4 | 200 | 7843 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-38/20-38-4.htm |  |  |
| RIS_20_20-38_20-38-5 | 200 | 5828 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-38/20-38-5.htm |  |  |
| RIS_20_20-38_20-38-6 | 200 | 3914 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-38/20-38-6.htm |  |  |
| RIS_20_20-38_20-38-7 | 200 | 4722 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-38/20-38-7.htm |  |  |
| RIS_20_20-39_20-39-1 | 200 | 28498 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-39/20-39-1.htm |  |  |
| RIS_20_20-39_20-39-2 | 200 | 4702 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-39/20-39-2.htm |  |  |
| RIS_20_20-39_20-39-3 | 200 | 6323 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-39/20-39-3.htm |  |  |
| RIS_20_20-39_20-39-4 | 200 | 5080 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-39/20-39-4.htm |  |  |
| RIS_20_20-39_20-39-5 | 200 | 6156 | https://webserver.rilegislature.gov/Statutes/TITLE20/20-39/20-39-5.htm |  |  |
| RIS_21_21-1_21-1-1 | 200 | 3882 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-1/21-1-1.htm |  | render-thin 242 |
| RIS_21_21-1_21-1-2 | 200 | 4533 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-1/21-1-2.htm |  |  |
| RIS_21_21-1_21-1-3 | 200 | 4166 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-1/21-1-3.htm |  |  |
| RIS_21_21-1_21-1-4 | 200 | 4254 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-1/21-1-4.htm |  |  |
| RIS_21_21-1_21-1-5 | 200 | 4337 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-1/21-1-5.htm |  |  |
| RIS_21_21-1_21-1-6 | 200 | 4154 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-1/21-1-6.htm |  |  |
| RIS_21_21-1_21-1-7 | 200 | 4205 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-1/21-1-7.htm |  |  |
| RIS_21_21-1_21-1-8 | 200 | 4146 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-1/21-1-8.htm |  |  |
| RIS_21_21-1_21-1-9 | 200 | 4189 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-1/21-1-9.htm |  |  |
| RIS_21_21-1_21-1-10 | 200 | 4571 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-1/21-1-10.htm |  |  |
| RIS_21_21-1_21-1-11 | 200 | 3917 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-1/21-1-11.htm |  | render-thin 281 |
| RIS_21_21-1_21-1-12 | 200 | 3619 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-1/21-1-12.htm |  | render-thin 110 |
| RIS_21_21-2_21-2-1 | 200 | 3861 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-1.htm |  | render-thin 242 |
| RIS_21_21-2_21-2-2 | 200 | 8266 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-2.htm |  |  |
| RIS_21_21-2_21-2-3 | 200 | 6309 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-3.htm |  |  |
| RIS_21_21-2_21-2-4 | 200 | 3605 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-4.htm |  | render-thin 98 |
| RIS_21_21-2_21-2-5 | 200 | 6101 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-5.htm |  |  |
| RIS_21_21-2_21-2-6 | 200 | 5106 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-6.htm |  |  |
| RIS_21_21-2_21-2-7 | 200 | 8323 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-7.htm |  |  |
| RIS_21_21-2_21-2-7.1 | 200 | 4404 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-7.1.htm |  |  |
| RIS_21_21-2_21-2-8 | 200 | 8239 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-8.htm |  |  |
| RIS_21_21-2_21-2-9 | 200 | 4689 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-9.htm |  |  |
| RIS_21_21-2_21-2-10 | 200 | 4566 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-10.htm |  |  |
| RIS_21_21-2_21-2-11 | 200 | 7020 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-11.htm |  |  |
| RIS_21_21-2_21-2-12 | 200 | 5422 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-12.htm |  |  |
| RIS_21_21-2_21-2-13 | 200 | 3945 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-13.htm |  |  |
| RIS_21_21-2_21-2-14 | 200 | 4057 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-14.htm |  |  |
| RIS_21_21-2_21-2-15 | 200 | 3607 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-15.htm |  | render-thin 100 |
| RIS_21_21-2_21-2-16 | 200 | 4814 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-16.htm |  |  |
| RIS_21_21-2_21-2-17 | 200 | 3616 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-17.htm |  | render-thin 109 |
| RIS_21_21-2_21-2-19 | 200 | 5076 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-19.htm |  |  |
| RIS_21_21-2_21-2-20 | 200 | 5175 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-20.htm |  |  |
| RIS_21_21-2_21-2-21 | 200 | 4327 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-21.htm |  |  |
| RIS_21_21-2_21-2-22 | 200 | 6963 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-22.htm |  |  |
| RIS_21_21-2_21-2-23 | 200 | 6611 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-23.htm |  |  |
| RIS_21_21-2_21-2-24 | 200 | 3619 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-24.htm |  | render-thin 110 |
| RIS_21_21-2_21-2-29 | 200 | 4292 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-29.htm |  |  |
| RIS_21_21-2_21-2-30 | 200 | 4749 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-30.htm |  |  |
| RIS_21_21-2_21-2-31 | 200 | 5327 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-31.htm |  |  |
| RIS_21_21-2_21-2-32 | 200 | 4889 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-32.htm |  |  |
| RIS_21_21-2_21-2-33 | 200 | 3619 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-33.htm |  | render-thin 110 |
| RIS_21_21-2_21-2-43 | 200 | 3868 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-43.htm |  | render-thin 253 |
| RIS_21_21-2_21-2-44 | 200 | 4853 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-44.htm |  |  |
| RIS_21_21-2_21-2-45 | 200 | 3956 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-45.htm |  |  |
| RIS_21_21-2_21-2-46 | 200 | 4582 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-46.htm |  |  |
| RIS_21_21-2_21-2-47 | 200 | 3619 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-47.htm |  | render-thin 110 |
| RIS_21_21-2_21-2-51 | 200 | 4319 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-51.htm |  |  |
| RIS_21_21-2_21-2-52 | 200 | 4350 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-52.htm |  |  |
| RIS_21_21-2_21-2-53 | 200 | 5954 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-53.htm |  |  |
| RIS_21_21-2_21-2-54 | 200 | 4287 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-54.htm |  |  |
| RIS_21_21-2_21-2-55 | 200 | 4420 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-55.htm |  |  |
| RIS_21_21-2_21-2-56 | 200 | 4667 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-56.htm |  |  |
| RIS_21_21-2_21-2-57 | 200 | 4177 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2/21-2-57.htm |  |  |
| RIS_21_21-2.1_21-2.1-1 | 200 | 4164 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2.1/21-2.1-1.htm |  |  |
| RIS_21_21-2.1_21-2.1-2 | 200 | 4070 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2.1/21-2.1-2.htm |  |  |
| RIS_21_21-2.1_21-2.1-3 | 200 | 4261 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-2.1/21-2.1-3.htm |  |  |
| RIS_21_21-3_21-3-1 | 200 | 3657 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-3/21-3-1.htm |  | render-thin 148 |
| RIS_21_21-4_21-4-1 | 200 | 3638 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-4/21-4-1.htm |  | render-thin 129 |
| RIS_21_21-4.1_21-4.1-1 | 200 | 4168 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-4.1/21-4.1-1.htm |  |  |
| RIS_21_21-4.1_21-4.1-2 | 200 | 6536 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-4.1/21-4.1-2.htm |  |  |
| RIS_21_21-4.1_21-4.1-3 | 200 | 6030 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-4.1/21-4.1-3.htm |  |  |
| RIS_21_21-4.1_21-4.1-4 | 200 | 6072 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-4.1/21-4.1-4.htm |  |  |
| RIS_21_21-4.1_21-4.1-5 | 200 | 3923 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-4.1/21-4.1-5.htm |  | render-thin 286 |
| RIS_21_21-4.1_21-4.1-6 | 200 | 3982 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-4.1/21-4.1-6.htm |  |  |
| RIS_21_21-4.1_21-4.1-7 | 200 | 4070 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-4.1/21-4.1-7.htm |  |  |
| RIS_21_21-4.1_21-4.1-8 | 200 | 4292 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-4.1/21-4.1-8.htm |  |  |
| RIS_21_21-4.1_21-4.1-9 | 200 | 4222 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-4.1/21-4.1-9.htm |  |  |
| RIS_21_21-5_21-5-1 | 200 | 3648 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-5/21-5-1.htm |  | render-thin 139 |
| RIS_21_21-5_21-5-4 | 200 | 4366 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-5/21-5-4.htm |  |  |
| RIS_21_21-5_21-5-5 | 200 | 4535 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-5/21-5-5.htm |  |  |
| RIS_21_21-5_21-5-6 | 200 | 4963 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-5/21-5-6.htm |  |  |
| RIS_21_21-5_21-5-7 | 200 | 4797 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-5/21-5-7.htm |  |  |
| RIS_21_21-5_21-5-8 | 200 | 3637 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-5/21-5-8.htm |  | render-thin 130 |
| RIS_21_21-5_21-5-9 | 200 | 4435 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-5/21-5-9.htm |  |  |
| RIS_21_21-5_21-5-10 | 200 | 4440 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-5/21-5-10.htm |  |  |
| RIS_21_21-5_21-5-11 | 200 | 4307 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-5/21-5-11.htm |  |  |
| RIS_21_21-5_21-5-12 | 200 | 4138 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-5/21-5-12.htm |  |  |
| RIS_21_21-5_21-5-13 | 200 | 4210 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-5/21-5-13.htm |  |  |
| RIS_21_21-5_21-5-14 | 200 | 4425 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-5/21-5-14.htm |  |  |
| RIS_21_21-6_21-6-1 | 200 | 3630 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-6/21-6-1.htm |  | render-thin 121 |
| RIS_21_21-7_21-7-1 | 200 | 3638 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-7/21-7-1.htm |  | render-thin 129 |
| RIS_21_21-8_21-8-1 | 200 | 3662 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-8/21-8-1.htm |  | render-thin 153 |
| RIS_21_21-9_21-9-1 | 200 | 9763 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-1.htm |  |  |
| RIS_21_21-9_21-9-2 | 200 | 5448 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-2.htm |  |  |
| RIS_21_21-9_21-9-3 | 200 | 4807 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-3.htm |  |  |
| RIS_21_21-9_21-9-4 | 200 | 4114 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-4.htm |  |  |
| RIS_21_21-9_21-9-5 | 200 | 3989 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-5.htm |  |  |
| RIS_21_21-9_21-9-6 | 200 | 3974 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-6.htm |  |  |
| RIS_21_21-9_21-9-7 | 200 | 4074 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-7.htm |  |  |
| RIS_21_21-9_21-9-8 | 200 | 3600 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-8.htm |  | render-thin 93 |
| RIS_21_21-9_21-9-9 | 200 | 4038 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-9.htm |  |  |
| RIS_21_21-9_21-9-10 | 200 | 3602 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-10.htm |  | render-thin 95 |
| RIS_21_21-9_21-9-11 | 200 | 4389 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-11.htm |  |  |
| RIS_21_21-9_21-9-12 | 200 | 7037 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-12.htm |  |  |
| RIS_21_21-9_21-9-13 | 200 | 6120 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-13.htm |  |  |
| RIS_21_21-9_21-9-14 | 200 | 4433 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-14.htm |  |  |
| RIS_21_21-9_21-9-15 | 200 | 4661 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-15.htm |  |  |
| RIS_21_21-9_21-9-16 | 200 | 4162 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-16.htm |  |  |
| RIS_21_21-9_21-9-17 | 200 | 4259 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-17.htm |  |  |
| RIS_21_21-9_21-9-18 | 200 | 7426 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-18.htm |  |  |
| RIS_21_21-9_21-9-19 | 200 | 5185 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-19.htm |  |  |
| RIS_21_21-9_21-9-20 | 200 | 4650 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-20.htm |  |  |
| RIS_21_21-9_21-9-21 | 200 | 4351 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-21.htm |  |  |
| RIS_21_21-9_21-9-22 | 200 | 4337 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-22.htm |  |  |
| RIS_21_21-9_21-9-23 | 200 | 4110 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-9/21-9-23.htm |  |  |
| RIS_21_21-10_21-10-1 | 200 | 3636 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-10/21-10-1.htm |  | render-thin 127 |
| RIS_21_21-11_21-11-1 | 200 | 3982 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-1.htm |  |  |
| RIS_21_21-11_21-11-2 | 200 | 4454 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-2.htm |  |  |
| RIS_21_21-11_21-11-3 | 200 | 5050 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-3.htm |  |  |
| RIS_21_21-11_21-11-4 | 200 | 6086 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-4.htm |  |  |
| RIS_21_21-11_21-11-5 | 200 | 4621 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-5.htm |  |  |
| RIS_21_21-11_21-11-6 | 200 | 4457 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-6.htm |  |  |
| RIS_21_21-11_21-11-6.1 | 200 | 4074 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-6.1.htm |  |  |
| RIS_21_21-11_21-11-7 | 200 | 4352 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-7.htm |  |  |
| RIS_21_21-11_21-11-8 | 200 | 4162 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-8.htm |  |  |
| RIS_21_21-11_21-11-9 | 200 | 4744 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-9.htm |  |  |
| RIS_21_21-11_21-11-10 | 200 | 4290 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-10.htm |  |  |
| RIS_21_21-11_21-11-11 | 200 | 3608 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-11.htm |  | render-thin 99 |
| RIS_21_21-11_21-11-14 | 200 | 3595 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-11/21-11-14.htm |  | render-thin 88 |
| RIS_21_21-12_21-12-1 | 200 | 3625 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-12/21-12-1.htm |  | render-thin 116 |
| RIS_21_21-13_21-13-1 | 200 | 4309 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-13/21-13-1.htm |  |  |
| RIS_21_21-13_21-13-2 | 200 | 4152 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-13/21-13-2.htm |  |  |
| RIS_21_21-13_21-13-3 | 200 | 3998 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-13/21-13-3.htm |  |  |
| RIS_21_21-13_21-13-4 | 200 | 5187 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-13/21-13-4.htm |  |  |
| RIS_21_21-13_21-13-5 | 200 | 3988 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-13/21-13-5.htm |  |  |
| RIS_21_21-13_21-13-6 | 200 | 4165 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-13/21-13-6.htm |  |  |
| RIS_21_21-13_21-13-6.1 | 200 | 4123 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-13/21-13-6.1.htm |  |  |
| RIS_21_21-13_21-13-7 | 200 | 4440 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-13/21-13-7.htm |  |  |
| RIS_21_21-13_21-13-8 | 200 | 4335 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-13/21-13-8.htm |  |  |
| RIS_21_21-13_21-13-9 | 200 | 4051 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-13/21-13-9.htm |  |  |
| RIS_21_21-13_21-13-10 | 200 | 3888 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-13/21-13-10.htm |  | render-thin 272 |
| RIS_21_21-14_21-14-1 | 200 | 5847 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-14/21-14-1.htm |  |  |
| RIS_21_21-14_21-14-2 | 200 | 6152 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-14/21-14-2.htm |  |  |
| RIS_21_21-14_21-14-3 | 200 | 4310 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-14/21-14-3.htm |  |  |
| RIS_21_21-14_21-14-4 | 200 | 3624 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-14/21-14-4.htm |  | render-thin 115 |
| RIS_21_21-14_21-14-9 | 200 | 4794 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-14/21-14-9.htm |  |  |
| RIS_21_21-14_21-14-10 | 200 | 4184 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-14/21-14-10.htm |  |  |
| RIS_21_21-14_21-14-11 | 200 | 4418 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-14/21-14-11.htm |  |  |
| RIS_21_21-14_21-14-12 | 200 | 6571 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-14/21-14-12.htm |  |  |
| RIS_21_21-14_21-14-13 | 200 | 4277 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-14/21-14-13.htm |  |  |
| RIS_21_21-14_21-14-14 | 200 | 4430 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-14/21-14-14.htm |  |  |
| RIS_21_21-14_21-14-15 | 200 | 4958 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-14/21-14-15.htm |  |  |
| RIS_21_21-15_21-15-1 | 200 | 4298 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-1.htm |  |  |
| RIS_21_21-15_21-15-2 | 200 | 4236 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-2.htm |  |  |
| RIS_21_21-15_21-15-3 | 200 | 4043 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-3.htm |  |  |
| RIS_21_21-15_21-15-4 | 200 | 4354 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-4.htm |  |  |
| RIS_21_21-15_21-15-5 | 200 | 4537 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-5.htm |  |  |
| RIS_21_21-15_21-15-6 | 200 | 4104 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-6.htm |  |  |
| RIS_21_21-15_21-15-7 | 200 | 4341 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-7.htm |  |  |
| RIS_21_21-15_21-15-8 | 200 | 4175 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-8.htm |  |  |
| RIS_21_21-15_21-15-9 | 200 | 4137 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-9.htm |  |  |
| RIS_21_21-15_21-15-10 | 200 | 4163 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-10.htm |  |  |
| RIS_21_21-15_21-15-11 | 200 | 3970 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-11.htm |  |  |
| RIS_21_21-15_21-15-12 | 200 | 4171 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-12.htm |  |  |
| RIS_21_21-15_21-15-13 | 200 | 4204 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-13.htm |  |  |
| RIS_21_21-15_21-15-14 | 200 | 4217 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-14.htm |  |  |
| RIS_21_21-15_21-15-15 | 200 | 4428 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-15.htm |  |  |
| RIS_21_21-15_21-15-16 | 200 | 4180 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-16.htm |  |  |
| RIS_21_21-15_21-15-17 | 200 | 4754 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-15/21-15-17.htm |  |  |
| RIS_21_21-16_21-16-1 | 200 | 7467 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-16/21-16-1.htm |  |  |
| RIS_21_21-16_21-16-2 | 200 | 5332 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-16/21-16-2.htm |  |  |
| RIS_21_21-16_21-16-3 | 200 | 4972 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-16/21-16-3.htm |  |  |
| RIS_21_21-16_21-16-4 | 200 | 5014 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-16/21-16-4.htm |  |  |
| RIS_21_21-17_21-17-1 | 200 | 4043 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-1.htm |  |  |
| RIS_21_21-17_21-17-2 | 200 | 4377 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-2.htm |  |  |
| RIS_21_21-17_21-17-3 | 200 | 4100 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-3.htm |  |  |
| RIS_21_21-17_21-17-4 | 200 | 4533 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-4.htm |  |  |
| RIS_21_21-17_21-17-5 | 200 | 4553 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-5.htm |  |  |
| RIS_21_21-17_21-17-6 | 200 | 4279 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-6.htm |  |  |
| RIS_21_21-17_21-17-7 | 200 | 4413 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-7.htm |  |  |
| RIS_21_21-17_21-17-8 | 200 | 4062 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-8.htm |  |  |
| RIS_21_21-17_21-17-9 | 200 | 4305 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-9.htm |  |  |
| RIS_21_21-17_21-17-10 | 200 | 4705 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-10.htm |  |  |
| RIS_21_21-17_21-17-11 | 200 | 4151 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-11.htm |  |  |
| RIS_21_21-17_21-17-12 | 200 | 4879 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-12.htm |  |  |
| RIS_21_21-17_21-17-13 | 200 | 4083 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-13.htm |  |  |
| RIS_21_21-17_21-17-14 | 200 | 4189 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-14.htm |  |  |
| RIS_21_21-17_21-17-15 | 200 | 4186 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-17/21-17-15.htm |  |  |
| RIS_21_21-18_21-18-1 | 200 | 4096 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-18/21-18-1.htm |  |  |
| RIS_21_21-18_21-18-2 | 200 | 4788 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-18/21-18-2.htm |  |  |
| RIS_21_21-18_21-18-3 | 200 | 4501 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-18/21-18-3.htm |  |  |
| RIS_21_21-18_21-18-4 | 200 | 4224 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-18/21-18-4.htm |  |  |
| RIS_21_21-18_21-18-5 | 200 | 4344 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-18/21-18-5.htm |  |  |
| RIS_21_21-18_21-18-6 | 200 | 4902 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-18/21-18-6.htm |  |  |
| RIS_21_21-18_21-18-7 | 200 | 4544 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-18/21-18-7.htm |  |  |
| RIS_21_21-18_21-18-8 | 200 | 4655 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-18/21-18-8.htm |  |  |
| RIS_21_21-19_21-19-1 | 200 | 5050 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-19/21-19-1.htm |  |  |
| RIS_21_21-19_21-19-2 | 200 | 4035 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-19/21-19-2.htm |  |  |
| RIS_21_21-19_21-19-3 | 200 | 3951 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-19/21-19-3.htm |  |  |
| RIS_21_21-19_21-19-4 | 200 | 4703 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-19/21-19-4.htm |  |  |
| RIS_21_21-19_21-19-5 | 200 | 4264 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-19/21-19-5.htm |  |  |
| RIS_21_21-19_21-19-6 | 200 | 3915 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-19/21-19-6.htm |  | render-thin 278 |
| RIS_21_21-19_21-19-7 | 200 | 4486 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-19/21-19-7.htm |  |  |
| RIS_21_21-19_21-19-8 | 200 | 4300 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-19/21-19-8.htm |  |  |
| RIS_21_21-19_21-19-9 | 200 | 4366 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-19/21-19-9.htm |  |  |
| RIS_21_21-20_21-20-1 | 200 | 4272 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-20/21-20-1.htm |  |  |
| RIS_21_21-20_21-20-2 | 200 | 4167 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-20/21-20-2.htm |  |  |
| RIS_21_21-20_21-20-3 | 200 | 3969 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-20/21-20-3.htm |  |  |
| RIS_21_21-20_21-20-4 | 200 | 4414 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-20/21-20-4.htm |  |  |
| RIS_21_21-20_21-20-5 | 200 | 4717 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-20/21-20-5.htm |  |  |
| RIS_21_21-20_21-20-6 | 200 | 4363 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-20/21-20-6.htm |  |  |
| RIS_21_21-20_21-20-7 | 200 | 4186 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-20/21-20-7.htm |  |  |
| RIS_21_21-21_21-21-1 | 200 | 4027 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-21/21-21-1.htm |  |  |
| RIS_21_21-21_21-21-2 | 200 | 3995 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-21/21-21-2.htm |  |  |
| RIS_21_21-21_21-21-3 | 200 | 5504 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-21/21-21-3.htm |  |  |
| RIS_21_21-21_21-21-4 | 200 | 3956 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-21/21-21-4.htm |  |  |
| RIS_21_21-21_21-21-5 | 200 | 4888 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-21/21-21-5.htm |  |  |
| RIS_21_21-21_21-21-6 | 200 | 4056 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-21/21-21-6.htm |  |  |
| RIS_21_21-22_21-22-1 | 200 | 4346 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-22/21-22-1.htm |  |  |
| RIS_21_21-22_21-22-2 | 200 | 4760 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-22/21-22-2.htm |  |  |
| RIS_21_21-22_21-22-3 | 200 | 4387 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-22/21-22-3.htm |  |  |
| RIS_21_21-22_21-22-4 | 200 | 4108 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-22/21-22-4.htm |  |  |
| RIS_21_21-22_21-22-5 | 200 | 4602 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-22/21-22-5.htm |  |  |
| RIS_21_21-22_21-22-6 | 200 | 4061 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-22/21-22-6.htm |  |  |
| RIS_21_21-23_21-23-1 | 200 | 5161 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-23/21-23-1.htm |  |  |
| RIS_21_21-23_21-23-2 | 200 | 6341 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-23/21-23-2.htm |  |  |
| RIS_21_21-23_21-23-3 | 200 | 4330 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-23/21-23-3.htm |  |  |
| RIS_21_21-23_21-23-4 | 200 | 4650 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-23/21-23-4.htm |  |  |
| RIS_21_21-23_21-23-5 | 200 | 4790 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-23/21-23-5.htm |  |  |
| RIS_21_21-23_21-23-6 | 200 | 4271 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-23/21-23-6.htm |  |  |
| RIS_21_21-23_21-23-7 | 200 | 4386 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-23/21-23-7.htm |  |  |
| RIS_21_21-24_21-24-1 | 200 | 4277 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-24/21-24-1.htm |  |  |
| RIS_21_21-24_21-24-2 | 200 | 6161 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-24/21-24-2.htm |  |  |
| RIS_21_21-24_21-24-3 | 200 | 4030 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-24/21-24-3.htm |  |  |
| RIS_21_21-24_21-24-4 | 200 | 3898 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-24/21-24-4.htm |  | render-thin 279 |
| RIS_21_21-24_21-24-5 | 200 | 4610 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-24/21-24-5.htm |  |  |
| RIS_21_21-24_21-24-6 | 200 | 4205 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-24/21-24-6.htm |  |  |
| RIS_21_21-24_21-24-7 | 200 | 4216 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-24/21-24-7.htm |  |  |
| RIS_21_21-24_21-24-8 | 200 | 4363 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-24/21-24-8.htm |  |  |
| RIS_21_21-25_21-25-1 | 200 | 4077 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-25/21-25-1.htm |  |  |
| RIS_21_21-25_21-25-2 | 200 | 4190 | https://webserver.rilegislature.gov/Statutes/TITLE21/21-25/21-25-2.htm |  |  |
