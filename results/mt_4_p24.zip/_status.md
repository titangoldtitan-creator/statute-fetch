| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0190-0080-0010-0010 | 200 | 15481 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0010/section_0010/0190-0080-0010-0010.html |    19-8-101. Definitions, MCA  |  |
| MTS_0190-0080-0010-0020 | 200 | 11480 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0010/section_0020/0190-0080-0010-0020.html |    19-8-102. Game wardens' and peace officers' retirement system established, MC |  |
| MTS_0190-0080-0010-0030 | 200 | 11058 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0010/section_0030/0190-0080-0010-0030.html |    19-8-103. Repealed, MCA  |  |
| MTS_0190-0080-0010-0040 | 200 | 11012 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0010/section_0040/0190-0080-0010-0040.html |    19-8-104. Repealed, MCA  |  |
| MTS_0190-0080-0010-0050 | 200 | 11112 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0010/section_0050/0190-0080-0010-0050.html |    19-8-105. Short title, MCA  |  |
| MTS_0190-0080-0010-0060 | 200 | 11268 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0010/section_0060/0190-0080-0010-0060.html |    19-8-106. Game wardens' and peace officers' retirement system benefit policy  |  |
| MTS_0190-0080-0020-0010 | 200 | 10928 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0020/section_0010/0190-0080-0020-0010.html |    19-8-201. Repealed, MCA  |  |
| MTS_0190-0080-0020-0020 | 200 | 11131 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0020/section_0020/0190-0080-0020-0020.html |    19-8-202. Repealed, MCA  |  |
| MTS_0190-0080-0020-0030 | 200 | 11259 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0020/section_0030/0190-0080-0020-0030.html |    19-8-203. Repealed, MCA  |  |
| MTS_0190-0080-0020-0040 | 200 | 10854 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0020/section_0040/0190-0080-0020-0040.html |    19-8-204. Terminated, MCA  |  |
| MTS_0190-0080-0030-0010 | 200 | 13975 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0030/section_0010/0190-0080-0030-0010.html |    19-8-301. Membership -- inactive vested members -- inactive nonvested members |  |
| MTS_0190-0080-0030-0020 | 200 | 12947 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0030/section_0020/0190-0080-0030-0020.html |    19-8-302. Public employees' retirement system -- transfer of membership, MCA  |  |
| MTS_0190-0080-0030-0030 | 200 | 11355 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0030/section_0030/0190-0080-0030-0030.html |    19-8-303. Repealed, MCA  |  |
| MTS_0190-0080-0030-0040 | 200 | 10851 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0030/section_0040/0190-0080-0030-0040.html |    19-8-304. Renumbered 19-8-901, MCA  |  |
| MTS_0190-0080-0030-0050 | 200 | 11116 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0030/section_0050/0190-0080-0030-0050.html |    19-8-305. Repealed, MCA  |  |
| MTS_0190-0080-0030-0060 | 200 | 10862 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0030/section_0060/0190-0080-0030-0060.html |    19-8-306. Renumbered 19-8-902, MCA  |  |
| MTS_0190-0080-0030-0070 | 200 | 10873 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0030/section_0070/0190-0080-0030-0070.html |    19-8-307. Renumbered 19-8-903, MCA  |  |
| MTS_0190-0080-0030-0080 | 200 | 11391 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0030/section_0080/0190-0080-0030-0080.html |    19-8-308. Transfer of service, MCA  |  |
| MTS_0190-0080-0040-0010 | 200 | 10983 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0040/section_0010/0190-0080-0040-0010.html |    19-8-401. Repealed, MCA  |  |
| MTS_0190-0080-0040-0020 | 200 | 11274 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0040/section_0020/0190-0080-0040-0020.html |    19-8-402. Repealed, MCA  |  |
| MTS_0190-0080-0040-0030 | 200 | 11305 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0040/section_0030/0190-0080-0040-0030.html |    19-8-403. Repealed, MCA  |  |
| MTS_0190-0080-0040-0040 | 200 | 11274 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0040/section_0040/0190-0080-0040-0040.html |    19-8-404. Repealed, MCA  |  |
| MTS_0190-0080-0040-0050 | 200 | 11149 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0040/section_0050/0190-0080-0040-0050.html |    19-8-405. Repealed, MCA  |  |
| MTS_0190-0080-0040-0060 | 200 | 11074 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0040/section_0060/0190-0080-0040-0060.html |    19-8-406. Repealed, MCA  |  |
| MTS_0190-0080-0050-0010 | 200 | 11677 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0050/section_0010/0190-0080-0050-0010.html |    19-8-501. Contributions to pension trust fund, MCA  |  |
| MTS_0190-0080-0050-0020 | 200 | 12963 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0050/section_0020/0190-0080-0050-0020.html |    19-8-502. Member's contribution, MCA  |  |
| MTS_0190-0080-0050-0030 | 200 | 11113 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0050/section_0030/0190-0080-0050-0030.html |    19-8-503. Repealed, MCA  |  |
| MTS_0190-0080-0050-0040 | 200 | 13436 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0050/section_0040/0190-0080-0050-0040.html |    19-8-504. Employer's contribution, MCA  |  |
| MTS_0190-0080-0050-0050 | 200 | 10816 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0050/section_0050/0190-0080-0050-0050.html |    19-8-505. Repealed, MCA  |  |
| MTS_0190-0080-0060-0010 | 200 | 12238 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0060/section_0010/0190-0080-0060-0010.html |    19-8-601. Time of retirement, MCA  |  |
| MTS_0190-0080-0060-0020 | 200 | 11055 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0060/section_0020/0190-0080-0060-0020.html |    19-8-602. Repealed, MCA  |  |
| MTS_0190-0080-0060-0030 | 200 | 11527 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0060/section_0030/0190-0080-0060-0030.html |    19-8-603. Service retirement benefit, MCA  |  |
| MTS_0190-0080-0060-0040 | 200 | 11033 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0060/section_0040/0190-0080-0060-0040.html |    19-8-604. Repealed, MCA  |  |
| MTS_0190-0080-0070-0010 | 200 | 12186 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0070/section_0010/0190-0080-0070-0010.html |    19-8-701. Disability retirement benefit, MCA  |  |
| MTS_0190-0080-0070-0020 | 200 | 11165 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0070/section_0020/0190-0080-0070-0020.html |    19-8-702. Repealed, MCA  |  |
| MTS_0190-0080-0070-0030 | 200 | 10850 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0070/section_0030/0190-0080-0070-0030.html |    19-8-703. Renumbered 19-8-1001, MCA  |  |
| MTS_0190-0080-0070-0040 | 200 | 10867 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0070/section_0040/0190-0080-0070-0040.html |    19-8-704. Renumbered 19-8-1002, MCA  |  |
| MTS_0190-0080-0070-0050 | 200 | 10843 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0070/section_0050/0190-0080-0070-0050.html |    19-8-705. through 19-8-710 reserved, MCA  |  |
| MTS_0190-0080-0070-0110 | 200 | 11093 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0070/section_0110/0190-0080-0070-0110.html |    19-8-711. Repealed, MCA  |  |
| MTS_0190-0080-0070-0120 | 200 | 14779 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0070/section_0120/0190-0080-0070-0120.html |    19-8-712. Medical examination of disability retiree -- cancellation of benefi |  |
| MTS_0190-0080-0080-0010 | 200 | 18772 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0080/section_0010/0190-0080-0080-0010.html |    19-8-801. Optional forms of benefits -- designation of contingent annuitant,  |  |
| MTS_0190-0080-0080-0020 | 200 | 11145 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0080/section_0020/0190-0080-0080-0020.html |    19-8-802. Repealed, MCA  |  |
| MTS_0190-0080-0080-0030 | 200 | 11051 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0080/section_0030/0190-0080-0080-0030.html |    19-8-803. Repealed, MCA  |  |
| MTS_0190-0080-0080-0040 | 200 | 11057 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0080/section_0040/0190-0080-0080-0040.html |    19-8-804. Repealed, MCA  |  |
| MTS_0190-0080-0080-0050 | 200 | 11146 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0080/section_0050/0190-0080-0080-0050.html |    19-8-805. Repealed, MCA  |  |
| MTS_0190-0080-0080-0060 | 200 | 11065 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0080/section_0060/0190-0080-0080-0060.html |    19-8-806. Repealed, MCA  |  |
| MTS_0190-0080-0080-0070 | 200 | 11039 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0080/section_0070/0190-0080-0080-0070.html |    19-8-807. Repealed, MCA  |  |
| MTS_0190-0080-0080-0080 | 200 | 10862 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0080/section_0080/0190-0080-0080-0080.html |    19-8-808. Renumbered 19-8-1101, MCA  |  |
| MTS_0190-0080-0080-0090 | 200 | 10874 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0080/section_0090/0190-0080-0080-0090.html |    19-8-809. Renumbered 19-8-1102, MCA  |  |
| MTS_0190-0080-0080-0100 | 200 | 10879 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0080/section_0100/0190-0080-0080-0100.html |    19-8-810. Renumbered 19-8-1103, MCA  |  |
| MTS_0190-0080-0080-0110 | 200 | 10867 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0080/section_0110/0190-0080-0080-0110.html |    19-8-811. through 19-8-815 reserved, MCA  |  |
| MTS_0190-0080-0080-0160 | 200 | 10667 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0080/section_0160/0190-0080-0080-0160.html |    19-8-816. Renumbered 19-8-1104, MCA  |  |
| MTS_0190-0080-0090-0010 | 200 | 13228 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0090/section_0010/0190-0080-0090-0010.html |    19-8-901. Application to purchase military service, MCA  |  |
| MTS_0190-0080-0090-0020 | 200 | 11381 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0090/section_0020/0190-0080-0090-0020.html |    19-8-902. Repealed, MCA  |  |
| MTS_0190-0080-0090-0030 | 200 | 12865 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0090/section_0030/0190-0080-0090-0030.html |    19-8-903. Employment in United States government, MCA  |  |
| MTS_0190-0080-0090-0040 | 200 | 12180 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0090/section_0040/0190-0080-0090-0040.html |    19-8-904. Application to purchase additional service, MCA  |  |
| MTS_0190-0080-0090-0050 | 200 | 13500 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0090/section_0050/0190-0080-0090-0050.html |    19-8-905. Absence due to injury or illness, MCA  |  |
| MTS_0190-0080-0090-0060 | 200 | 11131 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0090/section_0060/0190-0080-0090-0060.html |    19-8-906. Service purchase limitation, MCA  |  |
| MTS_0190-0080-0100-0010 | 200 | 11765 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0100/section_0010/0190-0080-0100-0010.html |    19-8-1001. Benefits upon employment-related death, MCA  |  |
| MTS_0190-0080-0100-0020 | 200 | 13042 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0100/section_0020/0190-0080-0100-0020.html |    19-8-1002. Postretirement death payments, MCA  |  |
| MTS_0190-0080-0100-0030 | 200 | 11692 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0100/section_0030/0190-0080-0100-0030.html |    19-8-1003. Nonduty-related death of active member, MCA  |  |
| MTS_0190-0080-0110-0010 | 200 | 11029 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0110/section_0010/0190-0080-0110-0010.html |    19-8-1101. Repealed, MCA  |  |
| MTS_0190-0080-0110-0020 | 200 | 11233 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0110/section_0020/0190-0080-0110-0020.html |    19-8-1102. Repealed, MCA  |  |
| MTS_0190-0080-0110-0030 | 200 | 11233 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0110/section_0030/0190-0080-0110-0030.html |    19-8-1103. Repealed, MCA  |  |
| MTS_0190-0080-0110-0040 | 200 | 11261 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0110/section_0040/0190-0080-0110-0040.html |    19-8-1104. Repealed, MCA  |  |
| MTS_0190-0080-0110-0050 | 200 | 14953 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0110/section_0050/0190-0080-0110-0050.html |    19-8-1105. Guaranteed annual benefit adjustment, MCA  |  |
| MTS_0190-0080-0110-0060 | 200 | 10919 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0110/section_0060/0190-0080-0110-0060.html |    19-8-1106. through 19-8-1109 reserved, MCA  |  |
| MTS_0190-0080-0110-0100 | 200 | 10891 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0110/section_0100/0190-0080-0110-0100.html |    19-8-1110. Repealed, MCA  |  |
| MTS_0190-0080-0120-0010 | 200 | 12432 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0120/section_0010/0190-0080-0120-0010.html |    19-8-1201. Reemployment of retired members -- contributions required, MCA  |  |
| MTS_0190-0080-0120-0020 | 200 | 14484 | https://leg.mt.gov/bills/mca/title_0190/chapter_0080/part_0120/section_0020/0190-0080-0120-0020.html |    19-8-1202. Refunds and benefits for reemployed retired members, MCA  |  |
| MTS_0190-0090-0010-0010 | 200 | 10843 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0010/section_0010/0190-0090-0010-0010.html |    19-9-101. Short title, MCA  |  |
| MTS_0190-0090-0010-0020 | 200 | 12536 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0010/section_0020/0190-0090-0010-0020.html |    19-9-102. Purpose -- application of prior law, MCA  |  |
| MTS_0190-0090-0010-0030 | 200 | 11417 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0010/section_0030/0190-0090-0010-0030.html |    19-9-103. Municipal police officers' retirement system established, MCA  |  |
| MTS_0190-0090-0010-0040 | 200 | 15809 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0010/section_0040/0190-0090-0010-0040.html |    19-9-104. Definitions, MCA  |  |
| MTS_0190-0090-0010-0050 | 200 | 10793 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0010/section_0050/0190-0090-0010-0050.html |    19-9-105. Renumbered 19-9-205, MCA  |  |
| MTS_0190-0090-0010-0060 | 200 | 10801 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0010/section_0060/0190-0090-0010-0060.html |    19-9-106. Renumbered 19-9-206, MCA  |  |
| MTS_0190-0090-0010-0070 | 200 | 10790 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0010/section_0070/0190-0090-0010-0070.html |    19-9-107. Renumbered 19-9-207, MCA  |  |
| MTS_0190-0090-0010-0080 | 200 | 11076 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0010/section_0080/0190-0090-0010-0080.html |    19-9-108. Repealed, MCA  |  |
| MTS_0190-0090-0010-0090 | 200 | 11418 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0010/section_0090/0190-0090-0010-0090.html |    19-9-109. Municipal police officers' retirement system benefit policy stateme |  |
| MTS_0190-0090-0010-0100 | 200 | 10898 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0010/section_0100/0190-0090-0010-0100.html |    19-9-110. and 19-9-111 reserved, MCA  |  |
| MTS_0190-0090-0010-0120 | 200 | 11985 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0010/section_0120/0190-0090-0010-0120.html |    19-9-112. Termination of participation in retirement system or reduction of e |  |
| MTS_0190-0090-0020-0010 | 200 | 10900 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0020/section_0010/0190-0090-0020-0010.html |    19-9-201. Repealed, MCA  |  |
| MTS_0190-0090-0020-0020 | 200 | 11095 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0020/section_0020/0190-0090-0020-0020.html |    19-9-202. Repealed, MCA  |  |
| MTS_0190-0090-0020-0030 | 200 | 11160 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0020/section_0030/0190-0090-0020-0030.html |    19-9-203. Repealed, MCA  |  |
| MTS_0190-0090-0020-0040 | 200 | 11112 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0020/section_0040/0190-0090-0020-0040.html |    19-9-204. Terminated, MCA  |  |
| MTS_0190-0090-0020-0050 | 200 | 11602 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0020/section_0050/0190-0090-0020-0050.html |    19-9-205. Transfer of assets and liabilities from prior plans, MCA  |  |
| MTS_0190-0090-0020-0060 | 200 | 11776 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0020/section_0060/0190-0090-0020-0060.html |    19-9-206. Effect on members of prior plans, MCA  |  |
| MTS_0190-0090-0020-0070 | 200 | 13246 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0020/section_0070/0190-0090-0020-0070.html |    19-9-207. Election to join retirement system -- transfer of assets, MCA  |  |
| MTS_0190-0090-0020-0080 | 200 | 11420 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0020/section_0080/0190-0090-0020-0080.html |    19-9-208. Repealed, MCA  |  |
| MTS_0190-0090-0020-0090 | 200 | 11467 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0020/section_0090/0190-0090-0020-0090.html |    19-9-209. Taxing authority of employers, MCA  |  |
| MTS_0190-0090-0030-0010 | 200 | 14059 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0030/section_0010/0190-0090-0030-0010.html |    19-9-301. Active membership -- inactive vested member -- inactive nonvested m |  |
| MTS_0190-0090-0030-0020 | 200 | 11507 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0030/section_0020/0190-0090-0030-0020.html |    19-9-302. Ineligibility for other retirement plans, MCA  |  |
| MTS_0190-0090-0030-0030 | 200 | 11081 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0030/section_0030/0190-0090-0030-0030.html |    19-9-303. Repealed, MCA  |  |
| MTS_0190-0090-0030-0040 | 200 | 11080 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0030/section_0040/0190-0090-0030-0040.html |    19-9-304. Repealed, MCA  |  |
| MTS_0190-0090-0030-0050 | 200 | 10849 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0030/section_0050/0190-0090-0030-0050.html |    19-9-305. Repealed, MCA  |  |
| MTS_0190-0090-0040-0010 | 200 | 10815 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0040/section_0010/0190-0090-0040-0010.html |    19-9-401. Repealed, MCA  |  |
| MTS_0190-0090-0040-0020 | 200 | 11022 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0040/section_0020/0190-0090-0040-0020.html |    19-9-402. Repealed, MCA  |  |
| MTS_0190-0090-0040-0030 | 200 | 13414 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0040/section_0030/0190-0090-0040-0030.html |    19-9-403. Application to purchase military service, MCA  |  |
| MTS_0190-0090-0040-0040 | 200 | 11800 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0040/section_0040/0190-0090-0040-0040.html |    19-9-404. Service under sheriffs' retirement system prior to or following cit |  |
| MTS_0190-0090-0040-0050 | 200 | 11273 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0040/section_0050/0190-0090-0040-0050.html |    19-9-405. Repealed, MCA  |  |
| MTS_0190-0090-0040-0060 | 200 | 11307 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0040/section_0060/0190-0090-0040-0060.html |    19-9-406. Service purchase limitation, MCA  |  |
| MTS_0190-0090-0040-0070 | 200 | 10823 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0040/section_0070/0190-0090-0040-0070.html |    19-9-407. through 19-9-409 reserved, MCA  |  |
| MTS_0190-0090-0040-0100 | 200 | 11973 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0040/section_0100/0190-0090-0040-0100.html |    19-9-410. Transfer to public employees' retirement system, MCA  |  |
| MTS_0190-0090-0040-0110 | 200 | 11917 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0040/section_0110/0190-0090-0040-0110.html |    19-9-411. Application to purchase additional service, MCA  |  |
| MTS_0190-0090-0050-0010 | 200 | 10909 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0050/section_0010/0190-0090-0050-0010.html |    19-9-501. Repealed, MCA  |  |
| MTS_0190-0090-0050-0020 | 200 | 11094 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0050/section_0020/0190-0090-0050-0020.html |    19-9-502. Repealed, MCA  |  |
| MTS_0190-0090-0050-0030 | 200 | 10863 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0050/section_0030/0190-0090-0050-0030.html |    19-9-503. Renumbered 19-9-208, MCA  |  |
| MTS_0190-0090-0050-0040 | 200 | 11091 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0050/section_0040/0190-0090-0050-0040.html |    19-9-504. Repealed, MCA  |  |
| MTS_0190-0090-0050-0050 | 200 | 10880 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0050/section_0050/0190-0090-0050-0050.html |    19-9-505. Repealed, MCA  |  |
| MTS_0190-0090-0060-0010 | 200 | 10666 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0060/section_0010/0190-0090-0060-0010.html |    19-9-601. Renumbered 19-9-710, MCA  |  |
| MTS_0190-0090-0060-0020 | 200 | 11099 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0060/section_0020/0190-0090-0060-0020.html |    19-9-602. Repealed, MCA  |  |
| MTS_0190-0090-0060-0030 | 200 | 11116 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0060/section_0030/0190-0090-0060-0030.html |    19-9-603. Repealed, MCA  |  |
| MTS_0190-0090-0060-0040 | 200 | 10851 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0060/section_0040/0190-0090-0060-0040.html |    19-9-604. Repealed, MCA  |  |
| MTS_0190-0090-0070-0010 | 200 | 10790 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0070/section_0010/0190-0090-0070-0010.html |    19-9-701. Repealed, MCA  |  |
| MTS_0190-0090-0070-0020 | 200 | 11914 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0070/section_0020/0190-0090-0070-0020.html |    19-9-702. State contribution, MCA  |  |
| MTS_0190-0090-0070-0030 | 200 | 11605 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0070/section_0030/0190-0090-0070-0030.html |    19-9-703. Employer contribution, MCA  |  |
| MTS_0190-0090-0070-0040 | 200 | 10815 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0070/section_0040/0190-0090-0070-0040.html |    19-9-704. Renumbered 19-9-209, MCA  |  |
| MTS_0190-0090-0070-0050 | 200 | 11805 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0070/section_0050/0190-0090-0070-0050.html |    19-9-705. Other money credited as employer contributions, MCA  |  |
| MTS_0190-0090-0070-0060 | 200 | 11934 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0070/section_0060/0190-0090-0070-0060.html |    19-9-706. Contributions based on total compensation when member receives disa |  |
| MTS_0190-0090-0070-0070 | 200 | 11038 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0070/section_0070/0190-0090-0070-0070.html |    19-9-707. Repealed, MCA  |  |
| MTS_0190-0090-0070-0080 | 200 | 10755 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0070/section_0080/0190-0090-0070-0080.html |    19-9-708. and 19-9-709 reserved, MCA  |  |
| MTS_0190-0090-0070-0100 | 200 | 13804 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0070/section_0100/0190-0090-0070-0100.html |    19-9-710. Member's contribution, MCA  |  |
| MTS_0190-0090-0080-0010 | 200 | 12280 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0080/section_0010/0190-0090-0080-0010.html |    19-9-801. Eligibility for service retirement -- commencement of benefit, MCA  |  |
| MTS_0190-0090-0080-0020 | 200 | 11204 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0080/section_0020/0190-0090-0080-0020.html |    19-9-802. Repealed, MCA  |  |
| MTS_0190-0090-0080-0030 | 200 | 11098 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0080/section_0030/0190-0090-0080-0030.html |    19-9-803. Repealed, MCA  |  |
| MTS_0190-0090-0080-0040 | 200 | 12974 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0080/section_0040/0190-0090-0080-0040.html |    19-9-804. Amount of service retirement benefit -- continuation of benefit aft |  |
| MTS_0190-0090-0090-0010 | 200 | 10892 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0090/section_0010/0190-0090-0090-0010.html |    19-9-901. Repealed, MCA  |  |
| MTS_0190-0090-0090-0020 | 200 | 11553 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0090/section_0020/0190-0090-0090-0020.html |    19-9-902. Eligibility for disability retirement, MCA  |  |
| MTS_0190-0090-0090-0030 | 200 | 13157 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0090/section_0030/0190-0090-0090-0030.html |    19-9-903. Amount of disability retirement benefit -- continuation of benefit  |  |
| MTS_0190-0090-0090-0040 | 200 | 13272 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0090/section_0040/0190-0090-0090-0040.html |    19-9-904. Termination of disability benefit, MCA  |  |
| MTS_0190-0090-0090-0050 | 200 | 13482 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0090/section_0050/0190-0090-0090-0050.html |    19-9-905. Reinstatement upon termination of disability benefit, MCA  |  |
| MTS_0190-0090-0090-0060 | 200 | 10869 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0090/section_0060/0190-0090-0090-0060.html |    19-9-906. through 19-9-910 reserved, MCA  |  |
| MTS_0190-0090-0090-0110 | 200 | 10849 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0090/section_0110/0190-0090-0090-0110.html |    19-9-911. Renumbered 19-9-1101, MCA  |  |
| MTS_0190-0090-0090-0120 | 200 | 10632 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0090/section_0120/0190-0090-0090-0120.html |    19-9-912. Renumbered 19-9-1102, MCA  |  |
| MTS_0190-0090-0100-0010 | 200 | 10889 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0010/0190-0090-0100-0010.html |    19-9-1001. Repealed, MCA  |  |
| MTS_0190-0090-0100-0020 | 200 | 11087 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0020/0190-0090-0100-0020.html |    19-9-1002. Repealed, MCA  |  |
| MTS_0190-0090-0100-0030 | 200 | 11101 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0030/0190-0090-0100-0030.html |    19-9-1003. Repealed, MCA  |  |
| MTS_0190-0090-0100-0040 | 200 | 10873 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0040/0190-0090-0100-0040.html |    19-9-1004. Renumbered 19-2-906, MCA  |  |
| MTS_0190-0090-0100-0050 | 200 | 11162 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0050/0190-0090-0100-0050.html |    19-9-1005. Repealed, MCA  |  |
| MTS_0190-0090-0100-0060 | 200 | 11137 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0060/0190-0090-0100-0060.html |    19-9-1006. Repealed, MCA  |  |
| MTS_0190-0090-0100-0070 | 200 | 12887 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0070/0190-0090-0100-0070.html |    19-9-1007. Minimum benefit adjustment, MCA  |  |
| MTS_0190-0090-0100-0080 | 200 | 11100 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0080/0190-0090-0100-0080.html |    19-9-1008. Repealed, MCA  |  |
| MTS_0190-0090-0100-0090 | 200 | 13628 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0090/0190-0090-0100-0090.html |    19-9-1009. Guaranteed annual benefit adjustment, MCA  |  |
| MTS_0190-0090-0100-0100 | 200 | 13990 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0100/0190-0090-0100-0100.html |    19-9-1010. Original election -- guaranteed annual benefit adjustment, MCA  |  |
| MTS_0190-0090-0100-0110 | 200 | 11194 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0110/0190-0090-0100-0110.html |    19-9-1011. Repealed, MCA  |  |
| MTS_0190-0090-0100-0120 | 200 | 11101 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0120/0190-0090-0100-0120.html |    19-9-1012. Repealed, MCA  |  |
| MTS_0190-0090-0100-0130 | 200 | 14147 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0130/0190-0090-0100-0130.html |    19-9-1013. Extended election -- guaranteed annual benefit adjustment, MCA  |  |
| MTS_0190-0090-0100-0140 | 200 | 10922 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0140/0190-0090-0100-0140.html |    19-9-1014. through 19-9-1019 reserved, MCA  |  |
| MTS_0190-0090-0100-0200 | 200 | 10900 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0100/section_0200/0190-0090-0100-0200.html |    19-9-1020. Repealed, MCA  |  |
| MTS_0190-0090-0110-0010 | 200 | 12070 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0110/section_0010/0190-0090-0110-0010.html |    19-9-1101. Preretirement death benefits, MCA  |  |
| MTS_0190-0090-0110-0020 | 200 | 11727 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0110/section_0020/0190-0090-0110-0020.html |    19-9-1102. Payments in absence of spouse or child, MCA  |  |
| MTS_0190-0090-0120-0010 | 200 | 10848 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0120/section_0010/0190-0090-0120-0010.html |    19-9-1201. Short title, MCA  |  |
| MTS_0190-0090-0120-0020 | 200 | 12490 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0120/section_0020/0190-0090-0120-0020.html |    19-9-1202. Definitions, MCA  |  |
| MTS_0190-0090-0120-0030 | 200 | 11919 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0120/section_0030/0190-0090-0120-0030.html |    19-9-1203. Deferred retirement option plan established -- compliance with fed |  |
| MTS_0190-0090-0120-0040 | 200 | 13341 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0120/section_0040/0190-0090-0120-0040.html |    19-9-1204. Eligibility -- participation criteria -- membership status -- serv |  |
| MTS_0190-0090-0120-0050 | 200 | 12295 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0120/section_0050/0190-0090-0120-0050.html |    19-9-1205. Retirement system contributions -- benefit payments to individual  |  |
| MTS_0190-0090-0120-0060 | 200 | 13010 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0120/section_0060/0190-0090-0120-0060.html |    19-9-1206. Survivorship benefits, MCA  |  |
| MTS_0190-0090-0120-0070 | 200 | 12943 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0120/section_0070/0190-0090-0120-0070.html |    19-9-1207. Employment and benefits after DROP period, MCA  |  |
| MTS_0190-0090-0120-0080 | 200 | 12820 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0120/section_0080/0190-0090-0120-0080.html |    19-9-1208. Distribution of DROP benefit, MCA  |  |
| MTS_0190-0090-0130-0010 | 200 | 13029 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0130/section_0010/0190-0090-0130-0010.html |    19-9-1301. Reemployment of members, MCA  |  |
| MTS_0190-0090-0130-0020 | 200 | 13093 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0130/section_0020/0190-0090-0130-0020.html |    19-9-1302. Reemployment of retired members -- contributions required, MCA  |  |
| MTS_0190-0090-0130-0030 | 200 | 15172 | https://leg.mt.gov/bills/mca/title_0190/chapter_0090/part_0130/section_0030/0190-0090-0130-0030.html |    19-9-1303. Refunds and benefits for reemployed retired members, MCA  |  |
| MTS_0190-0100-0010-0010 | 200 | 10446 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0010/section_0010/0190-0100-0010-0010.html |    19-10-101. Renumbered 19-19-101, MCA  |  |
| MTS_0190-0100-0020-0010 | 200 | 10716 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0020/section_0010/0190-0100-0020-0010.html |    19-10-201. Renumbered 19-19-201, MCA  |  |
| MTS_0190-0100-0020-0020 | 200 | 10932 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0020/section_0020/0190-0100-0020-0020.html |    19-10-202. Renumbered 19-19-202, MCA  |  |
| MTS_0190-0100-0020-0030 | 200 | 10932 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0020/section_0030/0190-0100-0020-0030.html |    19-10-203. Renumbered 19-19-203, MCA  |  |
| MTS_0190-0100-0020-0040 | 200 | 10932 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0020/section_0040/0190-0100-0020-0040.html |    19-10-204. Renumbered 19-19-204, MCA  |  |
| MTS_0190-0100-0020-0050 | 200 | 10719 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0020/section_0050/0190-0100-0020-0050.html |    19-10-205. Renumbered 19-19-205, MCA  |  |
| MTS_0190-0100-0030-0010 | 200 | 10671 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0030/section_0010/0190-0100-0030-0010.html |    19-10-301. Renumbered 19-19-301, MCA  |  |
| MTS_0190-0100-0030-0020 | 200 | 10887 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0030/section_0020/0190-0100-0030-0020.html |    19-10-302. Renumbered 19-19-302, MCA  |  |
| MTS_0190-0100-0030-0030 | 200 | 10887 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0030/section_0030/0190-0100-0030-0030.html |    19-10-303. Renumbered 19-19-303, MCA  |  |
| MTS_0190-0100-0030-0040 | 200 | 10887 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0030/section_0040/0190-0100-0030-0040.html |    19-10-304. Renumbered 19-19-304, MCA  |  |
| MTS_0190-0100-0030-0050 | 200 | 10674 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0030/section_0050/0190-0100-0030-0050.html |    19-10-305. Renumbered 19-19-305, MCA  |  |
| MTS_0190-0100-0040-0010 | 200 | 10710 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0040/section_0010/0190-0100-0040-0010.html |    19-10-401. Renumbered 19-19-401, MCA  |  |
| MTS_0190-0100-0040-0020 | 200 | 10926 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0040/section_0020/0190-0100-0040-0020.html |    19-10-402. Renumbered 19-19-402, MCA  |  |
| MTS_0190-0100-0040-0030 | 200 | 10926 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0040/section_0030/0190-0100-0040-0030.html |    19-10-403. Renumbered 19-19-403, MCA  |  |
| MTS_0190-0100-0040-0040 | 200 | 10926 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0040/section_0040/0190-0100-0040-0040.html |    19-10-404. Renumbered 19-19-404, MCA  |  |
| MTS_0190-0100-0040-0050 | 200 | 10926 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0040/section_0050/0190-0100-0040-0050.html |    19-10-405. Renumbered 19-19-405, MCA  |  |
| MTS_0190-0100-0040-0060 | 200 | 10713 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0040/section_0060/0190-0100-0040-0060.html |    19-10-406. Renumbered 19-19-406, MCA  |  |
| MTS_0190-0100-0050-0010 | 200 | 10629 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0050/section_0010/0190-0100-0050-0010.html |    19-10-501. Renumbered 19-19-501, MCA  |  |
| MTS_0190-0100-0050-0020 | 200 | 10845 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0050/section_0020/0190-0100-0050-0020.html |    19-10-502. Renumbered 19-19-502, MCA  |  |
| MTS_0190-0100-0050-0030 | 200 | 10845 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0050/section_0030/0190-0100-0050-0030.html |    19-10-503. Renumbered 19-19-503, MCA  |  |
| MTS_0190-0100-0050-0040 | 200 | 10845 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0050/section_0040/0190-0100-0050-0040.html |    19-10-504. Renumbered 19-19-504, MCA  |  |
| MTS_0190-0100-0050-0050 | 200 | 10845 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0050/section_0050/0190-0100-0050-0050.html |    19-10-505. Renumbered 19-19-505, MCA  |  |
| MTS_0190-0100-0050-0060 | 200 | 10632 | https://leg.mt.gov/bills/mca/title_0190/chapter_0100/part_0050/section_0060/0190-0100-0050-0060.html |    19-10-506. Renumbered 19-19-506, MCA  |  |
| MTS_0190-0110-0010-0010 | 200 | 10670 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0010/section_0010/0190-0110-0010-0010.html |    19-11-101. Renumbered 19-18-101, MCA  |  |
| MTS_0190-0110-0010-0020 | 200 | 10886 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0010/section_0020/0190-0110-0010-0020.html |    19-11-102. Renumbered 19-18-102, MCA  |  |
| MTS_0190-0110-0010-0030 | 200 | 10886 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0010/section_0030/0190-0110-0010-0030.html |    19-11-103. Renumbered 19-18-103, MCA  |  |
| MTS_0190-0110-0010-0040 | 200 | 10886 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0010/section_0040/0190-0110-0010-0040.html |    19-11-104. Renumbered 19-18-104, MCA  |  |
| MTS_0190-0110-0010-0050 | 200 | 10886 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0010/section_0050/0190-0110-0010-0050.html |    19-11-105. Renumbered 19-18-105, MCA  |  |
| MTS_0190-0110-0010-0060 | 200 | 10886 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0010/section_0060/0190-0110-0010-0060.html |    19-11-106. Renumbered 19-18-106, MCA  |  |
| MTS_0190-0110-0010-0070 | 200 | 10673 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0010/section_0070/0190-0110-0010-0070.html |    19-11-107. Renumbered 19-18-107, MCA  |  |
| MTS_0190-0110-0020-0010 | 200 | 10715 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0020/section_0010/0190-0110-0020-0010.html |    19-11-201. Renumbered 19-18-201, MCA  |  |
| MTS_0190-0110-0020-0020 | 200 | 10931 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0020/section_0020/0190-0110-0020-0020.html |    19-11-202. Renumbered 19-18-202, MCA  |  |
| MTS_0190-0110-0020-0030 | 200 | 10931 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0020/section_0030/0190-0110-0020-0030.html |    19-11-203. Renumbered 19-18-203, MCA  |  |
| MTS_0190-0110-0020-0040 | 200 | 10931 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0020/section_0040/0190-0110-0020-0040.html |    19-11-204. Renumbered 19-18-204, MCA  |  |
| MTS_0190-0110-0020-0050 | 200 | 10931 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0020/section_0050/0190-0110-0020-0050.html |    19-11-205. Renumbered 19-18-205, MCA  |  |
| MTS_0190-0110-0020-0060 | 200 | 10931 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0020/section_0060/0190-0110-0020-0060.html |    19-11-206. Renumbered 19-18-206, MCA  |  |
| MTS_0190-0110-0020-0070 | 200 | 10931 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0020/section_0070/0190-0110-0020-0070.html |    19-11-207. Renumbered 19-18-207, MCA  |  |
| MTS_0190-0110-0020-0080 | 200 | 10718 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0020/section_0080/0190-0110-0020-0080.html |    19-11-208. Renumbered 19-18-208, MCA  |  |
| MTS_0190-0110-0030-0010 | 200 | 11324 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0030/section_0010/0190-0110-0030-0010.html |    19-11-301. Repealed, MCA  |  |
| MTS_0190-0110-0030-0020 | 200 | 11497 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0030/section_0020/0190-0110-0030-0020.html |    19-11-302. Repealed, MCA  |  |
| MTS_0190-0110-0030-0030 | 200 | 11327 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0030/section_0030/0190-0110-0030-0030.html |    19-11-303. Repealed, MCA  |  |
| MTS_0190-0110-0040-0010 | 200 | 10757 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0040/section_0010/0190-0110-0040-0010.html |    19-11-401. Renumbered 19-18-401, MCA  |  |
| MTS_0190-0110-0040-0020 | 200 | 10973 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0040/section_0020/0190-0110-0040-0020.html |    19-11-402. Renumbered 19-18-402, MCA  |  |
| MTS_0190-0110-0040-0030 | 200 | 10760 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0040/section_0030/0190-0110-0040-0030.html |    19-11-403. Renumbered 19-18-403, MCA  |  |
| MTS_0190-0110-0050-0010 | 200 | 10679 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0050/section_0010/0190-0110-0050-0010.html |    19-11-501. Renumbered 19-18-501, MCA  |  |
| MTS_0190-0110-0050-0020 | 200 | 10895 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0050/section_0020/0190-0110-0050-0020.html |    19-11-502. Renumbered 19-18-502, MCA  |  |
| MTS_0190-0110-0050-0030 | 200 | 10895 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0050/section_0030/0190-0110-0050-0030.html |    19-11-503. Renumbered 19-18-503, MCA  |  |
| MTS_0190-0110-0050-0040 | 200 | 10901 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0050/section_0040/0190-0110-0050-0040.html |    19-11-504. Renumbered 19-18-504, MCA  |  |
| MTS_0190-0110-0050-0050 | 200 | 10893 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0050/section_0050/0190-0110-0050-0050.html |    19-11-505. through 19-11-510 reserved, MCA  |  |
| MTS_0190-0110-0050-0110 | 200 | 10901 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0050/section_0110/0190-0110-0050-0110.html |    19-11-511. Renumbered 19-18-511, MCA  |  |
| MTS_0190-0110-0050-0120 | 200 | 10895 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0050/section_0120/0190-0110-0050-0120.html |    19-11-512. Renumbered 19-18-512, MCA  |  |
| MTS_0190-0110-0050-0130 | 200 | 10895 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0050/section_0130/0190-0110-0050-0130.html |    19-11-513. Renumbered 19-18-513, MCA  |  |
| MTS_0190-0110-0050-0140 | 200 | 10682 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0050/section_0140/0190-0110-0050-0140.html |    19-11-514. Renumbered 19-18-514, MCA  |  |
| MTS_0190-0110-0060-0010 | 200 | 10640 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0060/section_0010/0190-0110-0060-0010.html |    19-11-601. Renumbered 19-18-601, MCA  |  |
| MTS_0190-0110-0060-0020 | 200 | 10856 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0060/section_0020/0190-0110-0060-0020.html |    19-11-602. Renumbered 19-18-602, MCA  |  |
| MTS_0190-0110-0060-0030 | 200 | 10856 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0060/section_0030/0190-0110-0060-0030.html |    19-11-603. Renumbered 19-18-603, MCA  |  |
| MTS_0190-0110-0060-0040 | 200 | 10856 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0060/section_0040/0190-0110-0060-0040.html |    19-11-604. Renumbered 19-18-604, MCA  |  |
| MTS_0190-0110-0060-0050 | 200 | 10856 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0060/section_0050/0190-0110-0060-0050.html |    19-11-605. Renumbered 19-18-605, MCA  |  |
| MTS_0190-0110-0060-0060 | 200 | 10856 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0060/section_0060/0190-0110-0060-0060.html |    19-11-606. Renumbered 19-18-606, MCA  |  |
| MTS_0190-0110-0060-0070 | 200 | 10862 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0060/section_0070/0190-0110-0060-0070.html |    19-11-607. Renumbered 19-18-607, MCA  |  |
| MTS_0190-0110-0060-0080 | 200 | 10854 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0060/section_0080/0190-0110-0060-0080.html |    19-11-608. through 19-11-610 reserved, MCA  |  |
| MTS_0190-0110-0060-0110 | 200 | 10862 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0060/section_0110/0190-0110-0060-0110.html |    19-11-611. Renumbered 19-18-611, MCA  |  |
| MTS_0190-0110-0060-0120 | 200 | 10643 | https://leg.mt.gov/bills/mca/title_0190/chapter_0110/part_0060/section_0120/0190-0110-0060-0120.html |    19-11-612. Renumbered 19-18-612, MCA  |  |
| MTS_0190-0120-0010-0010 | 200 | 10675 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0010/section_0010/0190-0120-0010-0010.html |    19-12-101. Renumbered 19-17-101, MCA  |  |
| MTS_0190-0120-0010-0020 | 200 | 10891 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0010/section_0020/0190-0120-0010-0020.html |    19-12-102. Renumbered 19-17-102, MCA  |  |
| MTS_0190-0120-0010-0030 | 200 | 10891 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0010/section_0030/0190-0120-0010-0030.html |    19-12-103. Renumbered 19-17-103, MCA  |  |
| MTS_0190-0120-0010-0040 | 200 | 10891 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0010/section_0040/0190-0120-0010-0040.html |    19-12-104. Renumbered 19-17-104, MCA  |  |
| MTS_0190-0120-0010-0050 | 200 | 10678 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0010/section_0050/0190-0120-0010-0050.html |    19-12-105. Renumbered 19-17-105, MCA  |  |
| MTS_0190-0120-0020-0010 | 200 | 10687 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0020/section_0010/0190-0120-0020-0010.html |    19-12-201. Renumbered 19-17-201, MCA  |  |
| MTS_0190-0120-0020-0020 | 200 | 10903 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0020/section_0020/0190-0120-0020-0020.html |    19-12-202. Renumbered 19-17-202, MCA  |  |
| MTS_0190-0120-0020-0030 | 200 | 10903 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0020/section_0030/0190-0120-0020-0030.html |    19-12-203. Renumbered 19-17-203, MCA  |  |
| MTS_0190-0120-0020-0040 | 200 | 10690 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0020/section_0040/0190-0120-0020-0040.html |    19-12-204. Renumbered 19-17-204, MCA  |  |
| MTS_0190-0120-0030-0010 | 200 | 10684 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0030/section_0010/0190-0120-0030-0010.html |    19-12-301. Renumbered 19-17-301, MCA  |  |
| MTS_0190-0120-0030-0020 | 200 | 10687 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0030/section_0020/0190-0120-0030-0020.html |    19-12-302. Renumbered 19-17-302, MCA  |  |
| MTS_0190-0120-0040-0010 | 200 | 10669 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0040/section_0010/0190-0120-0040-0010.html |    19-12-401. Renumbered 19-17-401, MCA  |  |
| MTS_0190-0120-0040-0020 | 200 | 10885 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0040/section_0020/0190-0120-0040-0020.html |    19-12-402. Renumbered 19-17-402, MCA  |  |
| MTS_0190-0120-0040-0030 | 200 | 10885 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0040/section_0030/0190-0120-0040-0030.html |    19-12-403. Renumbered 19-17-403, MCA  |  |
| MTS_0190-0120-0040-0040 | 200 | 10885 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0040/section_0040/0190-0120-0040-0040.html |    19-12-404. Renumbered 19-17-404, MCA  |  |
| MTS_0190-0120-0040-0050 | 200 | 10885 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0040/section_0050/0190-0120-0040-0050.html |    19-12-405. Renumbered 19-17-405, MCA  |  |
| MTS_0190-0120-0040-0060 | 200 | 10885 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0040/section_0060/0190-0120-0040-0060.html |    19-12-406. Renumbered 19-17-406, MCA  |  |
| MTS_0190-0120-0040-0070 | 200 | 10885 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0040/section_0070/0190-0120-0040-0070.html |    19-12-407. Renumbered 19-17-407, MCA  |  |
| MTS_0190-0120-0040-0080 | 200 | 10885 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0040/section_0080/0190-0120-0040-0080.html |    19-12-408. Renumbered 19-17-408, MCA  |  |
| MTS_0190-0120-0040-0090 | 200 | 10672 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0040/section_0090/0190-0120-0040-0090.html |    19-12-409. Renumbered 19-17-409, MCA  |  |
| MTS_0190-0120-0050-0010 | 200 | 10708 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0050/section_0010/0190-0120-0050-0010.html |    19-12-501. Renumbered 19-17-501, MCA  |  |
| MTS_0190-0120-0050-0020 | 200 | 10924 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0050/section_0020/0190-0120-0050-0020.html |    19-12-502. Renumbered 19-17-502, MCA  |  |
| MTS_0190-0120-0050-0030 | 200 | 10924 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0050/section_0030/0190-0120-0050-0030.html |    19-12-503. Renumbered 19-17-503, MCA  |  |
| MTS_0190-0120-0050-0040 | 200 | 10924 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0050/section_0040/0190-0120-0050-0040.html |    19-12-504. Renumbered 19-17-504, MCA  |  |
| MTS_0190-0120-0050-0050 | 200 | 10924 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0050/section_0050/0190-0120-0050-0050.html |    19-12-505. Renumbered 19-17-505, MCA  |  |
| MTS_0190-0120-0050-0060 | 200 | 10711 | https://leg.mt.gov/bills/mca/title_0190/chapter_0120/part_0050/section_0060/0190-0120-0050-0060.html |    19-12-506. Renumbered 19-17-506, MCA  |  |
| MTS_0190-0130-0010-0010 | 200 | 10829 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0010/0190-0130-0010-0010.html |    19-13-101. Short title, MCA  |  |
| MTS_0190-0130-0010-0020 | 200 | 12219 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0020/0190-0130-0010-0020.html |    19-13-102. Purpose -- application of prior law, MCA  |  |
| MTS_0190-0130-0010-0030 | 200 | 11381 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0030/0190-0130-0010-0030.html |    19-13-103. Firefighters' unified retirement system established, MCA  |  |
| MTS_0190-0130-0010-0040 | 200 | 19656 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0040/0190-0130-0010-0040.html |    19-13-104. Definitions, MCA  |  |
| MTS_0190-0130-0010-0050 | 200 | 10804 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0050/0190-0130-0010-0050.html |    19-13-105. Renumbered 19-13-210, MCA  |  |
| MTS_0190-0130-0010-0060 | 200 | 11003 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0060/0190-0130-0010-0060.html |    19-13-106. Repealed, MCA  |  |
| MTS_0190-0130-0010-0070 | 200 | 10813 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0070/0190-0130-0010-0070.html |    19-13-107. Renumbered 19-13-310, MCA  |  |
| MTS_0190-0130-0010-0080 | 200 | 10813 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0080/0190-0130-0010-0080.html |    19-13-108. Renumbered 19-13-211, MCA  |  |
| MTS_0190-0130-0010-0090 | 200 | 11003 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0090/0190-0130-0010-0090.html |    19-13-109. Repealed, MCA  |  |
| MTS_0190-0130-0010-0100 | 200 | 10857 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0100/0190-0130-0010-0100.html |    19-13-110. Renumbered 19-13-212, MCA  |  |
| MTS_0190-0130-0010-0110 | 200 | 11422 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0110/0190-0130-0010-0110.html |    19-13-111. Firefighters' unified retirement system benefit policy statement,  |  |
| MTS_0190-0130-0010-0120 | 200 | 10888 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0120/0190-0130-0010-0120.html |    19-13-112. through 19-13-114 reserved, MCA  |  |
| MTS_0190-0130-0010-0150 | 200 | 11409 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0010/section_0150/0190-0130-0010-0150.html |    19-13-115. Firefighter's association to advise board, MCA  |  |
| MTS_0190-0130-0020-0010 | 200 | 10696 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0020/section_0010/0190-0130-0020-0010.html |    19-13-201. Renumbered 19-13-115, MCA  |  |
| MTS_0190-0130-0020-0020 | 200 | 11091 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0020/section_0020/0190-0130-0020-0020.html |    19-13-202. Repealed, MCA  |  |
| MTS_0190-0130-0020-0030 | 200 | 11079 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0020/section_0030/0190-0130-0020-0030.html |    19-13-203. Repealed, MCA  |  |
| MTS_0190-0130-0020-0040 | 200 | 11113 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0020/section_0040/0190-0130-0020-0040.html |    19-13-204. Repealed, MCA  |  |
| MTS_0190-0130-0020-0050 | 200 | 11104 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0020/section_0050/0190-0130-0020-0050.html |    19-13-205. Terminated, MCA  |  |
| MTS_0190-0130-0020-0060 | 200 | 10926 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0020/section_0060/0190-0130-0020-0060.html |    19-13-206. through 19-13-209 reserved, MCA  |  |
| MTS_0190-0130-0020-0100 | 200 | 15080 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0020/section_0100/0190-0130-0020-0100.html |    19-13-210. Participation in retirement system, MCA  |  |
| MTS_0190-0130-0020-0110 | 200 | 13668 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0020/section_0110/0190-0130-0020-0110.html |    19-13-211. Election to join retirement system -- transfer of assets, MCA  |  |
| MTS_0190-0130-0020-0120 | 200 | 12913 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0020/section_0120/0190-0130-0020-0120.html |    19-13-212. Termination of participation in retirement system or reduction of  |  |
| MTS_0190-0130-0020-0130 | 200 | 12291 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0020/section_0130/0190-0130-0020-0130.html |    19-13-213. Excess unfunded liabilities of prior plans, MCA  |  |
| MTS_0190-0130-0020-0140 | 200 | 11486 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0020/section_0140/0190-0130-0020-0140.html |    19-13-214. Taxing authority of employers, MCA  |  |
| MTS_0190-0130-0030-0010 | 200 | 14393 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0030/section_0010/0190-0130-0030-0010.html |    19-13-301. Active membership -- inactive vested member -- inactive nonvested  |  |
| MTS_0190-0130-0030-0020 | 200 | 11663 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0030/section_0020/0190-0130-0030-0020.html |    19-13-302. Ineligibility for other retirement plans, MCA  |  |
| MTS_0190-0130-0030-0030 | 200 | 11066 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0030/section_0030/0190-0130-0030-0030.html |    19-13-303. Repealed, MCA  |  |
| MTS_0190-0130-0030-0040 | 200 | 11065 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0030/section_0040/0190-0130-0030-0040.html |    19-13-304. Repealed, MCA  |  |
| MTS_0190-0130-0030-0050 | 200 | 11052 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0030/section_0050/0190-0130-0030-0050.html |    19-13-305. Repealed, MCA  |  |
| MTS_0190-0130-0030-0060 | 200 | 10877 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0030/section_0060/0190-0130-0030-0060.html |    19-13-306. through 19-13-309 reserved, MCA  |  |
| MTS_0190-0130-0030-0100 | 200 | 11250 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0030/section_0100/0190-0130-0030-0100.html |    19-13-310. Effect on members of prior plans, MCA  |  |
| MTS_0190-0130-0040-0010 | 200 | 10764 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0040/section_0010/0190-0130-0040-0010.html |    19-13-401. Repealed, MCA  |  |
| MTS_0190-0130-0040-0020 | 200 | 11000 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0040/section_0020/0190-0130-0040-0020.html |    19-13-402. Repealed, MCA  |  |
| MTS_0190-0130-0040-0030 | 200 | 13250 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0040/section_0030/0190-0130-0040-0030.html |    19-13-403. Application to purchase military service, MCA  |  |
| MTS_0190-0130-0040-0040 | 200 | 11225 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0040/section_0040/0190-0130-0040-0040.html |    19-13-404. Repealed, MCA  |  |
| MTS_0190-0130-0040-0050 | 200 | 12091 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0040/section_0050/0190-0130-0040-0050.html |    19-13-405. Application to purchase additional service, MCA  |  |
| MTS_0190-0130-0040-0060 | 200 | 11143 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0040/section_0060/0190-0130-0040-0060.html |    19-13-406. Service purchase limitation, MCA  |  |
| MTS_0190-0130-0050-0010 | 200 | 10967 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0050/section_0010/0190-0130-0050-0010.html |    19-13-501. Repealed, MCA  |  |
| MTS_0190-0130-0050-0020 | 200 | 11151 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0050/section_0020/0190-0130-0050-0020.html |    19-13-502. Repealed, MCA  |  |
| MTS_0190-0130-0050-0030 | 200 | 10960 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0050/section_0030/0190-0130-0050-0030.html |    19-13-503. Renumbered 19-13-213, MCA  |  |
| MTS_0190-0130-0050-0040 | 200 | 11151 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0050/section_0040/0190-0130-0050-0040.html |    19-13-504. Repealed, MCA  |  |
| MTS_0190-0130-0050-0050 | 200 | 11151 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0050/section_0050/0190-0130-0050-0050.html |    19-13-505. Repealed, MCA  |  |
| MTS_0190-0130-0050-0060 | 200 | 10759 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0050/section_0060/0190-0130-0050-0060.html |    19-13-506. Renumbered 19-13-615, MCA  |  |
| MTS_0190-0130-0060-0010 | 200 | 14398 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0060/section_0010/0190-0130-0060-0010.html |    19-13-601. Deduction remitted to firemen's association -- member's contributi |  |
| MTS_0190-0130-0060-0020 | 200 | 11061 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0060/section_0020/0190-0130-0060-0020.html |    19-13-602. Repealed, MCA  |  |
| MTS_0190-0130-0060-0030 | 200 | 11042 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0060/section_0030/0190-0130-0060-0030.html |    19-13-603. Repealed, MCA  |  |
| MTS_0190-0130-0060-0040 | 200 | 12029 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0060/section_0040/0190-0130-0060-0040.html |    19-13-604. State contribution, MCA  |  |
| MTS_0190-0130-0060-0050 | 200 | 11682 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0060/section_0050/0190-0130-0060-0050.html |    19-13-605. Employer contribution, MCA  |  |
| MTS_0190-0130-0060-0060 | 200 | 10873 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0060/section_0060/0190-0130-0060-0060.html |    19-13-606. Renumbered 19-13-214, MCA  |  |
| MTS_0190-0130-0060-0070 | 200 | 11713 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0060/section_0070/0190-0130-0060-0070.html |    19-13-607. Other money credited as employer contributions, MCA  |  |
| MTS_0190-0130-0060-0080 | 200 | 11037 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0060/section_0080/0190-0130-0060-0080.html |    19-13-608. Repealed, MCA  |  |
| MTS_0190-0130-0060-0090 | 200 | 11018 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0060/section_0090/0190-0130-0060-0090.html |    19-13-609. Repealed, MCA  |  |
| MTS_0190-0130-0060-0100 | 200 | 10820 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0060/section_0100/0190-0130-0060-0100.html |    19-13-610. through 19-13-614 reserved, MCA  |  |
| MTS_0190-0130-0060-0150 | 200 | 11007 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0060/section_0150/0190-0130-0060-0150.html |    19-13-615. Repealed, MCA  |  |
| MTS_0190-0130-0070-0010 | 200 | 12167 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0070/section_0010/0190-0130-0070-0010.html |    19-13-701. Eligibility for service retirement, MCA  |  |
| MTS_0190-0130-0070-0020 | 200 | 11031 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0070/section_0020/0190-0130-0070-0020.html |    19-13-702. Repealed, MCA  |  |
| MTS_0190-0130-0070-0030 | 200 | 11033 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0070/section_0030/0190-0130-0070-0030.html |    19-13-703. Repealed, MCA  |  |
| MTS_0190-0130-0070-0040 | 200 | 12854 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0070/section_0040/0190-0130-0070-0040.html |    19-13-704. Amount of service retirement benefit, MCA  |  |
| MTS_0190-0130-0080-0010 | 200 | 10841 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0080/section_0010/0190-0130-0080-0010.html |    19-13-801. Repealed, MCA  |  |
| MTS_0190-0130-0080-0020 | 200 | 11488 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0080/section_0020/0190-0130-0080-0020.html |    19-13-802. Eligibility for disability retirement, MCA  |  |
| MTS_0190-0130-0080-0030 | 200 | 13177 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0080/section_0030/0190-0130-0080-0030.html |    19-13-803. Amount of disability retirement benefit, MCA  |  |
| MTS_0190-0130-0080-0040 | 200 | 12818 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0080/section_0040/0190-0130-0080-0040.html |    19-13-804. Medical examination of disability retiree -- cancellation of benef |  |
| MTS_0190-0130-0080-0050 | 200 | 14181 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0080/section_0050/0190-0130-0080-0050.html |    19-13-805. Reinstatement upon termination of benefit, MCA  |  |
| MTS_0190-0130-0090-0010 | 200 | 10884 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0090/section_0010/0190-0130-0090-0010.html |    19-13-901. Repealed, MCA  |  |
| MTS_0190-0130-0090-0020 | 200 | 12866 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0090/section_0020/0190-0130-0090-0020.html |    19-13-902. Survivorship benefit, MCA  |  |
| MTS_0190-0130-0090-0030 | 200 | 11628 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0090/section_0030/0190-0130-0090-0030.html |    19-13-903. Payments to designated beneficiary, MCA  |  |
| MTS_0190-0130-0100-0010 | 200 | 10866 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0100/section_0010/0190-0130-0100-0010.html |    19-13-1001. Repealed, MCA  |  |
| MTS_0190-0130-0100-0020 | 200 | 11071 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0100/section_0020/0190-0130-0100-0020.html |    19-13-1002. Repealed, MCA  |  |
| MTS_0190-0130-0100-0030 | 200 | 11134 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0100/section_0030/0190-0130-0100-0030.html |    19-13-1003. Repealed, MCA  |  |
| MTS_0190-0130-0100-0040 | 200 | 11071 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0100/section_0040/0190-0130-0100-0040.html |    19-13-1004. Repealed, MCA  |  |
| MTS_0190-0130-0100-0050 | 200 | 11071 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0100/section_0050/0190-0130-0100-0050.html |    19-13-1005. Repealed, MCA  |  |
| MTS_0190-0130-0100-0060 | 200 | 11214 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0100/section_0060/0190-0130-0100-0060.html |    19-13-1006. Repealed, MCA  |  |
| MTS_0190-0130-0100-0070 | 200 | 14438 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0100/section_0070/0190-0130-0100-0070.html |    19-13-1007. Minimum benefit adjustment, MCA  |  |
| MTS_0190-0130-0100-0080 | 200 | 11087 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0100/section_0080/0190-0130-0100-0080.html |    19-13-1008. Repealed, MCA  |  |
| MTS_0190-0130-0100-0090 | 200 | 11161 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0100/section_0090/0190-0130-0100-0090.html |    19-13-1009. Repealed, MCA  |  |
| MTS_0190-0130-0100-0100 | 200 | 13636 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0100/section_0100/0190-0130-0100-0100.html |    19-13-1010. Guaranteed annual benefit adjustment, MCA  |  |
| MTS_0190-0130-0100-0110 | 200 | 13732 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0100/section_0110/0190-0130-0100-0110.html |    19-13-1011. Election -- guaranteed annual benefit adjustment, MCA  |  |
| MTS_0190-0130-0110-0010 | 200 | 12891 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0110/section_0010/0190-0130-0110-0010.html |    19-13-1101. Reemployment of retired members -- contributions required, MCA  |  |
| MTS_0190-0130-0110-0020 | 200 | 15198 | https://leg.mt.gov/bills/mca/title_0190/chapter_0130/part_0110/section_0020/0190-0130-0110-0020.html |    19-13-1102. Refunds and benefits for reemployed retired members, MCA  |  |
| MTS_0190-0150-0010-0010 | 200 | 10834 | https://leg.mt.gov/bills/mca/title_0190/chapter_0150/part_0010/section_0010/0190-0150-0010-0010.html |    19-15-101. Repealed, MCA  |  |
| MTS_0190-0150-0010-0020 | 200 | 10837 | https://leg.mt.gov/bills/mca/title_0190/chapter_0150/part_0010/section_0020/0190-0150-0010-0020.html |    19-15-102. Repealed, MCA  |  |
| MTS_0190-0170-0010-0010 | 200 | 11038 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0010/0190-0170-0010-0010.html |    19-17-101. Short title, MCA  |  |
| MTS_0190-0170-0010-0020 | 200 | 17295 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0020/0190-0170-0010-0020.html |    19-17-102. Definitions, MCA  |  |
| MTS_0190-0170-0010-0030 | 200 | 10807 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0030/0190-0170-0010-0030.html |    19-17-103. Renumbered 19-17-205, MCA  |  |
| MTS_0190-0170-0010-0040 | 200 | 11298 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0040/0190-0170-0010-0040.html |    19-17-104. Repealed, MCA  |  |
| MTS_0190-0170-0010-0050 | 200 | 11598 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0050/0190-0170-0010-0050.html |    19-17-105. Duties of volunteer firefighters, MCA  |  |
| MTS_0190-0170-0010-0060 | 200 | 13794 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0060/0190-0170-0010-0060.html |    19-17-106. Pension trust fund established -- restrictions on use, MCA  |  |
| MTS_0190-0170-0010-0070 | 200 | 12302 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0070/0190-0170-0010-0070.html |    19-17-107. Employment of actuary -- annual investigation, MCA  |  |
| MTS_0190-0170-0010-0080 | 200 | 13141 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0080/0190-0170-0010-0080.html |    19-17-108. Credit for service as volunteer firefighter -- records, MCA  |  |
| MTS_0190-0170-0010-0090 | 200 | 12696 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0090/0190-0170-0010-0090.html |    19-17-109. Eligible fire company, MCA  |  |
| MTS_0190-0170-0010-0100 | 200 | 11978 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0100/0190-0170-0010-0100.html |    19-17-110. Allowable payments to volunteer firefighters, MCA  |  |
| MTS_0190-0170-0010-0110 | 200 | 11719 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0110/0190-0170-0010-0110.html |    19-17-111. Records information management, MCA  |  |
| MTS_0190-0170-0010-0120 | 200 | 14115 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0120/0190-0170-0010-0120.html |    19-17-112. Filing required reports -- limitations, MCA  |  |
| MTS_0190-0170-0010-0130 | 200 | 12238 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0130/0190-0170-0010-0130.html |    19-17-113. Corrections, audits, and penalties, MCA  |  |
| MTS_0190-0170-0010-0140 | 200 | 10884 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0140/0190-0170-0010-0140.html |    19-17-114. through 19-17-116 reserved, MCA  |  |
| MTS_0190-0170-0010-0170 | 200 | 11217 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0010/section_0170/0190-0170-0010-0170.html |    19-17-117. Volunteer Firefighters' Compensation Act benefit policy statement, |  |
| MTS_0190-0170-0020-0010 | 200 | 12638 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0020/section_0010/0190-0170-0020-0010.html |    19-17-201. Administration of chapter, MCA  |  |
| MTS_0190-0170-0020-0020 | 200 | 12179 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0020/section_0020/0190-0170-0020-0020.html |    19-17-202. Reports of board, MCA  |  |
| MTS_0190-0170-0020-0030 | 200 | 11635 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0020/section_0030/0190-0170-0020-0030.html |    19-17-203. Rules to be made by board, MCA  |  |
| MTS_0190-0170-0020-0040 | 200 | 12061 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0020/section_0040/0190-0170-0020-0040.html |    19-17-204. Administrative expenses, MCA  |  |
| MTS_0190-0170-0020-0050 | 200 | 12269 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0020/section_0050/0190-0170-0020-0050.html |    19-17-205. Payments to fire companies maintaining supplemental insurance, MCA |  |
| MTS_0190-0170-0030-0010 | 200 | 12563 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0030/section_0010/0190-0170-0030-0010.html |    19-17-301. Fire insurance premium tax to be paid into pension trust fund, MCA |  |
| MTS_0190-0170-0030-0020 | 200 | 11783 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0030/section_0020/0190-0170-0030-0020.html |    19-17-302. Investment of pension trust fund, MCA  |  |
| MTS_0190-0170-0040-0010 | 200 | 12991 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0040/section_0010/0190-0170-0040-0010.html |    19-17-401. Eligibility for pension benefits, MCA  |  |
| MTS_0190-0170-0040-0020 | 200 | 11422 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0040/section_0020/0190-0170-0040-0020.html |    19-17-402. Repealed, MCA  |  |
| MTS_0190-0170-0040-0030 | 200 | 13079 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0040/section_0030/0190-0170-0040-0030.html |    19-17-403. Application for benefits, MCA  |  |
| MTS_0190-0170-0040-0040 | 200 | 13884 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0040/section_0040/0190-0170-0040-0040.html |    19-17-404. Amount of pension benefits, MCA  |  |
| MTS_0190-0170-0040-0050 | 200 | 13854 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0040/section_0050/0190-0170-0040-0050.html |    19-17-405. Survivorship benefits to surviving spouse or dependent children, M |  |
| MTS_0190-0170-0040-0060 | 200 | 11957 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0040/section_0060/0190-0170-0040-0060.html |    19-17-406. Termination of pension when no surviving spouse or child, MCA  |  |
| MTS_0190-0170-0040-0070 | 200 | 12852 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0040/section_0070/0190-0170-0040-0070.html |    19-17-407. Exemption from legal process, MCA  |  |
| MTS_0190-0170-0040-0080 | 200 | 10881 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0040/section_0080/0190-0170-0040-0080.html |    19-17-408. Renumbered 19-17-604, MCA  |  |
| MTS_0190-0170-0040-0090 | 200 | 10873 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0040/section_0090/0190-0170-0040-0090.html |    19-17-409. Renumbered 19-17-605, MCA  |  |
| MTS_0190-0170-0040-0100 | 200 | 10875 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0040/section_0100/0190-0170-0040-0100.html |    19-17-410. Renumbered 19-17-603, MCA  |  |
| MTS_0190-0170-0040-0110 | 200 | 11986 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0040/section_0110/0190-0170-0040-0110.html |    19-17-411. Time benefits commence, MCA  |  |
| MTS_0190-0170-0040-0120 | 200 | 11332 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0040/section_0120/0190-0170-0040-0120.html |    19-17-412. Return to service, MCA  |  |
| MTS_0190-0170-0050-0010 | 200 | 12577 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0050/section_0010/0190-0170-0050-0010.html |    19-17-501. Eligibility for medical and funeral expenses, MCA  |  |
| MTS_0190-0170-0050-0020 | 200 | 14988 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0050/section_0020/0190-0170-0050-0020.html |    19-17-502. Medical expenses, MCA  |  |
| MTS_0190-0170-0050-0030 | 200 | 12944 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0050/section_0030/0190-0170-0050-0030.html |    19-17-503. Funeral expenses, MCA  |  |
| MTS_0190-0170-0050-0040 | 200 | 11641 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0050/section_0040/0190-0170-0050-0040.html |    19-17-504. Repealed, MCA  |  |
| MTS_0190-0170-0050-0050 | 200 | 11566 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0050/section_0050/0190-0170-0050-0050.html |    19-17-505. Repealed, MCA  |  |
| MTS_0190-0170-0050-0060 | 200 | 11340 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0050/section_0060/0190-0170-0050-0060.html |    19-17-506. Repealed, MCA  |  |
| MTS_0190-0170-0060-0010 | 200 | 11699 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0060/section_0010/0190-0170-0060-0010.html |    19-17-601. Eligibility for disability benefits, MCA  |  |
| MTS_0190-0170-0060-0020 | 200 | 11691 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0060/section_0020/0190-0170-0060-0020.html |    19-17-602. Amount of disability benefit, MCA  |  |
| MTS_0190-0170-0060-0030 | 200 | 11985 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0060/section_0030/0190-0170-0060-0030.html |    19-17-603. Determination of disability, MCA  |  |
| MTS_0190-0170-0060-0040 | 200 | 11983 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0060/section_0040/0190-0170-0060-0040.html |    19-17-604. Medical review of certain disability retirees, MCA  |  |
| MTS_0190-0170-0060-0050 | 200 | 12235 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0060/section_0050/0190-0170-0060-0050.html |    19-17-605. Cancellation of disability benefits, MCA  |  |
| MTS_0190-0170-0060-0060 | 200 | 11255 | https://leg.mt.gov/bills/mca/title_0190/chapter_0170/part_0060/section_0060/0190-0170-0060-0060.html |    19-17-606. Time disability benefits commence, MCA  |  |
| MTS_0190-0180-0010-0010 | 200 | 12413 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0010/section_0010/0190-0180-0010-0010.html |    19-18-101. Definitions, MCA  |  |
| MTS_0190-0180-0010-0020 | 200 | 12434 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0010/section_0020/0190-0180-0010-0020.html |    19-18-102. Formation of fire department relief association -- membership, MCA |  |
| MTS_0190-0180-0010-0030 | 200 | 11723 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0010/section_0030/0190-0180-0010-0030.html |    19-18-103. Officers of association, MCA  |  |
| MTS_0190-0180-0010-0040 | 200 | 11844 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0010/section_0040/0190-0180-0010-0040.html |    19-18-104. Board of trustees of association, MCA  |  |
| MTS_0190-0180-0010-0050 | 200 | 11773 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0010/section_0050/0190-0180-0010-0050.html |    19-18-105. Establishment of disability and pension fund, MCA  |  |
| MTS_0190-0180-0010-0060 | 200 | 12094 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0010/section_0060/0190-0180-0010-0060.html |    19-18-106. Transfer of money into fund by city treasurer, MCA  |  |
| MTS_0190-0180-0010-0070 | 200 | 12407 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0010/section_0070/0190-0180-0010-0070.html |    19-18-107. Retention of firefighters' rights when local government consolidat |  |
| MTS_0190-0180-0020-0010 | 200 | 11537 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0020/section_0010/0190-0180-0020-0010.html |    19-18-201. Management of fund, MCA  |  |
| MTS_0190-0180-0020-0020 | 200 | 12114 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0020/section_0020/0190-0180-0020-0020.html |    19-18-202. Treasurer's bond, MCA  |  |
| MTS_0190-0180-0020-0030 | 200 | 13013 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0020/section_0030/0190-0180-0020-0030.html |    19-18-203. Use of disability and pension fund, MCA  |  |
| MTS_0190-0180-0020-0040 | 200 | 11912 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0020/section_0040/0190-0180-0020-0040.html |    19-18-204. Review and report by board of trustees, MCA  |  |
| MTS_0190-0180-0020-0050 | 200 | 12434 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0020/section_0050/0190-0180-0020-0050.html |    19-18-205. Annual report of secretary and treasurer to association and state  |  |
| MTS_0190-0180-0020-0060 | 200 | 12520 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0020/section_0060/0190-0180-0020-0060.html |    19-18-206. Authority of department of administration -- mishandling of funds, |  |
| MTS_0190-0180-0020-0070 | 200 | 11929 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0020/section_0070/0190-0180-0020-0070.html |    19-18-207. Theft from funds, MCA  |  |
| MTS_0190-0180-0020-0080 | 200 | 11577 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0020/section_0080/0190-0180-0020-0080.html |    19-18-208. Protection of fund as to bank depository securities, MCA  |  |
| MTS_0190-0180-0040-0010 | 200 | 11877 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0040/section_0010/0190-0180-0040-0010.html |    19-18-401. Management of association, MCA  |  |
| MTS_0190-0180-0040-0020 | 200 | 12874 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0040/section_0020/0190-0180-0040-0020.html |    19-18-402. Investment of fund by trustees, MCA  |  |
| MTS_0190-0180-0040-0030 | 200 | 12729 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0040/section_0030/0190-0180-0040-0030.html |    19-18-403. Investment of fund by board of investments, MCA  |  |
| MTS_0190-0180-0050-0010 | 200 | 12325 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0050/section_0010/0190-0180-0050-0010.html |    19-18-501. Contributions to fund, MCA  |  |
| MTS_0190-0180-0050-0020 | 200 | 12252 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0050/section_0020/0190-0180-0050-0020.html |    19-18-502. Refund of firefighter's contribution, MCA  |  |
| MTS_0190-0180-0050-0030 | 200 | 12581 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0050/section_0030/0190-0180-0050-0030.html |    19-18-503. Fund to be soundly funded, MCA  |  |
| MTS_0190-0180-0050-0040 | 200 | 13428 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0050/section_0040/0190-0180-0050-0040.html |    19-18-504. Special tax levy for fund required, MCA  |  |
| MTS_0190-0180-0050-0050 | 200 | 10853 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0050/section_0050/0190-0180-0050-0050.html |    19-18-505. through 19-18-510 reserved, MCA  |  |
| MTS_0190-0180-0050-0110 | 200 | 11962 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0050/section_0110/0190-0180-0050-0110.html |    19-18-511. Annual report of clerks of cities having fire departments, MCA  |  |
| MTS_0190-0180-0050-0120 | 200 | 12751 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0050/section_0120/0190-0180-0050-0120.html |    19-18-512. State auditor -- payment to association, MCA  |  |
| MTS_0190-0180-0050-0130 | 200 | 11354 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0050/section_0130/0190-0180-0050-0130.html |    19-18-513. Repealed, MCA  |  |
| MTS_0190-0180-0050-0140 | 200 | 11536 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0050/section_0140/0190-0180-0050-0140.html |    19-18-514. State treasurer to pay warrants, MCA  |  |
| MTS_0190-0180-0060-0010 | 200 | 12075 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0060/section_0010/0190-0180-0060-0010.html |    19-18-601. Benefits the association may provide, MCA  |  |
| MTS_0190-0180-0060-0020 | 200 | 15225 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0060/section_0020/0190-0180-0060-0020.html |    19-18-602. Service pension, MCA  |  |
| MTS_0190-0180-0060-0030 | 200 | 14693 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0060/section_0030/0190-0180-0060-0030.html |    19-18-603. Partial service pension, MCA  |  |
| MTS_0190-0180-0060-0040 | 200 | 13008 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0060/section_0040/0190-0180-0060-0040.html |    19-18-604. Disability pension, MCA  |  |
| MTS_0190-0180-0060-0050 | 200 | 14909 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0060/section_0050/0190-0180-0060-0050.html |    19-18-605. Pensions to surviving spouses and children, MCA  |  |
| MTS_0190-0180-0060-0060 | 200 | 11386 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0060/section_0060/0190-0180-0060-0060.html |    19-18-606. Repealed, MCA  |  |
| MTS_0190-0180-0060-0070 | 200 | 11817 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0060/section_0070/0190-0180-0060-0070.html |    19-18-607. Payment of death benefits in absence of spouse or child, MCA  |  |
| MTS_0190-0180-0060-0080 | 200 | 10827 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0060/section_0080/0190-0180-0060-0080.html |    19-18-608. through 19-18-610 reserved, MCA  |  |
| MTS_0190-0180-0060-0110 | 200 | 12380 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0060/section_0110/0190-0180-0060-0110.html |    19-18-611. Procedure -- applying for and collecting benefits, MCA  |  |
| MTS_0190-0180-0060-0120 | 200 | 11722 | https://leg.mt.gov/bills/mca/title_0190/chapter_0180/part_0060/section_0120/0190-0180-0060-0120.html |    19-18-612. Protection of benefits from legal process -- nonassignability, MCA |  |
| MTS_0190-0190-0010-0010 | 200 | 11054 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0010/section_0010/0190-0190-0010-0010.html |    19-19-101. Definition, MCA  |  |
| MTS_0190-0190-0020-0010 | 200 | 12921 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0020/section_0010/0190-0190-0020-0010.html |    19-19-201. Local boards of trustees of funds, MCA  |  |
| MTS_0190-0190-0020-0020 | 200 | 12437 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0020/section_0020/0190-0190-0020-0020.html |    19-19-202. Limit on use of fund, MCA  |  |
| MTS_0190-0190-0020-0030 | 200 | 13276 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0020/section_0030/0190-0190-0020-0030.html |    19-19-203. Investment of fund, MCA  |  |
| MTS_0190-0190-0020-0040 | 200 | 11574 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0020/section_0040/0190-0190-0020-0040.html |    19-19-204. Trustees' report to state auditor, MCA  |  |
| MTS_0190-0190-0020-0050 | 200 | 12672 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0020/section_0050/0190-0190-0020-0050.html |    19-19-205. Actuarial valuation of police retirement fund, MCA  |  |
| MTS_0190-0190-0030-0010 | 200 | 12237 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0030/section_0010/0190-0190-0030-0010.html |    19-19-301. City's contribution to fund, MCA  |  |
| MTS_0190-0190-0030-0020 | 200 | 12040 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0030/section_0020/0190-0190-0030-0020.html |    19-19-302. Officer's contribution deducted from salary, MCA  |  |
| MTS_0190-0190-0030-0030 | 200 | 11802 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0030/section_0030/0190-0190-0030-0030.html |    19-19-303. Refund of officer's contribution, MCA  |  |
| MTS_0190-0190-0030-0040 | 200 | 12178 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0030/section_0040/0190-0190-0030-0040.html |    19-19-304. Gifts and money to be applied to fund, MCA  |  |
| MTS_0190-0190-0030-0050 | 200 | 13070 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0030/section_0050/0190-0190-0030-0050.html |    19-19-305. Annual state payments to municipality with police department, MCA  |  |
| MTS_0190-0190-0040-0010 | 200 | 12090 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0040/section_0010/0190-0190-0040-0010.html |    19-19-401. Eligibility for service retirement, MCA  |  |
| MTS_0190-0190-0040-0020 | 200 | 11826 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0040/section_0020/0190-0190-0040-0020.html |    19-19-402. Eligibility for disability retirement, MCA  |  |
| MTS_0190-0190-0040-0030 | 200 | 12483 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0040/section_0030/0190-0190-0040-0030.html |    19-19-403. Option of officer to remain on active list, MCA  |  |
| MTS_0190-0190-0040-0040 | 200 | 11875 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0040/section_0040/0190-0190-0040-0040.html |    19-19-404. Reinstatement to retired list, MCA  |  |
| MTS_0190-0190-0040-0050 | 200 | 11604 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0040/section_0050/0190-0190-0040-0050.html |    19-19-405. Credit for military service, MCA  |  |
| MTS_0190-0190-0040-0060 | 200 | 12865 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0040/section_0060/0190-0190-0040-0060.html |    19-19-406. Election to qualify previous military service, MCA  |  |
| MTS_0190-0190-0050-0010 | 200 | 12474 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0050/section_0010/0190-0190-0050-0010.html |    19-19-501. Service retirement allowance, MCA  |  |
| MTS_0190-0190-0050-0020 | 200 | 12816 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0050/section_0020/0190-0190-0050-0020.html |    19-19-502. Disability retirement allowance, MCA  |  |
| MTS_0190-0190-0050-0030 | 200 | 12579 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0050/section_0030/0190-0190-0050-0030.html |    19-19-503. Death benefits, MCA  |  |
| MTS_0190-0190-0050-0040 | 200 | 11842 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0050/section_0040/0190-0190-0050-0040.html |    19-19-504. Protection of benefits from legal process, MCA  |  |
| MTS_0190-0190-0050-0050 | 200 | 11927 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0050/section_0050/0190-0190-0050-0050.html |    19-19-505. Withholding of group insurance premium from retirement benefit, MC |  |
| MTS_0190-0190-0050-0060 | 200 | 15703 | https://leg.mt.gov/bills/mca/title_0190/chapter_0190/part_0050/section_0060/0190-0190-0050-0060.html |    19-19-506. Supplement to certain pensions, MCA  |  |
| MTS_0190-0200-0010-0010 | 200 | 29353 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0010/section_0010/0190-0200-0010-0010.html |    19-20-101. Definitions, MCA  |  |
| MTS_0190-0200-0010-0020 | 200 | 13856 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0010/section_0020/0190-0200-0010-0020.html |    19-20-102. Retirement system -- policy, MCA  |  |
| MTS_0190-0200-0010-0030 | 200 | 11443 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0010/section_0030/0190-0200-0010-0030.html |    19-20-103. Implied consent of employee, MCA  |  |
| MTS_0190-0200-0010-0040 | 200 | 11614 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0010/section_0040/0190-0200-0010-0040.html |    19-20-104. Guarantee by state, MCA  |  |
| MTS_0190-0200-0010-0050 | 200 | 11406 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0010/section_0050/0190-0200-0010-0050.html |    19-20-105. Penalty for fraud, MCA  |  |
| MTS_0190-0200-0010-0060 | 200 | 12228 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0010/section_0060/0190-0200-0010-0060.html |    19-20-106. Retaining qualified plan status -- board rulemaking authority, MCA |  |
| MTS_0190-0200-0010-0070 | 200 | 10858 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0010/section_0070/0190-0200-0010-0070.html |    19-20-107. through 19-20-110 reserved, MCA  |  |
| MTS_0190-0200-0010-0110 | 200 | 11099 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0010/section_0110/0190-0200-0010-0110.html |    19-20-111. Teachers' retirement system benefit policy statement, MCA  |  |
| MTS_0190-0200-0020-0010 | 200 | 15938 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0010/0190-0200-0020-0010.html |    19-20-201. Administration by retirement board -- jurisdiction and venue for j |  |
| MTS_0190-0200-0020-0020 | 200 | 12239 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0020/0190-0200-0020-0020.html |    19-20-202. Per diem and expenses of board members, MCA  |  |
| MTS_0190-0200-0020-0030 | 200 | 12580 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0030/0190-0200-0020-0030.html |    19-20-203. Officers and employees of retirement board, MCA  |  |
| MTS_0190-0200-0020-0040 | 200 | 11240 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0040/0190-0200-0020-0040.html |    19-20-204. Repealed, MCA  |  |
| MTS_0190-0200-0020-0050 | 200 | 11509 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0050/0190-0200-0020-0050.html |    19-20-205. Board to determine membership, MCA  |  |
| MTS_0190-0200-0020-0060 | 200 | 11605 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0060/0190-0200-0020-0060.html |    19-20-206. Board to grant benefits, MCA  |  |
| MTS_0190-0200-0020-0070 | 200 | 11160 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0070/0190-0200-0020-0070.html |    19-20-207. Repealed, MCA  |  |
| MTS_0190-0200-0020-0080 | 200 | 15138 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0080/0190-0200-0020-0080.html |    19-20-208. Duties and liability of employer, MCA  |  |
| MTS_0190-0200-0020-0090 | 200 | 10847 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0090/0190-0200-0020-0090.html |    19-20-209. through 19-20-211 reserved, MCA  |  |
| MTS_0190-0200-0020-0120 | 200 | 14740 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0120/0190-0200-0020-0120.html |    19-20-212. General internal revenue service qualification rules, MCA  |  |
| MTS_0190-0200-0020-0130 | 200 | 10831 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0130/0190-0200-0020-0130.html |    19-20-213. and 19-20-214 reserved, MCA  |  |
| MTS_0190-0200-0020-0150 | 200 | 11506 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0150/0190-0200-0020-0150.html |    19-20-215. Presentation to board of investments, MCA  |  |
| MTS_0190-0200-0020-0160 | 200 | 11557 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0020/section_0160/0190-0200-0020-0160.html |    19-20-216. Board to make special report, MCA  |  |
| MTS_0190-0200-0030-0010 | 200 | 11267 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0030/section_0010/0190-0200-0030-0010.html |    19-20-301. Membership application, MCA  |  |
| MTS_0190-0200-0030-0020 | 200 | 23055 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0030/section_0020/0190-0200-0030-0020.html |    19-20-302. Active membership, MCA  |  |
| MTS_0190-0200-0030-0030 | 200 | 15575 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0030/section_0030/0190-0200-0030-0030.html |    19-20-303. Inactive membership -- dormant membership status, MCA  |  |
| MTS_0190-0200-0030-0040 | 200 | 11211 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0030/section_0040/0190-0200-0030-0040.html |    19-20-304. Repealed, MCA  |  |
| MTS_0190-0200-0030-0050 | 200 | 19587 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0030/section_0050/0190-0200-0030-0050.html |    19-20-305. Alternate payees -- family law orders, MCA  |  |
| MTS_0190-0200-0030-0060 | 200 | 14708 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0030/section_0060/0190-0200-0030-0060.html |    19-20-306. Execution or withholding for support obligation, MCA  |  |
| MTS_0190-0200-0030-0070 | 200 | 13466 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0030/section_0070/0190-0200-0030-0070.html |    19-20-307. Establishing independent contractor status, MCA  |  |
| MTS_0190-0200-0040-0010 | 200 | 22020 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0010/0190-0200-0040-0010.html |    19-20-401. Creditable service, MCA  |  |
| MTS_0190-0200-0040-0020 | 200 | 15995 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0020/0190-0200-0040-0020.html |    19-20-402. Creditable service for employment in out-of-state public and feder |  |
| MTS_0190-0200-0040-0030 | 200 | 20016 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0030/0190-0200-0040-0030.html |    19-20-403. Creditable service for employment while on leave, MCA  |  |
| MTS_0190-0200-0040-0040 | 200 | 14473 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0040/0190-0200-0040-0040.html |    19-20-404. Creditable service for active service in military, red cross, or m |  |
| MTS_0190-0200-0040-0050 | 200 | 12187 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0050/0190-0200-0040-0050.html |    19-20-405. Limit on creditable service that may be awarded, MCA  |  |
| MTS_0190-0200-0040-0060 | 200 | 11310 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0060/0190-0200-0040-0060.html |    19-20-406. Repealed, MCA  |  |
| MTS_0190-0200-0040-0070 | 200 | 11805 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0070/0190-0200-0040-0070.html |    19-20-407. No duplication of credit for same period of service, MCA  |  |
| MTS_0190-0200-0040-0080 | 200 | 14442 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0080/0190-0200-0040-0080.html |    19-20-408. Creditable service for employment in private schools, MCA  |  |
| MTS_0190-0200-0040-0090 | 200 | 21070 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0090/0190-0200-0040-0090.html |    19-20-409. Transfer of service credits and contributions from public employee |  |
| MTS_0190-0200-0040-0100 | 200 | 14176 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0100/0190-0200-0040-0100.html |    19-20-410. Creditable service for extension service employment, MCA  |  |
| MTS_0190-0200-0040-0110 | 200 | 14254 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0110/0190-0200-0040-0110.html |    19-20-411. Absence because of employment-related injury, MCA  |  |
| MTS_0190-0200-0040-0120 | 200 | 11198 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0120/0190-0200-0040-0120.html |    19-20-412. Repealed, MCA  |  |
| MTS_0190-0200-0040-0130 | 200 | 11107 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0130/0190-0200-0040-0130.html |    19-20-413. Repealed, MCA  |  |
| MTS_0190-0200-0040-0140 | 200 | 13929 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0140/0190-0200-0040-0140.html |    19-20-414. Payment methods for purchase of service credit, MCA  |  |
| MTS_0190-0200-0040-0150 | 200 | 16523 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0150/0190-0200-0040-0150.html |    19-20-415. Procedure for purchase of service credit and pick up, MCA  |  |
| MTS_0190-0200-0040-0160 | 200 | 12598 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0160/0190-0200-0040-0160.html |    19-20-416. Credit for legislative service required, MCA  |  |
| MTS_0190-0200-0040-0170 | 200 | 13781 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0170/0190-0200-0040-0170.html |    19-20-417. Credit for substitute teaching service, part-time teacher's aide s |  |
| MTS_0190-0200-0040-0180 | 200 | 10950 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0180/0190-0200-0040-0180.html |    19-20-418. through 19-20-425 reserved, MCA  |  |
| MTS_0190-0200-0040-0260 | 200 | 12871 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0260/0190-0200-0040-0260.html |    19-20-426. Creditable service for employment under university system retireme |  |
| MTS_0190-0200-0040-0270 | 200 | 15877 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0040/section_0270/0190-0200-0040-0270.html |    19-20-427. Redeposit of contributions previously withdrawn, MCA  |  |
| MTS_0190-0200-0050-0010 | 200 | 13336 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0050/section_0010/0190-0200-0050-0010.html |    19-20-501. Financial administration of money, MCA  |  |
| MTS_0190-0200-0050-0020 | 200 | 12936 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0050/section_0020/0190-0200-0050-0020.html |    19-20-502. Restrictions on use of money, MCA  |  |
| MTS_0190-0200-0050-0030 | 200 | 11913 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0050/section_0030/0190-0200-0050-0030.html |    19-20-503. Forfeiture of unclaimed account balances or benefits, MCA  |  |
| MTS_0190-0200-0050-0040 | 200 | 11875 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0050/section_0040/0190-0200-0050-0040.html |    19-20-504. Vesting of retirement allowances upon termination of system, MCA  |  |
| MTS_0190-0200-0050-0050 | 200 | 10858 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0050/section_0050/0190-0200-0050-0050.html |    19-20-505. through 19-20-509 reserved, MCA  |  |
| MTS_0190-0200-0050-0100 | 200 | 11097 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0050/section_0100/0190-0200-0050-0100.html |    19-20-510. Probate and nonprobate transfer statutes superseded, MCA  |  |
| MTS_0190-0200-0060-0010 | 200 | 11366 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0060/section_0010/0190-0200-0060-0010.html |    19-20-601. Method of financing, MCA  |  |
| MTS_0190-0200-0060-0020 | 200 | 15624 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0060/section_0020/0190-0200-0060-0020.html |    19-20-602. Annuity savings account -- member's contribution, MCA  |  |
| MTS_0190-0200-0060-0030 | 200 | 15073 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0060/section_0030/0190-0200-0060-0030.html |    19-20-603. Withdrawal from membership -- refund of accumulated contributions  |  |
| MTS_0190-0200-0060-0040 | 200 | 12079 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0060/section_0040/0190-0200-0060-0040.html |    19-20-604. State contributions -- termination, MCA  |  |
| MTS_0190-0200-0060-0050 | 200 | 15860 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0060/section_0050/0190-0200-0060-0050.html |    19-20-605. Pension accumulation account -- employer's contribution, MCA  |  |
| MTS_0190-0200-0060-0060 | 200 | 11451 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0060/section_0060/0190-0200-0060-0060.html |    19-20-606. Repealed, MCA  |  |
| MTS_0190-0200-0060-0070 | 200 | 12960 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0060/section_0070/0190-0200-0060-0070.html |    19-20-607. Supplemental state contribution -- appropriation, MCA  |  |
| MTS_0190-0200-0060-0080 | 200 | 15331 | https://leg.mt.gov/bills/mca/title_0190/chapter_0200/part_0060/section_0080/0190-0200-0060-0080.html |    19-20-608. Member supplemental contribution -- actuarially determined adjustm |  |
