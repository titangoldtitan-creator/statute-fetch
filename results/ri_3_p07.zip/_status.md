| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| RIS_16_16-37_16-37-9 | 200 | 3817 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-37/16-37-9.htm |  | render-thin 227 |
| RIS_16_16-38_16-38-1 | 200 | 5663 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-1.htm |  |  |
| RIS_16_16-38_16-38-1.1 | 200 | 9272 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-1.1.htm |  |  |
| RIS_16_16-38_16-38-2 | 200 | 5596 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-2.htm |  |  |
| RIS_16_16-38_16-38-3 | 200 | 4288 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-3.htm |  |  |
| RIS_16_16-38_16-38-4 | 200 | 4555 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-4.htm |  |  |
| RIS_16_16-38_16-38-5 | 200 | 4764 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-5.htm |  |  |
| RIS_16_16-38_16-38-5.1 | 200 | 5188 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-5.1.htm |  |  |
| RIS_16_16-38_16-38-6 | 200 | 8508 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-6.htm |  |  |
| RIS_16_16-38_16-38-7 | 200 | 4709 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-7.htm |  |  |
| RIS_16_16-38_16-38-8 | 200 | 4270 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-8.htm |  |  |
| RIS_16_16-38_16-38-9 | 200 | 4851 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-9.htm |  |  |
| RIS_16_16-38_16-38-10 | 200 | 4561 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-10.htm |  |  |
| RIS_16_16-38_16-38-11 | 200 | 4618 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-11.htm |  |  |
| RIS_16_16-38_16-38-12 | 200 | 4277 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-12.htm |  |  |
| RIS_16_16-38_16-38-13 | 200 | 4360 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-13.htm |  |  |
| RIS_16_16-38_16-38-14 | 200 | 5601 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-38/16-38-14.htm |  |  |
| RIS_16_16-39_16-39-1 | 200 | 4400 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-39/16-39-1.htm |  |  |
| RIS_16_16-39_16-39-2 | 200 | 4462 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-39/16-39-2.htm |  |  |
| RIS_16_16-39_16-39-3 | 200 | 4106 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-39/16-39-3.htm |  |  |
| RIS_16_16-39_16-39-3.1 | 200 | 4526 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-39/16-39-3.1.htm |  |  |
| RIS_16_16-39_16-39-3.2 | 200 | 4680 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-39/16-39-3.2.htm |  |  |
| RIS_16_16-39_16-39-4 | 200 | 3945 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-39/16-39-4.htm |  |  |
| RIS_16_16-39_16-39-5 | 200 | 4048 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-39/16-39-5.htm |  |  |
| RIS_16_16-39_16-39-6 | 200 | 4255 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-39/16-39-6.htm |  |  |
| RIS_16_16-39_16-39-7 | 200 | 4405 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-39/16-39-7.htm |  |  |
| RIS_16_16-39_16-39-8 | 200 | 4663 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-39/16-39-8.htm |  |  |
| RIS_16_16-40_16-40-1 | 200 | 6471 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-1.htm |  |  |
| RIS_16_16-40_16-40-2 | 200 | 5410 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-2.htm |  |  |
| RIS_16_16-40_16-40-3 | 200 | 4719 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-3.htm |  |  |
| RIS_16_16-40_16-40-4 | 200 | 4784 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-4.htm |  |  |
| RIS_16_16-40_16-40-5 | 200 | 4805 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-5.htm |  |  |
| RIS_16_16-40_16-40-6 | 200 | 4392 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-6.htm |  |  |
| RIS_16_16-40_16-40-7 | 200 | 4316 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-7.htm |  |  |
| RIS_16_16-40_16-40-8 | 200 | 5267 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-8.htm |  |  |
| RIS_16_16-40_16-40-9 | 200 | 6392 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-9.htm |  |  |
| RIS_16_16-40_16-40-9.1 | 200 | 4021 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-9.1.htm |  |  |
| RIS_16_16-40_16-40-10 | 200 | 5721 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-10.htm |  |  |
| RIS_16_16-40_16-40-10.1 | 200 | 3914 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-10.1.htm |  |  |
| RIS_16_16-40_16-40-10.2 | 200 | 4305 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-10.2.htm |  |  |
| RIS_16_16-40_16-40-11 | 200 | 4920 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-11.htm |  |  |
| RIS_16_16-40_16-40-12 | 200 | 5198 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-12.htm |  |  |
| RIS_16_16-40_16-40-13 | 200 | 4486 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-13.htm |  |  |
| RIS_16_16-40_16-40-14 | 200 | 4530 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-14.htm |  |  |
| RIS_16_16-40_16-40-15 | 200 | 4389 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-15.htm |  |  |
| RIS_16_16-40_16-40-16 | 200 | 6836 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40/16-40-16.htm |  |  |
| RIS_16_16-40.1_16-40.1-1 | 200 | 4012 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40.1/16-40.1-1.htm |  |  |
| RIS_16_16-40.1_16-40.1-10 | 200 | 4071 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-40.1/16-40.1-10.htm |  |  |
| RIS_16_16-41_16-41-1 | 200 | 15569 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-41/16-41-1.htm |  |  |
| RIS_16_16-41_16-41-2 | 200 | 4323 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-41/16-41-2.htm |  |  |
| RIS_16_16-41_16-41-3 | 200 | 5437 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-41/16-41-3.htm |  |  |
| RIS_16_16-41_16-41-4 | 200 | 4213 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-41/16-41-4.htm |  |  |
| RIS_16_16-41_16-41-5 | 200 | 5884 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-41/16-41-5.htm |  |  |
| RIS_16_16-42_16-42-1 | 200 | 5406 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-42/16-42-1.htm |  |  |
| RIS_16_16-42_16-42-2 | 200 | 5049 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-42/16-42-2.htm |  |  |
| RIS_16_16-42_16-42-3 | 200 | 5671 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-42/16-42-3.htm |  |  |
| RIS_16_16-42_16-42-4 | 200 | 3970 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-42/16-42-4.htm |  |  |
| RIS_16_16-42.1_16-42.1-1 | 200 | 4147 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-42.1/16-42.1-1.htm |  |  |
| RIS_16_16-42.1_16-42.1-2 | 200 | 4880 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-42.1/16-42.1-2.htm |  |  |
| RIS_16_16-42.1_16-42.1-3 | 200 | 5337 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-42.1/16-42.1-3.htm |  |  |
| RIS_16_16-42.1_16-42.1-4 | 200 | 3816 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-42.1/16-42.1-4.htm |  | render-thin 241 |
| RIS_16_16-42.2_16-42.2-1 | 200 | 4248 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-42.2/16-42.2-1.htm |  |  |
| RIS_16_16-42.2_16-42.2-2 | 200 | 4730 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-42.2/16-42.2-2.htm |  |  |
| RIS_16_16-42.2_16-42.2-3 | 200 | 5230 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-42.2/16-42.2-3.htm |  |  |
| RIS_16_16-43_16-43-1 | 200 | 4386 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-43/16-43-1.htm |  |  |
| RIS_16_16-43_16-43-2 | 200 | 4766 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-43/16-43-2.htm |  |  |
| RIS_16_16-43_16-43-3 | 200 | 4855 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-43/16-43-3.htm |  |  |
| RIS_16_16-43_16-43-4 | 200 | 3967 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-43/16-43-4.htm |  |  |
| RIS_16_16-44_16-44-1 | 200 | 4360 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-44/16-44-1.htm |  |  |
| RIS_16_16-44_16-44-2 | 200 | 4509 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-44/16-44-2.htm |  |  |
| RIS_16_16-44_16-44-3 | 200 | 4109 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-44/16-44-3.htm |  |  |
| RIS_16_16-44_16-44-4 | 200 | 4099 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-44/16-44-4.htm |  |  |
| RIS_16_16-44_16-44-5 | 200 | 4120 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-44/16-44-5.htm |  |  |
| RIS_16_16-44_16-44-6 | 200 | 4189 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-44/16-44-6.htm |  |  |
| RIS_16_16-44_16-44-7 | 200 | 4304 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-44/16-44-7.htm |  |  |
| RIS_16_16-45_16-45-1 | 200 | 4701 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-1.htm |  |  |
| RIS_16_16-45_16-45-1.1 | 200 | 9056 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-1.1.htm |  |  |
| RIS_16_16-45_16-45-2 | 200 | 4228 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-2.htm |  |  |
| RIS_16_16-45_16-45-3 | 200 | 4332 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-3.htm |  |  |
| RIS_16_16-45_16-45-4 | 200 | 4725 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-4.htm |  |  |
| RIS_16_16-45_16-45-4.1 | 200 | 4675 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-4.1.htm |  |  |
| RIS_16_16-45_16-45-4.2 | 200 | 4023 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-4.2.htm |  |  |
| RIS_16_16-45_16-45-5 | 200 | 5656 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-5.htm |  |  |
| RIS_16_16-45_16-45-6 | 200 | 15231 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-6.htm |  |  |
| RIS_16_16-45_16-45-6.1 | 200 | 16043 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-6.1.htm |  |  |
| RIS_16_16-45_16-45-6.2 | 200 | 4129 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-6.2.htm |  |  |
| RIS_16_16-45_16-45-7 | 200 | 5156 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-7.htm |  |  |
| RIS_16_16-45_16-45-8 | 200 | 4222 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-8.htm |  |  |
| RIS_16_16-45_16-45-9 | 200 | 4138 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-9.htm |  |  |
| RIS_16_16-45_16-45-10 | 200 | 4449 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-10.htm |  |  |
| RIS_16_16-45_16-45-11 | 200 | 6282 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45/16-45-11.htm |  |  |
| RIS_16_16-45.1_16-45.1-1 | 200 | 6019 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45.1/16-45.1-1.htm |  |  |
| RIS_16_16-45.1_16-45.1-2 | 200 | 4575 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45.1/16-45.1-2.htm |  |  |
| RIS_16_16-45.1_16-45.1-3 | 200 | 5745 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-45.1/16-45.1-3.htm |  |  |
| RIS_16_16-46_16-46-1 | 200 | 3964 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-46/16-46-1.htm |  |  |
| RIS_16_16-46.1_16-46.1-1 | 200 | 3802 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-46.1/16-46.1-1.htm |  | render-thin 225 |
| RIS_16_16-47_16-47-1 | 200 | 3812 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-47/16-47-1.htm |  | render-thin 222 |
| RIS_16_16-48_16-48-1 | 200 | 4351 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48/16-48-1.htm |  |  |
| RIS_16_16-48_16-48-2 | 200 | 4498 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48/16-48-2.htm |  |  |
| RIS_16_16-48_16-48-3 | 200 | 4257 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48/16-48-3.htm |  |  |
| RIS_16_16-48_16-48-4 | 200 | 3881 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48/16-48-4.htm |  | render-thin 290 |
| RIS_16_16-48_16-48-5 | 200 | 3881 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48/16-48-5.htm |  | render-thin 290 |
| RIS_16_16-48_16-48-6 | 200 | 3881 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48/16-48-6.htm |  | render-thin 290 |
| RIS_16_16-48_16-48-7 | 200 | 3881 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48/16-48-7.htm |  | render-thin 290 |
| RIS_16_16-48_16-48-8 | 200 | 3880 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48/16-48-8.htm |  | render-thin 289 |
| RIS_16_16-48_16-48-9 | 200 | 3890 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48/16-48-9.htm |  | render-thin 299 |
| RIS_16_16-48.1_16-48.1-1 | 200 | 4241 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48.1/16-48.1-1.htm |  |  |
| RIS_16_16-48.1_16-48.1-2 | 200 | 4459 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48.1/16-48.1-2.htm |  |  |
| RIS_16_16-48.1_16-48.1-3 | 200 | 4747 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48.1/16-48.1-3.htm |  |  |
| RIS_16_16-48.1_16-48.1-4 | 200 | 5023 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48.1/16-48.1-4.htm |  |  |
| RIS_16_16-48.1_16-48.1-5 | 200 | 6500 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48.1/16-48.1-5.htm |  |  |
| RIS_16_16-48.1_16-48.1-6 | 200 | 4573 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48.1/16-48.1-6.htm |  |  |
| RIS_16_16-48.1_16-48.1-7 | 200 | 3964 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48.1/16-48.1-7.htm |  |  |
| RIS_16_16-48.1_16-48.1-8 | 200 | 4071 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48.1/16-48.1-8.htm |  |  |
| RIS_16_16-48.2_16-48.2-1 | 200 | 3901 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-48.2/16-48.2-1.htm |  | render-thin 296 |
| RIS_16_16-49_16-49-1 | 200 | 5072 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-49/16-49-1.htm |  |  |
| RIS_16_16-49_16-49-18 | 200 | 3645 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-49/16-49-18.htm |  | render-thin 136 |
| RIS_16_16-50_16-50-1 | 200 | 4569 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-50/16-50-1.htm |  |  |
| RIS_16_16-50_16-50-2 | 200 | 4590 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-50/16-50-2.htm |  |  |
| RIS_16_16-50_16-50-3 | 200 | 4559 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-50/16-50-3.htm |  |  |
| RIS_16_16-50_16-50-4 | 200 | 5327 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-50/16-50-4.htm |  |  |
| RIS_16_16-50_16-50-5 | 200 | 9565 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-50/16-50-5.htm |  |  |
| RIS_16_16-50_16-50-6 | 200 | 4266 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-50/16-50-6.htm |  |  |
| RIS_16_16-50_16-50-7 | 200 | 4159 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-50/16-50-7.htm |  |  |
| RIS_16_16-50_16-50-8 | 200 | 4122 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-50/16-50-8.htm |  |  |
| RIS_16_16-50_16-50-9 | 200 | 4085 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-50/16-50-9.htm |  |  |
| RIS_16_16-50_16-50-10 | 200 | 4409 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-50/16-50-10.htm |  |  |
| RIS_16_16-51_16-51-1 | 200 | 3814 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-51/16-51-1.htm |  | render-thin 237 |
| RIS_16_16-52_16-52-1 | 200 | 4556 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-52/16-52-1.htm |  |  |
| RIS_16_16-52_16-52-2 | 200 | 5904 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-52/16-52-2.htm |  |  |
| RIS_16_16-52_16-52-3 | 200 | 6125 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-52/16-52-3.htm |  |  |
| RIS_16_16-53_16-53-1 | 200 | 4485 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-1.htm |  |  |
| RIS_16_16-53_16-53-2 | 200 | 8830 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-2.htm |  |  |
| RIS_16_16-53_16-53-3 | 200 | 13150 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-3.htm |  |  |
| RIS_16_16-53_16-53-4 | 200 | 4211 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-4.htm |  |  |
| RIS_16_16-53_16-53-5 | 200 | 4763 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-5.htm |  |  |
| RIS_16_16-53_16-53-6 | 200 | 4018 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-6.htm |  |  |
| RIS_16_16-53_16-53-7 | 200 | 4176 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-7.htm |  |  |
| RIS_16_16-53_16-53-7.1 | 200 | 4050 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-7.1.htm |  |  |
| RIS_16_16-53_16-53-8 | 200 | 6421 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-8.htm |  |  |
| RIS_16_16-53_16-53-9 | 200 | 4867 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-9.htm |  |  |
| RIS_16_16-53_16-53-10 | 200 | 4071 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-10.htm |  |  |
| RIS_16_16-53_16-53-11 | 200 | 4004 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-11.htm |  |  |
| RIS_16_16-53_16-53-12 | 200 | 4224 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53/16-53-12.htm |  |  |
| RIS_16_16-53.1_16-53.1-1 | 200 | 3901 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53.1/16-53.1-1.htm |  | render-thin 261 |
| RIS_16_16-53.1_16-53.1-2 | 200 | 9417 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53.1/16-53.1-2.htm |  |  |
| RIS_16_16-53.1_16-53.1-3 | 200 | 6035 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53.1/16-53.1-3.htm |  |  |
| RIS_16_16-53.1_16-53.1-4 | 200 | 4187 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-53.1/16-53.1-4.htm |  |  |
| RIS_16_16-54_16-54-1 | 200 | 4747 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-54/16-54-1.htm |  |  |
| RIS_16_16-54_16-54-2 | 200 | 4552 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-54/16-54-2.htm |  |  |
| RIS_16_16-54_16-54-3 | 200 | 5308 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-54/16-54-3.htm |  |  |
| RIS_16_16-54_16-54-4 | 200 | 11540 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-54/16-54-4.htm |  |  |
| RIS_16_16-54_16-54-5 | 200 | 5112 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-54/16-54-5.htm |  |  |
| RIS_16_16-54.1_16-54.1-1 | 200 | 3951 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-54.1/16-54.1-1.htm |  |  |
| RIS_16_16-54.1_16-54.1-2 | 200 | 7898 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-54.1/16-54.1-2.htm |  |  |
| RIS_16_16-54.1_16-54.1-3 | 200 | 4965 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-54.1/16-54.1-3.htm |  |  |
| RIS_16_16-54.1_16-54.1-4 | 200 | 7676 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-54.1/16-54.1-4.htm |  |  |
| RIS_16_16-54.1_16-54.1-5 | 200 | 6222 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-54.1/16-54.1-5.htm |  |  |
| RIS_16_16-55_16-55-1 | 200 | 4982 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-55/16-55-1.htm |  |  |
| RIS_16_16-56_16-56-1 | 200 | 4052 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-1.htm |  |  |
| RIS_16_16-56_16-56-2 | 200 | 4422 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-2.htm |  |  |
| RIS_16_16-56_16-56-3 | 200 | 3858 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-3.htm |  | render-thin 267 |
| RIS_16_16-56_16-56-4 | 200 | 4711 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-4.htm |  |  |
| RIS_16_16-56_16-56-5 | 200 | 4364 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-5.htm |  |  |
| RIS_16_16-56_16-56-6 | 200 | 5550 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-6.htm |  |  |
| RIS_16_16-56_16-56-7 | 200 | 3876 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-7.htm |  | render-thin 284 |
| RIS_16_16-56_16-56-8 | 200 | 3850 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-8.htm |  | render-thin 259 |
| RIS_16_16-56_16-56-9 | 200 | 3850 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-9.htm |  | render-thin 259 |
| RIS_16_16-56_16-56-10 | 200 | 4147 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-10.htm |  |  |
| RIS_16_16-56_16-56-11 | 200 | 4020 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-11.htm |  |  |
| RIS_16_16-56_16-56-12 | 200 | 4075 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-12.htm |  |  |
| RIS_16_16-56_16-56-13 | 200 | 3877 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-56/16-56-13.htm |  | render-thin 285 |
| RIS_16_16-57_16-57-1 | 200 | 3988 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-1.htm |  |  |
| RIS_16_16-57_16-57-2 | 200 | 6573 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-2.htm |  |  |
| RIS_16_16-57_16-57-3 | 200 | 10508 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-3.htm |  |  |
| RIS_16_16-57_16-57-4 | 200 | 7207 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-4.htm |  |  |
| RIS_16_16-57_16-57-4.1 | 200 | 5447 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-4.1.htm |  |  |
| RIS_16_16-57_16-57-4.2 | 200 | 4267 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-4.2.htm |  |  |
| RIS_16_16-57_16-57-5 | 200 | 3963 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-5.htm |  |  |
| RIS_16_16-57_16-57-6 | 200 | 4230 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-6.htm |  |  |
| RIS_16_16-57_16-57-6.1 | 200 | 8092 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-6.1.htm |  |  |
| RIS_16_16-57_16-57-6.2 | 200 | 4938 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-6.2.htm |  |  |
| RIS_16_16-57_16-57-6.3 | 200 | 5097 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-6.3.htm |  |  |
| RIS_16_16-57_16-57-6.4 | 200 | 3954 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-6.4.htm |  |  |
| RIS_16_16-57_16-57-6.5 | 200 | 5833 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-6.5.htm |  |  |
| RIS_16_16-57_16-57-6.6 | 200 | 3973 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-6.6.htm |  |  |
| RIS_16_16-57_16-57-6.7 | 200 | 4358 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-6.7.htm |  |  |
| RIS_16_16-57_16-57-7 | 200 | 4712 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-7.htm |  |  |
| RIS_16_16-57_16-57-8 | 200 | 4493 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-8.htm |  |  |
| RIS_16_16-57_16-57-9 | 200 | 4996 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-9.htm |  |  |
| RIS_16_16-57_16-57-10 | 200 | 5335 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-10.htm |  |  |
| RIS_16_16-57_16-57-11 | 200 | 3913 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-11.htm |  |  |
| RIS_16_16-57_16-57-12 | 200 | 4508 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-12.htm |  |  |
| RIS_16_16-57_16-57-13 | 200 | 3939 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-13.htm |  |  |
| RIS_16_16-57_16-57-14 | 200 | 3913 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-14.htm |  |  |
| RIS_16_16-57_16-57-15 | 200 | 3938 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-15.htm |  |  |
| RIS_16_16-57_16-57-16 | 200 | 4098 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-16.htm |  |  |
| RIS_16_16-57_16-57-17 | 200 | 3913 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-17.htm |  |  |
| RIS_16_16-57_16-57-18 | 200 | 4027 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-18.htm |  |  |
| RIS_16_16-57_16-57-19 | 200 | 4329 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-57/16-57-19.htm |  |  |
| RIS_16_16-58_16-58-1 | 200 | 3835 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-1.htm |  | render-thin 244 |
| RIS_16_16-58_16-58-2 | 200 | 3888 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-2.htm |  | render-thin 295 |
| RIS_16_16-58_16-58-3 | 200 | 3882 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-3.htm |  | render-thin 289 |
| RIS_16_16-58_16-58-4 | 200 | 3835 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-4.htm |  | render-thin 244 |
| RIS_16_16-58_16-58-5 | 200 | 3835 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-5.htm |  | render-thin 244 |
| RIS_16_16-58_16-58-6 | 200 | 3835 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-6.htm |  | render-thin 244 |
| RIS_16_16-58_16-58-7 | 200 | 3835 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-7.htm |  | render-thin 244 |
| RIS_16_16-58_16-58-8 | 200 | 3835 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-8.htm |  | render-thin 244 |
| RIS_16_16-58_16-58-9 | 200 | 3835 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-9.htm |  | render-thin 244 |
| RIS_16_16-58_16-58-10 | 200 | 3837 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-10.htm |  | render-thin 246 |
| RIS_16_16-58_16-58-11 | 200 | 3837 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-11.htm |  | render-thin 246 |
| RIS_16_16-58_16-58-12 | 200 | 3837 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-12.htm |  | render-thin 246 |
| RIS_16_16-58_16-58-13 | 200 | 3837 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-58/16-58-13.htm |  | render-thin 246 |
| RIS_16_16-59_16-59-1 | 200 | 8815 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-1.htm |  |  |
| RIS_16_16-59_16-59-2 | 200 | 5346 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-2.htm |  |  |
| RIS_16_16-59_16-59-3 | 200 | 4616 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-3.htm |  |  |
| RIS_16_16-59_16-59-4 | 200 | 19176 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-4.htm |  |  |
| RIS_16_16-59_16-59-4.1 | 200 | 3916 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-4.1.htm |  |  |
| RIS_16_16-59_16-59-5 | 200 | 4312 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-5.htm |  |  |
| RIS_16_16-59_16-59-6 | 200 | 13267 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-6.htm |  |  |
| RIS_16_16-59_16-59-7 | 200 | 3930 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-7.htm |  |  |
| RIS_16_16-59_16-59-7.1 | 200 | 4741 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-7.1.htm |  |  |
| RIS_16_16-59_16-59-7.2 | 200 | 6280 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-7.2.htm |  |  |
| RIS_16_16-59_16-59-8 | 200 | 3902 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-8.htm |  | render-thin 295 |
| RIS_16_16-59_16-59-9 | 200 | 11451 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-9.htm |  |  |
| RIS_16_16-59_16-59-9.1 | 200 | 5581 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-9.1.htm |  |  |
| RIS_16_16-59_16-59-9.2 | 200 | 4405 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-9.2.htm |  |  |
| RIS_16_16-59_16-59-9.3 | 200 | 5810 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-9.3.htm |  |  |
| RIS_16_16-59_16-59-10 | 200 | 4239 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-10.htm |  |  |
| RIS_16_16-59_16-59-11 | 200 | 4384 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-11.htm |  |  |
| RIS_16_16-59_16-59-12 | 200 | 4015 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-12.htm |  |  |
| RIS_16_16-59_16-59-13 | 200 | 4513 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-13.htm |  |  |
| RIS_16_16-59_16-59-14 | 200 | 4468 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-14.htm |  |  |
| RIS_16_16-59_16-59-15 | 200 | 3962 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-15.htm |  |  |
| RIS_16_16-59_16-59-16 | 200 | 4236 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-16.htm |  |  |
| RIS_16_16-59_16-59-17 | 200 | 4423 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-17.htm |  |  |
| RIS_16_16-59_16-59-18 | 200 | 4996 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-18.htm |  |  |
| RIS_16_16-59_16-59-19 | 200 | 4707 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-19.htm |  |  |
| RIS_16_16-59_16-59-20 | 200 | 4290 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-20.htm |  |  |
| RIS_16_16-59_16-59-21 | 200 | 4318 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-21.htm |  |  |
| RIS_16_16-59_16-59-22 | 200 | 5883 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-22.htm |  |  |
| RIS_16_16-59_16-59-23 | 200 | 4501 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-23.htm |  |  |
| RIS_16_16-59_16-59-24 | 200 | 4927 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-24.htm |  |  |
| RIS_16_16-59_16-59-25 | 200 | 4151 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-25.htm |  |  |
| RIS_16_16-59_16-59-25.1 | 200 | 6608 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-25.1.htm |  |  |
| RIS_16_16-59_16-59-26 | 200 | 12883 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-26.htm |  |  |
| RIS_16_16-59_16-59-27 | 200 | 5564 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-27.htm |  |  |
| RIS_16_16-59_16-59-28 | 200 | 3982 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-59/16-59-28.htm |  |  |
| RIS_16_16-60_16-60-1 | 200 | 5857 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-1.htm |  |  |
| RIS_16_16-60_16-60-2 | 200 | 8982 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-2.htm |  |  |
| RIS_16_16-60_16-60-3 | 200 | 4629 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-3.htm |  |  |
| RIS_16_16-60_16-60-4 | 200 | 23454 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-4.htm |  |  |
| RIS_16_16-60_16-60-4.1 | 200 | 4518 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-4.1.htm |  |  |
| RIS_16_16-60_16-60-5 | 200 | 5642 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-5.htm |  |  |
| RIS_16_16-60_16-60-6 | 200 | 13217 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-6.htm |  |  |
| RIS_16_16-60_16-60-7 | 200 | 8324 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-7.htm |  |  |
| RIS_16_16-60_16-60-7.1 | 200 | 6943 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-7.1.htm |  |  |
| RIS_16_16-60_16-60-7.2 | 200 | 6322 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-7.2.htm |  |  |
| RIS_16_16-60_16-60-7.3 | 200 | 5837 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-7.3.htm |  |  |
| RIS_16_16-60_16-60-8 | 200 | 4798 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-8.htm |  |  |
| RIS_16_16-60_16-60-8.1 | 200 | 4465 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-8.1.htm |  |  |
| RIS_16_16-60_16-60-9 | 200 | 4278 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-9.htm |  |  |
| RIS_16_16-60_16-60-10 | 200 | 4006 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-10.htm |  |  |
| RIS_16_16-60_16-60-11 | 200 | 3972 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-11.htm |  |  |
| RIS_16_16-60_16-60-12 | 200 | 4331 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-12.htm |  |  |
| RIS_16_16-60_16-60-13 | 200 | 4494 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-60/16-60-13.htm |  |  |
| RIS_16_16-61_16-61-1 | 200 | 3912 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-1.htm |  |  |
| RIS_16_16-61_16-61-2 | 200 | 3912 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-2.htm |  |  |
| RIS_16_16-61_16-61-3 | 200 | 3962 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-3.htm |  |  |
| RIS_16_16-61_16-61-4 | 200 | 4065 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-4.htm |  |  |
| RIS_16_16-61_16-61-5 | 200 | 3912 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-5.htm |  |  |
| RIS_16_16-61_16-61-6 | 200 | 4037 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-6.htm |  |  |
| RIS_16_16-61_16-61-6.2 | 200 | 3917 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-6.2.htm |  |  |
| RIS_16_16-61_16-61-7 | 200 | 3946 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-7.htm |  |  |
| RIS_16_16-61_16-61-8 | 200 | 3912 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-8.htm |  |  |
| RIS_16_16-61_16-61-8.1 | 200 | 3977 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-8.1.htm |  |  |
| RIS_16_16-61_16-61-9 | 200 | 3912 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-9.htm |  |  |
| RIS_16_16-61_16-61-10 | 200 | 3914 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-10.htm |  |  |
| RIS_16_16-61_16-61-11 | 200 | 3914 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-11.htm |  |  |
| RIS_16_16-61_16-61-12 | 200 | 4014 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-12.htm |  |  |
| RIS_16_16-61_16-61-13 | 200 | 3914 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-13.htm |  |  |
| RIS_16_16-61_16-61-14 | 200 | 3914 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-14.htm |  |  |
| RIS_16_16-61_16-61-15 | 200 | 3914 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-61/16-61-15.htm |  |  |
| RIS_16_16-62_16-62-1 | 200 | 3858 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-1.htm |  | render-thin 240 |
| RIS_16_16-62_16-62-2 | 200 | 5372 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-2.htm |  |  |
| RIS_16_16-62_16-62-3 | 200 | 7776 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-3.htm |  |  |
| RIS_16_16-62_16-62-4 | 200 | 6188 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-4.htm |  |  |
| RIS_16_16-62_16-62-5 | 200 | 6611 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-5.htm |  |  |
| RIS_16_16-62_16-62-6 | 200 | 9721 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-6.htm |  |  |
| RIS_16_16-62_16-62-7 | 200 | 11525 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-7.htm |  |  |
| RIS_16_16-62_16-62-8 | 200 | 4249 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-8.htm |  |  |
| RIS_16_16-62_16-62-9 | 200 | 14675 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-9.htm |  |  |
| RIS_16_16-62_16-62-10 | 200 | 6520 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-10.htm |  |  |
| RIS_16_16-62_16-62-11 | 200 | 4476 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-11.htm |  |  |
| RIS_16_16-62_16-62-12 | 200 | 5108 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-12.htm |  |  |
| RIS_16_16-62_16-62-13 | 200 | 4779 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-13.htm |  |  |
| RIS_16_16-62_16-62-14 | 200 | 4529 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-14.htm |  |  |
| RIS_16_16-62_16-62-15 | 200 | 4711 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-15.htm |  |  |
| RIS_16_16-62_16-62-16 | 200 | 4285 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-16.htm |  |  |
| RIS_16_16-62_16-62-17 | 200 | 4424 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-17.htm |  |  |
| RIS_16_16-62_16-62-18 | 200 | 5763 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-18.htm |  |  |
| RIS_16_16-62_16-62-19 | 200 | 4009 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-19.htm |  |  |
| RIS_16_16-62_16-62-20 | 200 | 4741 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-20.htm |  |  |
| RIS_16_16-62_16-62-21 | 200 | 3936 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-21.htm |  |  |
| RIS_16_16-62_16-62-22 | 200 | 4239 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62/16-62-22.htm |  |  |
| RIS_16_16-62.1_16-62.1-1 | 200 | 4805 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62.1/16-62.1-1.htm |  |  |
| RIS_16_16-62.1_16-62.1-2 | 200 | 5088 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62.1/16-62.1-2.htm |  |  |
| RIS_16_16-62.1_16-62.1-3 | 200 | 4063 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62.1/16-62.1-3.htm |  |  |
| RIS_16_16-62.1_16-62.1-4 | 200 | 4233 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62.1/16-62.1-4.htm |  |  |
| RIS_16_16-62.1_16-62.1-5 | 200 | 4082 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62.1/16-62.1-5.htm |  |  |
| RIS_16_16-62.1_16-62.1-6 | 200 | 4200 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62.1/16-62.1-6.htm |  |  |
| RIS_16_16-62.1_16-62.1-7 | 200 | 3931 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62.1/16-62.1-7.htm |  | render-thin 295 |
| RIS_16_16-62.1_16-62.1-8 | 200 | 4392 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62.1/16-62.1-8.htm |  |  |
| RIS_16_16-62.1_16-62.1-9 | 200 | 4022 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62.1/16-62.1-9.htm |  |  |
| RIS_16_16-62.1_16-62.1-10 | 200 | 3907 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-62.1/16-62.1-10.htm |  | render-thin 293 |
| RIS_16_16-63_16-63-1 | 200 | 3902 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-1.htm |  | render-thin 282 |
| RIS_16_16-63_16-63-2 | 200 | 7565 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-2.htm |  |  |
| RIS_16_16-63_16-63-3 | 200 | 5184 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-3.htm |  |  |
| RIS_16_16-63_16-63-4 | 200 | 4651 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-4.htm |  |  |
| RIS_16_16-63_16-63-5 | 200 | 7568 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-5.htm |  |  |
| RIS_16_16-63_16-63-6 | 200 | 4174 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-6.htm |  |  |
| RIS_16_16-63_16-63-7 | 200 | 10480 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-7.htm |  |  |
| RIS_16_16-63_16-63-8 | 200 | 4841 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-8.htm |  |  |
| RIS_16_16-63_16-63-9 | 200 | 6472 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-9.htm |  |  |
| RIS_16_16-63_16-63-10 | 200 | 5425 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-10.htm |  |  |
| RIS_16_16-63_16-63-11 | 200 | 4223 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-11.htm |  |  |
| RIS_16_16-63_16-63-12 | 200 | 4135 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-12.htm |  |  |
| RIS_16_16-63_16-63-13 | 200 | 4152 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-13.htm |  |  |
| RIS_16_16-63_16-63-14 | 200 | 4476 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-14.htm |  |  |
| RIS_16_16-63_16-63-15 | 200 | 4729 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-15.htm |  |  |
| RIS_16_16-63_16-63-16 | 200 | 4366 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-16.htm |  |  |
| RIS_16_16-63_16-63-17 | 200 | 3928 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-17.htm |  |  |
| RIS_16_16-63_16-63-18 | 200 | 5323 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-63/16-63-18.htm |  |  |
| RIS_16_16-64_16-64-1 | 200 | 5737 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-64/16-64-1.htm |  |  |
| RIS_16_16-64_16-64-1.1 | 200 | 10545 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-64/16-64-1.1.htm |  |  |
| RIS_16_16-64_16-64-1.2 | 200 | 6981 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-64/16-64-1.2.htm |  |  |
| RIS_16_16-64_16-64-1.3 | 200 | 5203 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-64/16-64-1.3.htm |  |  |
| RIS_16_16-64_16-64-2 | 200 | 4846 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-64/16-64-2.htm |  |  |
| RIS_16_16-64_16-64-3 | 200 | 4243 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-64/16-64-3.htm |  |  |
| RIS_16_16-64_16-64-4 | 200 | 4210 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-64/16-64-4.htm |  |  |
| RIS_16_16-64_16-64-5 | 200 | 4742 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-64/16-64-5.htm |  |  |
| RIS_16_16-64_16-64-6 | 200 | 5210 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-64/16-64-6.htm |  |  |
| RIS_16_16-64_16-64-7 | 200 | 4288 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-64/16-64-7.htm |  |  |
| RIS_16_16-64_16-64-8 | 200 | 4821 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-64/16-64-8.htm |  |  |
| RIS_16_16-64_16-64-9 | 200 | 3897 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-64/16-64-9.htm |  |  |
| RIS_16_16-65_16-65-1 | 200 | 4129 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-65/16-65-1.htm |  |  |
| RIS_16_16-66_16-66-1 | 200 | 3858 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-66/16-66-1.htm |  | render-thin 240 |
| RIS_16_16-66_16-66-2 | 200 | 5036 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-66/16-66-2.htm |  |  |
| RIS_16_16-66_16-66-3 | 200 | 3922 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-66/16-66-3.htm |  | render-thin 286 |
| RIS_16_16-66_16-66-4 | 200 | 9698 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-66/16-66-4.htm |  |  |
| RIS_16_16-66_16-66-5 | 200 | 4174 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-66/16-66-5.htm |  |  |
| RIS_16_16-66_16-66-6 | 200 | 7195 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-66/16-66-6.htm |  |  |
| RIS_16_16-67_16-67-1 | 200 | 5109 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67/16-67-1.htm |  |  |
| RIS_16_16-67_16-67-2 | 200 | 9659 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67/16-67-2.htm |  |  |
| RIS_16_16-67_16-67-3 | 200 | 5472 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67/16-67-3.htm |  |  |
| RIS_16_16-67_16-67-4 | 200 | 8878 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67/16-67-4.htm |  |  |
| RIS_16_16-67_16-67-5 | 200 | 4565 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67/16-67-5.htm |  |  |
| RIS_16_16-67_16-67-6 | 200 | 4152 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67/16-67-6.htm |  |  |
| RIS_16_16-67_16-67-7 | 200 | 4909 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67/16-67-7.htm |  |  |
| RIS_16_16-67.1_16-67.1-1 | 200 | 4021 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67.1/16-67.1-1.htm |  |  |
| RIS_16_16-67.1_16-67.1-2 | 200 | 8718 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67.1/16-67.1-2.htm |  |  |
| RIS_16_16-67.1_16-67.1-3 | 200 | 7046 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67.1/16-67.1-3.htm |  |  |
| RIS_16_16-67.1_16-67.1-4 | 200 | 5519 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67.1/16-67.1-4.htm |  |  |
| RIS_16_16-67.2_16-67.2-1 | 200 | 4600 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67.2/16-67.2-1.htm |  |  |
| RIS_16_16-67.2_16-67.2-2 | 200 | 5116 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67.2/16-67.2-2.htm |  |  |
| RIS_16_16-67.2_16-67.2-3 | 200 | 4516 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67.2/16-67.2-3.htm |  |  |
| RIS_16_16-67.2_16-67.2-4 | 200 | 4858 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67.2/16-67.2-4.htm |  |  |
| RIS_16_16-67.2_16-67.2-5 | 200 | 6577 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-67.2/16-67.2-5.htm |  |  |
| RIS_16_16-68_16-68-1 | 200 | 3884 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-68/16-68-1.htm |  | render-thin 288 |
| RIS_16_16-69_16-69-1 | 200 | 3933 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-69/16-69-1.htm |  | render-thin 298 |
| RIS_16_16-69_16-69-2 | 200 | 6132 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-69/16-69-2.htm |  |  |
| RIS_16_16-69_16-69-3 | 200 | 4675 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-69/16-69-3.htm |  |  |
| RIS_16_16-69_16-69-4 | 200 | 3892 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-69/16-69-4.htm |  | render-thin 285 |
| RIS_16_16-70_16-70-1 | 200 | 4075 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-70/16-70-1.htm |  |  |
| RIS_16_16-70_16-70-2 | 200 | 5701 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-70/16-70-2.htm |  |  |
| RIS_16_16-70_16-70-3 | 200 | 4381 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-70/16-70-3.htm |  |  |
| RIS_16_16-70_16-70-4 | 200 | 5217 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-70/16-70-4.htm |  |  |
| RIS_16_16-70_16-70-5 | 200 | 4994 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-70/16-70-5.htm |  |  |
| RIS_16_16-70_16-70-6 | 200 | 4364 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-70/16-70-6.htm |  |  |
| RIS_16_16-71_16-71-1 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-71/16-71-1.htm |  | render-thin 252 |
| RIS_16_16-71_16-71-2 | 200 | 4354 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-71/16-71-2.htm |  |  |
| RIS_16_16-71_16-71-3 | 200 | 6584 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-71/16-71-3.htm |  |  |
| RIS_16_16-71_16-71-4 | 200 | 3951 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-71/16-71-4.htm |  |  |
| RIS_16_16-71_16-71-5 | 200 | 3890 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-71/16-71-5.htm |  | render-thin 276 |
| RIS_16_16-71_16-71-6 | 200 | 3988 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-71/16-71-6.htm |  |  |
| RIS_16_16-72_16-72-1 | 200 | 3980 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-72/16-72-1.htm |  |  |
| RIS_16_16-72_16-72-2 | 200 | 4857 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-72/16-72-2.htm |  |  |
| RIS_16_16-72_16-72-3 | 200 | 6374 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-72/16-72-3.htm |  |  |
| RIS_16_16-72_16-72-4 | 200 | 4458 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-72/16-72-4.htm |  |  |
| RIS_16_16-73_16-73-1 | 200 | 4960 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-73/16-73-1.htm |  |  |
| RIS_16_16-73_16-73-1.1 | 200 | 4346 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-73/16-73-1.1.htm |  |  |
| RIS_16_16-73_16-73-2 | 200 | 4369 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-73/16-73-2.htm |  |  |
| RIS_16_16-73_16-73-3 | 200 | 4039 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-73/16-73-3.htm |  |  |
| RIS_16_16-73_16-73-4 | 200 | 3871 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-73/16-73-4.htm |  | render-thin 277 |
| RIS_16_16-73_16-73-5 | 200 | 4551 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-73/16-73-5.htm |  |  |
| RIS_16_16-73_16-73-6 | 200 | 4244 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-73/16-73-6.htm |  |  |
| RIS_16_16-73.1_16-73.1-1 | 200 | 7255 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-73.1/16-73.1-1.htm |  |  |
| RIS_16_16-73.1_16-73.1-2 | 200 | 4260 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-73.1/16-73.1-2.htm |  |  |
| RIS_16_16-74_16-74-1 | 200 | 5286 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-74/16-74-1.htm |  |  |
| RIS_16_16-74_16-74-2 | 200 | 6050 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-74/16-74-2.htm |  |  |
| RIS_16_16-75_16-75-1 | 200 | 3842 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-75/16-75-1.htm |  | render-thin 250 |
| RIS_16_16-76_16-76-1 | 200 | 4169 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-76/16-76-1.htm |  |  |
| RIS_16_16-76_16-76-2 | 200 | 4096 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-76/16-76-2.htm |  |  |
| RIS_16_16-76_16-76-3 | 200 | 3921 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-76/16-76-3.htm |  | render-thin 285 |
| RIS_16_16-76.1_16-76.1-1 | 200 | 4472 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-76.1/16-76.1-1.htm |  |  |
| RIS_16_16-76.2_16-76.2-1 | 200 | 4335 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-76.2/16-76.2-1.htm |  |  |
| RIS_16_16-76.2_16-76.2-2 | 200 | 5502 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-76.2/16-76.2-2.htm |  |  |
| RIS_16_16-77_16-77-1 | 200 | 4143 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-1.htm |  |  |
| RIS_16_16-77_16-77-2 | 200 | 3980 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-2.htm |  |  |
| RIS_16_16-77_16-77-2.1 | 200 | 5940 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-2.1.htm |  |  |
| RIS_16_16-77_16-77-3 | 200 | 4149 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-3.htm |  |  |
| RIS_16_16-77_16-77-3.1 | 200 | 10664 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-3.1.htm |  |  |
| RIS_16_16-77_16-77-4 | 200 | 4082 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-4.htm |  |  |
| RIS_16_16-77_16-77-4.1 | 200 | 4271 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-4.1.htm |  |  |
| RIS_16_16-77_16-77-4.2 | 200 | 3984 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-4.2.htm |  |  |
| RIS_16_16-77_16-77-5 | 200 | 4065 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-5.htm |  |  |
| RIS_16_16-77_16-77-5.1 | 200 | 8504 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-5.1.htm |  |  |
| RIS_16_16-77_16-77-6 | 200 | 4021 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-6.htm |  |  |
| RIS_16_16-77_16-77-6.1 | 200 | 5593 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-6.1.htm |  |  |
| RIS_16_16-77_16-77-7 | 200 | 3980 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-7.htm |  |  |
| RIS_16_16-77_16-77-8 | 200 | 4056 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-8.htm |  |  |
| RIS_16_16-77_16-77-9 | 200 | 3954 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-9.htm |  |  |
| RIS_16_16-77_16-77-10 | 200 | 3956 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-10.htm |  |  |
| RIS_16_16-77_16-77-11 | 200 | 4006 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-11.htm |  |  |
| RIS_16_16-77_16-77-12 | 200 | 3965 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77/16-77-12.htm |  |  |
| RIS_16_16-77.1_16-77.1-1 | 200 | 4123 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.1/16-77.1-1.htm |  |  |
| RIS_16_16-77.1_16-77.1-2 | 200 | 9704 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.1/16-77.1-2.htm |  |  |
| RIS_16_16-77.1_16-77.1-3 | 200 | 4726 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.1/16-77.1-3.htm |  |  |
| RIS_16_16-77.1_16-77.1-4 | 200 | 4809 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.1/16-77.1-4.htm |  |  |
| RIS_16_16-77.1_16-77.1-5 | 200 | 4744 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.1/16-77.1-5.htm |  |  |
| RIS_16_16-77.1_16-77.1-6 | 200 | 4130 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.1/16-77.1-6.htm |  |  |
| RIS_16_16-77.1_16-77.1-7 | 200 | 4115 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.1/16-77.1-7.htm |  |  |
| RIS_16_16-77.2_16-77.2-1 | 200 | 6533 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.2/16-77.2-1.htm |  |  |
| RIS_16_16-77.2_16-77.2-2 | 200 | 14137 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.2/16-77.2-2.htm |  |  |
| RIS_16_16-77.2_16-77.2-3 | 200 | 8830 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.2/16-77.2-3.htm |  |  |
| RIS_16_16-77.2_16-77.2-4 | 200 | 5413 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.2/16-77.2-4.htm |  |  |
| RIS_16_16-77.2_16-77.2-5 | 200 | 6833 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.2/16-77.2-5.htm |  |  |
| RIS_16_16-77.2_16-77.2-6 | 200 | 4148 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.2/16-77.2-6.htm |  |  |
| RIS_16_16-77.2_16-77.2-7 | 200 | 7725 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.2/16-77.2-7.htm |  |  |
| RIS_16_16-77.2_16-77.2-8 | 200 | 5460 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.2/16-77.2-8.htm |  |  |
| RIS_16_16-77.3_16-77.3-1 | 200 | 5205 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.3/16-77.3-1.htm |  |  |
| RIS_16_16-77.3_16-77.3-2 | 200 | 14531 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.3/16-77.3-2.htm |  |  |
| RIS_16_16-77.3_16-77.3-3 | 200 | 8144 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.3/16-77.3-3.htm |  |  |
| RIS_16_16-77.3_16-77.3-4 | 200 | 5417 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.3/16-77.3-4.htm |  |  |
| RIS_16_16-77.3_16-77.3-5 | 200 | 6021 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.3/16-77.3-5.htm |  |  |
| RIS_16_16-77.3_16-77.3-6 | 200 | 4155 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.3/16-77.3-6.htm |  |  |
| RIS_16_16-77.3_16-77.3-7 | 200 | 7741 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.3/16-77.3-7.htm |  |  |
| RIS_16_16-77.3_16-77.3-8 | 200 | 5482 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.3/16-77.3-8.htm |  |  |
| RIS_16_16-77.4_16-77.4-1 | 200 | 5967 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.4/16-77.4-1.htm |  |  |
| RIS_16_16-77.4_16-77.4-2 | 200 | 11054 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.4/16-77.4-2.htm |  |  |
| RIS_16_16-77.4_16-77.4-3 | 200 | 8070 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.4/16-77.4-3.htm |  |  |
| RIS_16_16-77.4_16-77.4-4 | 200 | 5365 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.4/16-77.4-4.htm |  |  |
| RIS_16_16-77.4_16-77.4-5 | 200 | 5873 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.4/16-77.4-5.htm |  |  |
| RIS_16_16-77.4_16-77.4-6 | 200 | 4120 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.4/16-77.4-6.htm |  |  |
| RIS_16_16-77.4_16-77.4-7 | 200 | 7484 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.4/16-77.4-7.htm |  |  |
| RIS_16_16-77.4_16-77.4-8 | 200 | 5392 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-77.4/16-77.4-8.htm |  |  |
| RIS_16_16-78_16-78-1 | 200 | 5233 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-78/16-78-1.htm |  |  |
| RIS_16_16-79_16-79-1 | 200 | 3815 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-79/16-79-1.htm |  | render-thin 223 |
| RIS_16_16-80_16-80-1 | 200 | 4323 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-80/16-80-1.htm |  |  |
| RIS_16_16-80_16-80-2 | 200 | 7737 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-80/16-80-2.htm |  |  |
| RIS_16_16-80_16-80-3 | 200 | 5521 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-80/16-80-3.htm |  |  |
| RIS_16_16-80_16-80-4 | 200 | 8736 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-80/16-80-4.htm |  |  |
| RIS_16_16-80_16-80-5 | 200 | 8035 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-80/16-80-5.htm |  |  |
| RIS_16_16-80_16-80-6 | 200 | 4931 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-80/16-80-6.htm |  |  |
| RIS_16_16-80_16-80-7 | 200 | 3966 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-80/16-80-7.htm |  |  |
| RIS_16_16-80_16-80-8 | 200 | 3988 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-80/16-80-8.htm |  |  |
| RIS_16_16-81_16-81-1 | 200 | 6034 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-81/16-81-1.htm |  |  |
| RIS_16_16-81_16-81-1.1 | 200 | 5098 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-81/16-81-1.1.htm |  |  |
| RIS_16_16-82_16-82-1 | 200 | 3903 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-82/16-82-1.htm |  | render-thin 263 |
| RIS_16_16-82_16-82-2 | 200 | 4060 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-82/16-82-2.htm |  |  |
| RIS_16_16-82_16-82-3 | 200 | 3938 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-82/16-82-3.htm |  | render-thin 297 |
| RIS_16_16-82_16-82-4 | 200 | 4059 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-82/16-82-4.htm |  |  |
| RIS_16_16-82_16-82-5 | 200 | 4035 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-82/16-82-5.htm |  |  |
| RIS_16_16-82_16-82-6 | 200 | 3801 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-82/16-82-6.htm |  | render-thin 226 |
| RIS_16_16-83_16-83-1 | 200 | 3914 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-83/16-83-1.htm |  | render-thin 274 |
| RIS_16_16-83_16-83-2 | 200 | 5303 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-83/16-83-2.htm |  |  |
| RIS_16_16-83_16-83-3 | 200 | 5351 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-83/16-83-3.htm |  |  |
| RIS_16_16-84_16-84-1 | 200 | 5332 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-84/16-84-1.htm |  |  |
| RIS_16_16-84_16-84-2 | 200 | 5304 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-84/16-84-2.htm |  |  |
| RIS_16_16-84_16-84-3 | 200 | 5241 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-84/16-84-3.htm |  |  |
| RIS_16_16-84_16-84-4 | 200 | 5351 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-84/16-84-4.htm |  |  |
| RIS_16_16-84_16-84-5 | 200 | 4027 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-84/16-84-5.htm |  |  |
| RIS_16_16-85_16-85-1 | 200 | 3866 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-85/16-85-1.htm |  | render-thin 247 |
| RIS_16_16-85_16-85-2 | 200 | 4737 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-85/16-85-2.htm |  |  |
| RIS_16_16-86_16-86-1 | 200 | 4550 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-86/16-86-1.htm |  |  |
| RIS_16_16-86_16-86-2 | 200 | 5471 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-86/16-86-2.htm |  |  |
| RIS_16_16-86_16-86-3 | 200 | 4621 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-86/16-86-3.htm |  |  |
| RIS_16_16-86_16-86-4 | 200 | 4629 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-86/16-86-4.htm |  |  |
| RIS_16_16-87_16-87-1 | 200 | 3926 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-87/16-87-1.htm |  | render-thin 285 |
| RIS_16_16-87_16-87-2 | 200 | 5976 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-87/16-87-2.htm |  |  |
| RIS_16_16-87_16-87-3 | 200 | 5492 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-87/16-87-3.htm |  |  |
| RIS_16_16-87_16-87-4 | 200 | 5736 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-87/16-87-4.htm |  |  |
| RIS_16_16-87_16-87-5 | 200 | 4039 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-87/16-87-5.htm |  |  |
| RIS_16_16-87_16-87-6 | 200 | 5614 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-87/16-87-6.htm |  |  |
| RIS_16_16-87_16-87-7 | 200 | 5351 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-87/16-87-7.htm |  |  |
| RIS_16_16-87.1_16-87.1-1 | 200 | 6846 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-87.1/16-87.1-1.htm |  |  |
| RIS_16_16-88_16-88-1 | 200 | 3954 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-88/16-88-1.htm |  |  |
| RIS_16_16-88_16-88-2 | 200 | 6686 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-88/16-88-2.htm |  |  |
| RIS_16_16-88_16-88-3 | 200 | 6084 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-88/16-88-3.htm |  |  |
| RIS_16_16-88_16-88-4 | 200 | 4127 | https://webserver.rilegislature.gov/Statutes/TITLE16/16-88/16-88-4.htm |  |  |
