| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| MTS_0820-0100-0050-0070 | 200 | 10787 | https://leg.mt.gov/bills/mca/title_0820/chapter_0100/part_0050/section_0070/0820-0100-0050-0070.html |    82-10-507. Agreement -- offer of settlement, MCA  |  |
| MTS_0820-0100-0050-0080 | 200 | 10535 | https://leg.mt.gov/bills/mca/title_0820/chapter_0100/part_0050/section_0080/0820-0100-0050-0080.html |    82-10-508. Rejection -- legal action, MCA  |  |
| MTS_0820-0100-0050-0090 | 200 | 9965 | https://leg.mt.gov/bills/mca/title_0820/chapter_0100/part_0050/section_0090/0820-0100-0050-0090.html |    82-10-509. reserved, MCA  |  |
| MTS_0820-0100-0050-0100 | 200 | 10867 | https://leg.mt.gov/bills/mca/title_0820/chapter_0100/part_0050/section_0100/0820-0100-0050-0100.html |    82-10-510. Penalty for notice violation, MCA  |  |
| MTS_0820-0100-0050-0110 | 200 | 10139 | https://leg.mt.gov/bills/mca/title_0820/chapter_0100/part_0050/section_0110/0820-0100-0050-0110.html |    82-10-511. Remedies cumulative, MCA  |  |
| MTS_0820-0100-0060-0010 | 200 | 10303 | https://leg.mt.gov/bills/mca/title_0820/chapter_0100/part_0060/section_0010/0820-0100-0060-0010.html |    82-10-601. Legislative findings -- purpose, MCA  |  |
| MTS_0820-0100-0060-0020 | 200 | 11045 | https://leg.mt.gov/bills/mca/title_0820/chapter_0100/part_0060/section_0020/0820-0100-0060-0020.html |    82-10-602. Definitions, MCA  |  |
| MTS_0820-0100-0060-0030 | 200 | 12134 | https://leg.mt.gov/bills/mca/title_0820/chapter_0100/part_0060/section_0030/0820-0100-0060-0030.html |    82-10-603. Fracturing fluid disclosure -- requirements, MCA  |  |
| MTS_0820-0100-0060-0040 | 200 | 17288 | https://leg.mt.gov/bills/mca/title_0820/chapter_0100/part_0060/section_0040/0820-0100-0060-0040.html |    82-10-604. Confidentiality request for trade secrets, MCA  |  |
| MTS_0820-0110-0010-0010 | 200 | 27224 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0010/0820-0110-0010-0010.html |    82-11-101. Definitions, MCA  |  |
| MTS_0820-0110-0010-0020 | 200 | 10504 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0020/0820-0110-0010-0020.html |    82-11-102. Oil or gas wells not public utilities, MCA  |  |
| MTS_0820-0110-0010-0030 | 200 | 11831 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0030/0820-0110-0010-0030.html |    82-11-103. Lands subject to law, MCA  |  |
| MTS_0820-0110-0010-0040 | 200 | 12179 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0040/0820-0110-0010-0040.html |    82-11-104. Construction -- no conflict with board of land commissioners' auth |  |
| MTS_0820-0110-0010-0050 | 200 | 10124 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0050/0820-0110-0010-0050.html |    82-11-105. through 82-11-109 reserved, MCA  |  |
| MTS_0820-0110-0010-0100 | 200 | 10706 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0100/0820-0110-0010-0100.html |    82-11-110. Oil and gas education and research account, MCA  |  |
| MTS_0820-0110-0010-0110 | 200 | 27803 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0110/0820-0110-0010-0110.html |    82-11-111. Powers and duties of board, MCA  |  |
| MTS_0820-0110-0010-0120 | 200 | 10718 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0120/0820-0110-0010-0120.html |    82-11-112. Intergovernmental cooperation, MCA  |  |
| MTS_0820-0110-0010-0130 | 200 | 10224 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0130/0820-0110-0010-0130.html |    82-11-113. Repealed, MCA  |  |
| MTS_0820-0110-0010-0140 | 200 | 10203 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0140/0820-0110-0010-0140.html |    82-11-114. Repealed, MCA  |  |
| MTS_0820-0110-0010-0150 | 200 | 10203 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0150/0820-0110-0010-0150.html |    82-11-115. Repealed, MCA  |  |
| MTS_0820-0110-0010-0160 | 200 | 10221 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0160/0820-0110-0010-0160.html |    82-11-116. Repealed, MCA  |  |
| MTS_0820-0110-0010-0170 | 200 | 12819 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0170/0820-0110-0010-0170.html |    82-11-117. Confidentiality of records, MCA  |  |
| MTS_0820-0110-0010-0180 | 200 | 12040 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0180/0820-0110-0010-0180.html |    82-11-118. Fees for processing applications, MCA  |  |
| MTS_0820-0110-0010-0190 | 200 | 10051 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0190/0820-0110-0010-0190.html |    82-11-119. and 82-11-120 reserved, MCA  |  |
| MTS_0820-0110-0010-0210 | 200 | 10523 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0210/0820-0110-0010-0210.html |    82-11-121. Oil and gas waste prohibited, MCA  |  |
| MTS_0820-0110-0010-0220 | 200 | 13990 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0220/0820-0110-0010-0220.html |    82-11-122. Notice of intention to drill or conduct seismic operations -- noti |  |
| MTS_0820-0110-0010-0230 | 200 | 21234 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0230/0820-0110-0010-0230.html |    82-11-123. Requirements for oil and gas operations, MCA  |  |
| MTS_0820-0110-0010-0240 | 200 | 11428 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0240/0820-0110-0010-0240.html |    82-11-124. Requirements relating to waste prevention, MCA  |  |
| MTS_0820-0110-0010-0250 | 200 | 12759 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0250/0820-0110-0010-0250.html |    82-11-125. Availability of cores or chips, cuttings, and bottom-hole temperat |  |
| MTS_0820-0110-0010-0260 | 200 | 11012 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0260/0820-0110-0010-0260.html |    82-11-126. Availability of facilities to bureau of mines, MCA  |  |
| MTS_0820-0110-0010-0270 | 200 | 15172 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0270/0820-0110-0010-0270.html |    82-11-127. Prohibited activity -- Makoshika state park, MCA  |  |
| MTS_0820-0110-0010-0280 | 200 | 10079 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0280/0820-0110-0010-0280.html |    82-11-128. through 82-11-130 reserved, MCA  |  |
| MTS_0820-0110-0010-0310 | 200 | 12064 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0310/0820-0110-0010-0310.html |    82-11-131. Privilege and license tax, MCA  |  |
| MTS_0820-0110-0010-0320 | 200 | 10621 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0320/0820-0110-0010-0320.html |    82-11-132. Repealed, MCA  |  |
| MTS_0820-0110-0010-0330 | 200 | 10576 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0330/0820-0110-0010-0330.html |    82-11-133. Repealed, MCA  |  |
| MTS_0820-0110-0010-0340 | 200 | 11118 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0340/0820-0110-0010-0340.html |    82-11-134. Permit fees, MCA  |  |
| MTS_0820-0110-0010-0350 | 200 | 11860 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0350/0820-0110-0010-0350.html |    82-11-135. Money earmarked for board expenses, MCA  |  |
| MTS_0820-0110-0010-0360 | 200 | 11636 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0360/0820-0110-0010-0360.html |    82-11-136. Expenditure of funds from bonds for plugging wells, MCA  |  |
| MTS_0820-0110-0010-0370 | 200 | 13629 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0370/0820-0110-0010-0370.html |    82-11-137. Class II injection well operating fee, MCA  |  |
| MTS_0820-0110-0010-0380 | 200 | 10522 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0380/0820-0110-0010-0380.html |    82-11-138. Rulemaking -- microbial conversion wells, MCA  |  |
| MTS_0820-0110-0010-0390 | 200 | 10055 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0390/0820-0110-0010-0390.html |    82-11-139. and 82-11-140 reserved, MCA  |  |
| MTS_0820-0110-0010-0410 | 200 | 13531 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0410/0820-0110-0010-0410.html |    82-11-141. Administrative procedure, MCA  |  |
| MTS_0820-0110-0010-0420 | 200 | 13384 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0420/0820-0110-0010-0420.html |    82-11-142. Subpoena power -- civil actions, MCA  |  |
| MTS_0820-0110-0010-0430 | 200 | 10600 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0430/0820-0110-0010-0430.html |    82-11-143. Rehearing, MCA  |  |
| MTS_0820-0110-0010-0440 | 200 | 13178 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0440/0820-0110-0010-0440.html |    82-11-144. Court review, MCA  |  |
| MTS_0820-0110-0010-0450 | 200 | 12383 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0450/0820-0110-0010-0450.html |    82-11-145. Injunction or restraining order, MCA  |  |
| MTS_0820-0110-0010-0460 | 200 | 10368 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0460/0820-0110-0010-0460.html |    82-11-146. Appeal, MCA  |  |
| MTS_0820-0110-0010-0470 | 200 | 11663 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0470/0820-0110-0010-0470.html |    82-11-147. Violations, MCA  |  |
| MTS_0820-0110-0010-0480 | 200 | 11398 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0480/0820-0110-0010-0480.html |    82-11-148. Criminal penalties, MCA  |  |
| MTS_0820-0110-0010-0490 | 200 | 11147 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0490/0820-0110-0010-0490.html |    82-11-149. Civil penalties, MCA  |  |
| MTS_0820-0110-0010-0500 | 200 | 10530 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0500/0820-0110-0010-0500.html |    82-11-150. Legal assistance, MCA  |  |
| MTS_0820-0110-0010-0510 | 200 | 13773 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0510/0820-0110-0010-0510.html |    82-11-151. Emergencies -- notice and hearing, MCA  |  |
| MTS_0820-0110-0010-0520 | 200 | 10119 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0520/0820-0110-0010-0520.html |    82-11-152. through 82-11-160 reserved, MCA  |  |
| MTS_0820-0110-0010-0610 | 200 | 18663 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0610/0820-0110-0010-0610.html |    82-11-161. Oil and gas production damage mitigation account -- statutory appr |  |
| MTS_0820-0110-0010-0620 | 200 | 10333 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0620/0820-0110-0010-0620.html |    82-11-162. Repealed, MCA  |  |
| MTS_0820-0110-0010-0630 | 200 | 12284 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0630/0820-0110-0010-0630.html |    82-11-163. Landowner's bond on noncommercial well, MCA  |  |
| MTS_0820-0110-0010-0640 | 200 | 11139 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0640/0820-0110-0010-0640.html |    82-11-164. Lien created, MCA  |  |
| MTS_0820-0110-0010-0650 | 200 | 10033 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0650/0820-0110-0010-0650.html |    82-11-165. through 82-11-170 reserved, MCA  |  |
| MTS_0820-0110-0010-0710 | 200 | 10254 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0710/0820-0110-0010-0710.html |    82-11-171. Terminated, MCA  |  |
| MTS_0820-0110-0010-0720 | 200 | 10478 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0720/0820-0110-0010-0720.html |    82-11-172. Short title, MCA  |  |
| MTS_0820-0110-0010-0730 | 200 | 12101 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0730/0820-0110-0010-0730.html |    82-11-173. Legislative findings -- purpose, MCA  |  |
| MTS_0820-0110-0010-0740 | 200 | 10862 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0740/0820-0110-0010-0740.html |    82-11-174. Offset permitting -- geographic requirements, MCA  |  |
| MTS_0820-0110-0010-0750 | 200 | 12798 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0750/0820-0110-0010-0750.html |    82-11-175. Coal bed methane wells -- requirements, MCA  |  |
| MTS_0820-0110-0010-0760 | 200 | 10080 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0760/0820-0110-0010-0760.html |    82-11-176. through 82-11-179 reserved, MCA  |  |
| MTS_0820-0110-0010-0800 | 200 | 13287 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0800/0820-0110-0010-0800.html |    82-11-180. Preservation of property rights, MCA  |  |
| MTS_0820-0110-0010-0810 | 200 | 12827 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0810/0820-0110-0010-0810.html |    82-11-181. Geologic storage reservoir administrative fee -- account establish |  |
| MTS_0820-0110-0010-0820 | 200 | 11724 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0820/0820-0110-0010-0820.html |    82-11-182. Liability for carbon dioxide during injection, MCA  |  |
| MTS_0820-0110-0010-0830 | 200 | 19433 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0830/0820-0110-0010-0830.html |    82-11-183. Certificate of completion -- department of environmental quality p |  |
| MTS_0820-0110-0010-0840 | 200 | 11789 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0840/0820-0110-0010-0840.html |    82-11-184. Conversion of enhanced recovery wells, MCA  |  |
| MTS_0820-0110-0010-0850 | 200 | 12409 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0850/0820-0110-0010-0850.html |    82-11-185. Makoshika state park requirements, MCA  |  |
| MTS_0820-0110-0010-0860 | 200 | 10074 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0860/0820-0110-0010-0860.html |    82-11-186. and 82-11-187 reserved, MCA  |  |
| MTS_0820-0110-0010-0880 | 200 | 11387 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0010/section_0880/0820-0110-0010-0880.html |    82-11-188. Incidental carbon dioxide storage -- certification, MCA  |  |
| MTS_0820-0110-0020-0010 | 200 | 18258 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0010/0820-0110-0020-0010.html |    82-11-201. Establishment of well spacing units, MCA  |  |
| MTS_0820-0110-0020-0020 | 200 | 18510 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0020/0820-0110-0020-0020.html |    82-11-202. Pooling of interest within spacing unit, MCA  |  |
| MTS_0820-0110-0020-0030 | 200 | 11202 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0030/0820-0110-0020-0030.html |    82-11-203. Pooling agreements not in violation of antitrust laws, MCA  |  |
| MTS_0820-0110-0020-0040 | 200 | 14183 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0040/0820-0110-0020-0040.html |    82-11-204. Hearing on operation of pool as unit, MCA  |  |
| MTS_0820-0110-0020-0050 | 200 | 12860 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0050/0820-0110-0020-0050.html |    82-11-205. Board order for unit operation -- criteria, MCA  |  |
| MTS_0820-0110-0020-0060 | 200 | 16516 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0060/0820-0110-0020-0060.html |    82-11-206. Terms and conditions of plan for unit operations, MCA  |  |
| MTS_0820-0110-0020-0070 | 200 | 12152 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0070/0820-0110-0020-0070.html |    82-11-207. Approval of plan for unit operations by persons paying costs, MCA  |  |
| MTS_0820-0110-0020-0080 | 200 | 11091 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0080/0820-0110-0020-0080.html |    82-11-208. Board orders -- amendment, MCA  |  |
| MTS_0820-0110-0020-0090 | 200 | 11451 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0090/0820-0110-0020-0090.html |    82-11-209. Units established by previous order, MCA  |  |
| MTS_0820-0110-0020-0100 | 200 | 10556 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0100/0820-0110-0020-0100.html |    82-11-210. Unit operations -- less than whole of pool, MCA  |  |
| MTS_0820-0110-0020-0110 | 200 | 11216 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0110/0820-0110-0020-0110.html |    82-11-211. Operations considered as done by all owners in unit, MCA  |  |
| MTS_0820-0110-0020-0120 | 200 | 11401 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0120/0820-0110-0020-0120.html |    82-11-212. Property rights and operator's lien, MCA  |  |
| MTS_0820-0110-0020-0130 | 200 | 10616 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0130/0820-0110-0020-0130.html |    82-11-213. Contract not terminated by board order, MCA  |  |
| MTS_0820-0110-0020-0140 | 200 | 11992 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0140/0820-0110-0020-0140.html |    82-11-214. Title to oil and gas rights not affected by board order, MCA  |  |
| MTS_0820-0110-0020-0150 | 200 | 10762 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0150/0820-0110-0020-0150.html |    82-11-215. Unit operation not restraint of trade, MCA  |  |
| MTS_0820-0110-0020-0160 | 200 | 10345 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0020/section_0160/0820-0110-0020-0160.html |    82-11-216. No creation of relationship between parties in unit, MCA  |  |
| MTS_0820-0110-0030-0010 | 200 | 10711 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0030/section_0010/0820-0110-0030-0010.html |    82-11-301. Authorization to join interstate compact for conservation of oil a |  |
| MTS_0820-0110-0030-0020 | 200 | 17668 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0030/section_0020/0820-0110-0030-0020.html |    82-11-302. Interstate oil and gas compact, MCA  |  |
| MTS_0820-0110-0030-0030 | 200 | 10993 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0030/section_0030/0820-0110-0030-0030.html |    82-11-303. Extension of expiration date, MCA  |  |
| MTS_0820-0110-0030-0040 | 200 | 11124 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0030/section_0040/0820-0110-0030-0040.html |    82-11-304. Governor as member of interstate oil compact commission, MCA  |  |
| MTS_0820-0110-0030-0050 | 200 | 11174 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0030/section_0050/0820-0110-0030-0050.html |    82-11-305. Limitation on power of representative, MCA  |  |
| MTS_0820-0110-0030-0060 | 200 | 10733 | https://leg.mt.gov/bills/mca/title_0820/chapter_0110/part_0030/section_0060/0820-0110-0030-0060.html |    82-11-306. Expenses of representative, MCA  |  |
| MTS_0820-0150-0010-0010 | 200 | 13850 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0010/0820-0150-0010-0010.html |    82-15-101. Definitions, MCA  |  |
| MTS_0820-0150-0010-0020 | 200 | 12148 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0020/0820-0150-0010-0020.html |    82-15-102. Enforcement of part -- rules, MCA  |  |
| MTS_0820-0150-0010-0030 | 200 | 11183 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0030/0820-0150-0010-0030.html |    82-15-103. Standards and specifications for petroleum products, MCA  |  |
| MTS_0820-0150-0010-0040 | 200 | 10861 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0040/0820-0150-0010-0040.html |    82-15-104. Departments authorized to employ laboratory for testing, MCA  |  |
| MTS_0820-0150-0010-0050 | 200 | 12280 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0050/0820-0150-0010-0050.html |    82-15-105. Licenses and fees -- status of license on transfer of ownership, M |  |
| MTS_0820-0150-0010-0060 | 200 | 11202 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0060/0820-0150-0010-0060.html |    82-15-106. Refusing, suspending, and revoking licenses -- hearing required, M |  |
| MTS_0820-0150-0010-0070 | 200 | 11364 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0070/0820-0150-0010-0070.html |    82-15-107. Inspections, sampling, and tests by department to insure complianc |  |
| MTS_0820-0150-0010-0080 | 200 | 10892 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0080/0820-0150-0010-0080.html |    82-15-108. Approved measure required for part delivery, MCA  |  |
| MTS_0820-0150-0010-0090 | 200 | 10688 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0090/0820-0150-0010-0090.html |    82-15-109. Full compartment sales -- approval of meter, MCA  |  |
| MTS_0820-0150-0010-0100 | 200 | 12634 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0100/0820-0150-0010-0100.html |    82-15-110. Unlawful acts, MCA  |  |
| MTS_0820-0150-0010-0110 | 200 | 10913 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0110/0820-0150-0010-0110.html |    82-15-111. Penalty for violations, MCA  |  |
| MTS_0820-0150-0010-0120 | 200 | 10592 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0120/0820-0150-0010-0120.html |    82-15-112. Injunction against violations, MCA  |  |
| MTS_0820-0150-0010-0130 | 200 | 11071 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0130/0820-0150-0010-0130.html |    82-15-113. Refilling of liquefied petroleum product containers -- unlawful ac |  |
| MTS_0820-0150-0010-0140 | 200 | 10563 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0140/0820-0150-0010-0140.html |    82-15-114. Violation -- penalty, MCA  |  |
| MTS_0820-0150-0010-0150 | 200 | 10397 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0150/0820-0150-0010-0150.html |    82-15-115. Owner identification, MCA  |  |
| MTS_0820-0150-0010-0160 | 200 | 10168 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0160/0820-0150-0010-0160.html |    82-15-116. through 82-15-119 reserved, MCA  |  |
| MTS_0820-0150-0010-0200 | 200 | 14460 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0200/0820-0150-0010-0200.html |    82-15-120. Department of environmental quality to enforce prohibition on meth |  |
| MTS_0820-0150-0010-0210 | 200 | 10333 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0210/0820-0150-0010-0210.html |    82-15-121. Repealed, MCA  |  |
| MTS_0820-0150-0010-0220 | 200 | 10004 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0010/section_0220/0820-0150-0010-0220.html |    82-15-122. Repealed, MCA  |  |
| MTS_0820-0150-0020-0010 | 200 | 10192 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0020/section_0010/0820-0150-0020-0010.html |    82-15-201. Standard petroleum product defined, MCA  |  |
| MTS_0820-0150-0020-0020 | 200 | 10799 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0020/section_0020/0820-0150-0020-0020.html |    82-15-202. Purpose, MCA  |  |
| MTS_0820-0150-0020-0030 | 200 | 12444 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0020/section_0030/0820-0150-0020-0030.html |    82-15-203. Discrimination in price of petroleum products, MCA  |  |
| MTS_0820-0150-0020-0040 | 200 | 11595 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0020/section_0040/0820-0150-0020-0040.html |    82-15-204. Investigation of complaints -- revocation of license, MCA  |  |
| MTS_0820-0150-0020-0050 | 200 | 11187 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0020/section_0050/0820-0150-0020-0050.html |    82-15-205. County attorney to prosecute violations, MCA  |  |
| MTS_0820-0150-0020-0060 | 200 | 10376 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0020/section_0060/0820-0150-0020-0060.html |    82-15-206. Penalty, MCA  |  |
| MTS_0820-0150-0020-0070 | 200 | 10567 | https://leg.mt.gov/bills/mca/title_0820/chapter_0150/part_0020/section_0070/0820-0150-0020-0070.html |    82-15-207. Liability for civil and exemplary damages, MCA  |  |
| MTS_0850-0010-0010-0010 | 200 | 13032 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0010/section_0010/0850-0010-0010-0010.html |    85-1-101. Policy considerations, MCA  |  |
| MTS_0850-0010-0010-0020 | 200 | 19543 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0010/section_0020/0850-0010-0010-0020.html |    85-1-102. Definitions, MCA  |  |
| MTS_0850-0010-0010-0030 | 200 | 10423 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0010/section_0030/0850-0010-0010-0030.html |    85-1-103. Interpretation of title, MCA  |  |
| MTS_0850-0010-0010-0040 | 200 | 9900 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0010/section_0040/0850-0010-0010-0040.html |    85-1-104. through 85-1-110 reserved, MCA  |  |
| MTS_0850-0010-0010-0110 | 200 | 10786 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0010/section_0110/0850-0010-0010-0110.html |    85-1-111. Public ways, MCA  |  |
| MTS_0850-0010-0010-0120 | 200 | 10820 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0010/section_0120/0850-0010-0010-0120.html |    85-1-112. Navigable waters, MCA  |  |
| MTS_0850-0010-0010-0130 | 200 | 9890 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0010/section_0130/0850-0010-0010-0130.html |    85-1-113. through 85-1-120 reserved, MCA  |  |
| MTS_0850-0010-0010-0210 | 200 | 10173 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0010/section_0210/0850-0010-0010-0210.html |    85-1-121. Repealed, MCA  |  |
| MTS_0850-0010-0010-0220 | 200 | 10387 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0010/section_0220/0850-0010-0010-0220.html |    85-1-122. Clark Fork River, MCA  |  |
| MTS_0850-0010-0020-0010 | 200 | 9964 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0010/0850-0010-0020-0010.html |    85-1-201. Rules, MCA  |  |
| MTS_0850-0010-0020-0020 | 200 | 10116 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0020/0850-0010-0020-0020.html |    85-1-202. Repealed, MCA  |  |
| MTS_0850-0010-0020-0030 | 200 | 17275 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0030/0850-0010-0020-0030.html |    85-1-203. State water plan, MCA  |  |
| MTS_0850-0010-0020-0040 | 200 | 14070 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0040/0850-0010-0020-0040.html |    85-1-204. Department powers over state water, MCA  |  |
| MTS_0850-0010-0020-0050 | 200 | 10874 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0050/0850-0010-0020-0050.html |    85-1-205. Acquisition of water in federal reservoirs, MCA  |  |
| MTS_0850-0010-0020-0060 | 200 | 12869 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0060/0850-0010-0020-0060.html |    85-1-206. Construction of works by department, MCA  |  |
| MTS_0850-0010-0020-0070 | 200 | 10794 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0070/0850-0010-0020-0070.html |    85-1-207. Determination of costs of works, MCA  |  |
| MTS_0850-0010-0020-0080 | 200 | 11591 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0080/0850-0010-0020-0080.html |    85-1-208. Construction across streams, highways, or other obstacles, MCA  |  |
| MTS_0850-0010-0020-0090 | 200 | 12877 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0090/0850-0010-0020-0090.html |    85-1-209. Acquisition of property by department, MCA  |  |
| MTS_0850-0010-0020-0100 | 200 | 11480 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0100/0850-0010-0020-0100.html |    85-1-210. Disposal of property by department, MCA  |  |
| MTS_0850-0010-0020-0110 | 200 | 14788 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0110/0850-0010-0020-0110.html |    85-1-211. Management of property -- water contracts, MCA  |  |
| MTS_0850-0010-0020-0120 | 200 | 10308 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0120/0850-0010-0020-0120.html |    85-1-212. Repealed, MCA  |  |
| MTS_0850-0010-0020-0130 | 200 | 11414 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0130/0850-0010-0020-0130.html |    85-1-213. Institution of court actions by department, MCA  |  |
| MTS_0850-0010-0020-0140 | 200 | 11251 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0140/0850-0010-0020-0140.html |    85-1-214. Exercise of department powers -- scope of jurisdiction, MCA  |  |
| MTS_0850-0010-0020-0150 | 200 | 11122 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0150/0850-0010-0020-0150.html |    85-1-215. Department duties -- records and operations, MCA  |  |
| MTS_0850-0010-0020-0160 | 200 | 10483 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0160/0850-0010-0020-0160.html |    85-1-216. Limitations on liabilities and obligations, MCA  |  |
| MTS_0850-0010-0020-0170 | 200 | 10621 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0170/0850-0010-0020-0170.html |    85-1-217. Restoration and repair of damaged property, MCA  |  |
| MTS_0850-0010-0020-0180 | 200 | 10494 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0180/0850-0010-0020-0180.html |    85-1-218. Employment of county surveyors, MCA  |  |
| MTS_0850-0010-0020-0190 | 200 | 13793 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0190/0850-0010-0020-0190.html |    85-1-219. State-owned works -- department approval -- bids -- procurement of  |  |
| MTS_0850-0010-0020-0200 | 200 | 11905 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0200/0850-0010-0020-0200.html |    85-1-220. State water project hydroelectric power generation special revenue  |  |
| MTS_0850-0010-0020-0210 | 200 | 11374 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0210/0850-0010-0020-0210.html |    85-1-221. Contracts with the United States, MCA  |  |
| MTS_0850-0010-0020-0220 | 200 | 10640 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0220/0850-0010-0020-0220.html |    85-1-222. Conformity to federal regulations authorized, MCA  |  |
| MTS_0850-0010-0020-0230 | 200 | 11238 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0230/0850-0010-0020-0230.html |    85-1-223. Negotiations with other states by the department, MCA  |  |
| MTS_0850-0010-0020-0240 | 200 | 11910 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0020/section_0240/0850-0010-0020-0240.html |    85-1-224. Contracts with state agencies and counties, MCA  |  |
| MTS_0850-0010-0030-0010 | 200 | 12410 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0010/0850-0010-0030-0010.html |    85-1-301. Water conservation revenue bonds, MCA  |  |
| MTS_0850-0010-0030-0020 | 200 | 11356 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0020/0850-0010-0030-0020.html |    85-1-302. Limitations on state liability, MCA  |  |
| MTS_0850-0010-0030-0030 | 200 | 11430 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0030/0850-0010-0030-0030.html |    85-1-303. Procedure in case of insufficient bond proceeds, MCA  |  |
| MTS_0850-0010-0030-0040 | 200 | 10773 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0040/0850-0010-0030-0040.html |    85-1-304. Lien upon bond proceeds, MCA  |  |
| MTS_0850-0010-0030-0050 | 200 | 11004 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0050/0850-0010-0030-0050.html |    85-1-305. Use of trust indenture to secure bonds, MCA  |  |
| MTS_0850-0010-0030-0060 | 200 | 12018 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0060/0850-0010-0030-0060.html |    85-1-306. Provisions for protecting bondholders, MCA  |  |
| MTS_0850-0010-0030-0070 | 200 | 15447 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0070/0850-0010-0030-0070.html |    85-1-307. Provisions to secure payment of bonds, MCA  |  |
| MTS_0850-0010-0030-0080 | 200 | 11507 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0080/0850-0010-0030-0080.html |    85-1-308. Provisions for conveyance in trust or mortgage, MCA  |  |
| MTS_0850-0010-0030-0090 | 200 | 11600 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0090/0850-0010-0030-0090.html |    85-1-309. Actions by trustee and bondholders, MCA  |  |
| MTS_0850-0010-0030-0100 | 200 | 10377 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0100/0850-0010-0030-0100.html |    85-1-310. Refunding revenue bonds, MCA  |  |
| MTS_0850-0010-0030-0110 | 200 | 9911 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0110/0850-0010-0030-0110.html |    85-1-311. through 85-1-319 reserved, MCA  |  |
| MTS_0850-0010-0030-0200 | 200 | 11692 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0200/0850-0010-0030-0200.html |    85-1-320. Montana water development state special revenue account, MCA  |  |
| MTS_0850-0010-0030-0210 | 200 | 11453 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0210/0850-0010-0030-0210.html |    85-1-321. Funds in general, MCA  |  |
| MTS_0850-0010-0030-0220 | 200 | 11383 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0220/0850-0010-0030-0220.html |    85-1-322. Construction capital projects funds, MCA  |  |
| MTS_0850-0010-0030-0230 | 200 | 12361 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0230/0850-0010-0030-0230.html |    85-1-323. Debt service funds, MCA  |  |
| MTS_0850-0010-0030-0240 | 200 | 9905 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0240/0850-0010-0030-0240.html |    85-1-324. through 85-1-330 reserved, MCA  |  |
| MTS_0850-0010-0030-0310 | 200 | 10564 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0310/0850-0010-0030-0310.html |    85-1-331. Acceptance and use of appropriations and contributions, MCA  |  |
| MTS_0850-0010-0030-0320 | 200 | 13137 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0320/0850-0010-0030-0320.html |    85-1-332. Disposition of money collected, MCA  |  |
| MTS_0850-0010-0030-0330 | 200 | 10180 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0330/0850-0010-0030-0330.html |    85-1-333. Repealed, MCA  |  |
| MTS_0850-0010-0030-0340 | 200 | 9921 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0030/section_0340/0850-0010-0030-0340.html |    85-1-334. Repealed, MCA  |  |
| MTS_0850-0010-0040-0010 | 200 | 9888 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0040/section_0010/0850-0010-0040-0010.html |    85-1-401. Repealed, MCA  |  |
| MTS_0850-0010-0040-0020 | 200 | 10091 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0040/section_0020/0850-0010-0040-0020.html |    85-1-402. Repealed, MCA  |  |
| MTS_0850-0010-0040-0030 | 200 | 10091 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0040/section_0030/0850-0010-0040-0030.html |    85-1-403. Repealed, MCA  |  |
| MTS_0850-0010-0040-0040 | 200 | 10091 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0040/section_0040/0850-0010-0040-0040.html |    85-1-404. Repealed, MCA  |  |
| MTS_0850-0010-0040-0050 | 200 | 10091 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0040/section_0050/0850-0010-0040-0050.html |    85-1-405. Repealed, MCA  |  |
| MTS_0850-0010-0040-0060 | 200 | 10091 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0040/section_0060/0850-0010-0040-0060.html |    85-1-406. Repealed, MCA  |  |
| MTS_0850-0010-0040-0070 | 200 | 10123 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0040/section_0070/0850-0010-0040-0070.html |    85-1-407. Repealed, MCA  |  |
| MTS_0850-0010-0040-0080 | 200 | 10091 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0040/section_0080/0850-0010-0040-0080.html |    85-1-408. Repealed, MCA  |  |
| MTS_0850-0010-0040-0090 | 200 | 9891 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0040/section_0090/0850-0010-0040-0090.html |    85-1-409. Repealed, MCA  |  |
| MTS_0850-0010-0050-0010 | 200 | 11593 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0010/0850-0010-0050-0010.html |    85-1-501. Survey of power generation capacity, MCA  |  |
| MTS_0850-0010-0050-0020 | 200 | 11411 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0020/0850-0010-0050-0020.html |    85-1-502. Notice of availability of lease sites, MCA  |  |
| MTS_0850-0010-0050-0030 | 200 | 10854 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0030/0850-0010-0050-0030.html |    85-1-503. Receipt of applications, MCA  |  |
| MTS_0850-0010-0050-0040 | 200 | 11305 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0040/0850-0010-0050-0040.html |    85-1-504. Determinations by department, MCA  |  |
| MTS_0850-0010-0050-0050 | 200 | 10509 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0050/0850-0010-0050-0050.html |    85-1-505. Lease conditions, MCA  |  |
| MTS_0850-0010-0050-0060 | 200 | 10259 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0060/0850-0010-0050-0060.html |    85-1-506. Compliance with federal law, MCA  |  |
| MTS_0850-0010-0050-0070 | 200 | 10351 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0070/0850-0010-0050-0070.html |    85-1-507. Duration of lease, MCA  |  |
| MTS_0850-0010-0050-0080 | 200 | 10255 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0080/0850-0010-0050-0080.html |    85-1-508. Duties of the department, MCA  |  |
| MTS_0850-0010-0050-0090 | 200 | 11248 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0090/0850-0010-0050-0090.html |    85-1-509. Power generation by department authorized, MCA  |  |
| MTS_0850-0010-0050-0100 | 200 | 11444 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0100/0850-0010-0050-0100.html |    85-1-510. Sale of power and allocation of revenue, MCA  |  |
| MTS_0850-0010-0050-0110 | 200 | 10913 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0110/0850-0010-0050-0110.html |    85-1-511. Determination by the public service commission, MCA  |  |
| MTS_0850-0010-0050-0120 | 200 | 12177 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0120/0850-0010-0050-0120.html |    85-1-512. Standards for the determination, MCA  |  |
| MTS_0850-0010-0050-0130 | 200 | 11168 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0130/0850-0010-0050-0130.html |    85-1-513. Purchase of power by electric cooperative not agreeing to be bound  |  |
| MTS_0850-0010-0050-0140 | 200 | 12109 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0050/section_0140/0850-0010-0050-0140.html |    85-1-514. Power generation negotiation process, MCA  |  |
| MTS_0850-0010-0060-0010 | 200 | 13639 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0010/0850-0010-0060-0010.html |    85-1-601. Purpose and policies, MCA  |  |
| MTS_0850-0010-0060-0020 | 200 | 13733 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0020/0850-0010-0060-0020.html |    85-1-602. Objectives, MCA  |  |
| MTS_0850-0010-0060-0030 | 200 | 14081 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0030/0850-0010-0060-0030.html |    85-1-603. Renewable resource loan debt service fund created -- coal severance |  |
| MTS_0850-0010-0060-0040 | 200 | 10773 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0040/0850-0010-0060-0040.html |    85-1-604. Repealed, MCA  |  |
| MTS_0850-0010-0060-0050 | 200 | 16246 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0050/0850-0010-0060-0050.html |    85-1-605. Grants, loans, and bonds for state, local, or tribal government ass |  |
| MTS_0850-0010-0060-0060 | 200 | 11313 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0060/0850-0010-0060-0060.html |    85-1-606. Grants and loans to private persons, MCA  |  |
| MTS_0850-0010-0060-0070 | 200 | 10206 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0070/0850-0010-0060-0070.html |    85-1-607. Repealed, MCA  |  |
| MTS_0850-0010-0060-0080 | 200 | 11029 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0080/0850-0010-0060-0080.html |    85-1-608. Applications for grants and loans to private persons, MCA  |  |
| MTS_0850-0010-0060-0090 | 200 | 13369 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0090/0850-0010-0060-0090.html |    85-1-609. Eligibility for a loan or grant to a private person, MCA  |  |
| MTS_0850-0010-0060-0100 | 200 | 12482 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0100/0850-0010-0060-0100.html |    85-1-610. Evaluation of grants and loans to private persons, MCA  |  |
| MTS_0850-0010-0060-0110 | 200 | 10615 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0110/0850-0010-0060-0110.html |    85-1-611. Department to solicit views, MCA  |  |
| MTS_0850-0010-0060-0120 | 200 | 11836 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0120/0850-0010-0060-0120.html |    85-1-612. Rulemaking authority, MCA  |  |
| MTS_0850-0010-0060-0130 | 200 | 13543 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0130/0850-0010-0060-0130.html |    85-1-613. Limits on loans, MCA  |  |
| MTS_0850-0010-0060-0140 | 200 | 11443 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0140/0850-0010-0060-0140.html |    85-1-614. Limits on grants from natural resources projects state special reve |  |
| MTS_0850-0010-0060-0150 | 200 | 13756 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0150/0850-0010-0060-0150.html |    85-1-615. Security interests -- purchase, operation, and resale of encumbered |  |
| MTS_0850-0010-0060-0160 | 200 | 11271 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0160/0850-0010-0060-0160.html |    85-1-616. Administration of loans and grants, MCA  |  |
| MTS_0850-0010-0060-0170 | 200 | 15658 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0170/0850-0010-0060-0170.html |    85-1-617. Issuing renewable resource bonds -- renewable resource loan proceed |  |
| MTS_0850-0010-0060-0180 | 200 | 10699 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0180/0850-0010-0060-0180.html |    85-1-618. Restrictions on use of bond proceeds, MCA  |  |
| MTS_0850-0010-0060-0190 | 200 | 12143 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0190/0850-0010-0060-0190.html |    85-1-619. Debt service fund -- pledge and administration of sufficient balanc |  |
| MTS_0850-0010-0060-0200 | 200 | 12443 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0200/0850-0010-0060-0200.html |    85-1-620. Renewable resource refunding bonds, MCA  |  |
| MTS_0850-0010-0060-0210 | 200 | 10981 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0210/0850-0010-0060-0210.html |    85-1-621. Report, MCA  |  |
| MTS_0850-0010-0060-0220 | 200 | 10645 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0220/0850-0010-0060-0220.html |    85-1-622. Penalty, MCA  |  |
| MTS_0850-0010-0060-0230 | 200 | 10274 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0230/0850-0010-0060-0230.html |    85-1-623. Repealed, MCA  |  |
| MTS_0850-0010-0060-0240 | 200 | 10838 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0240/0850-0010-0060-0240.html |    85-1-624. Authorization of bonds, MCA  |  |
| MTS_0850-0010-0060-0250 | 200 | 10061 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0250/0850-0010-0060-0250.html |    85-1-625. through 85-1-630 reserved, MCA  |  |
| MTS_0850-0010-0060-0310 | 200 | 13402 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0310/0850-0010-0060-0310.html |    85-1-631. Water storage state special revenue account created -- revenues all |  |
| MTS_0850-0010-0060-0320 | 200 | 10281 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0060/section_0320/0850-0010-0060-0320.html |    85-1-632. Exemption from environmental review, MCA  |  |
| MTS_0850-0010-0070-0010 | 200 | 9873 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0070/section_0010/0850-0010-0070-0010.html |    85-1-701. Short title, MCA  |  |
| MTS_0850-0010-0070-0020 | 200 | 10239 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0070/section_0020/0850-0010-0070-0020.html |    85-1-702. Purpose, MCA  |  |
| MTS_0850-0010-0070-0030 | 200 | 11791 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0070/section_0030/0850-0010-0070-0030.html |    85-1-703. Water storage policy, MCA  |  |
| MTS_0850-0010-0070-0040 | 200 | 13702 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0070/section_0040/0850-0010-0070-0040.html |    85-1-704. Prioritization of water storage projects -- governor's report, MCA  |  |
| MTS_0850-0010-0080-0010 | 200 | 10224 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0010/0850-0010-0080-0010.html |    85-1-801. Statement of policy, MCA  |  |
| MTS_0850-0010-0080-0020 | 200 | 10504 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0020/0850-0010-0080-0020.html |    85-1-802. Leases authorized, MCA  |  |
| MTS_0850-0010-0080-0030 | 200 | 11563 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0030/0850-0010-0080-0030.html |    85-1-803. Rulemaking, MCA  |  |
| MTS_0850-0010-0080-0040 | 200 | 10638 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0040/0850-0010-0080-0040.html |    85-1-804. Appraisal of project lands -- adjustment of lease fee, MCA  |  |
| MTS_0850-0010-0080-0050 | 200 | 10315 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0050/0850-0010-0080-0050.html |    85-1-805. Full market value required, MCA  |  |
| MTS_0850-0010-0080-0060 | 200 | 10338 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0060/0850-0010-0080-0060.html |    85-1-806. Withdrawal of lands from leasing, MCA  |  |
| MTS_0850-0010-0080-0070 | 200 | 10816 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0070/0850-0010-0080-0070.html |    85-1-807. Assignment of leases -- subleasing not allowed, MCA  |  |
| MTS_0850-0010-0080-0080 | 200 | 12396 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0080/0850-0010-0080-0080.html |    85-1-808. Changes in lease use not authorized -- cancellation, MCA  |  |
| MTS_0850-0010-0080-0090 | 200 | 11298 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0090/0850-0010-0080-0090.html |    85-1-809. Improvements authorized -- no compensation -- removal, MCA  |  |
| MTS_0850-0010-0080-0100 | 200 | 10372 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0100/0850-0010-0080-0100.html |    85-1-810. No pledge or mortgage of leasehold interest, MCA  |  |
| MTS_0850-0010-0080-0110 | 200 | 10516 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0110/0850-0010-0080-0110.html |    85-1-811. Project lands lease and sales account, MCA  |  |
| MTS_0850-0010-0080-0120 | 200 | 14934 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0120/0850-0010-0080-0120.html |    85-1-812. Sale of leased cabin or home sites -- rulemaking, MCA  |  |
| MTS_0850-0010-0080-0130 | 200 | 13932 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0080/section_0130/0850-0010-0080-0130.html |    85-1-813. Valuation of cabin or home sites and improvements, MCA  |  |
| MTS_0850-0010-0090-0010 | 200 | 10067 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0090/section_0010/0850-0010-0090-0010.html |    85-1-901. Short title, MCA  |  |
| MTS_0850-0010-0090-0020 | 200 | 10319 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0090/section_0020/0850-0010-0090-0020.html |    85-1-902. Purpose, MCA  |  |
| MTS_0850-0010-0090-0030 | 200 | 11275 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0090/section_0030/0850-0010-0090-0030.html |    85-1-903. Definitions, MCA  |  |
| MTS_0850-0010-0090-0040 | 200 | 15806 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0090/section_0040/0850-0010-0090-0040.html |    85-1-904. Duties of the commission, MCA  |  |
| MTS_0850-0010-0090-0050 | 200 | 11322 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0090/section_0050/0850-0010-0090-0050.html |    85-1-905. Commission authority, MCA  |  |
| MTS_0850-0010-0090-0060 | 200 | 10593 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0090/section_0060/0850-0010-0090-0060.html |    85-1-906. Special county government authority, MCA  |  |
| MTS_0850-0010-0090-0070 | 200 | 10462 | https://leg.mt.gov/bills/mca/title_0850/chapter_0010/part_0090/section_0070/0850-0010-0090-0070.html |    85-1-907. Cooperation with other agencies and organizations, MCA  |  |
| MTS_0850-0020-0010-0010 | 200 | 14581 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0010/0850-0020-0010-0010.html |    85-2-101. Declaration of policy and purpose, MCA  |  |
| MTS_0850-0020-0010-0020 | 200 | 25627 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0020/0850-0020-0010-0020.html |    85-2-102. Definitions, MCA  |  |
| MTS_0850-0020-0010-0030 | 200 | 11709 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0030/0850-0020-0010-0030.html |    85-2-103. Measurement of water, MCA  |  |
| MTS_0850-0020-0010-0040 | 200 | 10137 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0040/0850-0020-0010-0040.html |    85-2-104. Repealed, MCA  |  |
| MTS_0850-0020-0010-0050 | 200 | 13398 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0050/0850-0020-0010-0050.html |    85-2-105. Water policy interim committee duties, MCA  |  |
| MTS_0850-0020-0010-0060 | 200 | 9950 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0060/0850-0020-0010-0060.html |    85-2-106. through 85-2-110 reserved, MCA  |  |
| MTS_0850-0020-0010-0110 | 200 | 11247 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0110/0850-0020-0010-0110.html |    85-2-111. Department powers, MCA  |  |
| MTS_0850-0020-0010-0120 | 200 | 12313 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0120/0850-0020-0010-0120.html |    85-2-112. Department duties, MCA  |  |
| MTS_0850-0020-0010-0130 | 200 | 14271 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0130/0850-0020-0010-0130.html |    85-2-113. Department powers and duties, MCA  |  |
| MTS_0850-0020-0010-0140 | 200 | 14272 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0140/0850-0020-0010-0140.html |    85-2-114. Judicial enforcement, MCA  |  |
| MTS_0850-0020-0010-0150 | 200 | 10684 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0150/0850-0020-0010-0150.html |    85-2-115. Entry on land, MCA  |  |
| MTS_0850-0020-0010-0160 | 200 | 10865 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0160/0850-0020-0010-0160.html |    85-2-116. Legal assistance, MCA  |  |
| MTS_0850-0020-0010-0170 | 200 | 10855 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0170/0850-0020-0010-0170.html |    85-2-117. Water right records for filing with local clerk and recorder, MCA  |  |
| MTS_0850-0020-0010-0180 | 200 | 9982 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0180/0850-0020-0010-0180.html |    85-2-118. through 85-2-120 reserved, MCA  |  |
| MTS_0850-0020-0010-0210 | 200 | 10505 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0210/0850-0020-0010-0210.html |    85-2-121. Administrative proceedings, MCA  |  |
| MTS_0850-0020-0010-0220 | 200 | 12101 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0220/0850-0020-0010-0220.html |    85-2-122. Penalties, MCA  |  |
| MTS_0850-0020-0010-0230 | 200 | 11269 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0230/0850-0020-0010-0230.html |    85-2-123. Deposit of fees and penalties, MCA  |  |
| MTS_0850-0020-0010-0240 | 200 | 12427 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0240/0850-0020-0010-0240.html |    85-2-124. Costs and fees for environmental impact statements, MCA  |  |
| MTS_0850-0020-0010-0250 | 200 | 11148 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0250/0850-0020-0010-0250.html |    85-2-125. Recovery of costs and attorney fees by prevailing party, MCA  |  |
| MTS_0850-0020-0010-0260 | 200 | 9993 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0260/0850-0020-0010-0260.html |    85-2-126. through 85-2-130 reserved, MCA  |  |
| MTS_0850-0020-0010-0310 | 200 | 12147 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0310/0850-0020-0010-0310.html |    85-2-131. Application for change of watercourse name, MCA  |  |
| MTS_0850-0020-0010-0320 | 200 | 11264 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0320/0850-0020-0010-0320.html |    85-2-132. Change of watercourse name -- public notice, MCA  |  |
| MTS_0850-0020-0010-0330 | 200 | 10907 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0330/0850-0020-0010-0330.html |    85-2-133. Change of watercourse name -- hearing, MCA  |  |
| MTS_0850-0020-0010-0340 | 200 | 10953 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0340/0850-0020-0010-0340.html |    85-2-134. Change of watercourse name -- judgment to be filed with county cler |  |
| MTS_0850-0020-0010-0350 | 200 | 9985 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0350/0850-0020-0010-0350.html |    85-2-135. through 85-2-140 reserved, MCA  |  |
| MTS_0850-0020-0010-0410 | 200 | 16317 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0410/0850-0020-0010-0410.html |    85-2-141. Water leasing program, MCA  |  |
| MTS_0850-0020-0010-0420 | 200 | 10007 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0420/0850-0020-0010-0420.html |    85-2-142. through 85-2-144 reserved, MCA  |  |
| MTS_0850-0020-0010-0450 | 200 | 13236 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0450/0850-0020-0010-0450.html |    85-2-145. Removal of natural obstruction to exercise water right -- consent o |  |
| MTS_0850-0020-0010-0460 | 200 | 10037 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0460/0850-0020-0010-0460.html |    85-2-146. through 85-2-149 reserved, MCA  |  |
| MTS_0850-0020-0010-0500 | 200 | 12287 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0500/0850-0020-0010-0500.html |    85-2-150. Chronically dewatered watercourse -- identification, MCA  |  |
| MTS_0850-0020-0010-0510 | 200 | 9957 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0510/0850-0020-0010-0510.html |    85-2-151. through 85-2-153 reserved, MCA  |  |
| MTS_0850-0020-0010-0540 | 200 | 10124 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0540/0850-0020-0010-0540.html |    85-2-154. Terminated, MCA  |  |
| MTS_0850-0020-0010-0550 | 200 | 10120 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0550/0850-0020-0010-0550.html |    85-2-155. Terminated, MCA  |  |
| MTS_0850-0020-0010-0560 | 200 | 10984 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0560/0850-0020-0010-0560.html |    85-2-156. Policy considerations, MCA  |  |
| MTS_0850-0020-0010-0570 | 200 | 11283 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0010/section_0570/0850-0020-0010-0570.html |    85-2-157. Intent, MCA  |  |
| MTS_0850-0020-0020-0010 | 200 | 9944 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0010/0850-0020-0020-0010.html |    85-2-201. Repealed, MCA  |  |
| MTS_0850-0020-0020-0020 | 200 | 10147 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0020/0850-0020-0020-0020.html |    85-2-202. Repealed, MCA  |  |
| MTS_0850-0020-0020-0030 | 200 | 10209 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0030/0850-0020-0020-0030.html |    85-2-203. Repealed, MCA  |  |
| MTS_0850-0020-0020-0040 | 200 | 10178 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0040/0850-0020-0020-0040.html |    85-2-204. Repealed, MCA  |  |
| MTS_0850-0020-0020-0050 | 200 | 10179 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0050/0850-0020-0020-0050.html |    85-2-205. Repealed, MCA  |  |
| MTS_0850-0020-0020-0060 | 200 | 10210 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0060/0850-0020-0020-0060.html |    85-2-206. Repealed, MCA  |  |
| MTS_0850-0020-0020-0070 | 200 | 10179 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0070/0850-0020-0020-0070.html |    85-2-207. Repealed, MCA  |  |
| MTS_0850-0020-0020-0080 | 200 | 10179 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0080/0850-0020-0020-0080.html |    85-2-208. Repealed, MCA  |  |
| MTS_0850-0020-0020-0090 | 200 | 10148 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0090/0850-0020-0020-0090.html |    85-2-209. Repealed, MCA  |  |
| MTS_0850-0020-0020-0100 | 200 | 10148 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0100/0850-0020-0020-0100.html |    85-2-210. Repealed, MCA  |  |
| MTS_0850-0020-0020-0110 | 200 | 10172 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0110/0850-0020-0020-0110.html |    85-2-211. Repealed, MCA  |  |
| MTS_0850-0020-0020-0120 | 200 | 12695 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0120/0850-0020-0020-0120.html |    85-2-212. Order by supreme court, MCA  |  |
| MTS_0850-0020-0020-0130 | 200 | 12231 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0130/0850-0020-0020-0130.html |    85-2-213. Notice of order, MCA  |  |
| MTS_0850-0020-0020-0140 | 200 | 11070 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0140/0850-0020-0020-0140.html |    85-2-214. Commencement of action, MCA  |  |
| MTS_0850-0020-0020-0150 | 200 | 10664 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0150/0850-0020-0020-0150.html |    85-2-215. Consolidation of matters, MCA  |  |
| MTS_0850-0020-0020-0160 | 200 | 10666 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0160/0850-0020-0020-0160.html |    85-2-216. Venue for water rights determinations, MCA  |  |
| MTS_0850-0020-0020-0170 | 200 | 11760 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0170/0850-0020-0020-0170.html |    85-2-217. Suspension of adjudication, MCA  |  |
| MTS_0850-0020-0020-0180 | 200 | 12335 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0180/0850-0020-0020-0180.html |    85-2-218. Process and criteria for designating priority basins or subbasins,  |  |
| MTS_0850-0020-0020-0190 | 200 | 10031 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0190/0850-0020-0020-0190.html |    85-2-219. and 85-2-220 reserved, MCA  |  |
| MTS_0850-0020-0020-0210 | 200 | 15932 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0210/0850-0020-0020-0210.html |    85-2-221. Filing of claim of existing water right -- filing late claim, MCA  |  |
| MTS_0850-0020-0020-0220 | 200 | 13857 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0220/0850-0020-0020-0220.html |    85-2-222. Definition -- filing process -- notice, MCA  |  |
| MTS_0850-0020-0020-0230 | 200 | 10817 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0230/0850-0020-0020-0230.html |    85-2-223. Public recreational uses, MCA  |  |
| MTS_0850-0020-0020-0240 | 200 | 13141 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0240/0850-0020-0020-0240.html |    85-2-224. Statement of claim, MCA  |  |
| MTS_0850-0020-0020-0250 | 200 | 13197 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0250/0850-0020-0020-0250.html |    85-2-225. Filing fee -- processing fee for remitted claims, MCA  |  |
| MTS_0850-0020-0020-0260 | 200 | 10622 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0260/0850-0020-0020-0260.html |    85-2-226. Abandonment by failure to file claim, MCA  |  |
| MTS_0850-0020-0020-0270 | 200 | 14160 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0270/0850-0020-0020-0270.html |    85-2-227. Claim to constitute prima facie evidence -- relevant evidence -- ab |  |
| MTS_0850-0020-0020-0280 | 200 | 12021 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0280/0850-0020-0020-0280.html |    85-2-228. Federal reserved water rights with priority date of July 1, 1973, o |  |
| MTS_0850-0020-0020-0290 | 200 | 10104 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0290/0850-0020-0020-0290.html |    85-2-229. and 85-2-230 reserved, MCA  |  |
| MTS_0850-0020-0020-0310 | 200 | 14759 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0310/0850-0020-0020-0310.html |    85-2-231. Temporary preliminary decree, preliminary decree, and supplemental  |  |
| MTS_0850-0020-0020-0320 | 200 | 15040 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0320/0850-0020-0020-0320.html |    85-2-232. Availability of temporary preliminary decree, preliminary decree, o |  |
| MTS_0850-0020-0020-0330 | 200 | 21281 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0330/0850-0020-0020-0330.html |    85-2-233. Hearing on decrees or petition -- procedure, MCA  |  |
| MTS_0850-0020-0020-0340 | 200 | 16657 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0340/0850-0020-0020-0340.html |    85-2-234. Final decree, MCA  |  |
| MTS_0850-0020-0020-0350 | 200 | 11885 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0350/0850-0020-0020-0350.html |    85-2-235. Appeals, MCA  |  |
| MTS_0850-0020-0020-0360 | 200 | 10777 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0360/0850-0020-0020-0360.html |    85-2-236. Certificate of water right, MCA  |  |
| MTS_0850-0020-0020-0370 | 200 | 22373 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0370/0850-0020-0020-0370.html |    85-2-237. Reopening and review of decrees, MCA  |  |
| MTS_0850-0020-0020-0380 | 200 | 9965 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0380/0850-0020-0020-0380.html |    85-2-238. through 85-2-240 reserved, MCA  |  |
| MTS_0850-0020-0020-0410 | 200 | 10175 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0410/0850-0020-0020-0410.html |    85-2-241. Repealed, MCA  |  |
| MTS_0850-0020-0020-0420 | 200 | 10187 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0420/0850-0020-0020-0420.html |    85-2-242. Repealed, MCA  |  |
| MTS_0850-0020-0020-0430 | 200 | 11844 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0430/0850-0020-0020-0430.html |    85-2-243. Department assistance to water judges, MCA  |  |
| MTS_0850-0020-0020-0440 | 200 | 9970 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0440/0850-0020-0020-0440.html |    85-2-244. through 85-2-246 reserved, MCA  |  |
| MTS_0850-0020-0020-0470 | 200 | 10813 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0470/0850-0020-0020-0470.html |    85-2-247. Purpose, MCA  |  |
| MTS_0850-0020-0020-0480 | 200 | 15643 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0480/0850-0020-0020-0480.html |    85-2-248. Resolution of issue remarks other than by objection, MCA  |  |
| MTS_0850-0020-0020-0490 | 200 | 10319 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0490/0850-0020-0020-0490.html |    85-2-249. Prioritization of workload, MCA  |  |
| MTS_0850-0020-0020-0500 | 200 | 10616 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0500/0850-0020-0020-0500.html |    85-2-250. Definition, MCA  |  |
| MTS_0850-0020-0020-0510 | 200 | 9955 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0510/0850-0020-0020-0510.html |    85-2-251. through 85-2-269 reserved, MCA  |  |
| MTS_0850-0020-0020-0700 | 200 | 12074 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0700/0850-0020-0020-0700.html |    85-2-270. Findings -- purpose, MCA  |  |
| MTS_0850-0020-0020-0710 | 200 | 12437 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0710/0850-0020-0020-0710.html |    85-2-271. Benchmarks -- action taken if not met -- claims examination priorit |  |
| MTS_0850-0020-0020-0720 | 200 | 10185 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0720/0850-0020-0020-0720.html |    85-2-272. Repealed, MCA  |  |
| MTS_0850-0020-0020-0730 | 200 | 10138 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0730/0850-0020-0020-0730.html |    85-2-273. Repealed, MCA  |  |
| MTS_0850-0020-0020-0740 | 200 | 9922 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0740/0850-0020-0020-0740.html |    85-2-274. and 85-2-275 reserved, MCA  |  |
| MTS_0850-0020-0020-0760 | 200 | 10151 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0760/0850-0020-0020-0760.html |    85-2-276. Repealed, MCA  |  |
| MTS_0850-0020-0020-0770 | 200 | 9922 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0770/0850-0020-0020-0770.html |    85-2-277. and 85-2-278 reserved, MCA  |  |
| MTS_0850-0020-0020-0790 | 200 | 10156 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0790/0850-0020-0020-0790.html |    85-2-279. Repealed, MCA  |  |
| MTS_0850-0020-0020-0800 | 200 | 12181 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0800/0850-0020-0020-0800.html |    85-2-280. Water adjudication account, MCA  |  |
| MTS_0850-0020-0020-0810 | 200 | 12378 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0810/0850-0020-0020-0810.html |    85-2-281. Reporting requirements, MCA  |  |
| MTS_0850-0020-0020-0820 | 200 | 13197 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0820/0850-0020-0020-0820.html |    85-2-282. Examination of claims in verified basins, MCA  |  |
| MTS_0850-0020-0020-0830 | 200 | 9958 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0020/section_0830/0850-0020-0020-0830.html |    85-2-283. Repealed, MCA  |  |
| MTS_0850-0020-0030-0010 | 200 | 13147 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0010/0850-0020-0030-0010.html |    85-2-301. Right to appropriate -- recognition and confirmation of permits iss |  |
| MTS_0850-0020-0030-0020 | 200 | 20632 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0020/0850-0020-0030-0020.html |    85-2-302. Application for permit or change in appropriation right, MCA  |  |
| MTS_0850-0020-0030-0030 | 200 | 10984 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0030/0850-0020-0030-0030.html |    85-2-303. Permit for conversion of nonproductive oil or gas well, MCA  |  |
| MTS_0850-0020-0030-0040 | 200 | 10953 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0040/0850-0020-0030-0040.html |    85-2-304. Appropriation by state board of land commissioners, MCA  |  |
| MTS_0850-0020-0030-0050 | 200 | 10484 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0050/0850-0020-0030-0050.html |    85-2-305. Appropriation permit for reservoir, MCA  |  |
| MTS_0850-0020-0030-0060 | 200 | 24239 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0060/0850-0020-0030-0060.html |    85-2-306. Exceptions to permit requirements, MCA  |  |
| MTS_0850-0020-0030-0070 | 200 | 24235 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0070/0850-0020-0030-0070.html |    85-2-307. Notice of receipt of application for permit or change in appropriat |  |
| MTS_0850-0020-0030-0080 | 200 | 18625 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0080/0850-0020-0030-0080.html |    85-2-308. Objections, MCA  |  |
| MTS_0850-0020-0030-0090 | 200 | 13199 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0090/0850-0020-0030-0090.html |    85-2-309. Hearings on objections -- jurisdiction, MCA  |  |
| MTS_0850-0020-0030-0100 | 200 | 28985 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0100/0850-0020-0030-0100.html |    85-2-310. Action on application for permit or change in appropriation right,  |  |
| MTS_0850-0020-0030-0110 | 200 | 23539 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0110/0850-0020-0030-0110.html |    85-2-311. Criteria for issuance of permit, MCA  |  |
| MTS_0850-0020-0030-0120 | 200 | 16019 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0120/0850-0020-0030-0120.html |    85-2-312. Terms of permit, MCA  |  |
| MTS_0850-0020-0030-0130 | 200 | 16086 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0130/0850-0020-0030-0130.html |    85-2-313. Provisional permit, MCA  |  |
| MTS_0850-0020-0030-0140 | 200 | 13735 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0140/0850-0020-0030-0140.html |    85-2-314. Revocation or modification of permit or change in appropriation rig |  |
| MTS_0850-0020-0030-0150 | 200 | 12983 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0150/0850-0020-0030-0150.html |    85-2-315. Certificate of water right, MCA  |  |
| MTS_0850-0020-0030-0160 | 200 | 26527 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0160/0850-0020-0030-0160.html |    85-2-316. State reservation of waters, MCA  |  |
| MTS_0850-0020-0030-0170 | 200 | 11976 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0170/0850-0020-0030-0170.html |    85-2-317. Limitation on appropriation of ground water, MCA  |  |
| MTS_0850-0020-0030-0180 | 200 | 10876 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0180/0850-0020-0030-0180.html |    85-2-318. Water right appropriation account, MCA  |  |
| MTS_0850-0020-0030-0190 | 200 | 14797 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0190/0850-0020-0030-0190.html |    85-2-319. Permit action in highly appropriated basins or subbasins, MCA  |  |
| MTS_0850-0020-0030-0200 | 200 | 16319 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0200/0850-0020-0030-0200.html |    85-2-320. Change in appropriation right authorization for instream flow -- Un |  |
| MTS_0850-0020-0030-0210 | 200 | 12779 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0210/0850-0020-0030-0210.html |    85-2-321. Milk River basin -- suspension of action on permits -- proposal --  |  |
| MTS_0850-0020-0030-0220 | 200 | 13204 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0220/0850-0020-0030-0220.html |    85-2-322. Hearing -- order, MCA  |  |
| MTS_0850-0020-0030-0230 | 200 | 11175 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0230/0850-0020-0030-0230.html |    85-2-323. Request to modify suspension -- order, MCA  |  |
| MTS_0850-0020-0030-0240 | 200 | 10060 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0240/0850-0020-0030-0240.html |    85-2-324. through 85-2-326 reserved, MCA  |  |
| MTS_0850-0020-0030-0270 | 200 | 10241 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0270/0850-0020-0030-0270.html |    85-2-327. Terminated, MCA  |  |
| MTS_0850-0020-0030-0280 | 200 | 10227 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0280/0850-0020-0030-0280.html |    85-2-328. Terminated, MCA  |  |
| MTS_0850-0020-0030-0290 | 200 | 11054 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0290/0850-0020-0030-0290.html |    85-2-329. Definitions, MCA  |  |
| MTS_0850-0020-0030-0300 | 200 | 13496 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0300/0850-0020-0030-0300.html |    85-2-330. Basin closure -- exceptions, MCA  |  |
| MTS_0850-0020-0030-0310 | 200 | 14846 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0310/0850-0020-0030-0310.html |    85-2-331. Reservations within Missouri River basin and Little Missouri River  |  |
| MTS_0850-0020-0030-0320 | 200 | 10096 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0320/0850-0020-0030-0320.html |    85-2-332. through 85-2-334 reserved, MCA  |  |
| MTS_0850-0020-0030-0350 | 200 | 11200 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0350/0850-0020-0030-0350.html |    85-2-335. Definitions, MCA  |  |
| MTS_0850-0020-0030-0360 | 200 | 13558 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0360/0850-0020-0030-0360.html |    85-2-336. Basin closure -- exception, MCA  |  |
| MTS_0850-0020-0030-0370 | 200 | 10359 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0370/0850-0020-0030-0370.html |    85-2-337. Repealed, MCA  |  |
| MTS_0850-0020-0030-0380 | 200 | 15905 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0380/0850-0020-0030-0380.html |    85-2-338. Upper Clark Fork River basin steering committee -- membership and d |  |
| MTS_0850-0020-0030-0390 | 200 | 10322 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0390/0850-0020-0030-0390.html |    85-2-339. Terminated, MCA  |  |
| MTS_0850-0020-0030-0400 | 200 | 11510 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0400/0850-0020-0030-0400.html |    85-2-340. Definitions, MCA  |  |
| MTS_0850-0020-0030-0410 | 200 | 13783 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0410/0850-0020-0030-0410.html |    85-2-341. Basin closure -- exceptions, MCA  |  |
| MTS_0850-0020-0030-0420 | 200 | 11049 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0420/0850-0020-0030-0420.html |    85-2-342. Definitions, MCA  |  |
| MTS_0850-0020-0030-0430 | 200 | 14227 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0430/0850-0020-0030-0430.html |    85-2-343. Basin closure -- exceptions, MCA  |  |
| MTS_0850-0020-0030-0440 | 200 | 15893 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0440/0850-0020-0030-0440.html |    85-2-344. Bitterroot River subbasin temporary closure -- definitions -- excep |  |
| MTS_0850-0020-0030-0450 | 200 | 10093 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0450/0850-0020-0030-0450.html |    85-2-345. through 85-2-349 reserved, MCA  |  |
| MTS_0850-0020-0030-0500 | 200 | 10318 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0500/0850-0020-0030-0500.html |    85-2-350. Repealed, MCA  |  |
| MTS_0850-0020-0030-0510 | 200 | 10893 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0510/0850-0020-0030-0510.html |    85-2-351. Notice to permitholders -- Clark Fork River basin, MCA  |  |
| MTS_0850-0020-0030-0520 | 200 | 10073 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0520/0850-0020-0030-0520.html |    85-2-352. through 85-2-354 reserved, MCA  |  |
| MTS_0850-0020-0030-0550 | 200 | 11059 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0550/0850-0020-0030-0550.html |    85-2-355. Definitions, MCA  |  |
| MTS_0850-0020-0030-0560 | 200 | 10073 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0560/0850-0020-0030-0560.html |    85-2-356. through 85-2-359 reserved, MCA  |  |
| MTS_0850-0020-0030-0600 | 200 | 13411 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0600/0850-0020-0030-0600.html |    85-2-360. Ground water appropriation right in closed basins, MCA  |  |
| MTS_0850-0020-0030-0610 | 200 | 13674 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0610/0850-0020-0030-0610.html |    85-2-361. Hydrogeologic report -- minimum requirements, MCA  |  |
| MTS_0850-0020-0030-0620 | 200 | 13342 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0620/0850-0020-0030-0620.html |    85-2-362. Aquifer recharge or mitigation plans in closed basins -- minimum re |  |
| MTS_0850-0020-0030-0630 | 200 | 10362 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0630/0850-0020-0030-0630.html |    85-2-363. Repealed, MCA  |  |
| MTS_0850-0020-0030-0640 | 200 | 11449 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0640/0850-0020-0030-0640.html |    85-2-364. Department permit coordination -- requirements for aquifer recharge |  |
| MTS_0850-0020-0030-0650 | 200 | 10154 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0650/0850-0020-0030-0650.html |    85-2-365. through 85-2-367 reserved, MCA  |  |
| MTS_0850-0020-0030-0680 | 200 | 11168 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0680/0850-0020-0030-0680.html |    85-2-368. Aquifer storage and recovery projects in closed basins, MCA  |  |
| MTS_0850-0020-0030-0690 | 200 | 10700 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0690/0850-0020-0030-0690.html |    85-2-369. Permit not required for testing, MCA  |  |
| MTS_0850-0020-0030-0700 | 200 | 11385 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0700/0850-0020-0030-0700.html |    85-2-370. Rulemaking, MCA  |  |
| MTS_0850-0020-0030-0710 | 200 | 10076 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0710/0850-0020-0030-0710.html |    85-2-371. through 85-2-379 reserved, MCA  |  |
| MTS_0850-0020-0030-0800 | 200 | 13327 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0800/0850-0020-0030-0800.html |    85-2-380. Stream depletion zones -- establishment -- rulemaking, MCA  |  |
| MTS_0850-0020-0030-0810 | 200 | 14230 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0810/0850-0020-0030-0810.html |    85-2-381. Water right enforcement of ground water uses exempt from permitting |  |
| MTS_0850-0020-0030-0820 | 200 | 11774 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0030/section_0820/0850-0020-0030-0820.html |    85-2-382. Fox Hills-Hell Creek aquifer -- ground water study, MCA  |  |
| MTS_0850-0020-0040-0010 | 200 | 14355 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0010/0850-0020-0040-0010.html |    85-2-401. Priority -- recognition and confirmation of changes in appropriatio |  |
| MTS_0850-0020-0040-0020 | 200 | 31145 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0020/0850-0020-0040-0020.html |    85-2-402. Changes in appropriation rights -- definition, MCA  |  |
| MTS_0850-0020-0040-0030 | 200 | 11191 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0030/0850-0020-0040-0030.html |    85-2-403. Transfer of appropriation right, MCA  |  |
| MTS_0850-0020-0040-0040 | 200 | 14616 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0040/0850-0020-0040-0040.html |    85-2-404. Abandonment of appropriation right, MCA  |  |
| MTS_0850-0020-0040-0050 | 200 | 11768 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0050/0850-0020-0040-0050.html |    85-2-405. Procedure for declaring appropriation rights abandoned, MCA  |  |
| MTS_0850-0020-0040-0060 | 200 | 14251 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0060/0850-0020-0040-0060.html |    85-2-406. District court supervision of water distribution, MCA  |  |
| MTS_0850-0020-0040-0070 | 200 | 15403 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0070/0850-0020-0040-0070.html |    85-2-407. Temporary changes in appropriation right, MCA  |  |
| MTS_0850-0020-0040-0080 | 200 | 14615 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0080/0850-0020-0040-0080.html |    85-2-408. Temporary change authorization for instream flow -- additional requ |  |
| MTS_0850-0020-0040-0090 | 200 | 10198 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0090/0850-0020-0040-0090.html |    85-2-409. Repealed, MCA  |  |
| MTS_0850-0020-0040-0100 | 200 | 16303 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0100/0850-0020-0040-0100.html |    85-2-410. Short-term lease of appropriation right, MCA  |  |
| MTS_0850-0020-0040-0110 | 200 | 10881 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0110/0850-0020-0040-0110.html |    85-2-411. Water turned into natural channels, MCA  |  |
| MTS_0850-0020-0040-0120 | 200 | 11378 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0120/0850-0020-0040-0120.html |    85-2-412. Return of surplus water to stream, MCA  |  |
| MTS_0850-0020-0040-0130 | 200 | 11386 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0130/0850-0020-0040-0130.html |    85-2-413. Diversion of natural flow of waters -- when permitted, MCA  |  |
| MTS_0850-0020-0040-0140 | 200 | 11453 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0140/0850-0020-0040-0140.html |    85-2-414. Conduction of water, MCA  |  |
| MTS_0850-0020-0040-0150 | 200 | 11153 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0150/0850-0020-0040-0150.html |    85-2-415. Owners of water to sell surplus, MCA  |  |
| MTS_0850-0020-0040-0160 | 200 | 11268 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0160/0850-0020-0040-0160.html |    85-2-416. Duty of purchaser to dig ditches, MCA  |  |
| MTS_0850-0020-0040-0170 | 200 | 10919 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0170/0850-0020-0040-0170.html |    85-2-417. Enforcement of right to surplus, MCA  |  |
| MTS_0850-0020-0040-0180 | 200 | 11035 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0180/0850-0020-0040-0180.html |    85-2-418. Purchaser not to sell surplus water, MCA  |  |
| MTS_0850-0020-0040-0190 | 200 | 11736 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0190/0850-0020-0040-0190.html |    85-2-419. Salvaged water, MCA  |  |
| MTS_0850-0020-0040-0200 | 200 | 13140 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0200/0850-0020-0040-0200.html |    85-2-420. Change in appropriation right for aquifer recharge or mitigation -- |  |
| MTS_0850-0020-0040-0210 | 200 | 10644 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0210/0850-0020-0040-0210.html |    85-2-421. Purpose, MCA  |  |
| MTS_0850-0020-0040-0220 | 200 | 10188 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0220/0850-0020-0040-0220.html |    85-2-422. Repealed, MCA  |  |
| MTS_0850-0020-0040-0230 | 200 | 10308 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0230/0850-0020-0040-0230.html |    85-2-423. Water right ownership update form, MCA  |  |
| MTS_0850-0020-0040-0240 | 200 | 18999 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0240/0850-0020-0040-0240.html |    85-2-424. Filing, MCA  |  |
| MTS_0850-0020-0040-0250 | 200 | 10094 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0250/0850-0020-0040-0250.html |    85-2-425. Repealed, MCA  |  |
| MTS_0850-0020-0040-0260 | 200 | 10962 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0260/0850-0020-0040-0260.html |    85-2-426. Fee, MCA  |  |
| MTS_0850-0020-0040-0270 | 200 | 10177 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0270/0850-0020-0040-0270.html |    85-2-427. Terminated, MCA  |  |
| MTS_0850-0020-0040-0280 | 200 | 20738 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0280/0850-0020-0040-0280.html |    85-2-428. Temporary lease of appropriation right -- notice, MCA  |  |
| MTS_0850-0020-0040-0290 | 200 | 29706 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0290/0850-0020-0040-0290.html |    85-2-429. Changes in appropriation rights -- exceptions, MCA  |  |
| MTS_0850-0020-0040-0300 | 200 | 9839 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0300/0850-0020-0040-0300.html |    85-2-430. reserved, MCA  |  |
| MTS_0850-0020-0040-0310 | 200 | 11122 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0310/0850-0020-0040-0310.html |    85-2-431. Penalty, MCA  |  |
| MTS_0850-0020-0040-0320 | 200 | 10029 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0320/0850-0020-0040-0320.html |    85-2-432. through 85-2-435 reserved, MCA  |  |
| MTS_0850-0020-0040-0360 | 200 | 18909 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0360/0850-0020-0040-0360.html |    85-2-436. Instream flow to protect, maintain, or enhance streamflows to benef |  |
| MTS_0850-0020-0040-0370 | 200 | 10339 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0370/0850-0020-0040-0370.html |    85-2-437. Repealed, MCA  |  |
| MTS_0850-0020-0040-0380 | 200 | 10132 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0380/0850-0020-0040-0380.html |    85-2-438. Repealed, MCA  |  |
| MTS_0850-0020-0040-0390 | 200 | 10100 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0390/0850-0020-0040-0390.html |    85-2-439. Repealed, MCA  |  |
| MTS_0850-0020-0040-0400 | 200 | 10236 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0400/0850-0020-0040-0400.html |    85-2-440. Repealed, MCA  |  |
| MTS_0850-0020-0040-0410 | 200 | 12073 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0040/section_0410/0850-0020-0040-0410.html |    85-2-441. Temporary use of a water right on state trust land -- restrictions  |  |
| MTS_0850-0020-0050-0010 | 200 | 11656 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0010/0850-0020-0050-0010.html |    85-2-501. Definitions, MCA  |  |
| MTS_0850-0020-0050-0020 | 200 | 10495 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0020/0850-0020-0050-0020.html |    85-2-502. Administrative rules, MCA  |  |
| MTS_0850-0020-0050-0030 | 200 | 10486 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0030/0850-0020-0050-0030.html |    85-2-503. Controlled ground water subareas, MCA  |  |
| MTS_0850-0020-0050-0040 | 200 | 10660 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0040/0850-0020-0050-0040.html |    85-2-504. Standards for determining fresh water, MCA  |  |
| MTS_0850-0020-0050-0050 | 200 | 12941 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0050/0850-0020-0050-0050.html |    85-2-505. Waste and contamination of ground water prohibited, MCA  |  |
| MTS_0850-0020-0050-0060 | 200 | 22402 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0060/0850-0020-0050-0060.html |    85-2-506. Controlled ground water areas -- designation or modification, MCA  |  |
| MTS_0850-0020-0050-0070 | 200 | 10390 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0070/0850-0020-0050-0070.html |    85-2-507. Repealed, MCA  |  |
| MTS_0850-0020-0050-0080 | 200 | 11299 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0080/0850-0020-0050-0080.html |    85-2-508. Controlled ground water areas -- permits to appropriate, MCA  |  |
| MTS_0850-0020-0050-0090 | 200 | 10285 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0090/0850-0020-0050-0090.html |    85-2-509. Repealed, MCA  |  |
| MTS_0850-0020-0050-0100 | 200 | 11355 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0100/0850-0020-0050-0100.html |    85-2-510. Production of water from oil and gas wells -- hearings -- jurisdict |  |
| MTS_0850-0020-0050-0110 | 200 | 10268 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0110/0850-0020-0050-0110.html |    85-2-511. Repealed, MCA  |  |
| MTS_0850-0020-0050-0120 | 200 | 10813 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0120/0850-0020-0050-0120.html |    85-2-512. Investigations, MCA  |  |
| MTS_0850-0020-0050-0130 | 200 | 10149 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0130/0850-0020-0050-0130.html |    85-2-513. Repealed, MCA  |  |
| MTS_0850-0020-0050-0140 | 200 | 10457 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0140/0850-0020-0050-0140.html |    85-2-514. Inspection of wells, MCA  |  |
| MTS_0850-0020-0050-0150 | 200 | 10333 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0150/0850-0020-0050-0150.html |    85-2-515. Information available to public, MCA  |  |
| MTS_0850-0020-0050-0160 | 200 | 11223 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0160/0850-0020-0050-0160.html |    85-2-516. Well logs, MCA  |  |
| MTS_0850-0020-0050-0170 | 200 | 10402 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0170/0850-0020-0050-0170.html |    85-2-517. Reports by water well drillers, MCA  |  |
| MTS_0850-0020-0050-0180 | 200 | 10154 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0180/0850-0020-0050-0180.html |    85-2-518. Repealed, MCA  |  |
| MTS_0850-0020-0050-0190 | 200 | 10150 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0190/0850-0020-0050-0190.html |    85-2-519. Repealed, MCA  |  |
| MTS_0850-0020-0050-0200 | 200 | 10177 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0200/0850-0020-0050-0200.html |    85-2-520. Repealed, MCA  |  |
| MTS_0850-0020-0050-0210 | 200 | 9907 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0210/0850-0020-0050-0210.html |    85-2-521. Renumbered 82-11-175, MCA  |  |
| MTS_0850-0020-0050-0220 | 200 | 10634 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0220/0850-0020-0050-0220.html |    85-2-522. Aquifer tests, MCA  |  |
| MTS_0850-0020-0050-0230 | 200 | 10399 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0230/0850-0020-0050-0230.html |    85-2-523. Rulemaking, MCA  |  |
| MTS_0850-0020-0050-0240 | 200 | 11873 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0240/0850-0020-0050-0240.html |    85-2-524. Criteria for petition applications, MCA  |  |
| MTS_0850-0020-0050-0250 | 200 | 11878 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0250/0850-0020-0050-0250.html |    85-2-525. Ground water investigation program -- advisory committee, MCA  |  |
| MTS_0850-0020-0050-0260 | 200 | 10137 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0260/0850-0020-0050-0260.html |    85-2-526. Terminated, MCA  |  |
| MTS_0850-0020-0050-0270 | 200 | 9889 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0050/section_0270/0850-0020-0050-0270.html |    85-2-527. Terminated, MCA  |  |
| MTS_0850-0020-0060-0010 | 200 | 11337 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0060/section_0010/0850-0020-0060-0010.html |    85-2-601. Statement of legislative findings and policy, MCA  |  |
| MTS_0850-0020-0060-0020 | 200 | 11654 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0060/section_0020/0850-0020-0060-0020.html |    85-2-602. Definitions, MCA  |  |
| MTS_0850-0020-0060-0030 | 200 | 11739 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0060/section_0030/0850-0020-0060-0030.html |    85-2-603. Suspension of action, MCA  |  |
| MTS_0850-0020-0060-0040 | 200 | 10903 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0060/section_0040/0850-0020-0060-0040.html |    85-2-604. When department may suspend action, MCA  |  |
| MTS_0850-0020-0060-0050 | 200 | 11410 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0060/section_0050/0850-0020-0060-0050.html |    85-2-605. Reservations, MCA  |  |
| MTS_0850-0020-0060-0060 | 200 | 10352 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0060/section_0060/0850-0020-0060-0060.html |    85-2-606. Application of part, MCA  |  |
| MTS_0850-0020-0060-0070 | 200 | 10445 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0060/section_0070/0850-0020-0060-0070.html |    85-2-607. Utility facilities, MCA  |  |
| MTS_0850-0020-0060-0080 | 200 | 10306 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0060/section_0080/0850-0020-0060-0080.html |    85-2-608. Certain changes of use allowed, MCA  |  |
| MTS_0850-0020-0070-0010 | 200 | 11550 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0070/section_0010/0850-0020-0070-0010.html |    85-2-701. Legislative intent, MCA  |  |
| MTS_0850-0020-0070-0020 | 200 | 12970 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0070/section_0020/0850-0020-0070-0020.html |    85-2-702. Negotiation with Indian tribes, MCA  |  |
| MTS_0850-0020-0070-0030 | 200 | 10801 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0070/section_0030/0850-0020-0070-0030.html |    85-2-703. Negotiation with federal government, MCA  |  |
| MTS_0850-0020-0070-0040 | 200 | 11146 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0070/section_0040/0850-0020-0070-0040.html |    85-2-704. Termination of negotiations, MCA  |  |
| MTS_0850-0020-0070-0050 | 200 | 11089 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0070/section_0050/0850-0020-0070-0050.html |    85-2-705. Status reports to chief water judge, MCA  |  |
| MTS_0850-0020-0070-0060 | 200 | 10126 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0070/section_0060/0850-0020-0070-0060.html |    85-2-706. Renumbered 85-20-401, MCA  |  |
| MTS_0850-0020-0070-0070 | 200 | 10157 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0070/section_0070/0850-0020-0070-0070.html |    85-2-707. Renumbered 85-20-402, MCA  |  |
| MTS_0850-0020-0070-0080 | 200 | 15595 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0070/section_0080/0850-0020-0070-0080.html |    85-2-708. Water administration interim agreements within Indian reservations, |  |
| MTS_0850-0020-0080-0010 | 200 | 10399 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0080/section_0010/0850-0020-0080-0010.html |    85-2-801. Definitions, MCA  |  |
| MTS_0850-0020-0080-0020 | 200 | 10498 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0080/section_0020/0850-0020-0080-0020.html |    85-2-802. Authority to approve diversions, MCA  |  |
| MTS_0850-0020-0080-0030 | 200 | 10922 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0080/section_0030/0850-0020-0080-0030.html |    85-2-803. Legislative review, MCA  |  |
| MTS_0850-0020-0080-0040 | 200 | 16050 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0080/section_0040/0850-0020-0080-0040.html |    85-2-804. Application -- notice -- objections -- hearing, MCA  |  |
| MTS_0850-0020-0080-0050 | 200 | 12597 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0080/section_0050/0850-0020-0080-0050.html |    85-2-805. Criteria for approval -- terms, MCA  |  |
| MTS_0850-0020-0080-0060 | 200 | 11644 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0080/section_0060/0850-0020-0080-0060.html |    85-2-806. Combined proceeding, MCA  |  |
| MTS_0850-0020-0080-0070 | 200 | 10794 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0080/section_0070/0850-0020-0080-0070.html |    85-2-807. Department authorized to appear in administrative and legal proceed |  |
| MTS_0850-0020-0090-0010 | 200 | 9936 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0090/section_0010/0850-0020-0090-0010.html |    85-2-901. Short title, MCA  |  |
| MTS_0850-0020-0090-0020 | 200 | 12315 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0090/section_0020/0850-0020-0090-0020.html |    85-2-902. Findings and purpose, MCA  |  |
| MTS_0850-0020-0090-0030 | 200 | 11340 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0090/section_0030/0850-0020-0090-0030.html |    85-2-903. Definitions, MCA  |  |
| MTS_0850-0020-0090-0040 | 200 | 9838 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0090/section_0040/0850-0020-0090-0040.html |    85-2-904. reserved, MCA  |  |
| MTS_0850-0020-0090-0050 | 200 | 12446 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0090/section_0050/0850-0020-0090-0050.html |    85-2-905. Ground water assessment account, MCA  |  |
| MTS_0850-0020-0090-0060 | 200 | 13486 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0090/section_0060/0850-0020-0090-0060.html |    85-2-906. Ground water characterization program -- ground water monitoring pr |  |
| MTS_0850-0020-0090-0070 | 200 | 10787 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0090/section_0070/0850-0020-0090-0070.html |    85-2-907. Ground water information collection by local governments, MCA  |  |
| MTS_0850-0020-0100-0010 | 200 | 14490 | https://leg.mt.gov/bills/mca/title_0850/chapter_0020/part_0100/section_0010/0850-0020-0100-0010.html |    85-2-1001. Surface water assessment and monitoring program -- steering commit |  |
| MTS_0850-0030-0010-0010 | 200 | 11514 | https://leg.mt.gov/bills/mca/title_0850/chapter_0030/part_0010/section_0010/0850-0030-0010-0010.html |    85-3-101. Definitions, MCA  |  |
| MTS_0850-0030-0010-0020 | 200 | 10641 | https://leg.mt.gov/bills/mca/title_0850/chapter_0030/part_0010/section_0020/0850-0030-0010-0020.html |    85-3-102. Standards for research in weather modification control, MCA  |  |
| MTS_0850-0030-0010-0030 | 200 | 13144 | https://leg.mt.gov/bills/mca/title_0850/chapter_0030/part_0010/section_0030/0850-0030-0010-0030.html |    85-3-103. Department powers, MCA  |  |
| MTS_0850-0030-0010-0040 | 200 | 10690 | https://leg.mt.gov/bills/mca/title_0850/chapter_0030/part_0010/section_0040/0850-0030-0010-0040.html |    85-3-104. Nonliability of state and agents for acts of private persons, MCA  |  |
| MTS_0850-0030-0010-0050 | 200 | 10304 | https://leg.mt.gov/bills/mca/title_0850/chapter_0030/part_0010/section_0050/0850-0030-0010-0050.html |    85-3-105. Violation as misdemeanor and continuing violations, MCA  |  |
| MTS_0850-0030-0020-0010 | 200 | 10392 | https://leg.mt.gov/bills/mca/title_0850/chapter_0030/part_0020/section_0010/0850-0030-0020-0010.html |    85-3-201. License and permit required for weather modification and control, M |  |
