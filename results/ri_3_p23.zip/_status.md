| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| RIS_27_27-20_27-20-19 | 200 | 4378 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-19.htm |  |  |
| RIS_27_27-20_27-20-20 | 200 | 6883 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-20.htm |  |  |
| RIS_27_27-20_27-20-21 | 200 | 4301 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-21.htm |  |  |
| RIS_27_27-20_27-20-22 | 200 | 4674 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-22.htm |  |  |
| RIS_27_27-20_27-20-23 | 200 | 4227 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-23.htm |  |  |
| RIS_27_27-20_27-20-23.1 | 200 | 6986 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-23.1.htm |  |  |
| RIS_27_27-20_27-20-23.2 | 200 | 8131 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-23.2.htm |  |  |
| RIS_27_27-20_27-20-23.3 | 200 | 7671 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-23.3.htm |  |  |
| RIS_27_27-20_27-20-24 | 200 | 5845 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-24.htm |  |  |
| RIS_27_27-20_27-20-25 | 200 | 4126 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-25.htm |  |  |
| RIS_27_27-20_27-20-25.1 | 200 | 4327 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-25.1.htm |  |  |
| RIS_27_27-20_27-20-25.2 | 200 | 5435 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-25.2.htm |  |  |
| RIS_27_27-20_27-20-26 | 200 | 3975 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-26.htm |  |  |
| RIS_27_27-20_27-20-27 | 200 | 4197 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-27.htm |  |  |
| RIS_27_27-20_27-20-27.1 | 200 | 4492 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-27.1.htm |  |  |
| RIS_27_27-20_27-20-27.2 | 200 | 6695 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-27.2.htm |  |  |
| RIS_27_27-20_27-20-27.3 | 200 | 4427 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-27.3.htm |  |  |
| RIS_27_27-20_27-20-28 | 200 | 3623 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-28.htm |  | render-thin 116 |
| RIS_27_27-20_27-20-29 | 200 | 8037 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-29.htm |  |  |
| RIS_27_27-20_27-20-29.1 | 200 | 5972 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-29.1.htm |  |  |
| RIS_27_27-20_27-20-30 | 200 | 7086 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-30.htm |  |  |
| RIS_27_27-20_27-20-31 | 200 | 4345 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-31.htm |  |  |
| RIS_27_27-20_27-20-31.1 | 200 | 4599 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-31.1.htm |  |  |
| RIS_27_27-20_27-20-32 | 200 | 4722 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-32.htm |  |  |
| RIS_27_27-20_27-20-33 | 200 | 4776 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-33.htm |  |  |
| RIS_27_27-20_27-20-34 | 200 | 4654 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-34.htm |  |  |
| RIS_27_27-20_27-20-35 | 200 | 7167 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-35.htm |  |  |
| RIS_27_27-20_27-20-35.1 | 200 | 6627 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-35.1.htm |  |  |
| RIS_27_27-20_27-20-36 | 200 | 4802 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-36.htm |  |  |
| RIS_27_27-20_27-20-37 | 200 | 7373 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-37.htm |  |  |
| RIS_27_27-20_27-20-37.1 | 200 | 8985 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-37.1.htm |  |  |
| RIS_27_27-20_27-20-38 | 200 | 4723 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-38.htm |  |  |
| RIS_27_27-20_27-20-39 | 200 | 7615 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-39.htm |  |  |
| RIS_27_27-20_27-20-39.1 | 200 | 7353 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-39.1.htm |  |  |
| RIS_27_27-20_27-20-40 | 200 | 3623 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-40.htm |  | render-thin 116 |
| RIS_27_27-20_27-20-41 | 200 | 7577 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-41.htm |  |  |
| RIS_27_27-20_27-20-42 | 200 | 5549 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-42.htm |  |  |
| RIS_27_27-20_27-20-43 | 200 | 5881 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-43.htm |  |  |
| RIS_27_27-20_27-20-44 | 200 | 5158 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-44.htm |  |  |
| RIS_27_27-20_27-20-45 | 200 | 7903 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-45.htm |  |  |
| RIS_27_27-20_27-20-46 | 200 | 6095 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-46.htm |  |  |
| RIS_27_27-20_27-20-47 | 200 | 12675 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-47.htm |  |  |
| RIS_27_27-20_27-20-48 | 200 | 4828 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-48.htm |  |  |
| RIS_27_27-20_27-20-49 | 200 | 5347 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-49.htm |  |  |
| RIS_27_27-20_27-20-50 | 200 | 6851 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-50.htm |  |  |
| RIS_27_27-20_27-20-51 | 200 | 6813 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-51.htm |  |  |
| RIS_27_27-20_27-20-52 | 200 | 11405 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-52.htm |  |  |
| RIS_27_27-20_27-20-53 | 200 | 7356 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-53.htm |  |  |
| RIS_27_27-20_27-20-54 | 200 | 5075 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-54.htm |  |  |
| RIS_27_27-20_27-20-55 | 200 | 4993 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-55.htm |  |  |
| RIS_27_27-20_27-20-56 | 200 | 6213 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-56.htm |  |  |
| RIS_27_27-20_27-20-57 | 200 | 6638 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-57.htm |  |  |
| RIS_27_27-20_27-20-58 | 200 | 5636 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-58.htm |  |  |
| RIS_27_27-20_27-20-59 | 200 | 8817 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-59.htm |  |  |
| RIS_27_27-20_27-20-60 | 200 | 12920 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-60.htm |  |  |
| RIS_27_27-20_27-20-61 | 200 | 4645 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-61.htm |  |  |
| RIS_27_27-20_27-20-62 | 200 | 12400 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-62.htm |  |  |
| RIS_27_27-20_27-20-63 | 200 | 5002 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-63.htm |  |  |
| RIS_27_27-20_27-20-64 | 200 | 3625 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-64.htm |  | render-thin 118 |
| RIS_27_27-20_27-20-65 | 200 | 4719 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-65.htm |  |  |
| RIS_27_27-20_27-20-66 | 200 | 5338 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-66.htm |  |  |
| RIS_27_27-20_27-20-67 | 200 | 5372 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-67.htm |  |  |
| RIS_27_27-20_27-20-68 | 200 | 4168 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-68.htm |  |  |
| RIS_27_27-20_27-20-69 | 200 | 4993 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-69.htm |  |  |
| RIS_27_27-20_27-20-70 | 200 | 9215 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-70.htm |  |  |
| RIS_27_27-20_27-20-71 | 200 | 4642 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-71.htm |  |  |
| RIS_27_27-20_27-20-72 | 200 | 4234 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-72.htm |  |  |
| RIS_27_27-20_27-20-73 | 200 | 5242 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-73.htm |  |  |
| RIS_27_27-20_27-20-74 | 200 | 4962 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-74.htm |  |  |
| RIS_27_27-20_27-20-75 | 200 | 7615 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-75.htm |  |  |
| RIS_27_27-20_27-20-76 | 200 | 5629 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-76.htm |  |  |
| RIS_27_27-20_27-20-77 | 200 | 8576 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-77.htm |  |  |
| RIS_27_27-20_27-20-78 | 200 | 5628 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-78.htm |  |  |
| RIS_27_27-20_27-20-79 | 200 | 5878 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-79.htm |  |  |
| RIS_27_27-20_27-20-80 | 200 | 3984 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-80.htm |  |  |
| RIS_27_27-20_27-20-81 | 200 | 10827 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-81.htm |  |  |
| RIS_27_27-20_27-20-82 | 200 | 5271 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-82.htm |  |  |
| RIS_27_27-20_27-20-83 | 200 | 7866 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-83.htm |  |  |
| RIS_27_27-20_27-20-84 | 200 | 4274 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20/27-20-84.htm |  |  |
| RIS_27_27-20.1_27-20.1-1 | 200 | 5716 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-1.htm |  |  |
| RIS_27_27-20.1_27-20.1-2 | 200 | 7899 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-2.htm |  |  |
| RIS_27_27-20.1_27-20.1-3 | 200 | 5721 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-3.htm |  |  |
| RIS_27_27-20.1_27-20.1-4 | 200 | 5939 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-4.htm |  |  |
| RIS_27_27-20.1_27-20.1-5 | 200 | 4360 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-5.htm |  |  |
| RIS_27_27-20.1_27-20.1-6 | 200 | 4283 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-6.htm |  |  |
| RIS_27_27-20.1_27-20.1-7 | 200 | 5317 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-7.htm |  |  |
| RIS_27_27-20.1_27-20.1-8 | 200 | 4095 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-8.htm |  |  |
| RIS_27_27-20.1_27-20.1-9 | 200 | 4538 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-9.htm |  |  |
| RIS_27_27-20.1_27-20.1-10 | 200 | 4303 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-10.htm |  |  |
| RIS_27_27-20.1_27-20.1-11 | 200 | 5826 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-11.htm |  |  |
| RIS_27_27-20.1_27-20.1-12 | 200 | 4382 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-12.htm |  |  |
| RIS_27_27-20.1_27-20.1-12.1 | 200 | 4332 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-12.1.htm |  |  |
| RIS_27_27-20.1_27-20.1-13 | 200 | 3980 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-13.htm |  |  |
| RIS_27_27-20.1_27-20.1-14 | 200 | 4497 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-14.htm |  |  |
| RIS_27_27-20.1_27-20.1-15 | 200 | 7358 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-15.htm |  |  |
| RIS_27_27-20.1_27-20.1-15.1 | 200 | 8132 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-15.1.htm |  |  |
| RIS_27_27-20.1_27-20.1-16 | 200 | 4688 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-16.htm |  |  |
| RIS_27_27-20.1_27-20.1-17 | 200 | 5406 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-17.htm |  |  |
| RIS_27_27-20.1_27-20.1-18 | 200 | 5361 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-18.htm |  |  |
| RIS_27_27-20.1_27-20.1-19 | 200 | 5644 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-19.htm |  |  |
| RIS_27_27-20.1_27-20.1-20 | 200 | 4781 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-20.htm |  |  |
| RIS_27_27-20.1_27-20.1-21 | 200 | 5332 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-21.htm |  |  |
| RIS_27_27-20.1_27-20.1-22 | 200 | 4172 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.1/27-20.1-22.htm |  |  |
| RIS_27_27-20.2_27-20.2-1 | 200 | 5093 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-1.htm |  |  |
| RIS_27_27-20.2_27-20.2-2 | 200 | 5036 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-2.htm |  |  |
| RIS_27_27-20.2_27-20.2-3 | 200 | 4987 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-3.htm |  |  |
| RIS_27_27-20.2_27-20.2-4 | 200 | 5021 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-4.htm |  |  |
| RIS_27_27-20.2_27-20.2-5 | 200 | 4242 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-5.htm |  |  |
| RIS_27_27-20.2_27-20.2-6 | 200 | 4289 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-6.htm |  |  |
| RIS_27_27-20.2_27-20.2-7 | 200 | 5327 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-7.htm |  |  |
| RIS_27_27-20.2_27-20.2-8 | 200 | 4164 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-8.htm |  |  |
| RIS_27_27-20.2_27-20.2-9 | 200 | 4584 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-9.htm |  |  |
| RIS_27_27-20.2_27-20.2-10 | 200 | 4315 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-10.htm |  |  |
| RIS_27_27-20.2_27-20.2-11 | 200 | 5890 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-11.htm |  |  |
| RIS_27_27-20.2_27-20.2-12 | 200 | 4390 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-12.htm |  |  |
| RIS_27_27-20.2_27-20.2-12.1 | 200 | 4336 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-12.1.htm |  |  |
| RIS_27_27-20.2_27-20.2-13 | 200 | 3966 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-13.htm |  |  |
| RIS_27_27-20.2_27-20.2-14 | 200 | 5413 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.2/27-20.2-14.htm |  |  |
| RIS_27_27-20.3_27-20.3-1 | 200 | 5779 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-1.htm |  |  |
| RIS_27_27-20.3_27-20.3-2 | 200 | 5054 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-2.htm |  |  |
| RIS_27_27-20.3_27-20.3-3 | 200 | 5896 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-3.htm |  |  |
| RIS_27_27-20.3_27-20.3-4 | 200 | 5118 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-4.htm |  |  |
| RIS_27_27-20.3_27-20.3-5 | 200 | 4241 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-5.htm |  |  |
| RIS_27_27-20.3_27-20.3-6 | 200 | 4289 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-6.htm |  |  |
| RIS_27_27-20.3_27-20.3-7 | 200 | 5329 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-7.htm |  |  |
| RIS_27_27-20.3_27-20.3-8 | 200 | 4095 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-8.htm |  |  |
| RIS_27_27-20.3_27-20.3-9 | 200 | 5205 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-9.htm |  |  |
| RIS_27_27-20.3_27-20.3-10 | 200 | 4300 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-10.htm |  |  |
| RIS_27_27-20.3_27-20.3-11 | 200 | 5832 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-11.htm |  |  |
| RIS_27_27-20.3_27-20.3-12 | 200 | 4348 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-12.htm |  |  |
| RIS_27_27-20.3_27-20.3-13 | 200 | 3961 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.3/27-20.3-13.htm |  |  |
| RIS_27_27-20.4_27-20.4-1 | 200 | 6115 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.4/27-20.4-1.htm |  |  |
| RIS_27_27-20.4_27-20.4-2 | 200 | 4250 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.4/27-20.4-2.htm |  |  |
| RIS_27_27-20.4_27-20.4-3 | 200 | 6500 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.4/27-20.4-3.htm |  |  |
| RIS_27_27-20.4_27-20.4-4 | 200 | 6753 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.4/27-20.4-4.htm |  |  |
| RIS_27_27-20.4_27-20.4-5 | 200 | 6845 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.4/27-20.4-5.htm |  |  |
| RIS_27_27-20.4_27-20.4-6 | 200 | 4047 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.4/27-20.4-6.htm |  |  |
| RIS_27_27-20.4_27-20.4-7 | 200 | 3917 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.4/27-20.4-7.htm |  |  |
| RIS_27_27-20.4_27-20.4-8 | 200 | 4483 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.4/27-20.4-8.htm |  |  |
| RIS_27_27-20.4_27-20.4-9 | 200 | 4337 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.4/27-20.4-9.htm |  |  |
| RIS_27_27-20.5_27-20.5-1 | 200 | 4842 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.5/27-20.5-1.htm |  |  |
| RIS_27_27-20.6_27-20.6-1 | 200 | 4514 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.6/27-20.6-1.htm |  |  |
| RIS_27_27-20.6_27-20.6-2 | 200 | 4175 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.6/27-20.6-2.htm |  |  |
| RIS_27_27-20.6_27-20.6-3 | 200 | 4133 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.6/27-20.6-3.htm |  |  |
| RIS_27_27-20.6_27-20.6-4 | 200 | 4175 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.6/27-20.6-4.htm |  |  |
| RIS_27_27-20.6_27-20.6-5 | 200 | 4798 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.6/27-20.6-5.htm |  |  |
| RIS_27_27-20.6_27-20.6-6 | 200 | 4324 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.6/27-20.6-6.htm |  |  |
| RIS_27_27-20.7_27-20.7-1 | 200 | 3902 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-1.htm |  | render-thin 283 |
| RIS_27_27-20.7_27-20.7-2 | 200 | 10154 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-2.htm |  |  |
| RIS_27_27-20.7_27-20.7-3 | 200 | 5469 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-3.htm |  |  |
| RIS_27_27-20.7_27-20.7-4 | 200 | 4572 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-4.htm |  |  |
| RIS_27_27-20.7_27-20.7-5 | 200 | 9192 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-5.htm |  |  |
| RIS_27_27-20.7_27-20.7-6 | 200 | 4014 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-6.htm |  |  |
| RIS_27_27-20.7_27-20.7-7 | 200 | 5049 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-7.htm |  |  |
| RIS_27_27-20.7_27-20.7-8 | 200 | 6817 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-8.htm |  |  |
| RIS_27_27-20.7_27-20.7-9 | 200 | 4614 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-9.htm |  |  |
| RIS_27_27-20.7_27-20.7-10 | 200 | 4903 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-10.htm |  |  |
| RIS_27_27-20.7_27-20.7-11 | 200 | 4175 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-11.htm |  |  |
| RIS_27_27-20.7_27-20.7-12 | 200 | 10634 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-12.htm |  |  |
| RIS_27_27-20.7_27-20.7-13 | 200 | 4305 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-13.htm |  |  |
| RIS_27_27-20.7_27-20.7-14 | 200 | 4705 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-14.htm |  |  |
| RIS_27_27-20.7_27-20.7-15 | 200 | 8031 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-15.htm |  |  |
| RIS_27_27-20.7_27-20.7-16 | 200 | 4087 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.7/27-20.7-16.htm |  |  |
| RIS_27_27-20.8_27-20.8-1 | 200 | 4670 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.8/27-20.8-1.htm |  |  |
| RIS_27_27-20.8_27-20.8-2 | 200 | 4781 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.8/27-20.8-2.htm |  |  |
| RIS_27_27-20.8_27-20.8-3 | 200 | 5391 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.8/27-20.8-3.htm |  |  |
| RIS_27_27-20.8_27-20.8-4 | 200 | 4354 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.8/27-20.8-4.htm |  |  |
| RIS_27_27-20.9_27-20.9-1 | 200 | 5559 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.9/27-20.9-1.htm |  |  |
| RIS_27_27-20.9_27-20.9-2 | 200 | 4406 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.9/27-20.9-2.htm |  |  |
| RIS_27_27-20.9_27-20.9-3 | 200 | 4418 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.9/27-20.9-3.htm |  |  |
| RIS_27_27-20.10_27-20.10-1 | 200 | 8337 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.10/27-20.10-1.htm |  |  |
| RIS_27_27-20.10_27-20.10-2 | 200 | 5799 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.10/27-20.10-2.htm |  |  |
| RIS_27_27-20.10_27-20.10-3 | 200 | 5504 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.10/27-20.10-3.htm |  |  |
| RIS_27_27-20.10_27-20.10-4 | 200 | 9803 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.10/27-20.10-4.htm |  |  |
| RIS_27_27-20.10_27-20.10-5 | 200 | 5968 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.10/27-20.10-5.htm |  |  |
| RIS_27_27-20.10_27-20.10-6 | 200 | 5768 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.10/27-20.10-6.htm |  |  |
| RIS_27_27-20.10_27-20.10-7 | 200 | 3943 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.10/27-20.10-7.htm |  |  |
| RIS_27_27-20.11_27-20.11-1 | 200 | 4634 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.11/27-20.11-1.htm |  |  |
| RIS_27_27-20.11_27-20.11-2 | 200 | 5332 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.11/27-20.11-2.htm |  |  |
| RIS_27_27-20.11_27-20.11-3 | 200 | 5486 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.11/27-20.11-3.htm |  |  |
| RIS_27_27-20.11_27-20.11-4 | 200 | 5874 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.11/27-20.11-4.htm |  |  |
| RIS_27_27-20.11_27-20.11-5 | 200 | 4588 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.11/27-20.11-5.htm |  |  |
| RIS_27_27-20.11_27-20.11-6 | 200 | 4620 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.11/27-20.11-6.htm |  |  |
| RIS_27_27-20.11_27-20.11-7 | 200 | 4731 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.11/27-20.11-7.htm |  |  |
| RIS_27_27-20.11_27-20.11-8 | 200 | 4214 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-20.11/27-20.11-8.htm |  |  |
| RIS_27_27-21_27-21-1 | 200 | 3632 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-21/27-21-1.htm |  | render-thin 123 |
| RIS_27_27-22_27-22-1 | 200 | 3644 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-22/27-22-1.htm |  | render-thin 135 |
| RIS_27_27-23_27-23-1 | 200 | 3642 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-23/27-23-1.htm |  | render-thin 133 |
| RIS_27_27-24_27-24-1 | 200 | 3648 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-24/27-24-1.htm |  | render-thin 139 |
| RIS_27_27-25_27-25-1 | 200 | 4310 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-1.htm |  |  |
| RIS_27_27-25_27-25-2 | 200 | 4564 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-2.htm |  |  |
| RIS_27_27-25_27-25-3 | 200 | 6493 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-3.htm |  |  |
| RIS_27_27-25_27-25-4 | 200 | 5432 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-4.htm |  |  |
| RIS_27_27-25_27-25-5 | 200 | 4993 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-5.htm |  |  |
| RIS_27_27-25_27-25-6 | 200 | 4950 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-6.htm |  |  |
| RIS_27_27-25_27-25-7 | 200 | 5773 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-7.htm |  |  |
| RIS_27_27-25_27-25-8 | 200 | 7436 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-8.htm |  |  |
| RIS_27_27-25_27-25-9 | 200 | 4102 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-9.htm |  |  |
| RIS_27_27-25_27-25-10 | 200 | 11188 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-10.htm |  |  |
| RIS_27_27-25_27-25-11 | 200 | 6870 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-11.htm |  |  |
| RIS_27_27-25_27-25-12 | 200 | 4189 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-12.htm |  |  |
| RIS_27_27-25_27-25-13 | 200 | 5152 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-13.htm |  |  |
| RIS_27_27-25_27-25-14 | 200 | 7977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-14.htm |  |  |
| RIS_27_27-25_27-25-15 | 200 | 4773 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-15.htm |  |  |
| RIS_27_27-25_27-25-16 | 200 | 5110 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-16.htm |  |  |
| RIS_27_27-25_27-25-17 | 200 | 5566 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-17.htm |  |  |
| RIS_27_27-25_27-25-18 | 200 | 4310 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-18.htm |  |  |
| RIS_27_27-25_27-25-19 | 200 | 9611 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-19.htm |  |  |
| RIS_27_27-25_27-25-20 | 200 | 5000 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-20.htm |  |  |
| RIS_27_27-25_27-25-21 | 200 | 4329 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-21.htm |  |  |
| RIS_27_27-25_27-25-22 | 200 | 5733 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-22.htm |  |  |
| RIS_27_27-25_27-25-23 | 200 | 4043 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-23.htm |  |  |
| RIS_27_27-25_27-25-24 | 200 | 4086 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-24.htm |  |  |
| RIS_27_27-25_27-25-25 | 200 | 6398 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-25.htm |  |  |
| RIS_27_27-25_27-25-26 | 200 | 6656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-26.htm |  |  |
| RIS_27_27-25_27-25-27 | 200 | 4690 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-27.htm |  |  |
| RIS_27_27-25_27-25-28 | 200 | 4526 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-28.htm |  |  |
| RIS_27_27-25_27-25-29 | 200 | 5880 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-29.htm |  |  |
| RIS_27_27-25_27-25-30 | 200 | 8357 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-30.htm |  |  |
| RIS_27_27-25_27-25-31 | 200 | 5906 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-31.htm |  |  |
| RIS_27_27-25_27-25-32 | 200 | 4048 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-32.htm |  |  |
| RIS_27_27-25_27-25-33 | 200 | 5742 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-33.htm |  |  |
| RIS_27_27-25_27-25-34 | 200 | 4575 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-34.htm |  |  |
| RIS_27_27-25_27-25-35 | 200 | 5728 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-35.htm |  |  |
| RIS_27_27-25_27-25-36 | 200 | 4001 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-36.htm |  |  |
| RIS_27_27-25_27-25-37 | 200 | 3964 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-37.htm |  |  |
| RIS_27_27-25_27-25-38 | 200 | 9232 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-38.htm |  |  |
| RIS_27_27-25_27-25-39 | 200 | 4494 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-39.htm |  |  |
| RIS_27_27-25_27-25-40 | 200 | 4267 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-40.htm |  |  |
| RIS_27_27-25_27-25-41 | 200 | 5007 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-41.htm |  |  |
| RIS_27_27-25_27-25-42 | 200 | 4036 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-42.htm |  |  |
| RIS_27_27-25_27-25-43 | 200 | 3854 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-43.htm |  | render-thin 236 |
| RIS_27_27-25_27-25-44 | 200 | 5032 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-25/27-25-44.htm |  |  |
| RIS_27_27-26_27-26-1 | 200 | 3682 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-26/27-26-1.htm |  | render-thin 173 |
| RIS_27_27-27_27-27-1 | 200 | 3645 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-27/27-27-1.htm |  | render-thin 136 |
| RIS_27_27-28_27-28-1 | 200 | 3661 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-28/27-28-1.htm |  | render-thin 152 |
| RIS_27_27-29_27-29-1 | 200 | 4436 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-1.htm |  |  |
| RIS_27_27-29_27-29-2 | 200 | 8594 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-2.htm |  |  |
| RIS_27_27-29_27-29-3 | 200 | 4064 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-3.htm |  |  |
| RIS_27_27-29_27-29-4 | 200 | 39464 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-4.htm |  |  |
| RIS_27_27-29_27-29-4.1 | 200 | 4114 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-4.1.htm |  |  |
| RIS_27_27-29_27-29-4.2 | 200 | 3953 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-4.2.htm |  |  |
| RIS_27_27-29_27-29-4.3 | 200 | 4113 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-4.3.htm |  |  |
| RIS_27_27-29_27-29-4.4 | 200 | 9000 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-4.4.htm |  |  |
| RIS_27_27-29_27-29-4.5 | 200 | 4157 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-4.5.htm |  |  |
| RIS_27_27-29_27-29-4.6 | 200 | 4179 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-4.6.htm |  |  |
| RIS_27_27-29_27-29-4.7 | 200 | 7539 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-4.7.htm |  |  |
| RIS_27_27-29_27-29-5 | 200 | 8612 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-5.htm |  |  |
| RIS_27_27-29_27-29-6 | 200 | 6278 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-6.htm |  |  |
| RIS_27_27-29_27-29-7 | 200 | 7766 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-7.htm |  |  |
| RIS_27_27-29_27-29-8 | 200 | 7528 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-8.htm |  |  |
| RIS_27_27-29_27-29-9 | 200 | 4820 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-9.htm |  |  |
| RIS_27_27-29_27-29-10 | 200 | 4098 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-10.htm |  |  |
| RIS_27_27-29_27-29-11 | 200 | 5921 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-11.htm |  |  |
| RIS_27_27-29_27-29-12 | 200 | 3951 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-12.htm |  |  |
| RIS_27_27-29_27-29-13 | 200 | 5592 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-13.htm |  |  |
| RIS_27_27-29_27-29-13.1 | 200 | 4191 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-13.1.htm |  |  |
| RIS_27_27-29_27-29-13.2 | 200 | 5063 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-13.2.htm |  |  |
| RIS_27_27-29_27-29-13.3 | 200 | 4587 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-13.3.htm |  |  |
| RIS_27_27-29_27-29-14 | 200 | 5185 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-14.htm |  |  |
| RIS_27_27-29_27-29-15 | 200 | 4151 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-15.htm |  |  |
| RIS_27_27-29_27-29-16 | 200 | 3617 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-16.htm |  | render-thin 110 |
| RIS_27_27-29_27-29-17 | 200 | 4358 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-17.htm |  |  |
| RIS_27_27-29_27-29-17.1 | 200 | 4925 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-17.1.htm |  |  |
| RIS_27_27-29_27-29-17.2 | 200 | 5595 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-17.2.htm |  |  |
| RIS_27_27-29_27-29-17.3 | 200 | 6390 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-17.3.htm |  |  |
| RIS_27_27-29_27-29-17.4 | 200 | 5355 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-17.4.htm |  |  |
| RIS_27_27-29_27-29-17.5 | 200 | 5685 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29/27-29-17.5.htm |  |  |
| RIS_27_27-29.1_27-29.1-1_27-29.1-1 | 200 | 11471 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-1_27-29.1-1.htm |  |  |
| RIS_27_27-29.1_27-29.1-2_27-29.1-2 | 200 | 5204 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-2_27-29.1-2.htm |  |  |
| RIS_27_27-29.1_27-29.1-3 | 200 | 7045 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-3.htm |  |  |
| RIS_27_27-29.1_27-29.1-4 | 200 | 4759 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-4.htm |  |  |
| RIS_27_27-29.1_27-29.1-5 | 200 | 7576 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-5.htm |  |  |
| RIS_27_27-29.1_27-29.1-6 | 200 | 4949 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-6.htm |  |  |
| RIS_27_27-29.1_27-29.1-7_27-29.1-7 | 200 | 10908 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-7_27-29.1-7.htm |  |  |
| RIS_27_27-29.1_27-29.1-8 | 200 | 4050 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-8.htm |  |  |
| RIS_27_27-29.1_27-29.1-9 | 200 | 4285 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-9.htm |  |  |
| RIS_27_27-29.1_27-29.1-10_27-29.1-10 | 200 | 7141 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-10_27-29.1-10.htm |  |  |
| RIS_27_27-29.1_27-29.1-11_27-29.1-11 | 200 | 4956 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-11_27-29.1-11.htm |  |  |
| RIS_27_27-29.1_27-29.1-12 | 200 | 8173 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-12.htm |  |  |
| RIS_27_27-29.1_27-29.1-13 | 200 | 4229 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.1/27-29.1-13.htm |  |  |
| RIS_27_27-29.2_27-29.2-1 | 200 | 4146 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.2/27-29.2-1.htm |  |  |
| RIS_27_27-29.2_27-29.2-2 | 200 | 8306 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.2/27-29.2-2.htm |  |  |
| RIS_27_27-29.2_27-29.2-3 | 200 | 4046 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.2/27-29.2-3.htm |  |  |
| RIS_27_27-29.2_27-29.2-4 | 200 | 4676 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-29.2/27-29.2-4.htm |  |  |
| RIS_27_27-30_27-30-1 | 200 | 4093 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-1.htm |  |  |
| RIS_27_27-30_27-30-2 | 200 | 10435 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-2.htm |  |  |
| RIS_27_27-30_27-30-3 | 200 | 4185 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-3.htm |  |  |
| RIS_27_27-30_27-30-4 | 200 | 9620 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-4.htm |  |  |
| RIS_27_27-30_27-30-5 | 200 | 8703 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-5.htm |  |  |
| RIS_27_27-30_27-30-6 | 200 | 13846 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-6.htm |  |  |
| RIS_27_27-30_27-30-7 | 200 | 8565 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-7.htm |  |  |
| RIS_27_27-30_27-30-8 | 200 | 6885 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-8.htm |  |  |
| RIS_27_27-30_27-30-9 | 200 | 4144 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-9.htm |  |  |
| RIS_27_27-30_27-30-10 | 200 | 5353 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-10.htm |  |  |
| RIS_27_27-30_27-30-11 | 200 | 4351 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-11.htm |  |  |
| RIS_27_27-30_27-30-12 | 200 | 5047 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-12.htm |  |  |
| RIS_27_27-30_27-30-13 | 200 | 3986 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-13.htm |  |  |
| RIS_27_27-30_27-30-14 | 200 | 4198 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-14.htm |  |  |
| RIS_27_27-30_27-30-15 | 200 | 4126 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-15.htm |  |  |
| RIS_27_27-30_27-30-16 | 200 | 4070 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-16.htm |  |  |
| RIS_27_27-30_27-30-17 | 200 | 3610 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-30/27-30-17.htm |  | render-thin 103 |
| RIS_27_27-31_27-31-1 | 200 | 3644 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-31/27-31-1.htm |  | render-thin 135 |
| RIS_27_27-32_27-32-1 | 200 | 5572 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-32/27-32-1.htm |  |  |
| RIS_27_27-32_27-32-2 | 200 | 4149 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-32/27-32-2.htm |  |  |
| RIS_27_27-32_27-32-3 | 200 | 4100 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-32/27-32-3.htm |  |  |
| RIS_27_27-32_27-32-4 | 200 | 4329 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-32/27-32-4.htm |  |  |
| RIS_27_27-32_27-32-5 | 200 | 4310 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-32/27-32-5.htm |  |  |
| RIS_27_27-32_27-32-6 | 200 | 5284 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-32/27-32-6.htm |  |  |
| RIS_27_27-32_27-32-7 | 200 | 4256 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-32/27-32-7.htm |  |  |
| RIS_27_27-32_27-32-8 | 200 | 4013 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-32/27-32-8.htm |  |  |
| RIS_27_27-32_27-32-8.1 | 200 | 4089 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-32/27-32-8.1.htm |  |  |
| RIS_27_27-32_27-32-9 | 200 | 4152 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-32/27-32-9.htm |  |  |
| RIS_27_27-33_27-33-1 | 200 | 4496 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-33/27-33-1.htm |  |  |
| RIS_27_27-33_27-33-2 | 200 | 4321 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-33/27-33-2.htm |  |  |
| RIS_27_27-33_27-33-3 | 200 | 4413 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-33/27-33-3.htm |  |  |
| RIS_27_27-33_27-33-4 | 200 | 4410 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-33/27-33-4.htm |  |  |
| RIS_27_27-33_27-33-5 | 200 | 4291 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-33/27-33-5.htm |  |  |
| RIS_27_27-33_27-33-6 | 200 | 5060 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-33/27-33-6.htm |  |  |
| RIS_27_27-33_27-33-7 | 200 | 4031 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-33/27-33-7.htm |  |  |
| RIS_27_27-33_27-33-8 | 200 | 4137 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-33/27-33-8.htm |  |  |
| RIS_27_27-33_27-33-9 | 200 | 4791 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-33/27-33-9.htm |  |  |
| RIS_27_27-33_27-33-10 | 200 | 5764 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-33/27-33-10.htm |  |  |
| RIS_27_27-33_27-33-11 | 200 | 4419 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-33/27-33-11.htm |  |  |
| RIS_27_27-34_27-34-1 | 200 | 4007 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-1.htm |  |  |
| RIS_27_27-34_27-34-2 | 200 | 4288 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-2.htm |  |  |
| RIS_27_27-34_27-34-3 | 200 | 8303 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-3.htm |  |  |
| RIS_27_27-34_27-34-4 | 200 | 3943 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-4.htm |  |  |
| RIS_27_27-34_27-34-5 | 200 | 23963 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-5.htm |  |  |
| RIS_27_27-34_27-34-6 | 200 | 4829 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-6.htm |  |  |
| RIS_27_27-34_27-34-7 | 200 | 7518 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-7.htm |  |  |
| RIS_27_27-34_27-34-8 | 200 | 23260 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-8.htm |  |  |
| RIS_27_27-34_27-34-9 | 200 | 8129 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-9.htm |  |  |
| RIS_27_27-34_27-34-10 | 200 | 5941 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-10.htm |  |  |
| RIS_27_27-34_27-34-10.1 | 200 | 3656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-10.1.htm |  | render-thin 149 |
| RIS_27_27-34_27-34-10.2 | 200 | 3656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-10.2.htm |  | render-thin 149 |
| RIS_27_27-34_27-34-10.3 | 200 | 3656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-10.3.htm |  | render-thin 149 |
| RIS_27_27-34_27-34-10.4 | 200 | 3656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-10.4.htm |  | render-thin 149 |
| RIS_27_27-34_27-34-10.5 | 200 | 4956 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-10.5.htm |  |  |
| RIS_27_27-34_27-34-11 | 200 | 6516 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-11.htm |  |  |
| RIS_27_27-34_27-34-11.1 | 200 | 3656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-11.1.htm |  | render-thin 149 |
| RIS_27_27-34_27-34-11.2 | 200 | 3656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-11.2.htm |  | render-thin 149 |
| RIS_27_27-34_27-34-11.3 | 200 | 3656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-11.3.htm |  | render-thin 149 |
| RIS_27_27-34_27-34-11.4 | 200 | 3656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-11.4.htm |  | render-thin 149 |
| RIS_27_27-34_27-34-11.5 | 200 | 7950 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-11.5.htm |  |  |
| RIS_27_27-34_27-34-12 | 200 | 8854 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-12.htm |  |  |
| RIS_27_27-34_27-34-12.1 | 200 | 3656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-12.1.htm |  | render-thin 149 |
| RIS_27_27-34_27-34-12.2 | 200 | 3656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-12.2.htm |  | render-thin 149 |
| RIS_27_27-34_27-34-12.3 | 200 | 3656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-12.3.htm |  | render-thin 149 |
| RIS_27_27-34_27-34-12.4 | 200 | 3656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-12.4.htm |  | render-thin 149 |
| RIS_27_27-34_27-34-12.5 | 200 | 4767 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-12.5.htm |  |  |
| RIS_27_27-34_27-34-13 | 200 | 3897 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-13.htm |  |  |
| RIS_27_27-34_27-34-14 | 200 | 4066 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-14.htm |  |  |
| RIS_27_27-34_27-34-15 | 200 | 4335 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-15.htm |  |  |
| RIS_27_27-34_27-34-16 | 200 | 4366 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-16.htm |  |  |
| RIS_27_27-34_27-34-17 | 200 | 5016 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-17.htm |  |  |
| RIS_27_27-34_27-34-18 | 200 | 3897 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-18.htm |  |  |
| RIS_27_27-34_27-34-19 | 200 | 4222 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34/27-34-19.htm |  |  |
| RIS_27_27-34.1_27-34.1-1 | 200 | 3679 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.1/27-34.1-1.htm |  | render-thin 170 |
| RIS_27_27-34.2_27-34.2-1 | 200 | 4352 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-1.htm |  |  |
| RIS_27_27-34.2_27-34.2-2 | 200 | 4805 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-2.htm |  |  |
| RIS_27_27-34.2_27-34.2-3 | 200 | 3847 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-3.htm |  | render-thin 229 |
| RIS_27_27-34.2_27-34.2-4 | 200 | 15439 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-4.htm |  |  |
| RIS_27_27-34.2_27-34.2-5 | 200 | 4264 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-5.htm |  |  |
| RIS_27_27-34.2_27-34.2-6 | 200 | 22704 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-6.htm |  |  |
| RIS_27_27-34.2_27-34.2-7 | 200 | 3613 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-7.htm |  | render-thin 106 |
| RIS_27_27-34.2_27-34.2-7.1 | 200 | 6471 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-7.1.htm |  |  |
| RIS_27_27-34.2_27-34.2-8 | 200 | 5331 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-8.htm |  |  |
| RIS_27_27-34.2_27-34.2-9 | 200 | 3919 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-9.htm |  | render-thin 283 |
| RIS_27_27-34.2_27-34.2-10 | 200 | 5862 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-10.htm |  |  |
| RIS_27_27-34.2_27-34.2-11 | 200 | 3615 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-11.htm |  | render-thin 108 |
| RIS_27_27-34.2_27-34.2-12 | 200 | 8278 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-12.htm |  |  |
| RIS_27_27-34.2_27-34.2-13 | 200 | 8763 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-13.htm |  |  |
| RIS_27_27-34.2_27-34.2-14 | 200 | 12651 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-14.htm |  |  |
| RIS_27_27-34.2_27-34.2-15 | 200 | 4926 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-15.htm |  |  |
| RIS_27_27-34.2_27-34.2-16 | 200 | 4270 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-16.htm |  |  |
| RIS_27_27-34.2_27-34.2-17 | 200 | 3615 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-17.htm |  | render-thin 108 |
| RIS_27_27-34.2_27-34.2-18 | 200 | 5498 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-18.htm |  |  |
| RIS_27_27-34.2_27-34.2-19 | 200 | 5744 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-19.htm |  |  |
| RIS_27_27-34.2_27-34.2-20 | 200 | 4123 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-20.htm |  |  |
| RIS_27_27-34.2_27-34.2-21 | 200 | 8577 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-21.htm |  |  |
| RIS_27_27-34.2_27-34.2-22 | 200 | 5319 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.2/27-34.2-22.htm |  |  |
| RIS_27_27-34.3_27-34.3-1 | 200 | 3952 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-1.htm |  |  |
| RIS_27_27-34.3_27-34.3-2 | 200 | 5049 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-2.htm |  |  |
| RIS_27_27-34.3_27-34.3-3 | 200 | 24625 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-3.htm |  |  |
| RIS_27_27-34.3_27-34.3-4 | 200 | 3932 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-4.htm |  |  |
| RIS_27_27-34.3_27-34.3-5 | 200 | 17314 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-5.htm |  |  |
| RIS_27_27-34.3_27-34.3-6 | 200 | 6655 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-6.htm |  |  |
| RIS_27_27-34.3_27-34.3-7 | 200 | 5444 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-7.htm |  |  |
| RIS_27_27-34.3_27-34.3-8 | 200 | 38143 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-8.htm |  |  |
| RIS_27_27-34.3_27-34.3-9 | 200 | 15312 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-9.htm |  |  |
| RIS_27_27-34.3_27-34.3-10 | 200 | 7839 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-10.htm |  |  |
| RIS_27_27-34.3_27-34.3-11 | 200 | 6849 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-11.htm |  |  |
| RIS_27_27-34.3_27-34.3-12 | 200 | 7898 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-12.htm |  |  |
| RIS_27_27-34.3_27-34.3-13 | 200 | 4954 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-13.htm |  |  |
| RIS_27_27-34.3_27-34.3-14 | 200 | 10565 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-14.htm |  |  |
| RIS_27_27-34.3_27-34.3-15 | 200 | 4438 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-15.htm |  |  |
| RIS_27_27-34.3_27-34.3-16 | 200 | 3992 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-16.htm |  |  |
| RIS_27_27-34.3_27-34.3-17 | 200 | 4461 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-17.htm |  |  |
| RIS_27_27-34.3_27-34.3-18 | 200 | 4534 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-18.htm |  |  |
| RIS_27_27-34.3_27-34.3-19 | 200 | 8980 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-19.htm |  |  |
| RIS_27_27-34.3_27-34.3-20 | 200 | 4577 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-34.3/27-34.3-20.htm |  |  |
| RIS_27_27-35_27-35-1 | 200 | 12578 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-1.htm |  |  |
| RIS_27_27-35_27-35-1.1 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-1.1.htm |  | render-thin 115 |
| RIS_27_27-35_27-35-1.2 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-1.2.htm |  | render-thin 115 |
| RIS_27_27-35_27-35-1.3 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-1.3.htm |  | render-thin 115 |
| RIS_27_27-35_27-35-1.4 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-1.4.htm |  | render-thin 115 |
| RIS_27_27-35_27-35-1.5 | 200 | 9600 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-1.5.htm |  |  |
| RIS_27_27-35_27-35-2 | 200 | 26782 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-2.htm |  |  |
| RIS_27_27-35_27-35-2.1 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-2.1.htm |  | render-thin 115 |
| RIS_27_27-35_27-35-2.2 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-2.2.htm |  | render-thin 115 |
| RIS_27_27-35_27-35-2.3 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-2.3.htm |  | render-thin 115 |
| RIS_27_27-35_27-35-2.4 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-2.4.htm |  | render-thin 115 |
| RIS_27_27-35_27-35-2.5 | 200 | 21861 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-2.5.htm |  |  |
| RIS_27_27-35_27-35-3 | 200 | 23741 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-3.htm |  |  |
| RIS_27_27-35_27-35-4 | 200 | 24109 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-4.htm |  |  |
| RIS_27_27-35_27-35-5 | 200 | 8276 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-5.htm |  |  |
| RIS_27_27-35_27-35-5.1 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-5.1.htm |  | render-thin 115 |
| RIS_27_27-35_27-35-5.2 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-5.2.htm |  | render-thin 115 |
| RIS_27_27-35_27-35-5.3 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-5.3.htm |  | render-thin 115 |
| RIS_27_27-35_27-35-5.4 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-5.4.htm |  | render-thin 115 |
| RIS_27_27-35_27-35-5.5 | 200 | 19926 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-5.5.htm |  |  |
| RIS_27_27-35_27-35-6 | 200 | 16405 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-6.htm |  |  |
| RIS_27_27-35_27-35-7 | 200 | 4006 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-7.htm |  |  |
| RIS_27_27-35_27-35-8 | 200 | 7550 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-8.htm |  |  |
| RIS_27_27-35_27-35-9 | 200 | 7271 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-9.htm |  |  |
| RIS_27_27-35_27-35-10 | 200 | 4364 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-10.htm |  |  |
| RIS_27_27-35_27-35-10.1 | 200 | 3626 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-10.1.htm |  | render-thin 117 |
| RIS_27_27-35_27-35-10.2 | 200 | 3624 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-10.2.htm |  | render-thin 117 |
| RIS_27_27-35_27-35-10.3 | 200 | 3624 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-10.3.htm |  | render-thin 117 |
| RIS_27_27-35_27-35-10.4 | 200 | 3624 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-10.4.htm |  | render-thin 117 |
| RIS_27_27-35_27-35-10.5 | 200 | 6853 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-10.5.htm |  |  |
| RIS_27_27-35_27-35-11 | 200 | 4491 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-11.htm |  |  |
| RIS_27_27-35_27-35-12 | 200 | 5293 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-12.htm |  |  |
| RIS_27_27-35_27-35-13 | 200 | 3944 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-13.htm |  |  |
| RIS_27_27-35_27-35-14 | 200 | 4139 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-35/27-35-14.htm |  |  |
| RIS_27_27-36_27-36-1 | 200 | 5543 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-36/27-36-1.htm |  |  |
| RIS_27_27-36_27-36-2 | 200 | 6058 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-36/27-36-2.htm |  |  |
| RIS_27_27-37_27-37-1 | 200 | 4149 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-37/27-37-1.htm |  |  |
| RIS_27_27-38_27-38-1 | 200 | 3658 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-38/27-38-1.htm |  | render-thin 149 |
| RIS_27_27-38.1_27-38.1-1 | 200 | 5545 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-38.1/27-38.1-1.htm |  |  |
| RIS_27_27-38.1_27-38.1-2 | 200 | 4675 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-38.1/27-38.1-2.htm |  |  |
| RIS_27_27-38.1_27-38.1-3 | 200 | 4656 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-38.1/27-38.1-3.htm |  |  |
| RIS_27_27-38.2_27-38.2-1 | 200 | 7761 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-38.2/27-38.2-1.htm |  |  |
| RIS_27_27-38.2_27-38.2-2 | 200 | 8568 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-38.2/27-38.2-2.htm |  |  |
| RIS_27_27-38.2_27-38.2-3 | 200 | 5542 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-38.2/27-38.2-3.htm |  |  |
| RIS_27_27-38.2_27-38.2-4 | 200 | 4439 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-38.2/27-38.2-4.htm |  |  |
| RIS_27_27-38.2_27-38.2-5 | 200 | 3921 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-38.2/27-38.2-5.htm |  |  |
| RIS_27_27-38.2_27-38.2-6 | 200 | 11887 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-38.2/27-38.2-6.htm |  |  |
| RIS_27_27-39_27-39-1 | 200 | 5050 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-39/27-39-1.htm |  |  |
| RIS_27_27-39_27-39-2 | 200 | 5252 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-39/27-39-2.htm |  |  |
| RIS_27_27-39_27-39-3 | 200 | 4269 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-39/27-39-3.htm |  |  |
| RIS_27_27-39_27-39-4 | 200 | 4489 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-39/27-39-4.htm |  |  |
| RIS_27_27-39_27-39-5 | 200 | 4137 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-39/27-39-5.htm |  |  |
| RIS_27_27-40_27-40-1 | 200 | 3643 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-40/27-40-1.htm |  | render-thin 134 |
| RIS_27_27-41_27-41-1 | 200 | 3873 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-1.htm |  | render-thin 254 |
| RIS_27_27-41_27-41-2 | 200 | 16680 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-2.htm |  |  |
| RIS_27_27-41_27-41-3 | 200 | 12723 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-3.htm |  |  |
| RIS_27_27-41_27-41-4 | 200 | 9621 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-4.htm |  |  |
| RIS_27_27-41_27-41-5 | 200 | 8233 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-5.htm |  |  |
| RIS_27_27-41_27-41-6 | 200 | 4304 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-6.htm |  |  |
| RIS_27_27-41_27-41-7 | 200 | 4997 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-7.htm |  |  |
| RIS_27_27-41_27-41-8 | 200 | 4841 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-8.htm |  |  |
| RIS_27_27-41_27-41-9 | 200 | 6949 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-9.htm |  |  |
| RIS_27_27-41_27-41-10 | 200 | 4795 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-10.htm |  |  |
| RIS_27_27-41_27-41-11 | 200 | 4498 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-11.htm |  |  |
| RIS_27_27-41_27-41-12 | 200 | 11234 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-12.htm |  |  |
| RIS_27_27-41_27-41-13 | 200 | 16627 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-13.htm |  |  |
| RIS_27_27-41_27-41-13.1 | 200 | 4834 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-13.1.htm |  |  |
| RIS_27_27-41_27-41-13.2 | 200 | 4273 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-13.2.htm |  |  |
| RIS_27_27-41_27-41-13.3 | 200 | 5979 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-13.3.htm |  |  |
| RIS_27_27-41_27-41-14 | 200 | 9287 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-14.htm |  |  |
| RIS_27_27-41_27-41-14.1 | 200 | 5277 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-14.1.htm |  |  |
| RIS_27_27-41_27-41-15 | 200 | 4802 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-15.htm |  |  |
| RIS_27_27-41_27-41-16 | 200 | 7540 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-16.htm |  |  |
| RIS_27_27-41_27-41-17 | 200 | 8345 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-17.htm |  |  |
| RIS_27_27-41_27-41-18 | 200 | 7083 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-18.htm |  |  |
| RIS_27_27-41_27-41-18.1 | 200 | 6594 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-18.1.htm |  |  |
| RIS_27_27-41_27-41-19 | 200 | 4211 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-19.htm |  |  |
| RIS_27_27-41_27-41-20 | 200 | 5714 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-20.htm |  |  |
| RIS_27_27-41_27-41-21 | 200 | 7982 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-21.htm |  |  |
| RIS_27_27-41_27-41-22 | 200 | 6184 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-22.htm |  |  |
| RIS_27_27-41_27-41-23 | 200 | 4103 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-23.htm |  |  |
| RIS_27_27-41_27-41-24 | 200 | 4169 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-24.htm |  |  |
| RIS_27_27-41_27-41-25 | 200 | 4119 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-25.htm |  |  |
| RIS_27_27-41_27-41-26 | 200 | 4149 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-26.htm |  |  |
| RIS_27_27-41_27-41-26.1 | 200 | 4679 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-26.1.htm |  |  |
| RIS_27_27-41_27-41-27 | 200 | 10315 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-27.htm |  |  |
| RIS_27_27-41_27-41-27.1 | 200 | 4318 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-27.1.htm |  |  |
| RIS_27_27-41_27-41-27.2 | 200 | 5445 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-27.2.htm |  |  |
| RIS_27_27-41_27-41-28 | 200 | 6317 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-28.htm |  |  |
| RIS_27_27-41_27-41-29 | 200 | 4117 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-29.htm |  |  |
| RIS_27_27-41_27-41-29.1 | 200 | 5751 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-29.1.htm |  |  |
| RIS_27_27-41_27-41-29.2 | 200 | 5319 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-29.2.htm |  |  |
| RIS_27_27-41_27-41-30 | 200 | 5386 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-30.htm |  |  |
| RIS_27_27-41_27-41-30.1 | 200 | 6039 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-30.1.htm |  |  |
| RIS_27_27-41_27-41-31 | 200 | 4311 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-31.htm |  |  |
| RIS_27_27-41_27-41-32 | 200 | 4382 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-32.htm |  |  |
| RIS_27_27-41_27-41-33 | 200 | 6857 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-33.htm |  |  |
| RIS_27_27-41_27-41-34 | 200 | 4960 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-41/27-41-34.htm |  |  |
