| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| SC_t01c001 | 200 | 112572 | https://www.scstatehouse.gov/code/t01c001.php | Code of Laws - Title 1 - Chapter 1- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c003 | 200 | 72588 | https://www.scstatehouse.gov/code/t01c003.php | Code of Laws - Title 1 - Chapter 3- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c005 | 200 | 31698 | https://www.scstatehouse.gov/code/t01c005.php | Code of Laws - Title 1 - Chapter 5- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c006 | 200 | 43183 | https://www.scstatehouse.gov/code/t01c006.php | Code of Laws - Title 1 - Chapter 6- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c007 | 200 | 78993 | https://www.scstatehouse.gov/code/t01c007.php | Code of Laws - Title 1 - Chapter 7- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c009 | 200 | 35413 | https://www.scstatehouse.gov/code/t01c009.php | Code of Laws - Title 1 - Chapter 9- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c010 | 200 | 24184 | https://www.scstatehouse.gov/code/t01c010.php | Code of Laws - Title 1 - Chapter 10- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c011 | 200 | 219358 | https://www.scstatehouse.gov/code/t01c011.php | Code of Laws - Title 1 - Chapter 11- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c013 | 200 | 99673 | https://www.scstatehouse.gov/code/t01c013.php | Code of Laws - Title 1 - Chapter 13- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c015 | 200 | 26117 | https://www.scstatehouse.gov/code/t01c015.php | Code of Laws - Title 1 - Chapter 15- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c017 | 200 | 25099 | https://www.scstatehouse.gov/code/t01c017.php | Code of Laws - Title 1 - Chapter 17- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c018 | 200 | 27625 | https://www.scstatehouse.gov/code/t01c018.php | Code of Laws - Title 1 - Chapter 18- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c021 | 200 | 21679 | https://www.scstatehouse.gov/code/t01c021.php | Code of Laws - Title 1 - Chapter 21- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c023 | 200 | 172712 | https://www.scstatehouse.gov/code/t01c023.php | Code of Laws - Title 1 - Chapter 23- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c025 | 200 | 38195 | https://www.scstatehouse.gov/code/t01c025.php | Code of Laws - Title 1 - Chapter 25- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c029 | 200 | 22245 | https://www.scstatehouse.gov/code/t01c029.php | Code of Laws - Title 1 - Chapter 29- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c030 | 200 | 83399 | https://www.scstatehouse.gov/code/t01c030.php | Code of Laws - Title 1 - Chapter 30- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c031 | 200 | 28261 | https://www.scstatehouse.gov/code/t01c031.php | Code of Laws - Title 1 - Chapter 31- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c032 | 200 | 23967 | https://www.scstatehouse.gov/code/t01c032.php | Code of Laws - Title 1 - Chapter 32- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c033 | 200 | 25048 | https://www.scstatehouse.gov/code/t01c033.php | Code of Laws - Title 1 - Chapter 33- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t01c034 | 200 | 27449 | https://www.scstatehouse.gov/code/t01c034.php | Code of Laws - Title 1 - Chapter 34- - ADMINISTRATION OF THE GOVERNMENT |  |
| SC_t02c001 | 200 | 1653177 | https://www.scstatehouse.gov/code/t02c001.php | Code of Laws - Title 2 - Chapter 1- - GENERAL ASSEMBLY |  |
| SC_t02c002 | 200 | 40626 | https://www.scstatehouse.gov/code/t02c002.php | Code of Laws - Title 2 - Chapter 2- - GENERAL ASSEMBLY |  |
| SC_t02c003 | 200 | 50978 | https://www.scstatehouse.gov/code/t02c003.php | Code of Laws - Title 2 - Chapter 3- - GENERAL ASSEMBLY |  |
| SC_t02c005 | 200 | 30837 | https://www.scstatehouse.gov/code/t02c005.php | Code of Laws - Title 2 - Chapter 5- - GENERAL ASSEMBLY |  |
| SC_t02c007 | 200 | 62610 | https://www.scstatehouse.gov/code/t02c007.php | Code of Laws - Title 2 - Chapter 7- - GENERAL ASSEMBLY |  |
| SC_t02c011 | 200 | 23675 | https://www.scstatehouse.gov/code/t02c011.php | Code of Laws - Title 2 - Chapter 11- - GENERAL ASSEMBLY |  |
| SC_t02c013 | 200 | 57596 | https://www.scstatehouse.gov/code/t02c013.php | Code of Laws - Title 2 - Chapter 13- - GENERAL ASSEMBLY |  |
| SC_t02c015 | 200 | 35704 | https://www.scstatehouse.gov/code/t02c015.php | Code of Laws - Title 2 - Chapter 15- - GENERAL ASSEMBLY |  |
| SC_t02c017 | 200 | 90277 | https://www.scstatehouse.gov/code/t02c017.php | Code of Laws - Title 2 - Chapter 17- - GENERAL ASSEMBLY |  |
| SC_t02c019 | 200 | 54592 | https://www.scstatehouse.gov/code/t02c019.php | Code of Laws - Title 2 - Chapter 19- - GENERAL ASSEMBLY |  |
| SC_t02c020 | 200 | 50503 | https://www.scstatehouse.gov/code/t02c020.php | Code of Laws - Title 2 - Chapter 20- - GENERAL ASSEMBLY |  |
| SC_t02c035 | 200 | 22458 | https://www.scstatehouse.gov/code/t02c035.php | Code of Laws - Title 2 - Chapter 35- - GENERAL ASSEMBLY |  |
| SC_t02c041 | 200 | 25327 | https://www.scstatehouse.gov/code/t02c041.php | Code of Laws - Title 2 - Chapter 41- - GENERAL ASSEMBLY |  |
| SC_t02c047 | 200 | 42523 | https://www.scstatehouse.gov/code/t02c047.php | Code of Laws - Title 2 - Chapter 47- - GENERAL ASSEMBLY |  |
| SC_t02c048 | 200 | 29374 | https://www.scstatehouse.gov/code/t02c048.php | Code of Laws - Title 2 - Chapter 48- - GENERAL ASSEMBLY |  |
| SC_t02c051 | 200 | 20674 | https://www.scstatehouse.gov/code/t02c051.php | Code of Laws - Title 2 - Chapter 51- - GENERAL ASSEMBLY |  |
| SC_t02c059 | 200 | 21579 | https://www.scstatehouse.gov/code/t02c059.php | Code of Laws - Title 2 - Chapter 59- - GENERAL ASSEMBLY |  |
| SC_t02c065 | 200 | 45668 | https://www.scstatehouse.gov/code/t02c065.php | Code of Laws - Title 2 - Chapter 65- - GENERAL ASSEMBLY |  |
| SC_t02c066 | 200 | 22330 | https://www.scstatehouse.gov/code/t02c066.php | Code of Laws - Title 2 - Chapter 66- - GENERAL ASSEMBLY |  |
| SC_t02c067 | 200 | 23087 | https://www.scstatehouse.gov/code/t02c067.php | Code of Laws - Title 2 - Chapter 67- - GENERAL ASSEMBLY |  |
| SC_t02c069 | 200 | 27869 | https://www.scstatehouse.gov/code/t02c069.php | Code of Laws - Title 2 - Chapter 69- - GENERAL ASSEMBLY |  |
| SC_t02c075 | 200 | 42006 | https://www.scstatehouse.gov/code/t02c075.php | Code of Laws - Title 2 - Chapter 75- - GENERAL ASSEMBLY |  |
| SC_t02c077 | 200 | 30050 | https://www.scstatehouse.gov/code/t02c077.php | Code of Laws - Title 2 - Chapter 77- - GENERAL ASSEMBLY |  |
| SC_t02c079 | 200 | 23458 | https://www.scstatehouse.gov/code/t02c079.php | Code of Laws - Title 2 - Chapter 79- - GENERAL ASSEMBLY |  |
| SC_t03c001 | 200 | 35507 | https://www.scstatehouse.gov/code/t03c001.php | Code of Laws - Title 3 - Chapter 1- - UNITED STATES GOVERNMENT, AGREEMENTS AND R |  |
| SC_t03c003 | 200 | 115442 | https://www.scstatehouse.gov/code/t03c003.php | Code of Laws - Title 3 - Chapter 3- - UNITED STATES GOVERNMENT, AGREEMENTS AND R |  |
| SC_t03c005 | 200 | 60941 | https://www.scstatehouse.gov/code/t03c005.php | Code of Laws - Title 3 - Chapter 5- - UNITED STATES GOVERNMENT, AGREEMENTS AND R |  |
| SC_t03c007 | 200 | 28236 | https://www.scstatehouse.gov/code/t03c007.php | Code of Laws - Title 3 - Chapter 7- - UNITED STATES GOVERNMENT, AGREEMENTS AND R |  |
| SC_t03c009 | 200 | 27601 | https://www.scstatehouse.gov/code/t03c009.php | Code of Laws - Title 3 - Chapter 9- - UNITED STATES GOVERNMENT, AGREEMENTS AND R |  |
| SC_t03c011 | 200 | 40294 | https://www.scstatehouse.gov/code/t03c011.php | Code of Laws - Title 3 - Chapter 11- - UNITED STATES GOVERNMENT, AGREEMENTS AND  |  |
| SC_t04c001 | 200 | 41440 | https://www.scstatehouse.gov/code/t04c001.php | Code of Laws - Title 4 - Chapter 1- - COUNTIES |  |
| SC_t04c003 | 200 | 199063 | https://www.scstatehouse.gov/code/t04c003.php | Code of Laws - Title 4 - Chapter 3- - COUNTIES |  |
| SC_t04c005 | 200 | 32149 | https://www.scstatehouse.gov/code/t04c005.php | Code of Laws - Title 4 - Chapter 5- - COUNTIES |  |
| SC_t04c007 | 200 | 34049 | https://www.scstatehouse.gov/code/t04c007.php | Code of Laws - Title 4 - Chapter 7- - COUNTIES |  |
| SC_t04c008 | 200 | 48045 | https://www.scstatehouse.gov/code/t04c008.php | Code of Laws - Title 4 - Chapter 8- - COUNTIES |  |
| SC_t04c009 | 200 | 145018 | https://www.scstatehouse.gov/code/t04c009.php | Code of Laws - Title 4 - Chapter 9- - COUNTIES |  |
| SC_t04c010 | 200 | 177429 | https://www.scstatehouse.gov/code/t04c010.php | Code of Laws - Title 4 - Chapter 10- - COUNTIES |  |
| SC_t04c011 | 200 | 56154 | https://www.scstatehouse.gov/code/t04c011.php | Code of Laws - Title 4 - Chapter 11- - COUNTIES |  |
| SC_t04c012 | 200 | 74903 | https://www.scstatehouse.gov/code/t04c012.php | Code of Laws - Title 4 - Chapter 12- - COUNTIES |  |
| SC_t04c013 | 200 | 32346 | https://www.scstatehouse.gov/code/t04c013.php | Code of Laws - Title 4 - Chapter 13- - COUNTIES |  |
| SC_t04c015 | 200 | 32291 | https://www.scstatehouse.gov/code/t04c015.php | Code of Laws - Title 4 - Chapter 15- - COUNTIES |  |
| SC_t04c017 | 200 | 25247 | https://www.scstatehouse.gov/code/t04c017.php | Code of Laws - Title 4 - Chapter 17- - COUNTIES |  |
| SC_t04c018 | 200 | 20756 | https://www.scstatehouse.gov/code/t04c018.php | Code of Laws - Title 4 - Chapter 18- - COUNTIES |  |
| SC_t04c019 | 200 | 42111 | https://www.scstatehouse.gov/code/t04c019.php | Code of Laws - Title 4 - Chapter 19- - COUNTIES |  |
| SC_t04c020 | 200 | 31636 | https://www.scstatehouse.gov/code/t04c020.php | Code of Laws - Title 4 - Chapter 20- - COUNTIES |  |
| SC_t04c021 | 200 | 24756 | https://www.scstatehouse.gov/code/t04c021.php | Code of Laws - Title 4 - Chapter 21- - COUNTIES |  |
| SC_t04c023 | 200 | 127626 | https://www.scstatehouse.gov/code/t04c023.php | Code of Laws - Title 4 - Chapter 23- - COUNTIES |  |
| SC_t04c025 | 200 | 31730 | https://www.scstatehouse.gov/code/t04c025.php | Code of Laws - Title 4 - Chapter 25- - COUNTIES |  |
| SC_t04c029 | 200 | 130461 | https://www.scstatehouse.gov/code/t04c029.php | Code of Laws - Title 4 - Chapter 29- - COUNTIES |  |
| SC_t04c031 | 200 | 35451 | https://www.scstatehouse.gov/code/t04c031.php | Code of Laws - Title 4 - Chapter 31- - COUNTIES |  |
| SC_t04c033 | 200 | 22500 | https://www.scstatehouse.gov/code/t04c033.php | Code of Laws - Title 4 - Chapter 33- - COUNTIES |  |
| SC_t04c035 | 200 | 37511 | https://www.scstatehouse.gov/code/t04c035.php | Code of Laws - Title 4 - Chapter 35- - COUNTIES |  |
| SC_t04c037 | 200 | 56203 | https://www.scstatehouse.gov/code/t04c037.php | Code of Laws - Title 4 - Chapter 37- - COUNTIES |  |
| SC_t05c001 | 200 | 40907 | https://www.scstatehouse.gov/code/t05c001.php | Code of Laws - Title 5 - Chapter 1- - MUNICIPAL CORPORATIONS |  |
| SC_t05c003 | 200 | 63615 | https://www.scstatehouse.gov/code/t05c003.php | Code of Laws - Title 5 - Chapter 3- - MUNICIPAL CORPORATIONS |  |
| SC_t05c005 | 200 | 25594 | https://www.scstatehouse.gov/code/t05c005.php | Code of Laws - Title 5 - Chapter 5- - MUNICIPAL CORPORATIONS |  |
| SC_t05c007 | 200 | 66327 | https://www.scstatehouse.gov/code/t05c007.php | Code of Laws - Title 5 - Chapter 7- - MUNICIPAL CORPORATIONS |  |
| SC_t05c009 | 200 | 23390 | https://www.scstatehouse.gov/code/t05c009.php | Code of Laws - Title 5 - Chapter 9- - MUNICIPAL CORPORATIONS |  |
| SC_t05c011 | 200 | 22004 | https://www.scstatehouse.gov/code/t05c011.php | Code of Laws - Title 5 - Chapter 11- - MUNICIPAL CORPORATIONS |  |
| SC_t05c013 | 200 | 28861 | https://www.scstatehouse.gov/code/t05c013.php | Code of Laws - Title 5 - Chapter 13- - MUNICIPAL CORPORATIONS |  |
| SC_t05c015 | 200 | 58917 | https://www.scstatehouse.gov/code/t05c015.php | Code of Laws - Title 5 - Chapter 15- - MUNICIPAL CORPORATIONS |  |
| SC_t05c017 | 200 | 21952 | https://www.scstatehouse.gov/code/t05c017.php | Code of Laws - Title 5 - Chapter 17- - MUNICIPAL CORPORATIONS |  |
| SC_t05c019 | 200 | 41766 | https://www.scstatehouse.gov/code/t05c019.php | Code of Laws - Title 5 - Chapter 19- - MUNICIPAL CORPORATIONS |  |
| SC_t05c021 | 200 | 61551 | https://www.scstatehouse.gov/code/t05c021.php | Code of Laws - Title 5 - Chapter 21- - MUNICIPAL CORPORATIONS |  |
| SC_t05c023 | 200 | 19795 | https://www.scstatehouse.gov/code/t05c023.php | Code of Laws - Title 5 - Chapter 23- - MUNICIPAL CORPORATIONS |  |
| SC_t05c025 | 200 | 91601 | https://www.scstatehouse.gov/code/t05c025.php | Code of Laws - Title 5 - Chapter 25- - MUNICIPAL CORPORATIONS |  |
| SC_t05c027 | 200 | 38226 | https://www.scstatehouse.gov/code/t05c027.php | Code of Laws - Title 5 - Chapter 27- - MUNICIPAL CORPORATIONS |  |
| SC_t05c029 | 200 | 26714 | https://www.scstatehouse.gov/code/t05c029.php | Code of Laws - Title 5 - Chapter 29- - MUNICIPAL CORPORATIONS |  |
| SC_t05c031 | 200 | 129113 | https://www.scstatehouse.gov/code/t05c031.php | Code of Laws - Title 5 - Chapter 31- - MUNICIPAL CORPORATIONS |  |
| SC_t05c033 | 200 | 24380 | https://www.scstatehouse.gov/code/t05c033.php | Code of Laws - Title 5 - Chapter 33- - MUNICIPAL CORPORATIONS |  |
| SC_t05c035 | 200 | 24276 | https://www.scstatehouse.gov/code/t05c035.php | Code of Laws - Title 5 - Chapter 35- - MUNICIPAL CORPORATIONS |  |
| SC_t05c037 | 200 | 51442 | https://www.scstatehouse.gov/code/t05c037.php | Code of Laws - Title 5 - Chapter 37- - MUNICIPAL CORPORATIONS |  |
| SC_t05c039 | 200 | 30592 | https://www.scstatehouse.gov/code/t05c039.php | Code of Laws - Title 5 - Chapter 39- - MUNICIPAL CORPORATIONS |  |
| SC_t05c041 | 200 | 37050 | https://www.scstatehouse.gov/code/t05c041.php | Code of Laws - Title 5 - Chapter 41- - MUNICIPAL CORPORATIONS |  |
| SC_t06c001 | 200 | 176092 | https://www.scstatehouse.gov/code/t06c001.php | Code of Laws - Title 6 - Chapter 1- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO  |  |
| SC_t06c003 | 200 | 22157 | https://www.scstatehouse.gov/code/t06c003.php | Code of Laws - Title 6 - Chapter 3- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO  |  |
| SC_t06c004 | 200 | 49436 | https://www.scstatehouse.gov/code/t06c004.php | Code of Laws - Title 6 - Chapter 4- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO  |  |
| SC_t06c005 | 200 | 35632 | https://www.scstatehouse.gov/code/t06c005.php | Code of Laws - Title 6 - Chapter 5- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO  |  |
| SC_t06c006 | 200 | 21776 | https://www.scstatehouse.gov/code/t06c006.php | Code of Laws - Title 6 - Chapter 6- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO  |  |
| SC_t06c007 | 200 | 46783 | https://www.scstatehouse.gov/code/t06c007.php | Code of Laws - Title 6 - Chapter 7- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO  |  |
| SC_t06c008 | 200 | 30019 | https://www.scstatehouse.gov/code/t06c008.php | Code of Laws - Title 6 - Chapter 8- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO  |  |
| SC_t06c009 | 200 | 57767 | https://www.scstatehouse.gov/code/t06c009.php | Code of Laws - Title 6 - Chapter 9- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO  |  |
| SC_t06c010 | 200 | 34783 | https://www.scstatehouse.gov/code/t06c010.php | Code of Laws - Title 6 - Chapter 10- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c011 | 200 | 193122 | https://www.scstatehouse.gov/code/t06c011.php | Code of Laws - Title 6 - Chapter 11- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c013 | 200 | 126532 | https://www.scstatehouse.gov/code/t06c013.php | Code of Laws - Title 6 - Chapter 13- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c015 | 200 | 35225 | https://www.scstatehouse.gov/code/t06c015.php | Code of Laws - Title 6 - Chapter 15- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c016 | 200 | 48087 | https://www.scstatehouse.gov/code/t06c016.php | Code of Laws - Title 6 - Chapter 16- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c017 | 200 | 58956 | https://www.scstatehouse.gov/code/t06c017.php | Code of Laws - Title 6 - Chapter 17- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c019 | 200 | 30847 | https://www.scstatehouse.gov/code/t06c019.php | Code of Laws - Title 6 - Chapter 19- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c021 | 200 | 73089 | https://www.scstatehouse.gov/code/t06c021.php | Code of Laws - Title 6 - Chapter 21- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c023 | 200 | 78795 | https://www.scstatehouse.gov/code/t06c023.php | Code of Laws - Title 6 - Chapter 23- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c024 | 200 | 62881 | https://www.scstatehouse.gov/code/t06c024.php | Code of Laws - Title 6 - Chapter 24- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c025 | 200 | 93285 | https://www.scstatehouse.gov/code/t06c025.php | Code of Laws - Title 6 - Chapter 25- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c027 | 200 | 28681 | https://www.scstatehouse.gov/code/t06c027.php | Code of Laws - Title 6 - Chapter 27- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c029 | 200 | 181187 | https://www.scstatehouse.gov/code/t06c029.php | Code of Laws - Title 6 - Chapter 29- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c031 | 200 | 45123 | https://www.scstatehouse.gov/code/t06c031.php | Code of Laws - Title 6 - Chapter 31- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c032 | 200 | 21468 | https://www.scstatehouse.gov/code/t06c032.php | Code of Laws - Title 6 - Chapter 32- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c033 | 200 | 21982 | https://www.scstatehouse.gov/code/t06c033.php | Code of Laws - Title 6 - Chapter 33- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c034 | 200 | 21412 | https://www.scstatehouse.gov/code/t06c034.php | Code of Laws - Title 6 - Chapter 34- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c035 | 200 | 51314 | https://www.scstatehouse.gov/code/t06c035.php | Code of Laws - Title 6 - Chapter 35- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t06c037 | 200 | 41244 | https://www.scstatehouse.gov/code/t06c037.php | Code of Laws - Title 6 - Chapter 37- - LOCAL GOVERNMENT—PROVISIONS APPLICABLE TO |  |
| SC_t07c001 | 200 | 34541 | https://www.scstatehouse.gov/code/t07c001.php | Code of Laws - Title 7 - Chapter 1- - ELECTIONS |  |
| SC_t07c003 | 200 | 50444 | https://www.scstatehouse.gov/code/t07c003.php | Code of Laws - Title 7 - Chapter 3- - ELECTIONS |  |
| SC_t07c005 | 200 | 91515 | https://www.scstatehouse.gov/code/t07c005.php | Code of Laws - Title 7 - Chapter 5- - ELECTIONS |  |
| SC_t07c007 | 200 | 188679 | https://www.scstatehouse.gov/code/t07c007.php | Code of Laws - Title 7 - Chapter 7- - ELECTIONS |  |
| SC_t07c009 | 200 | 33566 | https://www.scstatehouse.gov/code/t07c009.php | Code of Laws - Title 7 - Chapter 9- - ELECTIONS |  |
| SC_t07c011 | 200 | 73808 | https://www.scstatehouse.gov/code/t07c011.php | Code of Laws - Title 7 - Chapter 11- - ELECTIONS |  |
| SC_t07c013 | 200 | 229975 | https://www.scstatehouse.gov/code/t07c013.php | Code of Laws - Title 7 - Chapter 13- - ELECTIONS |  |
| SC_t07c015 | 200 | 94534 | https://www.scstatehouse.gov/code/t07c015.php | Code of Laws - Title 7 - Chapter 15- - ELECTIONS |  |
| SC_t07c017 | 200 | 60026 | https://www.scstatehouse.gov/code/t07c017.php | Code of Laws - Title 7 - Chapter 17- - ELECTIONS |  |
| SC_t07c019 | 200 | 218700 | https://www.scstatehouse.gov/code/t07c019.php | Code of Laws - Title 7 - Chapter 19- - ELECTIONS |  |
| SC_t07c021 | 200 | 20681 | https://www.scstatehouse.gov/code/t07c021.php | Code of Laws - Title 7 - Chapter 21- - ELECTIONS |  |
| SC_t07c023 | 200 | 21601 | https://www.scstatehouse.gov/code/t07c023.php | Code of Laws - Title 7 - Chapter 23- - ELECTIONS |  |
| SC_t07c025 | 200 | 40580 | https://www.scstatehouse.gov/code/t07c025.php | Code of Laws - Title 7 - Chapter 25- - ELECTIONS |  |
| SC_t08c001 | 200 | 42214 | https://www.scstatehouse.gov/code/t08c001.php | Code of Laws - Title 8 - Chapter 1- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c003 | 200 | 41441 | https://www.scstatehouse.gov/code/t08c003.php | Code of Laws - Title 8 - Chapter 3- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c005 | 200 | 22952 | https://www.scstatehouse.gov/code/t08c005.php | Code of Laws - Title 8 - Chapter 5- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c007 | 200 | 29563 | https://www.scstatehouse.gov/code/t08c007.php | Code of Laws - Title 8 - Chapter 7- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c009 | 200 | 24159 | https://www.scstatehouse.gov/code/t08c009.php | Code of Laws - Title 8 - Chapter 9- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c011 | 200 | 157449 | https://www.scstatehouse.gov/code/t08c011.php | Code of Laws - Title 8 - Chapter 11- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c012 | 200 | 26989 | https://www.scstatehouse.gov/code/t08c012.php | Code of Laws - Title 8 - Chapter 12- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c013 | 200 | 260836 | https://www.scstatehouse.gov/code/t08c013.php | Code of Laws - Title 8 - Chapter 13- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c014 | 200 | 27978 | https://www.scstatehouse.gov/code/t08c014.php | Code of Laws - Title 8 - Chapter 14- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c015 | 200 | 33308 | https://www.scstatehouse.gov/code/t08c015.php | Code of Laws - Title 8 - Chapter 15- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c017 | 200 | 66321 | https://www.scstatehouse.gov/code/t08c017.php | Code of Laws - Title 8 - Chapter 17- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c019 | 200 | 19997 | https://www.scstatehouse.gov/code/t08c019.php | Code of Laws - Title 8 - Chapter 19- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c021 | 200 | 74941 | https://www.scstatehouse.gov/code/t08c021.php | Code of Laws - Title 8 - Chapter 21- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c023 | 200 | 29075 | https://www.scstatehouse.gov/code/t08c023.php | Code of Laws - Title 8 - Chapter 23- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c025 | 200 | 24502 | https://www.scstatehouse.gov/code/t08c025.php | Code of Laws - Title 8 - Chapter 25- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c027 | 200 | 28304 | https://www.scstatehouse.gov/code/t08c027.php | Code of Laws - Title 8 - Chapter 27- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c029 | 200 | 27522 | https://www.scstatehouse.gov/code/t08c029.php | Code of Laws - Title 8 - Chapter 29- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t08c030 | 200 | 20212 | https://www.scstatehouse.gov/code/t08c030.php | Code of Laws - Title 8 - Chapter 30- - PUBLIC OFFICERS AND EMPLOYEES |  |
| SC_t09c001 | 200 | 245089 | https://www.scstatehouse.gov/code/t09c001.php | Code of Laws - Title 9 - Chapter 1- - RETIREMENT SYSTEMS |  |
| SC_t09c002 | 200 | 21166 | https://www.scstatehouse.gov/code/t09c002.php | Code of Laws - Title 9 - Chapter 2- - RETIREMENT SYSTEMS |  |
| SC_t09c003 | 200 | 47440 | https://www.scstatehouse.gov/code/t09c003.php | Code of Laws - Title 9 - Chapter 3- - RETIREMENT SYSTEMS |  |
| SC_t09c004 | 200 | 36654 | https://www.scstatehouse.gov/code/t09c004.php | Code of Laws - Title 9 - Chapter 4- - RETIREMENT SYSTEMS |  |
| SC_t09c005 | 200 | 40499 | https://www.scstatehouse.gov/code/t09c005.php | Code of Laws - Title 9 - Chapter 5- - RETIREMENT SYSTEMS |  |
| SC_t09c008 | 200 | 104111 | https://www.scstatehouse.gov/code/t09c008.php | Code of Laws - Title 9 - Chapter 8- - RETIREMENT SYSTEMS |  |
| SC_t09c009 | 200 | 96760 | https://www.scstatehouse.gov/code/t09c009.php | Code of Laws - Title 9 - Chapter 9- - RETIREMENT SYSTEMS |  |
| SC_t09c010 | 200 | 28044 | https://www.scstatehouse.gov/code/t09c010.php | Code of Laws - Title 9 - Chapter 10- - RETIREMENT SYSTEMS |  |
| SC_t09c011 | 200 | 196220 | https://www.scstatehouse.gov/code/t09c011.php | Code of Laws - Title 9 - Chapter 11- - RETIREMENT SYSTEMS |  |
| SC_t09c012 | 200 | 28144 | https://www.scstatehouse.gov/code/t09c012.php | Code of Laws - Title 9 - Chapter 12- - RETIREMENT SYSTEMS |  |
| SC_t09c013 | 200 | 40005 | https://www.scstatehouse.gov/code/t09c013.php | Code of Laws - Title 9 - Chapter 13- - RETIREMENT SYSTEMS |  |
| SC_t09c015 | 200 | 20942 | https://www.scstatehouse.gov/code/t09c015.php | Code of Laws - Title 9 - Chapter 15- - RETIREMENT SYSTEMS |  |
| SC_t09c016 | 200 | 81137 | https://www.scstatehouse.gov/code/t09c016.php | Code of Laws - Title 9 - Chapter 16- - RETIREMENT SYSTEMS |  |
| SC_t09c018 | 200 | 38700 | https://www.scstatehouse.gov/code/t09c018.php | Code of Laws - Title 9 - Chapter 18- - RETIREMENT SYSTEMS |  |
| SC_t09c020 | 200 | 31372 | https://www.scstatehouse.gov/code/t09c020.php | Code of Laws - Title 9 - Chapter 20- - RETIREMENT SYSTEMS |  |
| SC_t09c021 | 200 | 29042 | https://www.scstatehouse.gov/code/t09c021.php | Code of Laws - Title 9 - Chapter 21- - RETIREMENT SYSTEMS |  |
| SC_t10c001 | 200 | 100829 | https://www.scstatehouse.gov/code/t10c001.php | Code of Laws - Title 10 - Chapter 1- - PUBLIC BUILDINGS AND PROPERTY |  |
| SC_t10c003 | 200 | 24821 | https://www.scstatehouse.gov/code/t10c003.php | Code of Laws - Title 10 - Chapter 3- - PUBLIC BUILDINGS AND PROPERTY |  |
| SC_t10c005 | 200 | 33868 | https://www.scstatehouse.gov/code/t10c005.php | Code of Laws - Title 10 - Chapter 5- - PUBLIC BUILDINGS AND PROPERTY |  |
| SC_t10c007 | 200 | 45178 | https://www.scstatehouse.gov/code/t10c007.php | Code of Laws - Title 10 - Chapter 7- - PUBLIC BUILDINGS AND PROPERTY |  |
| SC_t10c009 | 200 | 49495 | https://www.scstatehouse.gov/code/t10c009.php | Code of Laws - Title 10 - Chapter 9- - PUBLIC BUILDINGS AND PROPERTY |  |
| SC_t10c011 | 200 | 40232 | https://www.scstatehouse.gov/code/t10c011.php | Code of Laws - Title 10 - Chapter 11- - PUBLIC BUILDINGS AND PROPERTY |  |
| SC_t11c001 | 200 | 39762 | https://www.scstatehouse.gov/code/t11c001.php | Code of Laws - Title 11 - Chapter 1- - PUBLIC FINANCE |  |
| SC_t11c003 | 200 | 34590 | https://www.scstatehouse.gov/code/t11c003.php | Code of Laws - Title 11 - Chapter 3- - PUBLIC FINANCE |  |
| SC_t11c005 | 200 | 70962 | https://www.scstatehouse.gov/code/t11c005.php | Code of Laws - Title 11 - Chapter 5- - PUBLIC FINANCE |  |
| SC_t11c007 | 200 | 28109 | https://www.scstatehouse.gov/code/t11c007.php | Code of Laws - Title 11 - Chapter 7- - PUBLIC FINANCE |  |
| SC_t11c009 | 200 | 98976 | https://www.scstatehouse.gov/code/t11c009.php | Code of Laws - Title 11 - Chapter 9- - PUBLIC FINANCE |  |
| SC_t11c011 | 200 | 97687 | https://www.scstatehouse.gov/code/t11c011.php | Code of Laws - Title 11 - Chapter 11- - PUBLIC FINANCE |  |
| SC_t11c013 | 200 | 37952 | https://www.scstatehouse.gov/code/t11c013.php | Code of Laws - Title 11 - Chapter 13- - PUBLIC FINANCE |  |
| SC_t11c014 | 200 | 22479 | https://www.scstatehouse.gov/code/t11c014.php | Code of Laws - Title 11 - Chapter 14- - PUBLIC FINANCE |  |
| SC_t11c015 | 200 | 46944 | https://www.scstatehouse.gov/code/t11c015.php | Code of Laws - Title 11 - Chapter 15- - PUBLIC FINANCE |  |
| SC_t11c017 | 200 | 28172 | https://www.scstatehouse.gov/code/t11c017.php | Code of Laws - Title 11 - Chapter 17- - PUBLIC FINANCE |  |
| SC_t11c018 | 200 | 33942 | https://www.scstatehouse.gov/code/t11c018.php | Code of Laws - Title 11 - Chapter 18- - PUBLIC FINANCE |  |
| SC_t11c019 | 200 | 24427 | https://www.scstatehouse.gov/code/t11c019.php | Code of Laws - Title 11 - Chapter 19- - PUBLIC FINANCE |  |
| SC_t11c021 | 200 | 27953 | https://www.scstatehouse.gov/code/t11c021.php | Code of Laws - Title 11 - Chapter 21- - PUBLIC FINANCE |  |
| SC_t11c023 | 200 | 25039 | https://www.scstatehouse.gov/code/t11c023.php | Code of Laws - Title 11 - Chapter 23- - PUBLIC FINANCE |  |
| SC_t11c025 | 200 | 35956 | https://www.scstatehouse.gov/code/t11c025.php | Code of Laws - Title 11 - Chapter 25- - PUBLIC FINANCE |  |
| SC_t11c027 | 200 | 57021 | https://www.scstatehouse.gov/code/t11c027.php | Code of Laws - Title 11 - Chapter 27- - PUBLIC FINANCE |  |
| SC_t11c029 | 200 | 24215 | https://www.scstatehouse.gov/code/t11c029.php | Code of Laws - Title 11 - Chapter 29- - PUBLIC FINANCE |  |
| SC_t11c031 | 200 | 22845 | https://www.scstatehouse.gov/code/t11c031.php | Code of Laws - Title 11 - Chapter 31- - PUBLIC FINANCE |  |
| SC_t11c035 | 200 | 376569 | https://www.scstatehouse.gov/code/t11c035.php | Code of Laws - Title 11 - Chapter 35- - PUBLIC FINANCE |  |
| SC_t11c037 | 200 | 59102 | https://www.scstatehouse.gov/code/t11c037.php | Code of Laws - Title 11 - Chapter 37- - PUBLIC FINANCE |  |
| SC_t11c038 | 200 | 22576 | https://www.scstatehouse.gov/code/t11c038.php | Code of Laws - Title 11 - Chapter 38- - PUBLIC FINANCE |  |
| SC_t11c039 | 200 | 23335 | https://www.scstatehouse.gov/code/t11c039.php | Code of Laws - Title 11 - Chapter 39- - PUBLIC FINANCE |  |
| SC_t11c040 | 200 | 64354 | https://www.scstatehouse.gov/code/t11c040.php | Code of Laws - Title 11 - Chapter 40- - PUBLIC FINANCE |  |
| SC_t11c041 | 200 | 61949 | https://www.scstatehouse.gov/code/t11c041.php | Code of Laws - Title 11 - Chapter 41- - PUBLIC FINANCE |  |
| SC_t11c042 | 200 | 33635 | https://www.scstatehouse.gov/code/t11c042.php | Code of Laws - Title 11 - Chapter 42- - PUBLIC FINANCE |  |
| SC_t11c043 | 200 | 79975 | https://www.scstatehouse.gov/code/t11c043.php | Code of Laws - Title 11 - Chapter 43- - PUBLIC FINANCE |  |
| SC_t11c044 | 200 | 47940 | https://www.scstatehouse.gov/code/t11c044.php | Code of Laws - Title 11 - Chapter 44- - PUBLIC FINANCE |  |
| SC_t11c045 | 200 | 50375 | https://www.scstatehouse.gov/code/t11c045.php | Code of Laws - Title 11 - Chapter 45- - PUBLIC FINANCE |  |
| SC_t11c046 | 200 | 27096 | https://www.scstatehouse.gov/code/t11c046.php | Code of Laws - Title 11 - Chapter 46- - PUBLIC FINANCE |  |
| SC_t11c047 | 200 | 31498 | https://www.scstatehouse.gov/code/t11c047.php | Code of Laws - Title 11 - Chapter 47- - PUBLIC FINANCE |  |
| SC_t11c048 | 200 | 45040 | https://www.scstatehouse.gov/code/t11c048.php | Code of Laws - Title 11 - Chapter 48- - PUBLIC FINANCE |  |
| SC_t11c049 | 200 | 47490 | https://www.scstatehouse.gov/code/t11c049.php | Code of Laws - Title 11 - Chapter 49- - PUBLIC FINANCE |  |
| SC_t11c050 | 200 | 45785 | https://www.scstatehouse.gov/code/t11c050.php | Code of Laws - Title 11 - Chapter 50- - PUBLIC FINANCE |  |
| SC_t11c051 | 200 | 26127 | https://www.scstatehouse.gov/code/t11c051.php | Code of Laws - Title 11 - Chapter 51- - PUBLIC FINANCE |  |
| SC_t11c053 | 200 | 24654 | https://www.scstatehouse.gov/code/t11c053.php | Code of Laws - Title 11 - Chapter 53- - PUBLIC FINANCE |  |
| SC_t11c055 | 200 | 23753 | https://www.scstatehouse.gov/code/t11c055.php | Code of Laws - Title 11 - Chapter 55- - PUBLIC FINANCE |  |
| SC_t11c056 | 200 | 34043 | https://www.scstatehouse.gov/code/t11c056.php | Code of Laws - Title 11 - Chapter 56- - PUBLIC FINANCE |  |
| SC_t11c057 | 200 | 44409 | https://www.scstatehouse.gov/code/t11c057.php | Code of Laws - Title 11 - Chapter 57- - PUBLIC FINANCE |  |
| SC_t11c058 | 200 | 44839 | https://www.scstatehouse.gov/code/t11c058.php | Code of Laws - Title 11 - Chapter 58- - PUBLIC FINANCE |  |
| SC_t11c060 | 200 | 30444 | https://www.scstatehouse.gov/code/t11c060.php | Code of Laws - Title 11 - Chapter 60- - PUBLIC FINANCE |  |
| SC_t12c002 | 200 | 48087 | https://www.scstatehouse.gov/code/t12c002.php | Code of Laws - Title 12 - Chapter 2- - TAXATION |  |
| SC_t12c003 | 200 | 28225 | https://www.scstatehouse.gov/code/t12c003.php | Code of Laws - Title 12 - Chapter 3- - TAXATION |  |
| SC_t12c004 | 200 | 63528 | https://www.scstatehouse.gov/code/t12c004.php | Code of Laws - Title 12 - Chapter 4- - TAXATION |  |
| SC_t12c006 | 200 | 587989 | https://www.scstatehouse.gov/code/t12c006.php | Code of Laws - Title 12 - Chapter 6- - TAXATION |  |
| SC_t12c008 | 200 | 71631 | https://www.scstatehouse.gov/code/t12c008.php | Code of Laws - Title 12 - Chapter 8- - TAXATION |  |
| SC_t12c010 | 200 | 90301 | https://www.scstatehouse.gov/code/t12c010.php | Code of Laws - Title 12 - Chapter 10- - TAXATION |  |
| SC_t12c011 | 200 | 23178 | https://www.scstatehouse.gov/code/t12c011.php | Code of Laws - Title 12 - Chapter 11- - TAXATION |  |
| SC_t12c013 | 200 | 26352 | https://www.scstatehouse.gov/code/t12c013.php | Code of Laws - Title 12 - Chapter 13- - TAXATION |  |
| SC_t12c014 | 200 | 40387 | https://www.scstatehouse.gov/code/t12c014.php | Code of Laws - Title 12 - Chapter 14- - TAXATION |  |
| SC_t12c015 | 200 | 24088 | https://www.scstatehouse.gov/code/t12c015.php | Code of Laws - Title 12 - Chapter 15- - TAXATION |  |
| SC_t12c016 | 200 | 59485 | https://www.scstatehouse.gov/code/t12c016.php | Code of Laws - Title 12 - Chapter 16- - TAXATION |  |
| SC_t12c020 | 200 | 51363 | https://www.scstatehouse.gov/code/t12c020.php | Code of Laws - Title 12 - Chapter 20- - TAXATION |  |
| SC_t12c021 | 200 | 250306 | https://www.scstatehouse.gov/code/t12c021.php | Code of Laws - Title 12 - Chapter 21- - TAXATION |  |
| SC_t12c022 | 200 | 54742 | https://www.scstatehouse.gov/code/t12c022.php | Code of Laws - Title 12 - Chapter 22- - TAXATION |  |
| SC_t12c023 | 200 | 46240 | https://www.scstatehouse.gov/code/t12c023.php | Code of Laws - Title 12 - Chapter 23- - TAXATION |  |
| SC_t12c024 | 200 | 41366 | https://www.scstatehouse.gov/code/t12c024.php | Code of Laws - Title 12 - Chapter 24- - TAXATION |  |
| SC_t12c028 | 200 | 256198 | https://www.scstatehouse.gov/code/t12c028.php | Code of Laws - Title 12 - Chapter 28- - TAXATION |  |
| SC_t12c033 | 200 | 47966 | https://www.scstatehouse.gov/code/t12c033.php | Code of Laws - Title 12 - Chapter 33- - TAXATION |  |
| SC_t12c035 | 200 | 32300 | https://www.scstatehouse.gov/code/t12c035.php | Code of Laws - Title 12 - Chapter 35- - TAXATION |  |
| SC_t12c036 | 200 | 227902 | https://www.scstatehouse.gov/code/t12c036.php | Code of Laws - Title 12 - Chapter 36- - TAXATION |  |
| SC_t12c037 | 200 | 364313 | https://www.scstatehouse.gov/code/t12c037.php | Code of Laws - Title 12 - Chapter 37- - TAXATION |  |
| SC_t12c039 | 200 | 50594 | https://www.scstatehouse.gov/code/t12c039.php | Code of Laws - Title 12 - Chapter 39- - TAXATION |  |
| SC_t12c043 | 200 | 118237 | https://www.scstatehouse.gov/code/t12c043.php | Code of Laws - Title 12 - Chapter 43- - TAXATION |  |
| SC_t12c044 | 200 | 74728 | https://www.scstatehouse.gov/code/t12c044.php | Code of Laws - Title 12 - Chapter 44- - TAXATION |  |
| SC_t12c045 | 200 | 60856 | https://www.scstatehouse.gov/code/t12c045.php | Code of Laws - Title 12 - Chapter 45- - TAXATION |  |
| SC_t12c049 | 200 | 65282 | https://www.scstatehouse.gov/code/t12c049.php | Code of Laws - Title 12 - Chapter 49- - TAXATION |  |
| SC_t12c051 | 200 | 49258 | https://www.scstatehouse.gov/code/t12c051.php | Code of Laws - Title 12 - Chapter 51- - TAXATION |  |
| SC_t12c053 | 200 | 25657 | https://www.scstatehouse.gov/code/t12c053.php | Code of Laws - Title 12 - Chapter 53- - TAXATION |  |
| SC_t12c054 | 200 | 135979 | https://www.scstatehouse.gov/code/t12c054.php | Code of Laws - Title 12 - Chapter 54- - TAXATION |  |
| SC_t12c055 | 200 | 24297 | https://www.scstatehouse.gov/code/t12c055.php | Code of Laws - Title 12 - Chapter 55- - TAXATION |  |
| SC_t12c056 | 200 | 39189 | https://www.scstatehouse.gov/code/t12c056.php | Code of Laws - Title 12 - Chapter 56- - TAXATION |  |
| SC_t12c057 | 200 | 25055 | https://www.scstatehouse.gov/code/t12c057.php | Code of Laws - Title 12 - Chapter 57- - TAXATION |  |
| SC_t12c058 | 200 | 36000 | https://www.scstatehouse.gov/code/t12c058.php | Code of Laws - Title 12 - Chapter 58- - TAXATION |  |
| SC_t12c059 | 200 | 46240 | https://www.scstatehouse.gov/code/t12c059.php | Code of Laws - Title 12 - Chapter 59- - TAXATION |  |
| SC_t12c060 | 200 | 138399 | https://www.scstatehouse.gov/code/t12c060.php | Code of Laws - Title 12 - Chapter 60- - TAXATION |  |
| SC_t12c061 | 200 | 23756 | https://www.scstatehouse.gov/code/t12c061.php | Code of Laws - Title 12 - Chapter 61- - TAXATION |  |
| SC_t12c062 | 200 | 44235 | https://www.scstatehouse.gov/code/t12c062.php | Code of Laws - Title 12 - Chapter 62- - TAXATION |  |
| SC_t12c063 | 200 | 24440 | https://www.scstatehouse.gov/code/t12c063.php | Code of Laws - Title 12 - Chapter 63- - TAXATION |  |
| SC_t12c065 | 200 | 41625 | https://www.scstatehouse.gov/code/t12c065.php | Code of Laws - Title 12 - Chapter 65- - TAXATION |  |
| SC_t12c067 | 200 | 56859 | https://www.scstatehouse.gov/code/t12c067.php | Code of Laws - Title 12 - Chapter 67- - TAXATION |  |
| SC_t12c069 | 200 | 23604 | https://www.scstatehouse.gov/code/t12c069.php | Code of Laws - Title 12 - Chapter 69- - TAXATION |  |
| SC_t13c001 | 200 | 168954 | https://www.scstatehouse.gov/code/t13c001.php | Code of Laws - Title 13 - Chapter 1- - PLANNING, RESEARCH AND DEVELOPMENT |  |
| SC_t13c002 | 200 | 21101 | https://www.scstatehouse.gov/code/t13c002.php | Code of Laws - Title 13 - Chapter 2- - PLANNING, RESEARCH AND DEVELOPMENT |  |
| SC_t13c007 | 200 | 141535 | https://www.scstatehouse.gov/code/t13c007.php | Code of Laws - Title 13 - Chapter 7- - PLANNING, RESEARCH AND DEVELOPMENT |  |
| SC_t13c011 | 200 | 39077 | https://www.scstatehouse.gov/code/t13c011.php | Code of Laws - Title 13 - Chapter 11- - PLANNING, RESEARCH AND DEVELOPMENT |  |
| SC_t13c012 | 200 | 51897 | https://www.scstatehouse.gov/code/t13c012.php | Code of Laws - Title 13 - Chapter 12- - PLANNING, RESEARCH AND DEVELOPMENT |  |
| SC_t13c013 | 200 | 40798 | https://www.scstatehouse.gov/code/t13c013.php | Code of Laws - Title 13 - Chapter 13- - PLANNING, RESEARCH AND DEVELOPMENT |  |
| SC_t13c015 | 200 | 23449 | https://www.scstatehouse.gov/code/t13c015.php | Code of Laws - Title 13 - Chapter 15- - PLANNING, RESEARCH AND DEVELOPMENT |  |
| SC_t13c017 | 200 | 62205 | https://www.scstatehouse.gov/code/t13c017.php | Code of Laws - Title 13 - Chapter 17- - PLANNING, RESEARCH AND DEVELOPMENT |  |
| SC_t13c019 | 200 | 54336 | https://www.scstatehouse.gov/code/t13c019.php | Code of Laws - Title 13 - Chapter 19- - PLANNING, RESEARCH AND DEVELOPMENT |  |
| SC_t13c021 | 200 | 53421 | https://www.scstatehouse.gov/code/t13c021.php | Code of Laws - Title 13 - Chapter 21- - PLANNING, RESEARCH AND DEVELOPMENT |  |
| SC_t14c001 | 200 | 117458 | https://www.scstatehouse.gov/code/t14c001.php | Code of Laws - Title 14 - Chapter 1- - COURTS |  |
| SC_t14c002 | 200 | 26827 | https://www.scstatehouse.gov/code/t14c002.php | Code of Laws - Title 14 - Chapter 2- - COURTS |  |
| SC_t14c003 | 200 | 57261 | https://www.scstatehouse.gov/code/t14c003.php | Code of Laws - Title 14 - Chapter 3- - COURTS |  |
| SC_t14c005 | 200 | 110613 | https://www.scstatehouse.gov/code/t14c005.php | Code of Laws - Title 14 - Chapter 5- - COURTS |  |
| SC_t14c007 | 200 | 177307 | https://www.scstatehouse.gov/code/t14c007.php | Code of Laws - Title 14 - Chapter 7- - COURTS |  |
| SC_t14c008 | 200 | 46577 | https://www.scstatehouse.gov/code/t14c008.php | Code of Laws - Title 14 - Chapter 8- - COURTS |  |
| SC_t14c009 | 200 | 42535 | https://www.scstatehouse.gov/code/t14c009.php | Code of Laws - Title 14 - Chapter 9- - COURTS |  |
| SC_t14c011 | 200 | 42583 | https://www.scstatehouse.gov/code/t14c011.php | Code of Laws - Title 14 - Chapter 11- - COURTS |  |
| SC_t14c013 | 200 | 21466 | https://www.scstatehouse.gov/code/t14c013.php | Code of Laws - Title 14 - Chapter 13- - COURTS |  |
| SC_t14c015 | 200 | 28651 | https://www.scstatehouse.gov/code/t14c015.php | Code of Laws - Title 14 - Chapter 15- - COURTS |  |
| SC_t14c017 | 200 | 65744 | https://www.scstatehouse.gov/code/t14c017.php | Code of Laws - Title 14 - Chapter 17- - COURTS |  |
| SC_t14c023 | 200 | 62462 | https://www.scstatehouse.gov/code/t14c023.php | Code of Laws - Title 14 - Chapter 23- - COURTS |  |
| SC_t14c025 | 200 | 49464 | https://www.scstatehouse.gov/code/t14c025.php | Code of Laws - Title 14 - Chapter 25- - COURTS |  |
| SC_t14c027 | 200 | 30540 | https://www.scstatehouse.gov/code/t14c027.php | Code of Laws - Title 14 - Chapter 27- - COURTS |  |
| SC_t14c029 | 200 | 21094 | https://www.scstatehouse.gov/code/t14c029.php | Code of Laws - Title 14 - Chapter 29- - COURTS |  |
| SC_t14c031 | 200 | 23968 | https://www.scstatehouse.gov/code/t14c031.php | Code of Laws - Title 14 - Chapter 31- - COURTS |  |
| SC_t15c001 | 200 | 37031 | https://www.scstatehouse.gov/code/t15c001.php | Code of Laws - Title 15 - Chapter 1- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c003 | 200 | 68578 | https://www.scstatehouse.gov/code/t15c003.php | Code of Laws - Title 15 - Chapter 3- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c005 | 200 | 27904 | https://www.scstatehouse.gov/code/t15c005.php | Code of Laws - Title 15 - Chapter 5- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c007 | 200 | 39174 | https://www.scstatehouse.gov/code/t15c007.php | Code of Laws - Title 15 - Chapter 7- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c009 | 200 | 76160 | https://www.scstatehouse.gov/code/t15c009.php | Code of Laws - Title 15 - Chapter 9- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c011 | 200 | 25093 | https://www.scstatehouse.gov/code/t15c011.php | Code of Laws - Title 15 - Chapter 11- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c017 | 200 | 61291 | https://www.scstatehouse.gov/code/t15c017.php | Code of Laws - Title 15 - Chapter 17- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c019 | 200 | 66714 | https://www.scstatehouse.gov/code/t15c019.php | Code of Laws - Title 15 - Chapter 19- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c027 | 200 | 24799 | https://www.scstatehouse.gov/code/t15c027.php | Code of Laws - Title 15 - Chapter 27- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c028 | 200 | 20078 | https://www.scstatehouse.gov/code/t15c028.php | Code of Laws - Title 15 - Chapter 28- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c029 | 200 | 28615 | https://www.scstatehouse.gov/code/t15c029.php | Code of Laws - Title 15 - Chapter 29- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c031 | 200 | 20524 | https://www.scstatehouse.gov/code/t15c031.php | Code of Laws - Title 15 - Chapter 31- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c032 | 200 | 41832 | https://www.scstatehouse.gov/code/t15c032.php | Code of Laws - Title 15 - Chapter 32- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c033 | 200 | 20403 | https://www.scstatehouse.gov/code/t15c033.php | Code of Laws - Title 15 - Chapter 33- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c035 | 200 | 52699 | https://www.scstatehouse.gov/code/t15c035.php | Code of Laws - Title 15 - Chapter 35- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c036 | 200 | 37370 | https://www.scstatehouse.gov/code/t15c036.php | Code of Laws - Title 15 - Chapter 36- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c037 | 200 | 33997 | https://www.scstatehouse.gov/code/t15c037.php | Code of Laws - Title 15 - Chapter 37- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c038 | 200 | 36889 | https://www.scstatehouse.gov/code/t15c038.php | Code of Laws - Title 15 - Chapter 38- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c039 | 200 | 77469 | https://www.scstatehouse.gov/code/t15c039.php | Code of Laws - Title 15 - Chapter 39- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c041 | 200 | 34231 | https://www.scstatehouse.gov/code/t15c041.php | Code of Laws - Title 15 - Chapter 41- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c043 | 200 | 30975 | https://www.scstatehouse.gov/code/t15c043.php | Code of Laws - Title 15 - Chapter 43- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c047 | 200 | 26023 | https://www.scstatehouse.gov/code/t15c047.php | Code of Laws - Title 15 - Chapter 47- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c048 | 200 | 39454 | https://www.scstatehouse.gov/code/t15c048.php | Code of Laws - Title 15 - Chapter 48- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c049 | 200 | 30167 | https://www.scstatehouse.gov/code/t15c049.php | Code of Laws - Title 15 - Chapter 49- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c050 | 200 | 68746 | https://www.scstatehouse.gov/code/t15c050.php | Code of Laws - Title 15 - Chapter 50- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c051 | 200 | 32683 | https://www.scstatehouse.gov/code/t15c051.php | Code of Laws - Title 15 - Chapter 51- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c053 | 200 | 26915 | https://www.scstatehouse.gov/code/t15c053.php | Code of Laws - Title 15 - Chapter 53- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c061 | 200 | 59572 | https://www.scstatehouse.gov/code/t15c061.php | Code of Laws - Title 15 - Chapter 61- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c063 | 200 | 35348 | https://www.scstatehouse.gov/code/t15c063.php | Code of Laws - Title 15 - Chapter 63- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c065 | 200 | 31404 | https://www.scstatehouse.gov/code/t15c065.php | Code of Laws - Title 15 - Chapter 65- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c067 | 200 | 55776 | https://www.scstatehouse.gov/code/t15c067.php | Code of Laws - Title 15 - Chapter 67- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c069 | 200 | 38571 | https://www.scstatehouse.gov/code/t15c069.php | Code of Laws - Title 15 - Chapter 69- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c072 | 200 | 20077 | https://www.scstatehouse.gov/code/t15c072.php | Code of Laws - Title 15 - Chapter 72- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c073 | 200 | 22253 | https://www.scstatehouse.gov/code/t15c073.php | Code of Laws - Title 15 - Chapter 73- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c074 | 200 | 23638 | https://www.scstatehouse.gov/code/t15c074.php | Code of Laws - Title 15 - Chapter 74- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c075 | 200 | 54372 | https://www.scstatehouse.gov/code/t15c075.php | Code of Laws - Title 15 - Chapter 75- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c077 | 200 | 29355 | https://www.scstatehouse.gov/code/t15c077.php | Code of Laws - Title 15 - Chapter 77- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c078 | 200 | 73274 | https://www.scstatehouse.gov/code/t15c078.php | Code of Laws - Title 15 - Chapter 78- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c079 | 200 | 29049 | https://www.scstatehouse.gov/code/t15c079.php | Code of Laws - Title 15 - Chapter 79- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c081 | 200 | 28991 | https://www.scstatehouse.gov/code/t15c081.php | Code of Laws - Title 15 - Chapter 81- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t15c082 | 200 | 22128 | https://www.scstatehouse.gov/code/t15c082.php | Code of Laws - Title 15 - Chapter 82- - CIVIL REMEDIES AND PROCEDURES |  |
| SC_t16c001 | 200 | 355773 | https://www.scstatehouse.gov/code/t16c001.php | Code of Laws - Title 16 - Chapter 1- - CRIMES AND OFFENSES |  |
| SC_t16c003 | 200 | 377935 | https://www.scstatehouse.gov/code/t16c003.php | Code of Laws - Title 16 - Chapter 3- - CRIMES AND OFFENSES |  |
| SC_t16c005 | 200 | 33769 | https://www.scstatehouse.gov/code/t16c005.php | Code of Laws - Title 16 - Chapter 5- - CRIMES AND OFFENSES |  |
| SC_t16c007 | 200 | 29625 | https://www.scstatehouse.gov/code/t16c007.php | Code of Laws - Title 16 - Chapter 7- - CRIMES AND OFFENSES |  |
| SC_t16c008 | 200 | 51907 | https://www.scstatehouse.gov/code/t16c008.php | Code of Laws - Title 16 - Chapter 8- - CRIMES AND OFFENSES |  |
| SC_t16c009 | 200 | 49450 | https://www.scstatehouse.gov/code/t16c009.php | Code of Laws - Title 16 - Chapter 9- - CRIMES AND OFFENSES |  |
| SC_t16c011 | 200 | 156712 | https://www.scstatehouse.gov/code/t16c011.php | Code of Laws - Title 16 - Chapter 11- - CRIMES AND OFFENSES |  |
| SC_t16c013 | 200 | 130136 | https://www.scstatehouse.gov/code/t16c013.php | Code of Laws - Title 16 - Chapter 13- - CRIMES AND OFFENSES |  |
| SC_t16c014 | 200 | 42054 | https://www.scstatehouse.gov/code/t16c014.php | Code of Laws - Title 16 - Chapter 14- - CRIMES AND OFFENSES |  |
| SC_t16c015 | 200 | 94909 | https://www.scstatehouse.gov/code/t16c015.php | Code of Laws - Title 16 - Chapter 15- - CRIMES AND OFFENSES |  |
| SC_t16c016 | 200 | 37925 | https://www.scstatehouse.gov/code/t16c016.php | Code of Laws - Title 16 - Chapter 16- - CRIMES AND OFFENSES |  |
| SC_t16c017 | 200 | 170460 | https://www.scstatehouse.gov/code/t16c017.php | Code of Laws - Title 16 - Chapter 17- - CRIMES AND OFFENSES |  |
| SC_t16c019 | 200 | 36290 | https://www.scstatehouse.gov/code/t16c019.php | Code of Laws - Title 16 - Chapter 19- - CRIMES AND OFFENSES |  |
| SC_t16c021 | 200 | 31154 | https://www.scstatehouse.gov/code/t16c021.php | Code of Laws - Title 16 - Chapter 21- - CRIMES AND OFFENSES |  |
| SC_t16c023 | 200 | 103446 | https://www.scstatehouse.gov/code/t16c023.php | Code of Laws - Title 16 - Chapter 23- - CRIMES AND OFFENSES |  |
| SC_t16c025 | 200 | 98385 | https://www.scstatehouse.gov/code/t16c025.php | Code of Laws - Title 16 - Chapter 25- - CRIMES AND OFFENSES |  |
| SC_t16c027 | 200 | 32803 | https://www.scstatehouse.gov/code/t16c027.php | Code of Laws - Title 16 - Chapter 27- - CRIMES AND OFFENSES |  |
| SC_t17c001 | 200 | 44138 | https://www.scstatehouse.gov/code/t17c001.php | Code of Laws - Title 17 - Chapter 1- - CRIMINAL PROCEDURES |  |
| SC_t17c003 | 200 | 73850 | https://www.scstatehouse.gov/code/t17c003.php | Code of Laws - Title 17 - Chapter 3- - CRIMINAL PROCEDURES |  |
| SC_t17c005 | 200 | 80310 | https://www.scstatehouse.gov/code/t17c005.php | Code of Laws - Title 17 - Chapter 5- - CRIMINAL PROCEDURES |  |
| SC_t17c007 | 200 | 61299 | https://www.scstatehouse.gov/code/t17c007.php | Code of Laws - Title 17 - Chapter 7- - CRIMINAL PROCEDURES |  |
| SC_t17c009 | 200 | 26235 | https://www.scstatehouse.gov/code/t17c009.php | Code of Laws - Title 17 - Chapter 9- - CRIMINAL PROCEDURES |  |
| SC_t17c011 | 200 | 38889 | https://www.scstatehouse.gov/code/t17c011.php | Code of Laws - Title 17 - Chapter 11- - CRIMINAL PROCEDURES |  |
| SC_t17c013 | 200 | 53806 | https://www.scstatehouse.gov/code/t17c013.php | Code of Laws - Title 17 - Chapter 13- - CRIMINAL PROCEDURES |  |
| SC_t17c015 | 200 | 72906 | https://www.scstatehouse.gov/code/t17c015.php | Code of Laws - Title 17 - Chapter 15- - CRIMINAL PROCEDURES |  |
| SC_t17c017 | 200 | 36177 | https://www.scstatehouse.gov/code/t17c017.php | Code of Laws - Title 17 - Chapter 17- - CRIMINAL PROCEDURES |  |
| SC_t17c019 | 200 | 28221 | https://www.scstatehouse.gov/code/t17c019.php | Code of Laws - Title 17 - Chapter 19- - CRIMINAL PROCEDURES |  |
| SC_t17c021 | 200 | 29649 | https://www.scstatehouse.gov/code/t17c021.php | Code of Laws - Title 17 - Chapter 21- - CRIMINAL PROCEDURES |  |
| SC_t17c022 | 200 | 90493 | https://www.scstatehouse.gov/code/t17c022.php | Code of Laws - Title 17 - Chapter 22- - CRIMINAL PROCEDURES |  |
| SC_t17c023 | 200 | 37171 | https://www.scstatehouse.gov/code/t17c023.php | Code of Laws - Title 17 - Chapter 23- - CRIMINAL PROCEDURES |  |
| SC_t17c024 | 200 | 30726 | https://www.scstatehouse.gov/code/t17c024.php | Code of Laws - Title 17 - Chapter 24- - CRIMINAL PROCEDURES |  |
| SC_t17c025 | 200 | 91576 | https://www.scstatehouse.gov/code/t17c025.php | Code of Laws - Title 17 - Chapter 25- - CRIMINAL PROCEDURES |  |
| SC_t17c027 | 200 | 39439 | https://www.scstatehouse.gov/code/t17c027.php | Code of Laws - Title 17 - Chapter 27- - CRIMINAL PROCEDURES |  |
| SC_t17c028 | 200 | 59214 | https://www.scstatehouse.gov/code/t17c028.php | Code of Laws - Title 17 - Chapter 28- - CRIMINAL PROCEDURES |  |
| SC_t17c029 | 200 | 29816 | https://www.scstatehouse.gov/code/t17c029.php | Code of Laws - Title 17 - Chapter 29- - CRIMINAL PROCEDURES |  |
| SC_t17c030 | 200 | 96361 | https://www.scstatehouse.gov/code/t17c030.php | Code of Laws - Title 17 - Chapter 30- - CRIMINAL PROCEDURES |  |
| SC_t18c001 | 200 | 28178 | https://www.scstatehouse.gov/code/t18c001.php | Code of Laws - Title 18 - Chapter 1- - APPEALS |  |
| SC_t18c003 | 200 | 24470 | https://www.scstatehouse.gov/code/t18c003.php | Code of Laws - Title 18 - Chapter 3- - APPEALS |  |
| SC_t18c007 | 200 | 40428 | https://www.scstatehouse.gov/code/t18c007.php | Code of Laws - Title 18 - Chapter 7- - APPEALS |  |
| SC_t18c009 | 200 | 38861 | https://www.scstatehouse.gov/code/t18c009.php | Code of Laws - Title 18 - Chapter 9- - APPEALS |  |
| SC_t19c001 | 200 | 66020 | https://www.scstatehouse.gov/code/t19c001.php | Code of Laws - Title 19 - Chapter 1- - EVIDENCE |  |
| SC_t19c003 | 200 | 23499 | https://www.scstatehouse.gov/code/t19c003.php | Code of Laws - Title 19 - Chapter 3- - EVIDENCE |  |
| SC_t19c005 | 200 | 36118 | https://www.scstatehouse.gov/code/t19c005.php | Code of Laws - Title 19 - Chapter 5- - EVIDENCE |  |
| SC_t19c007 | 200 | 21122 | https://www.scstatehouse.gov/code/t19c007.php | Code of Laws - Title 19 - Chapter 7- - EVIDENCE |  |
| SC_t19c009 | 200 | 28426 | https://www.scstatehouse.gov/code/t19c009.php | Code of Laws - Title 19 - Chapter 9- - EVIDENCE |  |
| SC_t19c011 | 200 | 32075 | https://www.scstatehouse.gov/code/t19c011.php | Code of Laws - Title 19 - Chapter 11- - EVIDENCE |  |
| SC_t19c021 | 200 | 24590 | https://www.scstatehouse.gov/code/t19c021.php | Code of Laws - Title 19 - Chapter 21- - EVIDENCE |  |
| SC_t20c001 | 200 | 60667 | https://www.scstatehouse.gov/code/t20c001.php | Code of Laws - Title 20 - Chapter 1- - DOMESTIC RELATIONS |  |
| SC_t20c003 | 200 | 70922 | https://www.scstatehouse.gov/code/t20c003.php | Code of Laws - Title 20 - Chapter 3- - DOMESTIC RELATIONS |  |
| SC_t20c004 | 200 | 51807 | https://www.scstatehouse.gov/code/t20c004.php | Code of Laws - Title 20 - Chapter 4- - DOMESTIC RELATIONS |  |
| SC_t20c005 | 200 | 25907 | https://www.scstatehouse.gov/code/t20c005.php | Code of Laws - Title 20 - Chapter 5- - DOMESTIC RELATIONS |  |
| SC_t20c007 | 200 | 19679 | https://www.scstatehouse.gov/code/t20c007.php | Code of Laws - Title 20 - Chapter 7- - DOMESTIC RELATIONS |  |
| SC_t21c021 | 200 | 22448 | https://www.scstatehouse.gov/code/t21c021.php | Code of Laws - Title 21 - Chapter 21- - ESTATES, TRUSTS, GUARDIANS AND FIDUCIARI |  |
| SC_t21c029 | 200 | 20656 | https://www.scstatehouse.gov/code/t21c029.php | Code of Laws - Title 21 - Chapter 29- - ESTATES, TRUSTS, GUARDIANS AND FIDUCIARI |  |
| SC_t22c001 | 200 | 51678 | https://www.scstatehouse.gov/code/t22c001.php | Code of Laws - Title 22 - Chapter 1- - MAGISTRATES AND CONSTABLES |  |
| SC_t22c002 | 200 | 61223 | https://www.scstatehouse.gov/code/t22c002.php | Code of Laws - Title 22 - Chapter 2- - MAGISTRATES AND CONSTABLES |  |
| SC_t22c003 | 200 | 85880 | https://www.scstatehouse.gov/code/t22c003.php | Code of Laws - Title 22 - Chapter 3- - MAGISTRATES AND CONSTABLES |  |
| SC_t22c005 | 200 | 74176 | https://www.scstatehouse.gov/code/t22c005.php | Code of Laws - Title 22 - Chapter 5- - MAGISTRATES AND CONSTABLES |  |
| SC_t22c007 | 200 | 20711 | https://www.scstatehouse.gov/code/t22c007.php | Code of Laws - Title 22 - Chapter 7- - MAGISTRATES AND CONSTABLES |  |
| SC_t22c008 | 200 | 31015 | https://www.scstatehouse.gov/code/t22c008.php | Code of Laws - Title 22 - Chapter 8- - MAGISTRATES AND CONSTABLES |  |
| SC_t22c009 | 200 | 36940 | https://www.scstatehouse.gov/code/t22c009.php | Code of Laws - Title 22 - Chapter 9- - MAGISTRATES AND CONSTABLES |  |
| SC_t23c001 | 200 | 50466 | https://www.scstatehouse.gov/code/t23c001.php | Code of Laws - Title 23 - Chapter 1- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c003 | 200 | 243474 | https://www.scstatehouse.gov/code/t23c003.php | Code of Laws - Title 23 - Chapter 3- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c004 | 200 | 34262 | https://www.scstatehouse.gov/code/t23c004.php | Code of Laws - Title 23 - Chapter 4- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c006 | 200 | 53197 | https://www.scstatehouse.gov/code/t23c006.php | Code of Laws - Title 23 - Chapter 6- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c007 | 200 | 24289 | https://www.scstatehouse.gov/code/t23c007.php | Code of Laws - Title 23 - Chapter 7- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c009 | 200 | 96879 | https://www.scstatehouse.gov/code/t23c009.php | Code of Laws - Title 23 - Chapter 9- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c010 | 200 | 23300 | https://www.scstatehouse.gov/code/t23c010.php | Code of Laws - Title 23 - Chapter 10- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c011 | 200 | 33064 | https://www.scstatehouse.gov/code/t23c011.php | Code of Laws - Title 23 - Chapter 11- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c013 | 200 | 44212 | https://www.scstatehouse.gov/code/t23c013.php | Code of Laws - Title 23 - Chapter 13- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c015 | 200 | 35426 | https://www.scstatehouse.gov/code/t23c015.php | Code of Laws - Title 23 - Chapter 15- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c017 | 200 | 31663 | https://www.scstatehouse.gov/code/t23c017.php | Code of Laws - Title 23 - Chapter 17- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c019 | 200 | 28960 | https://www.scstatehouse.gov/code/t23c019.php | Code of Laws - Title 23 - Chapter 19- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c020 | 200 | 25870 | https://www.scstatehouse.gov/code/t23c020.php | Code of Laws - Title 23 - Chapter 20- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c021 | 200 | 26190 | https://www.scstatehouse.gov/code/t23c021.php | Code of Laws - Title 23 - Chapter 21- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c023 | 200 | 87816 | https://www.scstatehouse.gov/code/t23c023.php | Code of Laws - Title 23 - Chapter 23- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c024 | 200 | 22547 | https://www.scstatehouse.gov/code/t23c024.php | Code of Laws - Title 23 - Chapter 24- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c025 | 200 | 25344 | https://www.scstatehouse.gov/code/t23c025.php | Code of Laws - Title 23 - Chapter 25- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c027 | 200 | 29913 | https://www.scstatehouse.gov/code/t23c027.php | Code of Laws - Title 23 - Chapter 27- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c028 | 200 | 35008 | https://www.scstatehouse.gov/code/t23c028.php | Code of Laws - Title 23 - Chapter 28- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c031 | 200 | 109594 | https://www.scstatehouse.gov/code/t23c031.php | Code of Laws - Title 23 - Chapter 31- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c033 | 200 | 21118 | https://www.scstatehouse.gov/code/t23c033.php | Code of Laws - Title 23 - Chapter 33- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c035 | 200 | 35543 | https://www.scstatehouse.gov/code/t23c035.php | Code of Laws - Title 23 - Chapter 35- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c036 | 200 | 41049 | https://www.scstatehouse.gov/code/t23c036.php | Code of Laws - Title 23 - Chapter 36- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c037 | 200 | 26823 | https://www.scstatehouse.gov/code/t23c037.php | Code of Laws - Title 23 - Chapter 37- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c039 | 200 | 46118 | https://www.scstatehouse.gov/code/t23c039.php | Code of Laws - Title 23 - Chapter 39- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c041 | 200 | 25945 | https://www.scstatehouse.gov/code/t23c041.php | Code of Laws - Title 23 - Chapter 41- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c043 | 200 | 42422 | https://www.scstatehouse.gov/code/t23c043.php | Code of Laws - Title 23 - Chapter 43- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c047 | 200 | 88829 | https://www.scstatehouse.gov/code/t23c047.php | Code of Laws - Title 23 - Chapter 47- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c049 | 200 | 33668 | https://www.scstatehouse.gov/code/t23c049.php | Code of Laws - Title 23 - Chapter 49- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c050 | 200 | 35858 | https://www.scstatehouse.gov/code/t23c050.php | Code of Laws - Title 23 - Chapter 50- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t23c051 | 200 | 44959 | https://www.scstatehouse.gov/code/t23c051.php | Code of Laws - Title 23 - Chapter 51- - LAW ENFORCEMENT AND PUBLIC SAFETY |  |
| SC_t24c001 | 200 | 51901 | https://www.scstatehouse.gov/code/t24c001.php | Code of Laws - Title 24 - Chapter 1- - CORRECTIONS, JAILS, PROBATIONS, PAROLES A |  |
| SC_t24c003 | 200 | 112382 | https://www.scstatehouse.gov/code/t24c003.php | Code of Laws - Title 24 - Chapter 3- - CORRECTIONS, JAILS, PROBATIONS, PAROLES A |  |
| SC_t24c005 | 200 | 49447 | https://www.scstatehouse.gov/code/t24c005.php | Code of Laws - Title 24 - Chapter 5- - CORRECTIONS, JAILS, PROBATIONS, PAROLES A |  |
| SC_t24c007 | 200 | 25773 | https://www.scstatehouse.gov/code/t24c007.php | Code of Laws - Title 24 - Chapter 7- - CORRECTIONS, JAILS, PROBATIONS, PAROLES A |  |
| SC_t24c009 | 200 | 30098 | https://www.scstatehouse.gov/code/t24c009.php | Code of Laws - Title 24 - Chapter 9- - CORRECTIONS, JAILS, PROBATIONS, PAROLES A |  |
| SC_t24c011 | 200 | 33229 | https://www.scstatehouse.gov/code/t24c011.php | Code of Laws - Title 24 - Chapter 11- - CORRECTIONS, JAILS, PROBATIONS, PAROLES  |  |
| SC_t24c013 | 200 | 132379 | https://www.scstatehouse.gov/code/t24c013.php | Code of Laws - Title 24 - Chapter 13- - CORRECTIONS, JAILS, PROBATIONS, PAROLES  |  |
| SC_t24c019 | 200 | 41628 | https://www.scstatehouse.gov/code/t24c019.php | Code of Laws - Title 24 - Chapter 19- - CORRECTIONS, JAILS, PROBATIONS, PAROLES  |  |
| SC_t24c021 | 200 | 186822 | https://www.scstatehouse.gov/code/t24c021.php | Code of Laws - Title 24 - Chapter 21- - CORRECTIONS, JAILS, PROBATIONS, PAROLES  |  |
| SC_t24c022 | 200 | 43533 | https://www.scstatehouse.gov/code/t24c022.php | Code of Laws - Title 24 - Chapter 22- - CORRECTIONS, JAILS, PROBATIONS, PAROLES  |  |
| SC_t24c023 | 200 | 30916 | https://www.scstatehouse.gov/code/t24c023.php | Code of Laws - Title 24 - Chapter 23- - CORRECTIONS, JAILS, PROBATIONS, PAROLES  |  |
| SC_t24c025 | 200 | 29825 | https://www.scstatehouse.gov/code/t24c025.php | Code of Laws - Title 24 - Chapter 25- - CORRECTIONS, JAILS, PROBATIONS, PAROLES  |  |
| SC_t24c026 | 200 | 27836 | https://www.scstatehouse.gov/code/t24c026.php | Code of Laws - Title 24 - Chapter 26- - CORRECTIONS, JAILS, PROBATIONS, PAROLES  |  |
| SC_t24c027 | 200 | 28581 | https://www.scstatehouse.gov/code/t24c027.php | Code of Laws - Title 24 - Chapter 27- - CORRECTIONS, JAILS, PROBATIONS, PAROLES  |  |
| SC_t24c028 | 200 | 28531 | https://www.scstatehouse.gov/code/t24c028.php | Code of Laws - Title 24 - Chapter 28- - CORRECTIONS, JAILS, PROBATIONS, PAROLES  |  |
| SC_t25c001 | 200 | 309632 | https://www.scstatehouse.gov/code/t25c001.php | Code of Laws - Title 25 - Chapter 1- - MILITARY, CIVIL DEFENSE AND VETERANS AFFA |  |
| SC_t25c003 | 200 | 32110 | https://www.scstatehouse.gov/code/t25c003.php | Code of Laws - Title 25 - Chapter 3- - MILITARY, CIVIL DEFENSE AND VETERANS AFFA |  |
| SC_t25c007 | 200 | 30603 | https://www.scstatehouse.gov/code/t25c007.php | Code of Laws - Title 25 - Chapter 7- - MILITARY, CIVIL DEFENSE AND VETERANS AFFA |  |
| SC_t25c009 | 200 | 57364 | https://www.scstatehouse.gov/code/t25c009.php | Code of Laws - Title 25 - Chapter 9- - MILITARY, CIVIL DEFENSE AND VETERANS AFFA |  |
| SC_t25c011 | 200 | 144721 | https://www.scstatehouse.gov/code/t25c011.php | Code of Laws - Title 25 - Chapter 11- - MILITARY, CIVIL DEFENSE AND VETERANS AFF |  |
| SC_t25c012 | 200 | 29084 | https://www.scstatehouse.gov/code/t25c012.php | Code of Laws - Title 25 - Chapter 12- - MILITARY, CIVIL DEFENSE AND VETERANS AFF |  |
| SC_t25c013 | 200 | 29345 | https://www.scstatehouse.gov/code/t25c013.php | Code of Laws - Title 25 - Chapter 13- - MILITARY, CIVIL DEFENSE AND VETERANS AFF |  |
| SC_t25c015 | 200 | 24467 | https://www.scstatehouse.gov/code/t25c015.php | Code of Laws - Title 25 - Chapter 15- - MILITARY, CIVIL DEFENSE AND VETERANS AFF |  |
| SC_t25c017 | 200 | 22846 | https://www.scstatehouse.gov/code/t25c017.php | Code of Laws - Title 25 - Chapter 17- - MILITARY, CIVIL DEFENSE AND VETERANS AFF |  |
| SC_t25c019 | 200 | 26027 | https://www.scstatehouse.gov/code/t25c019.php | Code of Laws - Title 25 - Chapter 19- - MILITARY, CIVIL DEFENSE AND VETERANS AFF |  |
