| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| RIS_27_27-4_27-4-25 | 200 | 4444 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4/27-4-25.htm |  |  |
| RIS_27_27-4_27-4-26 | 200 | 4379 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4/27-4-26.htm |  |  |
| RIS_27_27-4_27-4-27 | 200 | 9269 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4/27-4-27.htm |  |  |
| RIS_27_27-4_27-4-28 | 200 | 5322 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4/27-4-28.htm |  |  |
| RIS_27_27-4_27-4-29 | 200 | 5583 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4/27-4-29.htm |  |  |
| RIS_27_27-4_27-4-30 | 200 | 5249 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4/27-4-30.htm |  |  |
| RIS_27_27-4.1_27-4.1-1 | 200 | 4033 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.1/27-4.1-1.htm |  |  |
| RIS_27_27-4.1_27-4.1-2 | 200 | 4732 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.1/27-4.1-2.htm |  |  |
| RIS_27_27-4.1_27-4.1-3 | 200 | 4159 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.1/27-4.1-3.htm |  |  |
| RIS_27_27-4.1_27-4.1-4 | 200 | 5548 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.1/27-4.1-4.htm |  |  |
| RIS_27_27-4.1_27-4.1-5 | 200 | 5049 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.1/27-4.1-5.htm |  |  |
| RIS_27_27-4.1_27-4.1-6 | 200 | 4357 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.1/27-4.1-6.htm |  |  |
| RIS_27_27-4.1_27-4.1-7 | 200 | 5339 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.1/27-4.1-7.htm |  |  |
| RIS_27_27-4.1_27-4.1-8 | 200 | 4522 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.1/27-4.1-8.htm |  |  |
| RIS_27_27-4.1_27-4.1-9 | 200 | 4022 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.1/27-4.1-9.htm |  |  |
| RIS_27_27-4.1_27-4.1-10 | 200 | 3908 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.1/27-4.1-10.htm |  | render-thin 272 |
| RIS_27_27-4.2_27-4.2-1 | 200 | 5697 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.2/27-4.2-1.htm |  |  |
| RIS_27_27-4.2_27-4.2-2 | 200 | 4408 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.2/27-4.2-2.htm |  |  |
| RIS_27_27-4.2_27-4.2-3 | 200 | 13317 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.2/27-4.2-3.htm |  |  |
| RIS_27_27-4.2_27-4.2-4 | 200 | 5311 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.2/27-4.2-4.htm |  |  |
| RIS_27_27-4.2_27-4.2-5 | 200 | 3630 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.2/27-4.2-5.htm |  | render-thin 123 |
| RIS_27_27-4.2_27-4.2-6 | 200 | 3956 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.2/27-4.2-6.htm |  |  |
| RIS_27_27-4.2_27-4.2-7 | 200 | 4375 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.2/27-4.2-7.htm |  |  |
| RIS_27_27-4.3_27-4.3-1 | 200 | 3900 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.3/27-4.3-1.htm |  | render-thin 260 |
| RIS_27_27-4.3_27-4.3-1.1 | 200 | 4004 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.3/27-4.3-1.1.htm |  |  |
| RIS_27_27-4.3_27-4.3-2 | 200 | 9754 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.3/27-4.3-2.htm |  |  |
| RIS_27_27-4.3_27-4.3-3 | 200 | 6911 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.3/27-4.3-3.htm |  |  |
| RIS_27_27-4.3_27-4.3-4 | 200 | 4374 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.3/27-4.3-4.htm |  |  |
| RIS_27_27-4.3_27-4.3-5 | 200 | 18502 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.3/27-4.3-5.htm |  |  |
| RIS_27_27-4.3_27-4.3-6 | 200 | 5270 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.3/27-4.3-6.htm |  |  |
| RIS_27_27-4.3_27-4.3-7 | 200 | 5811 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.3/27-4.3-7.htm |  |  |
| RIS_27_27-4.3_27-4.3-8 | 200 | 8570 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.3/27-4.3-8.htm |  |  |
| RIS_27_27-4.3_27-4.3-9 | 200 | 6252 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.3/27-4.3-9.htm |  |  |
| RIS_27_27-4.3_27-4.3-10 | 200 | 4137 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.3/27-4.3-10.htm |  |  |
| RIS_27_27-4.3_27-4.3-11 | 200 | 3976 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.3/27-4.3-11.htm |  |  |
| RIS_27_27-4.4_27-4.4-1 | 200 | 3934 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.4/27-4.4-1.htm |  | render-thin 294 |
| RIS_27_27-4.4_27-4.4-2 | 200 | 4609 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.4/27-4.4-2.htm |  |  |
| RIS_27_27-4.4_27-4.4-3 | 200 | 7568 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.4/27-4.4-3.htm |  |  |
| RIS_27_27-4.4_27-4.4-4 | 200 | 8906 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.4/27-4.4-4.htm |  |  |
| RIS_27_27-4.4_27-4.4-5 | 200 | 4285 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.4/27-4.4-5.htm |  |  |
| RIS_27_27-4.4_27-4.4-6 | 200 | 5090 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.4/27-4.4-6.htm |  |  |
| RIS_27_27-4.4_27-4.4-7 | 200 | 5167 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.4/27-4.4-7.htm |  |  |
| RIS_27_27-4.4_27-4.4-8 | 200 | 4410 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.4/27-4.4-8.htm |  |  |
| RIS_27_27-4.4_27-4.4-9 | 200 | 4172 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.4/27-4.4-9.htm |  |  |
| RIS_27_27-4.4_27-4.4-10 | 200 | 4290 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.4/27-4.4-10.htm |  |  |
| RIS_27_27-4.4_27-4.4-11 | 200 | 5277 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.4/27-4.4-11.htm |  |  |
| RIS_27_27-4.4_27-4.4-12 | 200 | 3952 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.4/27-4.4-12.htm |  |  |
| RIS_27_27-4.5_27-4.5-1 | 200 | 8186 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-1.htm |  |  |
| RIS_27_27-4.5_27-4.5-2 | 200 | 6946 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-2.htm |  |  |
| RIS_27_27-4.5_27-4.5-3 | 200 | 20705 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-3.htm |  |  |
| RIS_27_27-4.5_27-4.5-4 | 200 | 7815 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-4.htm |  |  |
| RIS_27_27-4.5_27-4.5-4.1 | 200 | 24416 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-4.1.htm |  |  |
| RIS_27_27-4.5_27-4.5-5 | 200 | 8878 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-5.htm |  |  |
| RIS_27_27-4.5_27-4.5-5.1 | 200 | 5553 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-5.1.htm |  |  |
| RIS_27_27-4.5_27-4.5-6 | 200 | 4642 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-6.htm |  |  |
| RIS_27_27-4.5_27-4.5-7 | 200 | 5714 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-7.htm |  |  |
| RIS_27_27-4.5_27-4.5-8 | 200 | 6020 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-8.htm |  |  |
| RIS_27_27-4.5_27-4.5-9 | 200 | 5117 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-9.htm |  |  |
| RIS_27_27-4.5_27-4.5-10 | 200 | 4380 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-10.htm |  |  |
| RIS_27_27-4.5_27-4.5-11 | 200 | 3933 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-11.htm |  | render-thin 297 |
| RIS_27_27-4.5_27-4.5-12 | 200 | 4124 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-12.htm |  |  |
| RIS_27_27-4.5_27-4.5-13 | 200 | 12203 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-13.htm |  |  |
| RIS_27_27-4.5_27-4.5-14 | 200 | 7555 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-14.htm |  |  |
| RIS_27_27-4.5_27-4.5-15 | 200 | 4060 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-15.htm |  |  |
| RIS_27_27-4.5_27-4.5-16 | 200 | 13151 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-16.htm |  |  |
| RIS_27_27-4.5_27-4.5-17 | 200 | 5088 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.5/27-4.5-17.htm |  |  |
| RIS_27_27-4.6_27-4.6-1 | 200 | 8115 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-1.htm |  |  |
| RIS_27_27-4.6_27-4.6-2 | 200 | 7519 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-2.htm |  |  |
| RIS_27_27-4.6_27-4.6-3 | 200 | 11236 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-3.htm |  |  |
| RIS_27_27-4.6_27-4.6-4 | 200 | 10092 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-4.htm |  |  |
| RIS_27_27-4.6_27-4.6-5 | 200 | 7060 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-5.htm |  |  |
| RIS_27_27-4.6_27-4.6-6 | 200 | 7430 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-6.htm |  |  |
| RIS_27_27-4.6_27-4.6-7 | 200 | 5664 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-7.htm |  |  |
| RIS_27_27-4.6_27-4.6-8 | 200 | 7739 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-8.htm |  |  |
| RIS_27_27-4.6_27-4.6-9 | 200 | 4936 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-9.htm |  |  |
| RIS_27_27-4.6_27-4.6-10 | 200 | 6424 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-10.htm |  |  |
| RIS_27_27-4.6_27-4.6-11 | 200 | 4070 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-11.htm |  |  |
| RIS_27_27-4.6_27-4.6-12 | 200 | 4114 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-12.htm |  |  |
| RIS_27_27-4.6_27-4.6-13 | 200 | 4155 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.6/27-4.6-13.htm |  |  |
| RIS_27_27-4.7_27-4.7-1 | 200 | 3996 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-1.htm |  |  |
| RIS_27_27-4.7_27-4.7-2 | 200 | 8419 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-2.htm |  |  |
| RIS_27_27-4.7_27-4.7-3 | 200 | 7208 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-3.htm |  |  |
| RIS_27_27-4.7_27-4.7-4 | 200 | 11167 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-4.htm |  |  |
| RIS_27_27-4.7_27-4.7-5 | 200 | 10730 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-5.htm |  |  |
| RIS_27_27-4.7_27-4.7-6 | 200 | 7379 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-6.htm |  |  |
| RIS_27_27-4.7_27-4.7-7 | 200 | 6167 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-7.htm |  |  |
| RIS_27_27-4.7_27-4.7-8 | 200 | 5961 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-8.htm |  |  |
| RIS_27_27-4.7_27-4.7-9 | 200 | 6982 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-9.htm |  |  |
| RIS_27_27-4.7_27-4.7-10 | 200 | 6250 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-10.htm |  |  |
| RIS_27_27-4.7_27-4.7-11 | 200 | 6728 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-11.htm |  |  |
| RIS_27_27-4.7_27-4.7-12 | 200 | 4136 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-12.htm |  |  |
| RIS_27_27-4.7_27-4.7-13 | 200 | 4214 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-13.htm |  |  |
| RIS_27_27-4.7_27-4.7-14 | 200 | 4198 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-14.htm |  |  |
| RIS_27_27-4.7_27-4.7-15 | 200 | 3643 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-15.htm |  | render-thin 136 |
| RIS_27_27-4.7_27-4.7-16 | 200 | 5010 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.7/27-4.7-16.htm |  |  |
| RIS_27_27-4.8_27-4.8-1 | 200 | 19260 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.8/27-4.8-1.htm |  |  |
| RIS_27_27-4.8_27-4.8-2 | 200 | 5537 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.8/27-4.8-2.htm |  |  |
| RIS_27_27-4.8_27-4.8-3 | 200 | 6112 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.8/27-4.8-3.htm |  |  |
| RIS_27_27-4.8_27-4.8-4 | 200 | 5233 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.8/27-4.8-4.htm |  |  |
| RIS_27_27-4.8_27-4.8-5 | 200 | 16404 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.8/27-4.8-5.htm |  |  |
| RIS_27_27-4.8_27-4.8-6 | 200 | 5897 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.8/27-4.8-6.htm |  |  |
| RIS_27_27-4.9_27-4.9-1 | 200 | 3923 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.9/27-4.9-1.htm |  | render-thin 278 |
| RIS_27_27-4.9_27-4.9-2 | 200 | 4126 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.9/27-4.9-2.htm |  |  |
| RIS_27_27-4.9_27-4.9-3 | 200 | 4526 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.9/27-4.9-3.htm |  |  |
| RIS_27_27-4.9_27-4.9-4 | 200 | 4388 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.9/27-4.9-4.htm |  |  |
| RIS_27_27-4.9_27-4.9-5 | 200 | 7181 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.9/27-4.9-5.htm |  |  |
| RIS_27_27-4.9_27-4.9-6 | 200 | 7893 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.9/27-4.9-6.htm |  |  |
| RIS_27_27-4.9_27-4.9-7 | 200 | 4054 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.9/27-4.9-7.htm |  |  |
| RIS_27_27-4.10_27-4.10-1 | 200 | 4842 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.10/27-4.10-1.htm |  |  |
| RIS_27_27-4.10_27-4.10-2 | 200 | 7605 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-4.10/27-4.10-2.htm |  |  |
| RIS_27_27-5_27-5-1 | 200 | 4135 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-1.htm |  |  |
| RIS_27_27-5_27-5-2 | 200 | 4509 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-2.htm |  |  |
| RIS_27_27-5_27-5-2.1 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-2.1.htm |  | render-thin 115 |
| RIS_27_27-5_27-5-3 | 200 | 51744 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-3.htm |  |  |
| RIS_27_27-5_27-5-3.1 | 200 | 4495 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-3.1.htm |  |  |
| RIS_27_27-5_27-5-3.2 | 200 | 5989 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-3.2.htm |  |  |
| RIS_27_27-5_27-5-3.3 | 200 | 4572 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-3.3.htm |  |  |
| RIS_27_27-5_27-5-3.4 | 200 | 5474 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-3.4.htm |  |  |
| RIS_27_27-5_27-5-3.5 | 200 | 4401 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-3.5.htm |  |  |
| RIS_27_27-5_27-5-3.6 | 200 | 4378 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-3.6.htm |  |  |
| RIS_27_27-5_27-5-3.7 | 200 | 3982 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-3.7.htm |  |  |
| RIS_27_27-5_27-5-3.8 | 200 | 3967 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-3.8.htm |  |  |
| RIS_27_27-5_27-5-3.9 | 200 | 4045 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-3.9.htm |  |  |
| RIS_27_27-5_27-5-4 | 200 | 4573 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-4.htm |  |  |
| RIS_27_27-5_27-5-5 | 200 | 4217 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-5.htm |  |  |
| RIS_27_27-5_27-5-6 | 200 | 6190 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-6.htm |  |  |
| RIS_27_27-5_27-5-6.1 | 200 | 5371 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-6.1.htm |  |  |
| RIS_27_27-5_27-5-6.2 | 200 | 5405 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-6.2.htm |  |  |
| RIS_27_27-5_27-5-7 | 200 | 4923 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-7.htm |  |  |
| RIS_27_27-5_27-5-8 | 200 | 4939 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-8.htm |  |  |
| RIS_27_27-5_27-5-9 | 200 | 3998 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-9.htm |  |  |
| RIS_27_27-5_27-5-9.1 | 200 | 4379 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-9.1.htm |  |  |
| RIS_27_27-5_27-5-10 | 200 | 4377 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-10.htm |  |  |
| RIS_27_27-5_27-5-11 | 200 | 4017 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-11.htm |  |  |
| RIS_27_27-5_27-5-12 | 200 | 4584 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-12.htm |  |  |
| RIS_27_27-5_27-5-13 | 200 | 4285 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-13.htm |  |  |
| RIS_27_27-5_27-5-14 | 200 | 5605 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-14.htm |  |  |
| RIS_27_27-5_27-5-15 | 200 | 4401 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-15.htm |  |  |
| RIS_27_27-5_27-5-16 | 200 | 5124 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-16.htm |  |  |
| RIS_27_27-5_27-5-17 | 200 | 5092 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-17.htm |  |  |
| RIS_27_27-5_27-5-18 | 200 | 5872 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-18.htm |  |  |
| RIS_27_27-5_27-5-19 | 200 | 4812 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-19.htm |  |  |
| RIS_27_27-5_27-5-20 | 200 | 4315 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-20.htm |  |  |
| RIS_27_27-5_27-5-21 | 200 | 4757 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-21.htm |  |  |
| RIS_27_27-5_27-5-22 | 200 | 7178 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-22.htm |  |  |
| RIS_27_27-5_27-5-23 | 200 | 4147 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-23.htm |  |  |
| RIS_27_27-5_27-5-24 | 200 | 4458 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-24.htm |  |  |
| RIS_27_27-5_27-5-25 | 200 | 5084 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-25.htm |  |  |
| RIS_27_27-5_27-5-26 | 200 | 4294 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-26.htm |  |  |
| RIS_27_27-5_27-5-27 | 200 | 5543 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-27.htm |  |  |
| RIS_27_27-5_27-5-28 | 200 | 4210 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-28.htm |  |  |
| RIS_27_27-5_27-5-29 | 200 | 4495 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-29.htm |  |  |
| RIS_27_27-5_27-5-30 | 200 | 4864 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-30.htm |  |  |
| RIS_27_27-5_27-5-31 | 200 | 6504 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-5/27-5-31.htm |  |  |
| RIS_27_27-6_27-6-1 | 200 | 4552 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-1.htm |  |  |
| RIS_27_27-6_27-6-2 | 200 | 5314 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-2.htm |  |  |
| RIS_27_27-6_27-6-3 | 200 | 4524 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-3.htm |  |  |
| RIS_27_27-6_27-6-4 | 200 | 5168 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-4.htm |  |  |
| RIS_27_27-6_27-6-5 | 200 | 3975 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-5.htm |  |  |
| RIS_27_27-6_27-6-6 | 200 | 4108 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-6.htm |  |  |
| RIS_27_27-6_27-6-6.1 | 200 | 4441 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-6.1.htm |  |  |
| RIS_27_27-6_27-6-7 | 200 | 3899 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-7.htm |  | render-thin 280 |
| RIS_27_27-6_27-6-8 | 200 | 5865 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-8.htm |  |  |
| RIS_27_27-6_27-6-8.1 | 200 | 7160 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-8.1.htm |  |  |
| RIS_27_27-6_27-6-8.2 | 200 | 4863 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-8.2.htm |  |  |
| RIS_27_27-6_27-6-9 | 200 | 4274 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-9.htm |  |  |
| RIS_27_27-6_27-6-10 | 200 | 3990 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-10.htm |  |  |
| RIS_27_27-6_27-6-11 | 200 | 5905 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-11.htm |  |  |
| RIS_27_27-6_27-6-11.1 | 200 | 4224 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-11.1.htm |  |  |
| RIS_27_27-6_27-6-12 | 200 | 4150 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-12.htm |  |  |
| RIS_27_27-6_27-6-13 | 200 | 4554 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-13.htm |  |  |
| RIS_27_27-6_27-6-14 | 200 | 4072 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-14.htm |  |  |
| RIS_27_27-6_27-6-15 | 200 | 4187 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-15.htm |  |  |
| RIS_27_27-6_27-6-16 | 200 | 5570 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-16.htm |  |  |
| RIS_27_27-6_27-6-17 | 200 | 4343 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-17.htm |  |  |
| RIS_27_27-6_27-6-18 | 200 | 4631 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-18.htm |  |  |
| RIS_27_27-6_27-6-19 | 200 | 5327 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-19.htm |  |  |
| RIS_27_27-6_27-6-20 | 200 | 6380 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-20.htm |  |  |
| RIS_27_27-6_27-6-21 | 200 | 4663 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-21.htm |  |  |
| RIS_27_27-6_27-6-22 | 200 | 4163 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-22.htm |  |  |
| RIS_27_27-6_27-6-23 | 200 | 7485 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-23.htm |  |  |
| RIS_27_27-6_27-6-24 | 200 | 5812 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-24.htm |  |  |
| RIS_27_27-6_27-6-25 | 200 | 4146 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-25.htm |  |  |
| RIS_27_27-6_27-6-26 | 200 | 4825 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-26.htm |  |  |
| RIS_27_27-6_27-6-27 | 200 | 4593 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-27.htm |  |  |
| RIS_27_27-6_27-6-28 | 200 | 4070 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-28.htm |  |  |
| RIS_27_27-6_27-6-29 | 200 | 5023 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-29.htm |  |  |
| RIS_27_27-6_27-6-30 | 200 | 5817 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-30.htm |  |  |
| RIS_27_27-6_27-6-31 | 200 | 4210 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-31.htm |  |  |
| RIS_27_27-6_27-6-32 | 200 | 4948 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-32.htm |  |  |
| RIS_27_27-6_27-6-33 | 200 | 4282 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-33.htm |  |  |
| RIS_27_27-6_27-6-34 | 200 | 4688 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-34.htm |  |  |
| RIS_27_27-6_27-6-35 | 200 | 4370 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-35.htm |  |  |
| RIS_27_27-6_27-6-36 | 200 | 4438 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-36.htm |  |  |
| RIS_27_27-6_27-6-37 | 200 | 4257 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-37.htm |  |  |
| RIS_27_27-6_27-6-38 | 200 | 4382 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-38.htm |  |  |
| RIS_27_27-6_27-6-39 | 200 | 5454 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-39.htm |  |  |
| RIS_27_27-6_27-6-40 | 200 | 4933 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-40.htm |  |  |
| RIS_27_27-6_27-6-41 | 200 | 5639 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-41.htm |  |  |
| RIS_27_27-6_27-6-42 | 200 | 3977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-42.htm |  |  |
| RIS_27_27-6_27-6-43 | 200 | 4223 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-43.htm |  |  |
| RIS_27_27-6_27-6-44 | 200 | 3935 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-44.htm |  | render-thin 298 |
| RIS_27_27-6_27-6-45 | 200 | 4309 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-45.htm |  |  |
| RIS_27_27-6_27-6-46 | 200 | 3911 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-46.htm |  |  |
| RIS_27_27-6_27-6-47 | 200 | 4138 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-47.htm |  |  |
| RIS_27_27-6_27-6-48 | 200 | 5141 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-48.htm |  |  |
| RIS_27_27-6_27-6-49 | 200 | 4856 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-49.htm |  |  |
| RIS_27_27-6_27-6-50 | 200 | 3953 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-50.htm |  |  |
| RIS_27_27-6_27-6-51 | 200 | 4984 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-51.htm |  |  |
| RIS_27_27-6_27-6-52 | 200 | 4025 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-52.htm |  |  |
| RIS_27_27-6_27-6-53 | 200 | 11609 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6/27-6-53.htm |  |  |
| RIS_27_27-6.1_27-6.1-1 | 200 | 4601 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6.1/27-6.1-1.htm |  |  |
| RIS_27_27-6.1_27-6.1-2 | 200 | 4968 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6.1/27-6.1-2.htm |  |  |
| RIS_27_27-6.1_27-6.1-3 | 200 | 9549 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6.1/27-6.1-3.htm |  |  |
| RIS_27_27-6.1_27-6.1-4 | 200 | 5542 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6.1/27-6.1-4.htm |  |  |
| RIS_27_27-6.1_27-6.1-5 | 200 | 5778 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6.1/27-6.1-5.htm |  |  |
| RIS_27_27-6.1_27-6.1-6 | 200 | 5763 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6.1/27-6.1-6.htm |  |  |
| RIS_27_27-6.1_27-6.1-7 | 200 | 4204 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6.1/27-6.1-7.htm |  |  |
| RIS_27_27-6.1_27-6.1-8 | 200 | 5241 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6.1/27-6.1-8.htm |  |  |
| RIS_27_27-6.1_27-6.1-9 | 200 | 7718 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6.1/27-6.1-9.htm |  |  |
| RIS_27_27-6.1_27-6.1-10 | 200 | 4238 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6.1/27-6.1-10.htm |  |  |
| RIS_27_27-6.1_27-6.1-11 | 200 | 4042 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6.1/27-6.1-11.htm |  |  |
| RIS_27_27-6.1_27-6.1-12 | 200 | 4187 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-6.1/27-6.1-12.htm |  |  |
| RIS_27_27-7_27-7-1 | 200 | 4491 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7/27-7-1.htm |  |  |
| RIS_27_27-7_27-7-2 | 200 | 5686 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7/27-7-2.htm |  |  |
| RIS_27_27-7_27-7-2.1 | 200 | 12519 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7/27-7-2.1.htm |  |  |
| RIS_27_27-7_27-7-2.2 | 200 | 4624 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7/27-7-2.2.htm |  |  |
| RIS_27_27-7_27-7-2.3 | 200 | 4324 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7/27-7-2.3.htm |  |  |
| RIS_27_27-7_27-7-2.4 | 200 | 4543 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7/27-7-2.4.htm |  |  |
| RIS_27_27-7_27-7-2.5 | 200 | 5426 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7/27-7-2.5.htm |  |  |
| RIS_27_27-7_27-7-3 | 200 | 4093 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7/27-7-3.htm |  |  |
| RIS_27_27-7_27-7-4 | 200 | 4049 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7/27-7-4.htm |  |  |
| RIS_27_27-7_27-7-5 | 200 | 4183 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7/27-7-5.htm |  |  |
| RIS_27_27-7_27-7-6 | 200 | 7155 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7/27-7-6.htm |  |  |
| RIS_27_27-7_27-7-7 | 200 | 4271 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7/27-7-7.htm |  |  |
| RIS_27_27-7.1_27-7.1-1 | 200 | 4017 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-1.htm |  |  |
| RIS_27_27-7.1_27-7.1-1.1 | 200 | 9524 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-1.1.htm |  |  |
| RIS_27_27-7.1_27-7.1-2 | 200 | 5558 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-2.htm |  |  |
| RIS_27_27-7.1_27-7.1-3 | 200 | 3631 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-3.htm |  | render-thin 122 |
| RIS_27_27-7.1_27-7.1-4.1 | 200 | 5302 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-4.1.htm |  |  |
| RIS_27_27-7.1_27-7.1-5 | 200 | 3621 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-5.htm |  | render-thin 112 |
| RIS_27_27-7.1_27-7.1-5.1 | 200 | 8781 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-5.1.htm |  |  |
| RIS_27_27-7.1_27-7.1-6 | 200 | 3621 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-6.htm |  | render-thin 112 |
| RIS_27_27-7.1_27-7.1-6.1 | 200 | 5697 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-6.1.htm |  |  |
| RIS_27_27-7.1_27-7.1-6.2 | 200 | 4065 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-6.2.htm |  |  |
| RIS_27_27-7.1_27-7.1-7 | 200 | 3621 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-7.htm |  | render-thin 112 |
| RIS_27_27-7.1_27-7.1-7.1 | 200 | 4117 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-7.1.htm |  |  |
| RIS_27_27-7.1_27-7.1-7.2 | 200 | 3866 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-7.2.htm |  | render-thin 273 |
| RIS_27_27-7.1_27-7.1-8 | 200 | 3621 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-8.htm |  | render-thin 112 |
| RIS_27_27-7.1_27-7.1-8.1 | 200 | 4418 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-8.1.htm |  |  |
| RIS_27_27-7.1_27-7.1-9 | 200 | 3621 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-9.htm |  | render-thin 112 |
| RIS_27_27-7.1_27-7.1-9.1 | 200 | 6046 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-9.1.htm |  |  |
| RIS_27_27-7.1_27-7.1-10 | 200 | 3623 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-10.htm |  | render-thin 114 |
| RIS_27_27-7.1_27-7.1-10.1 | 200 | 6408 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-10.1.htm |  |  |
| RIS_27_27-7.1_27-7.1-11 | 200 | 3623 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-11.htm |  | render-thin 114 |
| RIS_27_27-7.1_27-7.1-11.1 | 200 | 5921 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-11.1.htm |  |  |
| RIS_27_27-7.1_27-7.1-12 | 200 | 3623 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-12.htm |  | render-thin 114 |
| RIS_27_27-7.1_27-7.1-12.1 | 200 | 6915 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-12.1.htm |  |  |
| RIS_27_27-7.1_27-7.1-13 | 200 | 4245 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-13.htm |  |  |
| RIS_27_27-7.1_27-7.1-13.1 | 200 | 4248 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-13.1.htm |  |  |
| RIS_27_27-7.1_27-7.1-13.2 | 200 | 4096 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-13.2.htm |  |  |
| RIS_27_27-7.1_27-7.1-14 | 200 | 3637 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-14.htm |  | render-thin 126 |
| RIS_27_27-7.1_27-7.1-18 | 200 | 5580 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-18.htm |  |  |
| RIS_27_27-7.1_27-7.1-19 | 200 | 4343 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-19.htm |  |  |
| RIS_27_27-7.1_27-7.1-20 | 200 | 5038 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-20.htm |  |  |
| RIS_27_27-7.1_27-7.1-21 | 200 | 5621 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-21.htm |  |  |
| RIS_27_27-7.1_27-7.1-22 | 200 | 3623 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-22.htm |  | render-thin 114 |
| RIS_27_27-7.1_27-7.1-23 | 200 | 3623 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-23.htm |  | render-thin 114 |
| RIS_27_27-7.1_27-7.1-24 | 200 | 4681 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-24.htm |  |  |
| RIS_27_27-7.1_27-7.1-25 | 200 | 4181 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.1/27-7.1-25.htm |  |  |
| RIS_27_27-7.2_27-7.2-1 | 200 | 3652 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-7.2/27-7.2-1.htm |  | render-thin 141 |
| RIS_27_27-8_27-8-1 | 200 | 11180 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-1.htm |  |  |
| RIS_27_27-8_27-8-2 | 200 | 4021 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-2.htm |  |  |
| RIS_27_27-8_27-8-3 | 200 | 4484 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-3.htm |  |  |
| RIS_27_27-8_27-8-4 | 200 | 5217 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-4.htm |  |  |
| RIS_27_27-8_27-8-5 | 200 | 4692 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-5.htm |  |  |
| RIS_27_27-8_27-8-6 | 200 | 4753 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-6.htm |  |  |
| RIS_27_27-8_27-8-7 | 200 | 6514 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-7.htm |  |  |
| RIS_27_27-8_27-8-8 | 200 | 4715 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-8.htm |  |  |
| RIS_27_27-8_27-8-9 | 200 | 4061 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-9.htm |  |  |
| RIS_27_27-8_27-8-10 | 200 | 4003 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-10.htm |  |  |
| RIS_27_27-8_27-8-11 | 200 | 8793 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-11.htm |  |  |
| RIS_27_27-8_27-8-12 | 200 | 4232 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-12.htm |  |  |
| RIS_27_27-8_27-8-13 | 200 | 3612 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-13.htm |  | render-thin 105 |
| RIS_27_27-8_27-8-14 | 200 | 4217 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-14.htm |  |  |
| RIS_27_27-8_27-8-15 | 200 | 4573 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-15.htm |  |  |
| RIS_27_27-8_27-8-16 | 200 | 3612 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-16.htm |  | render-thin 105 |
| RIS_27_27-8_27-8-17 | 200 | 4446 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-17.htm |  |  |
| RIS_27_27-8_27-8-18 | 200 | 4208 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8/27-8-18.htm |  |  |
| RIS_27_27-8.1_27-8.1-1 | 200 | 3886 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.1/27-8.1-1.htm |  | render-thin 266 |
| RIS_27_27-8.1_27-8.1-2 | 200 | 7764 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.1/27-8.1-2.htm |  |  |
| RIS_27_27-8.1_27-8.1-2.1 | 200 | 4668 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.1/27-8.1-2.1.htm |  |  |
| RIS_27_27-8.1_27-8.1-3 | 200 | 10892 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.1/27-8.1-3.htm |  |  |
| RIS_27_27-8.1_27-8.1-4 | 200 | 4612 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.1/27-8.1-4.htm |  |  |
| RIS_27_27-8.1_27-8.1-5 | 200 | 4939 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.1/27-8.1-5.htm |  |  |
| RIS_27_27-8.1_27-8.1-6 | 200 | 3984 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.1/27-8.1-6.htm |  |  |
| RIS_27_27-8.2_27-8.2-1 | 200 | 4210 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.2/27-8.2-1.htm |  |  |
| RIS_27_27-8.2_27-8.2-2 | 200 | 4918 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.2/27-8.2-2.htm |  |  |
| RIS_27_27-8.2_27-8.2-3 | 200 | 4575 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.2/27-8.2-3.htm |  |  |
| RIS_27_27-8.2_27-8.2-4 | 200 | 4229 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.2/27-8.2-4.htm |  |  |
| RIS_27_27-8.2_27-8.2-5 | 200 | 3937 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.2/27-8.2-5.htm |  |  |
| RIS_27_27-8.3_27-8.3-1 | 200 | 3977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-1.htm |  |  |
| RIS_27_27-8.3_27-8.3-2 | 200 | 3977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-2.htm |  |  |
| RIS_27_27-8.3_27-8.3-3 | 200 | 3977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-3.htm |  |  |
| RIS_27_27-8.3_27-8.3-4 | 200 | 3977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-4.htm |  |  |
| RIS_27_27-8.3_27-8.3-5 | 200 | 3977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-5.htm |  |  |
| RIS_27_27-8.3_27-8.3-6 | 200 | 3977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-6.htm |  |  |
| RIS_27_27-8.3_27-8.3-7 | 200 | 3977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-7.htm |  |  |
| RIS_27_27-8.3_27-8.3-8 | 200 | 3977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-8.htm |  |  |
| RIS_27_27-8.3_27-8.3-9 | 200 | 3977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-9.htm |  |  |
| RIS_27_27-8.3_27-8.3-10 | 200 | 3979 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-10.htm |  |  |
| RIS_27_27-8.3_27-8.3-11 | 200 | 3979 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-11.htm |  |  |
| RIS_27_27-8.3_27-8.3-12 | 200 | 3980 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-12.htm |  |  |
| RIS_27_27-8.3_27-8.3-13 | 200 | 3979 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-13.htm |  |  |
| RIS_27_27-8.3_27-8.3-14 | 200 | 3979 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-8.3/27-8.3-14.htm |  |  |
| RIS_27_27-9_27-9-1 | 200 | 4569 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-1.htm |  |  |
| RIS_27_27-9_27-9-2 | 200 | 4557 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-2.htm |  |  |
| RIS_27_27-9_27-9-3 | 200 | 4588 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-3.htm |  |  |
| RIS_27_27-9_27-9-4 | 200 | 13330 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-4.htm |  |  |
| RIS_27_27-9_27-9-4.1 | 200 | 3848 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-4.1.htm |  | render-thin 257 |
| RIS_27_27-9_27-9-5 | 200 | 3977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-5.htm |  |  |
| RIS_27_27-9_27-9-5.1 | 200 | 4377 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-5.1.htm |  |  |
| RIS_27_27-9_27-9-6 | 200 | 4130 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-6.htm |  |  |
| RIS_27_27-9_27-9-6.1 | 200 | 4427 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-6.1.htm |  |  |
| RIS_27_27-9_27-9-7 | 200 | 5380 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-7.htm |  |  |
| RIS_27_27-9_27-9-7.1 | 200 | 6265 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-7.1.htm |  |  |
| RIS_27_27-9_27-9-7.2 | 200 | 4249 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-7.2.htm |  |  |
| RIS_27_27-9_27-9-7.3 | 200 | 7085 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-7.3.htm |  |  |
| RIS_27_27-9_27-9-7.4 | 200 | 4722 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-7.4.htm |  |  |
| RIS_27_27-9_27-9-8 | 200 | 4901 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-8.htm |  |  |
| RIS_27_27-9_27-9-8.1 | 200 | 6893 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-8.1.htm |  |  |
| RIS_27_27-9_27-9-8.2 | 200 | 3949 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-8.2.htm |  |  |
| RIS_27_27-9_27-9-9 | 200 | 3980 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-9.htm |  |  |
| RIS_27_27-9_27-9-10 | 200 | 5960 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-10.htm |  |  |
| RIS_27_27-9_27-9-10.1 | 200 | 4217 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-10.1.htm |  |  |
| RIS_27_27-9_27-9-11 | 200 | 4264 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-11.htm |  |  |
| RIS_27_27-9_27-9-12 | 200 | 4507 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-12.htm |  |  |
| RIS_27_27-9_27-9-13 | 200 | 4062 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-13.htm |  |  |
| RIS_27_27-9_27-9-14 | 200 | 4052 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-14.htm |  |  |
| RIS_27_27-9_27-9-15 | 200 | 5621 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-15.htm |  |  |
| RIS_27_27-9_27-9-16 | 200 | 4351 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-16.htm |  |  |
| RIS_27_27-9_27-9-17 | 200 | 4595 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-17.htm |  |  |
| RIS_27_27-9_27-9-18 | 200 | 6441 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-18.htm |  |  |
| RIS_27_27-9_27-9-19 | 200 | 6388 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-19.htm |  |  |
| RIS_27_27-9_27-9-20 | 200 | 4658 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-20.htm |  |  |
| RIS_27_27-9_27-9-21 | 200 | 4233 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-21.htm |  |  |
| RIS_27_27-9_27-9-22 | 200 | 7359 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-22.htm |  |  |
| RIS_27_27-9_27-9-23 | 200 | 5756 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-23.htm |  |  |
| RIS_27_27-9_27-9-24 | 200 | 4138 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-24.htm |  |  |
| RIS_27_27-9_27-9-25 | 200 | 4852 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-25.htm |  |  |
| RIS_27_27-9_27-9-26 | 200 | 5447 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-26.htm |  |  |
| RIS_27_27-9_27-9-27 | 200 | 5499 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-27.htm |  |  |
| RIS_27_27-9_27-9-28 | 200 | 4446 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-28.htm |  |  |
| RIS_27_27-9_27-9-29 | 200 | 4962 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-29.htm |  |  |
| RIS_27_27-9_27-9-30 | 200 | 4266 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-30.htm |  |  |
| RIS_27_27-9_27-9-31 | 200 | 4670 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-31.htm |  |  |
| RIS_27_27-9_27-9-32 | 200 | 4350 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-32.htm |  |  |
| RIS_27_27-9_27-9-33 | 200 | 4426 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-33.htm |  |  |
| RIS_27_27-9_27-9-34 | 200 | 4252 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-34.htm |  |  |
| RIS_27_27-9_27-9-35 | 200 | 4371 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-35.htm |  |  |
| RIS_27_27-9_27-9-36 | 200 | 5301 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-36.htm |  |  |
| RIS_27_27-9_27-9-37 | 200 | 4977 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-37.htm |  |  |
| RIS_27_27-9_27-9-38 | 200 | 5633 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-38.htm |  |  |
| RIS_27_27-9_27-9-39 | 200 | 3970 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-39.htm |  |  |
| RIS_27_27-9_27-9-40 | 200 | 4235 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-40.htm |  |  |
| RIS_27_27-9_27-9-41 | 200 | 3928 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-41.htm |  | render-thin 291 |
| RIS_27_27-9_27-9-42 | 200 | 4309 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-42.htm |  |  |
| RIS_27_27-9_27-9-43 | 200 | 4888 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-43.htm |  |  |
| RIS_27_27-9_27-9-44 | 200 | 3904 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-44.htm |  | render-thin 297 |
| RIS_27_27-9_27-9-45 | 200 | 4137 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-45.htm |  |  |
| RIS_27_27-9_27-9-46 | 200 | 5162 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-46.htm |  |  |
| RIS_27_27-9_27-9-47 | 200 | 4864 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-47.htm |  |  |
| RIS_27_27-9_27-9-48 | 200 | 3618 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-48.htm |  | render-thin 111 |
| RIS_27_27-9_27-9-50 | 200 | 4018 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-50.htm |  |  |
| RIS_27_27-9_27-9-51 | 200 | 3886 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-51.htm |  | render-thin 294 |
| RIS_27_27-9_27-9-52 | 200 | 5048 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-52.htm |  |  |
| RIS_27_27-9_27-9-53 | 200 | 4366 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-53.htm |  |  |
| RIS_27_27-9_27-9-54 | 200 | 4479 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-54.htm |  |  |
| RIS_27_27-9_27-9-55 | 200 | 3850 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-55.htm |  | render-thin 259 |
| RIS_27_27-9_27-9-56 | 200 | 11541 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9/27-9-56.htm |  |  |
| RIS_27_27-9.1_27-9.1-1 | 200 | 4317 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.1/27-9.1-1.htm |  |  |
| RIS_27_27-9.1_27-9.1-2 | 200 | 5834 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.1/27-9.1-2.htm |  |  |
| RIS_27_27-9.1_27-9.1-3 | 200 | 4417 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.1/27-9.1-3.htm |  |  |
| RIS_27_27-9.1_27-9.1-4 | 200 | 24646 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.1/27-9.1-4.htm |  |  |
| RIS_27_27-9.1_27-9.1-4.1 | 200 | 5006 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.1/27-9.1-4.1.htm |  |  |
| RIS_27_27-9.1_27-9.1-5 | 200 | 4585 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.1/27-9.1-5.htm |  |  |
| RIS_27_27-9.1_27-9.1-6 | 200 | 5134 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.1/27-9.1-6.htm |  |  |
| RIS_27_27-9.1_27-9.1-7 | 200 | 4521 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.1/27-9.1-7.htm |  |  |
| RIS_27_27-9.1_27-9.1-8 | 200 | 4098 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.1/27-9.1-8.htm |  |  |
| RIS_27_27-9.1_27-9.1-9 | 200 | 4161 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.1/27-9.1-9.htm |  |  |
| RIS_27_27-9.2_27-9.2-1 | 200 | 4262 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.2/27-9.2-1.htm |  |  |
| RIS_27_27-9.2_27-9.2-2 | 200 | 4328 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.2/27-9.2-2.htm |  |  |
| RIS_27_27-9.2_27-9.2-3 | 200 | 4273 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.2/27-9.2-3.htm |  |  |
| RIS_27_27-9.2_27-9.2-4 | 200 | 3941 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.2/27-9.2-4.htm |  | render-thin 297 |
| RIS_27_27-9.2_27-9.2-5 | 200 | 3912 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.2/27-9.2-5.htm |  | render-thin 276 |
| RIS_27_27-9.3_27-9.3-1 | 200 | 3900 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.3/27-9.3-1.htm |  | render-thin 260 |
| RIS_27_27-9.3_27-9.3-2 | 200 | 11414 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.3/27-9.3-2.htm |  |  |
| RIS_27_27-9.3_27-9.3-3 | 200 | 5845 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.3/27-9.3-3.htm |  |  |
| RIS_27_27-9.3_27-9.3-4 | 200 | 5333 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.3/27-9.3-4.htm |  |  |
| RIS_27_27-9.3_27-9.3-5 | 200 | 5471 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.3/27-9.3-5.htm |  |  |
| RIS_27_27-9.3_27-9.3-6 | 200 | 5832 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.3/27-9.3-6.htm |  |  |
| RIS_27_27-9.3_27-9.3-7 | 200 | 6393 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.3/27-9.3-7.htm |  |  |
| RIS_27_27-9.4_27-9.4-1 | 200 | 3978 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.4/27-9.4-1.htm |  |  |
| RIS_27_27-9.4_27-9.4-2 | 200 | 3948 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.4/27-9.4-2.htm |  |  |
| RIS_27_27-9.4_27-9.4-3 | 200 | 5807 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.4/27-9.4-3.htm |  |  |
| RIS_27_27-9.4_27-9.4-4 | 200 | 4037 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.4/27-9.4-4.htm |  |  |
| RIS_27_27-9.4_27-9.4-5 | 200 | 3923 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-9.4/27-9.4-5.htm |  | render-thin 285 |
| RIS_27_27-10_27-10-1 | 200 | 4368 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-1.htm |  |  |
| RIS_27_27-10_27-10-1.1 | 200 | 8777 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-1.1.htm |  |  |
| RIS_27_27-10_27-10-1.2 | 200 | 4316 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-1.2.htm |  |  |
| RIS_27_27-10_27-10-2 | 200 | 7351 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-2.htm |  |  |
| RIS_27_27-10_27-10-3 | 200 | 6612 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-3.htm |  |  |
| RIS_27_27-10_27-10-4 | 200 | 4247 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-4.htm |  |  |
| RIS_27_27-10_27-10-5 | 200 | 6865 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-5.htm |  |  |
| RIS_27_27-10_27-10-6 | 200 | 6285 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-6.htm |  |  |
| RIS_27_27-10_27-10-7 | 200 | 5186 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-7.htm |  |  |
| RIS_27_27-10_27-10-7.1 | 200 | 6739 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-7.1.htm |  |  |
| RIS_27_27-10_27-10-8 | 200 | 7198 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-8.htm |  |  |
| RIS_27_27-10_27-10-9 | 200 | 4547 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-9.htm |  |  |
| RIS_27_27-10_27-10-10 | 200 | 4346 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-10.htm |  |  |
| RIS_27_27-10_27-10-11 | 200 | 4368 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-11.htm |  |  |
| RIS_27_27-10_27-10-12 | 200 | 8869 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-12.htm |  |  |
| RIS_27_27-10_27-10-13 | 200 | 4369 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-13.htm |  |  |
| RIS_27_27-10_27-10-14 | 200 | 3914 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-14.htm |  | render-thin 278 |
| RIS_27_27-10_27-10-15 | 200 | 3602 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10/27-10-15.htm |  | render-thin 95 |
| RIS_27_27-10.1_27-10.1-1 | 200 | 6736 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-1.htm |  |  |
| RIS_27_27-10.1_27-10.1-1.1 | 200 | 6021 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-1.1.htm |  |  |
| RIS_27_27-10.1_27-10.1-2 | 200 | 5032 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-2.htm |  |  |
| RIS_27_27-10.1_27-10.1-3 | 200 | 4250 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-3.htm |  |  |
| RIS_27_27-10.1_27-10.1-4 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-4.htm |  | render-thin 115 |
| RIS_27_27-10.1_27-10.1-5 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-5.htm |  | render-thin 115 |
| RIS_27_27-10.1_27-10.1-6 | 200 | 7559 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-6.htm |  |  |
| RIS_27_27-10.1_27-10.1-7 | 200 | 4191 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-7.htm |  |  |
| RIS_27_27-10.1_27-10.1-8 | 200 | 5420 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-8.htm |  |  |
| RIS_27_27-10.1_27-10.1-8.1 | 200 | 4302 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-8.1.htm |  |  |
| RIS_27_27-10.1_27-10.1-9 | 200 | 5437 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-9.htm |  |  |
| RIS_27_27-10.1_27-10.1-10 | 200 | 4655 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-10.htm |  |  |
| RIS_27_27-10.1_27-10.1-11 | 200 | 6045 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.1/27-10.1-11.htm |  |  |
| RIS_27_27-10.2_27-10.2-1 | 200 | 4299 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.2/27-10.2-1.htm |  |  |
| RIS_27_27-10.2_27-10.2-2 | 200 | 7046 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.2/27-10.2-2.htm |  |  |
| RIS_27_27-10.2_27-10.2-3 | 200 | 5948 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.2/27-10.2-3.htm |  |  |
| RIS_27_27-10.3_27-10.3-1 | 200 | 8013 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.3/27-10.3-1.htm |  |  |
| RIS_27_27-10.4_27-10.4-1 | 200 | 9368 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-10.4/27-10.4-1.htm |  |  |
| RIS_27_27-11_27-11-1 | 200 | 4852 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11/27-11-1.htm |  |  |
| RIS_27_27-11_27-11-2 | 200 | 4641 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11/27-11-2.htm |  |  |
| RIS_27_27-11_27-11-3 | 200 | 4213 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11/27-11-3.htm |  |  |
| RIS_27_27-11.1_27-11.1-1 | 200 | 4230 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11.1/27-11.1-1.htm |  |  |
| RIS_27_27-11.1_27-11.1-2 | 200 | 4094 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11.1/27-11.1-2.htm |  |  |
| RIS_27_27-11.1_27-11.1-3 | 200 | 3885 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11.1/27-11.1-3.htm |  | render-thin 294 |
| RIS_27_27-11.1_27-11.1-4 | 200 | 5047 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11.1/27-11.1-4.htm |  |  |
| RIS_27_27-11.1_27-11.1-5 | 200 | 4097 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11.1/27-11.1-5.htm |  |  |
| RIS_27_27-11.1_27-11.1-6 | 200 | 3951 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11.1/27-11.1-6.htm |  |  |
| RIS_27_27-11.1_27-11.1-7 | 200 | 3937 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11.1/27-11.1-7.htm |  |  |
| RIS_27_27-11.1_27-11.1-8 | 200 | 5338 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11.1/27-11.1-8.htm |  |  |
| RIS_27_27-11.2_27-11.2-1 | 200 | 5365 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11.2/27-11.2-1.htm |  |  |
| RIS_27_27-11.2_27-11.2-2 | 200 | 5088 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-11.2/27-11.2-2.htm |  |  |
| RIS_27_27-12_27-12-1 | 200 | 10742 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12/27-12-1.htm |  |  |
| RIS_27_27-12_27-12-2 | 200 | 4323 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12/27-12-2.htm |  |  |
| RIS_27_27-12_27-12-3 | 200 | 6530 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12/27-12-3.htm |  |  |
| RIS_27_27-12_27-12-4 | 200 | 4282 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12/27-12-4.htm |  |  |
| RIS_27_27-12_27-12-5 | 200 | 4307 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12/27-12-5.htm |  |  |
| RIS_27_27-12_27-12-6 | 200 | 3948 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12/27-12-6.htm |  |  |
| RIS_27_27-12.1_27-12.1-1 | 200 | 4139 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.1/27-12.1-1.htm |  |  |
| RIS_27_27-12.1_27-12.1-2 | 200 | 5487 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.1/27-12.1-2.htm |  |  |
| RIS_27_27-12.1_27-12.1-3 | 200 | 4760 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.1/27-12.1-3.htm |  |  |
| RIS_27_27-12.1_27-12.1-4 | 200 | 4212 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.1/27-12.1-4.htm |  |  |
| RIS_27_27-12.1_27-12.1-5 | 200 | 4321 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.1/27-12.1-5.htm |  |  |
| RIS_27_27-12.2_27-12.2-1 | 200 | 3872 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.2/27-12.2-1.htm |  | render-thin 281 |
| RIS_27_27-12.2_27-12.2-2 | 200 | 3897 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.2/27-12.2-2.htm |  |  |
| RIS_27_27-12.2_27-12.2-3 | 200 | 3872 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.2/27-12.2-3.htm |  | render-thin 281 |
| RIS_27_27-12.2_27-12.2-4 | 200 | 3872 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.2/27-12.2-4.htm |  | render-thin 281 |
| RIS_27_27-12.2_27-12.2-5 | 200 | 3872 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.2/27-12.2-5.htm |  | render-thin 281 |
| RIS_27_27-12.2_27-12.2-6 | 200 | 3872 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.2/27-12.2-6.htm |  | render-thin 281 |
| RIS_27_27-12.2_27-12.2-7 | 200 | 3872 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.2/27-12.2-7.htm |  | render-thin 281 |
| RIS_27_27-12.2_27-12.2-8 | 200 | 3872 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.2/27-12.2-8.htm |  | render-thin 281 |
| RIS_27_27-12.2_27-12.2-9 | 200 | 3872 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.2/27-12.2-9.htm |  | render-thin 281 |
| RIS_27_27-12.2_27-12.2-10 | 200 | 3874 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.2/27-12.2-10.htm |  | render-thin 283 |
| RIS_27_27-12.3_27-12.3-1 | 200 | 3887 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.3/27-12.3-1.htm |  | render-thin 268 |
| RIS_27_27-12.3_27-12.3-2 | 200 | 6758 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.3/27-12.3-2.htm |  |  |
| RIS_27_27-12.3_27-12.3-3 | 200 | 7282 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-12.3/27-12.3-3.htm |  |  |
| RIS_27_27-13_27-13-1 | 200 | 5587 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-13/27-13-1.htm |  |  |
| RIS_27_27-13_27-13-2 | 200 | 3633 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-13/27-13-2.htm |  | render-thin 124 |
| RIS_27_27-13.1_27-13.1-1 | 200 | 4433 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-13.1/27-13.1-1.htm |  |  |
| RIS_27_27-13.1_27-13.1-2 | 200 | 5221 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-13.1/27-13.1-2.htm |  |  |
| RIS_27_27-13.1_27-13.1-3 | 200 | 6578 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-13.1/27-13.1-3.htm |  |  |
| RIS_27_27-13.1_27-13.1-3.1 | 200 | 5521 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-13.1/27-13.1-3.1.htm |  |  |
| RIS_27_27-13.1_27-13.1-4 | 200 | 8157 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-13.1/27-13.1-4.htm |  |  |
| RIS_27_27-13.1_27-13.1-5 | 200 | 18344 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-13.1/27-13.1-5.htm |  |  |
| RIS_27_27-13.1_27-13.1-6 | 200 | 5421 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-13.1/27-13.1-6.htm |  |  |
| RIS_27_27-13.1_27-13.1-7 | 200 | 5774 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-13.1/27-13.1-7.htm |  |  |
| RIS_27_27-13.1_27-13.1-8 | 200 | 5554 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-13.1/27-13.1-8.htm |  |  |
| RIS_27_27-14_27-14-1 | 200 | 3642 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-14/27-14-1.htm |  | render-thin 133 |
| RIS_27_27-14.1_27-14.1-1 | 200 | 7157 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-14.1/27-14.1-1.htm |  |  |
| RIS_27_27-14.1_27-14.1-2 | 200 | 4458 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-14.1/27-14.1-2.htm |  |  |
| RIS_27_27-14.1_27-14.1-3 | 200 | 6666 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-14.1/27-14.1-3.htm |  |  |
| RIS_27_27-14.1_27-14.1-4 | 200 | 5734 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-14.1/27-14.1-4.htm |  |  |
| RIS_27_27-14.1_27-14.1-5 | 200 | 5964 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-14.1/27-14.1-5.htm |  |  |
| RIS_27_27-14.1_27-14.1-6 | 200 | 4296 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-14.1/27-14.1-6.htm |  |  |
| RIS_27_27-14.1_27-14.1-7 | 200 | 4264 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-14.1/27-14.1-7.htm |  |  |
| RIS_27_27-14.1_27-14.1-8 | 200 | 3892 | https://webserver.rilegislature.gov/Statutes/TITLE27/27-14.1/27-14.1-8.htm |  | render-thin 256 |
