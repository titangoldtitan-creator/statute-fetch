| label | http | bytes | url | title | flag |
|---|---|---|---|---|---|
| RIS_37_37-12.1_37-12.1-5 | 200 | 3972 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-12.1/37-12.1-5.htm |  |  |
| RIS_37_37-13_37-13-1 | 200 | 4756 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-1.htm |  |  |
| RIS_37_37-13_37-13-2 | 200 | 4801 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-2.htm |  |  |
| RIS_37_37-13_37-13-3 | 200 | 4652 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-3.htm |  |  |
| RIS_37_37-13_37-13-3.1 | 200 | 4982 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-3.1.htm |  |  |
| RIS_37_37-13_37-13-3.2 | 200 | 4703 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-3.2.htm |  |  |
| RIS_37_37-13_37-13-4 | 200 | 4793 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-4.htm |  |  |
| RIS_37_37-13_37-13-5 | 200 | 5264 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-5.htm |  |  |
| RIS_37_37-13_37-13-6 | 200 | 5648 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-6.htm |  |  |
| RIS_37_37-13_37-13-7 | 200 | 16789 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-7.htm |  |  |
| RIS_37_37-13_37-13-8 | 200 | 5600 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-8.htm |  |  |
| RIS_37_37-13_37-13-9 | 200 | 4557 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-9.htm |  |  |
| RIS_37_37-13_37-13-10 | 200 | 5446 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-10.htm |  |  |
| RIS_37_37-13_37-13-11 | 200 | 5911 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-11.htm |  |  |
| RIS_37_37-13_37-13-12 | 200 | 4955 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-12.htm |  |  |
| RIS_37_37-13_37-13-12.1 | 200 | 4047 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-12.1.htm |  |  |
| RIS_37_37-13_37-13-12.2 | 200 | 4235 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-12.2.htm |  |  |
| RIS_37_37-13_37-13-12.3 | 200 | 4268 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-12.3.htm |  |  |
| RIS_37_37-13_37-13-12.4 | 200 | 4543 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-12.4.htm |  |  |
| RIS_37_37-13_37-13-13 | 200 | 7957 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-13.htm |  |  |
| RIS_37_37-13_37-13-13.1 | 200 | 4342 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-13.1.htm |  |  |
| RIS_37_37-13_37-13-14 | 200 | 4901 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-14.htm |  |  |
| RIS_37_37-13_37-13-14.1 | 200 | 11499 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-14.1.htm |  |  |
| RIS_37_37-13_37-13-15 | 200 | 8090 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-15.htm |  |  |
| RIS_37_37-13_37-13-16 | 200 | 5714 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-16.htm |  |  |
| RIS_37_37-13_37-13-17 | 200 | 9613 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13/37-13-17.htm |  |  |
| RIS_37_37-13.1_37-13.1-1 | 200 | 8138 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13.1/37-13.1-1.htm |  |  |
| RIS_37_37-13.1_37-13.1-2 | 200 | 6015 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-13.1/37-13.1-2.htm |  |  |
| RIS_37_37-14_37-14-1 | 200 | 4386 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14/37-14-1.htm |  |  |
| RIS_37_37-14.1_37-14.1-1 | 200 | 4261 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.1/37-14.1-1.htm |  |  |
| RIS_37_37-14.1_37-14.1-2 | 200 | 4243 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.1/37-14.1-2.htm |  |  |
| RIS_37_37-14.1_37-14.1-3 | 200 | 7755 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.1/37-14.1-3.htm |  |  |
| RIS_37_37-14.1_37-14.1-4 | 200 | 4058 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.1/37-14.1-4.htm |  |  |
| RIS_37_37-14.1_37-14.1-5 | 200 | 4086 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.1/37-14.1-5.htm |  |  |
| RIS_37_37-14.1_37-14.1-6 | 200 | 7931 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.1/37-14.1-6.htm |  |  |
| RIS_37_37-14.1_37-14.1-7 | 200 | 4439 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.1/37-14.1-7.htm |  |  |
| RIS_37_37-14.1_37-14.1-8 | 200 | 4803 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.1/37-14.1-8.htm |  |  |
| RIS_37_37-14.2_37-14.2-1 | 200 | 3842 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.2/37-14.2-1.htm |  | render-thin 252 |
| RIS_37_37-14.2_37-14.2-2 | 200 | 3842 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.2/37-14.2-2.htm |  | render-thin 252 |
| RIS_37_37-14.2_37-14.2-3 | 200 | 3842 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.2/37-14.2-3.htm |  | render-thin 252 |
| RIS_37_37-14.2_37-14.2-4 | 200 | 3842 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.2/37-14.2-4.htm |  | render-thin 252 |
| RIS_37_37-14.3_37-14.3-1 | 200 | 4486 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.3/37-14.3-1.htm |  |  |
| RIS_37_37-14.3_37-14.3-2 | 200 | 4251 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.3/37-14.3-2.htm |  |  |
| RIS_37_37-14.3_37-14.3-3 | 200 | 6773 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.3/37-14.3-3.htm |  |  |
| RIS_37_37-14.3_37-14.3-4 | 200 | 4775 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.3/37-14.3-4.htm |  |  |
| RIS_37_37-14.3_37-14.3-5 | 200 | 4312 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.3/37-14.3-5.htm |  |  |
| RIS_37_37-14.3_37-14.3-6 | 200 | 4840 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.3/37-14.3-6.htm |  |  |
| RIS_37_37-14.3_37-14.3-7 | 200 | 4550 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-14.3/37-14.3-7.htm |  |  |
| RIS_37_37-15_37-15-1 | 200 | 4602 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-1.htm |  |  |
| RIS_37_37-15_37-15-2 | 200 | 5661 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-2.htm |  |  |
| RIS_37_37-15_37-15-3 | 200 | 7113 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-3.htm |  |  |
| RIS_37_37-15_37-15-4 | 200 | 3629 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-4.htm |  | render-thin 122 |
| RIS_37_37-15_37-15-5 | 200 | 5023 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-5.htm |  |  |
| RIS_37_37-15_37-15-6 | 200 | 4531 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-6.htm |  |  |
| RIS_37_37-15_37-15-7 | 200 | 7032 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-7.htm |  |  |
| RIS_37_37-15_37-15-7.1 | 200 | 6199 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-7.1.htm |  |  |
| RIS_37_37-15_37-15-8 | 200 | 4236 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-8.htm |  |  |
| RIS_37_37-15_37-15-9 | 200 | 7419 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-9.htm |  |  |
| RIS_37_37-15_37-15-10 | 200 | 4289 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-10.htm |  |  |
| RIS_37_37-15_37-15-11 | 200 | 3945 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-11.htm |  |  |
| RIS_37_37-15_37-15-12 | 200 | 3857 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-12.htm |  | render-thin 266 |
| RIS_37_37-15_37-15-13 | 200 | 6974 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-13.htm |  |  |
| RIS_37_37-15_37-15-14 | 200 | 5017 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-14.htm |  |  |
| RIS_37_37-15_37-15-15 | 200 | 5752 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-15.htm |  |  |
| RIS_37_37-15_37-15-16 | 200 | 4204 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-16.htm |  |  |
| RIS_37_37-15_37-15-17 | 200 | 4035 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-17.htm |  |  |
| RIS_37_37-15_37-15-18 | 200 | 4460 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-18.htm |  |  |
| RIS_37_37-15_37-15-19 | 200 | 4254 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15/37-15-19.htm |  |  |
| RIS_37_37-15.1_37-15.1-1 | 200 | 4596 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15.1/37-15.1-1.htm |  |  |
| RIS_37_37-15.1_37-15.1-2 | 200 | 6142 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15.1/37-15.1-2.htm |  |  |
| RIS_37_37-15.1_37-15.1-3 | 200 | 6809 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15.1/37-15.1-3.htm |  |  |
| RIS_37_37-15.1_37-15.1-4 | 200 | 4527 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15.1/37-15.1-4.htm |  |  |
| RIS_37_37-15.1_37-15.1-5 | 200 | 4010 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15.1/37-15.1-5.htm |  |  |
| RIS_37_37-15.1_37-15.1-6 | 200 | 5169 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15.1/37-15.1-6.htm |  |  |
| RIS_37_37-15.1_37-15.1-7 | 200 | 3855 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15.1/37-15.1-7.htm |  | render-thin 263 |
| RIS_37_37-15.1_37-15.1-8 | 200 | 4829 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15.1/37-15.1-8.htm |  |  |
| RIS_37_37-15.1_37-15.1-9 | 200 | 5688 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15.1/37-15.1-9.htm |  |  |
| RIS_37_37-15.1_37-15.1-10 | 200 | 4283 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15.1/37-15.1-10.htm |  |  |
| RIS_37_37-15.1_37-15.1-11 | 200 | 4063 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-15.1/37-15.1-11.htm |  |  |
| RIS_37_37-16_37-16-1 | 200 | 3849 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-1.htm |  | render-thin 231 |
| RIS_37_37-16_37-16-2 | 200 | 10150 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-2.htm |  |  |
| RIS_37_37-16_37-16-3 | 200 | 6789 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-3.htm |  |  |
| RIS_37_37-16_37-16-4 | 200 | 4266 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-4.htm |  |  |
| RIS_37_37-16_37-16-5 | 200 | 5524 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-5.htm |  |  |
| RIS_37_37-16_37-16-6 | 200 | 4607 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-6.htm |  |  |
| RIS_37_37-16_37-16-7 | 200 | 4432 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-7.htm |  |  |
| RIS_37_37-16_37-16-8 | 200 | 4643 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-8.htm |  |  |
| RIS_37_37-16_37-16-9 | 200 | 3986 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-9.htm |  |  |
| RIS_37_37-16_37-16-10 | 200 | 4407 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-10.htm |  |  |
| RIS_37_37-16_37-16-11 | 200 | 4388 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-11.htm |  |  |
| RIS_37_37-16_37-16-12 | 200 | 4060 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-12.htm |  |  |
| RIS_37_37-16_37-16-13 | 200 | 6529 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-13.htm |  |  |
| RIS_37_37-16_37-16-14 | 200 | 4099 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-14.htm |  |  |
| RIS_37_37-16_37-16-15 | 200 | 4048 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-15.htm |  |  |
| RIS_37_37-16_37-16-16 | 200 | 4188 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-16.htm |  |  |
| RIS_37_37-16_37-16-17 | 200 | 4532 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-17.htm |  |  |
| RIS_37_37-16_37-16-18 | 200 | 4541 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-18.htm |  |  |
| RIS_37_37-16_37-16-19 | 200 | 4388 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-19.htm |  |  |
| RIS_37_37-16_37-16-20 | 200 | 4793 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-20.htm |  |  |
| RIS_37_37-16_37-16-21 | 200 | 4591 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-21.htm |  |  |
| RIS_37_37-16_37-16-22 | 200 | 4273 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-22.htm |  |  |
| RIS_37_37-16_37-16-23 | 200 | 4655 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-23.htm |  |  |
| RIS_37_37-16_37-16-24 | 200 | 4095 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-24.htm |  |  |
| RIS_37_37-16_37-16-25 | 200 | 4156 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-25.htm |  |  |
| RIS_37_37-16_37-16-26 | 200 | 4756 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-26.htm |  |  |
| RIS_37_37-16_37-16-27 | 200 | 5559 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-16/37-16-27.htm |  |  |
| RIS_37_37-17_37-17-1 | 200 | 4026 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-17/37-17-1.htm |  |  |
| RIS_37_37-18_37-18-1 | 200 | 3917 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-1.htm |  | render-thin 277 |
| RIS_37_37-18_37-18-2 | 200 | 5498 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-2.htm |  |  |
| RIS_37_37-18_37-18-3 | 200 | 5254 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-3.htm |  |  |
| RIS_37_37-18_37-18-4 | 200 | 4198 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-4.htm |  |  |
| RIS_37_37-18_37-18-5 | 200 | 9468 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-5.htm |  |  |
| RIS_37_37-18_37-18-6 | 200 | 10233 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-6.htm |  |  |
| RIS_37_37-18_37-18-7 | 200 | 6675 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-7.htm |  |  |
| RIS_37_37-18_37-18-8 | 200 | 4326 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-8.htm |  |  |
| RIS_37_37-18_37-18-9 | 200 | 4593 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-9.htm |  |  |
| RIS_37_37-18_37-18-10 | 200 | 5475 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-10.htm |  |  |
| RIS_37_37-18_37-18-11 | 200 | 4005 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-11.htm |  |  |
| RIS_37_37-18_37-18-12 | 200 | 4687 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-12.htm |  |  |
| RIS_37_37-18_37-18-13 | 200 | 5336 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-13.htm |  |  |
| RIS_37_37-18_37-18-14 | 200 | 6830 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-14.htm |  |  |
| RIS_37_37-18_37-18-15 | 200 | 4255 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-18/37-18-15.htm |  |  |
| RIS_37_37-19_37-19-1 | 200 | 3904 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-19/37-19-1.htm |  |  |
| RIS_37_37-20_37-20-1 | 200 | 5654 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-20/37-20-1.htm |  |  |
| RIS_37_37-21_37-21-1 | 200 | 3917 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-21/37-21-1.htm |  | render-thin 277 |
| RIS_37_37-21_37-21-2 | 200 | 3840 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-21/37-21-2.htm |  | render-thin 250 |
| RIS_37_37-21_37-21-3 | 200 | 4931 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-21/37-21-3.htm |  |  |
| RIS_37_37-21_37-21-4 | 200 | 3849 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-21/37-21-4.htm |  | render-thin 259 |
| RIS_37_37-22_37-22-1 | 200 | 3887 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-1.htm |  | render-thin 295 |
| RIS_37_37-22_37-22-2 | 200 | 3887 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-2.htm |  | render-thin 295 |
| RIS_37_37-22_37-22-3 | 200 | 3887 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-3.htm |  | render-thin 295 |
| RIS_37_37-22_37-22-4 | 200 | 3887 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-4.htm |  | render-thin 295 |
| RIS_37_37-22_37-22-5 | 200 | 3887 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-5.htm |  | render-thin 295 |
| RIS_37_37-22_37-22-6 | 200 | 3887 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-6.htm |  | render-thin 295 |
| RIS_37_37-22_37-22-7 | 200 | 3887 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-7.htm |  | render-thin 295 |
| RIS_37_37-22_37-22-8 | 200 | 3887 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-8.htm |  | render-thin 295 |
| RIS_37_37-22_37-22-9 | 200 | 3887 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-9.htm |  | render-thin 295 |
| RIS_37_37-22_37-22-10 | 200 | 3889 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-10.htm |  | render-thin 297 |
| RIS_37_37-22_37-22-11 | 200 | 3889 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-11.htm |  | render-thin 297 |
| RIS_37_37-22_37-22-12 | 200 | 3889 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-12.htm |  | render-thin 297 |
| RIS_37_37-22_37-22-13 | 200 | 3889 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-13.htm |  | render-thin 297 |
| RIS_37_37-22_37-22-14 | 200 | 3889 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-22/37-22-14.htm |  | render-thin 297 |
| RIS_37_37-23_37-23-1 | 200 | 5460 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-23/37-23-1.htm |  |  |
| RIS_37_37-23_37-23-2 | 200 | 7362 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-23/37-23-2.htm |  |  |
| RIS_37_37-23_37-23-3 | 200 | 5026 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-23/37-23-3.htm |  |  |
| RIS_37_37-23_37-23-4 | 200 | 4219 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-23/37-23-4.htm |  |  |
| RIS_37_37-23_37-23-5 | 200 | 4188 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-23/37-23-5.htm |  |  |
| RIS_37_37-23_37-23-6 | 200 | 4261 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-23/37-23-6.htm |  |  |
| RIS_37_37-23_37-23-7 | 200 | 4056 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-23/37-23-7.htm |  |  |
| RIS_37_37-23_37-23-8 | 200 | 4676 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-23/37-23-8.htm |  |  |
| RIS_37_37-23_37-23-9 | 200 | 4017 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-23/37-23-9.htm |  |  |
| RIS_37_37-23_37-23-10 | 200 | 4107 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-23/37-23-10.htm |  |  |
| RIS_37_37-23_37-23-11 | 200 | 4538 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-23/37-23-11.htm |  |  |
| RIS_37_37-23_37-23-12 | 200 | 4324 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-23/37-23-12.htm |  |  |
| RIS_37_37-24_37-24-1 | 200 | 3852 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-24/37-24-1.htm |  | render-thin 234 |
| RIS_37_37-24_37-24-2 | 200 | 5562 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-24/37-24-2.htm |  |  |
| RIS_37_37-24_37-24-3 | 200 | 7338 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-24/37-24-3.htm |  |  |
| RIS_37_37-24_37-24-4 | 200 | 6736 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-24/37-24-4.htm |  |  |
| RIS_37_37-24_37-24-5 | 200 | 13760 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-24/37-24-5.htm |  |  |
| RIS_37_37-24_37-24-6 | 200 | 4342 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-24/37-24-6.htm |  |  |
| RIS_37_37-25_37-25-1 | 200 | 10089 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-25/37-25-1.htm |  |  |
| RIS_37_37-26_37-26-1 | 200 | 13392 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-26/37-26-1.htm |  |  |
| RIS_37_37-26_37-26-2 | 200 | 4580 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-26/37-26-2.htm |  |  |
| RIS_37_37-26_37-26-3 | 200 | 6217 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-26/37-26-3.htm |  |  |
| RIS_37_37-26_37-26-4 | 200 | 4215 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-26/37-26-4.htm |  |  |
| RIS_37_37-26_37-26-5 | 200 | 5329 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-26/37-26-5.htm |  |  |
| RIS_37_37-26_37-26-6 | 200 | 5406 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-26/37-26-6.htm |  |  |
| RIS_37_37-26_37-26-7 | 200 | 13336 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-26/37-26-7.htm |  |  |
| RIS_37_37-26_37-26-8 | 200 | 8040 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-26/37-26-8.htm |  |  |
| RIS_37_37-26_37-26-9 | 200 | 5851 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-26/37-26-9.htm |  |  |
| RIS_37_37-26_37-26-10 | 200 | 7273 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-26/37-26-10.htm |  |  |
| RIS_37_37-26_37-26-11 | 200 | 4215 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-26/37-26-11.htm |  |  |
| RIS_37_37-27_37-27-1 | 200 | 3993 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-27/37-27-1.htm |  |  |
| RIS_37_37-27_37-27-2 | 200 | 7111 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-27/37-27-2.htm |  |  |
| RIS_37_37-27_37-27-3 | 200 | 4605 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-27/37-27-3.htm |  |  |
| RIS_37_37-27_37-27-4 | 200 | 6068 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-27/37-27-4.htm |  |  |
| RIS_37_37-27_37-27-5 | 200 | 5271 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-27/37-27-5.htm |  |  |
| RIS_37_37-27_37-27-6 | 200 | 4909 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-27/37-27-6.htm |  |  |
| RIS_37_37-27_37-27-7 | 200 | 4225 | https://webserver.rilegislature.gov/Statutes/TITLE37/37-27/37-27-7.htm |  |  |
| RIS_38_38-1_38-1-1 | 200 | 5157 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-1/38-1-1.htm |  |  |
| RIS_38_38-1_38-1-1.1 | 200 | 5482 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-1/38-1-1.1.htm |  |  |
| RIS_38_38-1_38-1-2 | 200 | 4537 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-1/38-1-2.htm |  |  |
| RIS_38_38-1_38-1-3 | 200 | 4781 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-1/38-1-3.htm |  |  |
| RIS_38_38-1_38-1-4 | 200 | 4481 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-1/38-1-4.htm |  |  |
| RIS_38_38-1_38-1-5 | 200 | 4170 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-1/38-1-5.htm |  |  |
| RIS_38_38-1_38-1-9 | 200 | 3997 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-1/38-1-9.htm |  |  |
| RIS_38_38-1_38-1-10 | 200 | 4020 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-1/38-1-10.htm |  |  |
| RIS_38_38-1_38-1-11 | 200 | 4955 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-1/38-1-11.htm |  |  |
| RIS_38_38-2_38-2-1 | 200 | 4341 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-1.htm |  |  |
| RIS_38_38-2_38-2-2 | 200 | 19017 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-2.htm |  |  |
| RIS_38_38-2_38-2-3 | 200 | 9919 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-3.htm |  |  |
| RIS_38_38-2_38-2-3.1 | 200 | 3956 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-3.1.htm |  |  |
| RIS_38_38-2_38-2-3.2 | 200 | 5424 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-3.2.htm |  |  |
| RIS_38_38-2_38-2-3.16 | 200 | 4433 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-3.16.htm |  |  |
| RIS_38_38-2_38-2-4 | 200 | 5995 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-4.htm |  |  |
| RIS_38_38-2_38-2-5 | 200 | 4747 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-5.htm |  |  |
| RIS_38_38-2_38-2-6 | 200 | 3860 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-6.htm |  | render-thin 269 |
| RIS_38_38-2_38-2-7 | 200 | 5439 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-7.htm |  |  |
| RIS_38_38-2_38-2-8 | 200 | 5831 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-8.htm |  |  |
| RIS_38_38-2_38-2-9 | 200 | 6080 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-9.htm |  |  |
| RIS_38_38-2_38-2-10 | 200 | 4009 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-10.htm |  |  |
| RIS_38_38-2_38-2-11 | 200 | 3957 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-11.htm |  |  |
| RIS_38_38-2_38-2-12 | 200 | 4090 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-12.htm |  |  |
| RIS_38_38-2_38-2-13 | 200 | 4104 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-13.htm |  |  |
| RIS_38_38-2_38-2-14 | 200 | 3957 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-14.htm |  |  |
| RIS_38_38-2_38-2-15 | 200 | 4154 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-15.htm |  |  |
| RIS_38_38-2_38-2-16 | 200 | 4719 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-16.htm |  |  |
| RIS_38_38-2_38-2-17 | 200 | 4530 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-2/38-2-17.htm |  |  |
| RIS_38_38-3_38-3-1 | 200 | 3845 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-3/38-3-1.htm |  | render-thin 227 |
| RIS_38_38-3_38-3-2 | 200 | 8579 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-3/38-3-2.htm |  |  |
| RIS_38_38-3_38-3-3 | 200 | 5599 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-3/38-3-3.htm |  |  |
| RIS_38_38-3_38-3-4 | 200 | 10329 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-3/38-3-4.htm |  |  |
| RIS_38_38-3_38-3-5 | 200 | 3911 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-3/38-3-5.htm |  |  |
| RIS_38_38-3_38-3-5.1 | 200 | 6293 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-3/38-3-5.1.htm |  |  |
| RIS_38_38-3_38-3-6 | 200 | 8215 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-3/38-3-6.htm |  |  |
| RIS_38_38-3_38-3-7 | 200 | 7076 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-3/38-3-7.htm |  |  |
| RIS_38_38-3_38-3-8 | 200 | 4155 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-3/38-3-8.htm |  |  |
| RIS_38_38-3_38-3-9 | 200 | 4107 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-3/38-3-9.htm |  |  |
| RIS_38_38-3_38-3-10 | 200 | 4268 | https://webserver.rilegislature.gov/Statutes/TITLE38/38-3/38-3-10.htm |  |  |
| RIS_39_39-1_39-1-1 | 200 | 11104 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-1.htm |  |  |
| RIS_39_39-1_39-1-2 | 200 | 20356 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-2.htm |  |  |
| RIS_39_39-1_39-1-2.1 | 200 | 6733 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-2.1.htm |  |  |
| RIS_39_39-1_39-1-3 | 200 | 6131 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-3.htm |  |  |
| RIS_39_39-1_39-1-4 | 200 | 5700 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-4.htm |  |  |
| RIS_39_39-1_39-1-5 | 200 | 4333 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-5.htm |  |  |
| RIS_39_39-1_39-1-6 | 200 | 4737 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-6.htm |  |  |
| RIS_39_39-1_39-1-7 | 200 | 4826 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-7.htm |  |  |
| RIS_39_39-1_39-1-8 | 200 | 4367 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-8.htm |  |  |
| RIS_39_39-1_39-1-9 | 200 | 4182 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-9.htm |  |  |
| RIS_39_39-1_39-1-10 | 200 | 4403 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-10.htm |  |  |
| RIS_39_39-1_39-1-11 | 200 | 4641 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-11.htm |  |  |
| RIS_39_39-1_39-1-12 | 200 | 5402 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-12.htm |  |  |
| RIS_39_39-1_39-1-13 | 200 | 6154 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-13.htm |  |  |
| RIS_39_39-1_39-1-14 | 200 | 3803 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-14.htm |  | render-thin 227 |
| RIS_39_39-1_39-1-15 | 200 | 5478 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-15.htm |  |  |
| RIS_39_39-1_39-1-15.1 | 200 | 4787 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-15.1.htm |  |  |
| RIS_39_39-1_39-1-15.2 | 200 | 4396 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-15.2.htm |  |  |
| RIS_39_39-1_39-1-16 | 200 | 4133 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-16.htm |  |  |
| RIS_39_39-1_39-1-17 | 200 | 4459 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-17.htm |  |  |
| RIS_39_39-1_39-1-18 | 200 | 7786 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-18.htm |  |  |
| RIS_39_39-1_39-1-19 | 200 | 5358 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-19.htm |  |  |
| RIS_39_39-1_39-1-20 | 200 | 4581 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-20.htm |  |  |
| RIS_39_39-1_39-1-21 | 200 | 5113 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-21.htm |  |  |
| RIS_39_39-1_39-1-22 | 200 | 4322 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-22.htm |  |  |
| RIS_39_39-1_39-1-23 | 200 | 8257 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-23.htm |  |  |
| RIS_39_39-1_39-1-23.1 | 200 | 6084 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-23.1.htm |  |  |
| RIS_39_39-1_39-1-24 | 200 | 4730 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-24.htm |  |  |
| RIS_39_39-1_39-1-25 | 200 | 4365 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-25.htm |  |  |
| RIS_39_39-1_39-1-26 | 200 | 11414 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-26.htm |  |  |
| RIS_39_39-1_39-1-27 | 200 | 16845 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.htm |  |  |
| RIS_39_39-1_39-1-27.1 | 200 | 12750 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.1.htm |  |  |
| RIS_39_39-1_39-1-27.2 | 200 | 3810 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.2.htm |  | render-thin 235 |
| RIS_39_39-1_39-1-27.3 | 200 | 13326 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.3.htm |  |  |
| RIS_39_39-1_39-1-27.3.1 | 200 | 8279 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.3.1.htm |  |  |
| RIS_39_39-1_39-1-27.4 | 200 | 17517 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.4.htm |  |  |
| RIS_39_39-1_39-1-27.5 | 200 | 3810 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.5.htm |  | render-thin 235 |
| RIS_39_39-1_39-1-27.6 | 200 | 9847 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.6.htm |  |  |
| RIS_39_39-1_39-1-27.7 | 200 | 20382 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.7.htm |  |  |
| RIS_39_39-1_39-1-27.7.1 | 200 | 14365 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.7.1.htm |  |  |
| RIS_39_39-1_39-1-27.8 | 200 | 6697 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.8.htm |  |  |
| RIS_39_39-1_39-1-27.9 | 200 | 4698 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.9.htm |  |  |
| RIS_39_39-1_39-1-27.10 | 200 | 5653 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.10.htm |  |  |
| RIS_39_39-1_39-1-27.11 | 200 | 4319 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.11.htm |  |  |
| RIS_39_39-1_39-1-27.12 | 200 | 8717 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.12.htm |  |  |
| RIS_39_39-1_39-1-27.13 | 200 | 4526 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-27.13.htm |  |  |
| RIS_39_39-1_39-1-28 | 200 | 5055 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-28.htm |  |  |
| RIS_39_39-1_39-1-29 | 200 | 4339 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-29.htm |  |  |
| RIS_39_39-1_39-1-30 | 200 | 5537 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-30.htm |  |  |
| RIS_39_39-1_39-1-30.1 | 200 | 4576 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-30.1.htm |  |  |
| RIS_39_39-1_39-1-30.2 | 200 | 4127 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-30.2.htm |  |  |
| RIS_39_39-1_39-1-30.3 | 200 | 5798 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-30.3.htm |  |  |
| RIS_39_39-1_39-1-31 | 200 | 5489 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-31.htm |  |  |
| RIS_39_39-1_39-1-32 | 200 | 5891 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-32.htm |  |  |
| RIS_39_39-1_39-1-33 | 200 | 4502 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-33.htm |  |  |
| RIS_39_39-1_39-1-34 | 200 | 4233 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-34.htm |  |  |
| RIS_39_39-1_39-1-35 | 200 | 4812 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-35.htm |  |  |
| RIS_39_39-1_39-1-36 | 200 | 4577 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-36.htm |  |  |
| RIS_39_39-1_39-1-37 | 200 | 4407 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-37.htm |  |  |
| RIS_39_39-1_39-1-37.1 | 200 | 8526 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-37.1.htm |  |  |
| RIS_39_39-1_39-1-38 | 200 | 5157 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-38.htm |  |  |
| RIS_39_39-1_39-1-39 | 200 | 3822 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-39.htm |  | render-thin 232 |
| RIS_39_39-1_39-1-40 | 200 | 4185 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-40.htm |  |  |
| RIS_39_39-1_39-1-41 | 200 | 3806 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-41.htm |  | render-thin 231 |
| RIS_39_39-1_39-1-42 | 200 | 8847 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-42.htm |  |  |
| RIS_39_39-1_39-1-43 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-43.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-44 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-44.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-45 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-45.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-46 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-46.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-47 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-47.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-48 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-48.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-49 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-49.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-50 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-50.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-51 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-51.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-52 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-52.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-53 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-53.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-54 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-54.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-55 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-55.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-56 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-56.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-57 | 200 | 3896 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-57.htm |  |  |
| RIS_39_39-1_39-1-58 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-58.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-59 | 200 | 3896 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-59.htm |  |  |
| RIS_39_39-1_39-1-60 | 200 | 3870 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-60.htm |  | render-thin 279 |
| RIS_39_39-1_39-1-61 | 200 | 10977 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-61.htm |  |  |
| RIS_39_39-1_39-1-62 | 200 | 4029 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-62.htm |  |  |
| RIS_39_39-1_39-1-63 | 200 | 4903 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1/39-1-63.htm |  |  |
| RIS_39_39-1.1_39-1.1-1 | 200 | 5148 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.1/39-1.1-1.htm |  |  |
| RIS_39_39-1.1_39-1.1-2 | 200 | 7253 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.1/39-1.1-2.htm |  |  |
| RIS_39_39-1.1_39-1.1-2.1 | 200 | 4905 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.1/39-1.1-2.1.htm |  |  |
| RIS_39_39-1.1_39-1.1-3 | 200 | 4539 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.1/39-1.1-3.htm |  |  |
| RIS_39_39-1.1_39-1.1-4 | 200 | 4251 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.1/39-1.1-4.htm |  |  |
| RIS_39_39-1.1_39-1.1-5 | 200 | 4241 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.1/39-1.1-5.htm |  |  |
| RIS_39_39-1.2_39-1.2-1 | 200 | 9372 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-1.htm |  |  |
| RIS_39_39-1.2_39-1.2-1.1 | 200 | 5404 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-1.1.htm |  |  |
| RIS_39_39-1.2_39-1.2-2 | 200 | 4313 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-2.htm |  |  |
| RIS_39_39-1.2_39-1.2-3 | 200 | 4269 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-3.htm |  |  |
| RIS_39_39-1.2_39-1.2-4 | 200 | 4332 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-4.htm |  |  |
| RIS_39_39-1.2_39-1.2-5 | 200 | 8485 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-5.htm |  |  |
| RIS_39_39-1.2_39-1.2-6 | 200 | 3992 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-6.htm |  |  |
| RIS_39_39-1.2_39-1.2-7 | 200 | 8240 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-7.htm |  |  |
| RIS_39_39-1.2_39-1.2-8 | 200 | 5267 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-8.htm |  |  |
| RIS_39_39-1.2_39-1.2-9 | 200 | 4872 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-9.htm |  |  |
| RIS_39_39-1.2_39-1.2-10 | 200 | 4371 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-10.htm |  |  |
| RIS_39_39-1.2_39-1.2-11 | 200 | 5791 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-11.htm |  |  |
| RIS_39_39-1.2_39-1.2-12 | 200 | 4319 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-12.htm |  |  |
| RIS_39_39-1.2_39-1.2-13 | 200 | 5320 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-13.htm |  |  |
| RIS_39_39-1.2_39-1.2-13.1 | 200 | 7064 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-13.1.htm |  |  |
| RIS_39_39-1.2_39-1.2-14 | 200 | 4084 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-1.2/39-1.2-14.htm |  |  |
| RIS_39_39-2_39-2-1 | 200 | 16980 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-1.htm |  |  |
| RIS_39_39-2_39-2-1.1 | 200 | 4142 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-1.1.htm |  |  |
| RIS_39_39-2_39-2-1.2 | 200 | 24509 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-1.2.htm |  |  |
| RIS_39_39-2_39-2-1.3 | 200 | 4314 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-1.3.htm |  |  |
| RIS_39_39-2_39-2-1.4 | 200 | 7234 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-1.4.htm |  |  |
| RIS_39_39-2_39-2-2 | 200 | 5939 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-2.htm |  |  |
| RIS_39_39-2_39-2-3 | 200 | 4792 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-3.htm |  |  |
| RIS_39_39-2_39-2-4 | 200 | 5170 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-4.htm |  |  |
| RIS_39_39-2_39-2-5 | 200 | 12607 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-5.htm |  |  |
| RIS_39_39-2_39-2-6 | 200 | 5592 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-6.htm |  |  |
| RIS_39_39-2_39-2-7 | 200 | 4679 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-7.htm |  |  |
| RIS_39_39-2_39-2-8 | 200 | 4639 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-8.htm |  |  |
| RIS_39_39-2_39-2-9 | 200 | 4376 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-9.htm |  |  |
| RIS_39_39-2_39-2-10 | 200 | 4048 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-10.htm |  |  |
| RIS_39_39-2_39-2-11 | 200 | 4252 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-11.htm |  |  |
| RIS_39_39-2_39-2-12 | 200 | 4187 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-12.htm |  |  |
| RIS_39_39-2_39-2-13 | 200 | 5249 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-13.htm |  |  |
| RIS_39_39-2_39-2-14 | 200 | 3941 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-14.htm |  |  |
| RIS_39_39-2_39-2-15 | 200 | 9138 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-15.htm |  |  |
| RIS_39_39-2_39-2-15.1 | 200 | 7061 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-15.1.htm |  |  |
| RIS_39_39-2_39-2-16 | 200 | 3649 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-16.htm |  | render-thin 142 |
| RIS_39_39-2_39-2-18 | 200 | 4537 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-18.htm |  |  |
| RIS_39_39-2_39-2-19 | 200 | 4329 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-19.htm |  |  |
| RIS_39_39-2_39-2-20 | 200 | 7920 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-20.htm |  |  |
| RIS_39_39-2_39-2-20.1 | 200 | 13290 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-20.1.htm |  |  |
| RIS_39_39-2_39-2-21 | 200 | 4308 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-21.htm |  |  |
| RIS_39_39-2_39-2-22 | 200 | 4164 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-22.htm |  |  |
| RIS_39_39-2_39-2-23 | 200 | 4415 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-23.htm |  |  |
| RIS_39_39-2_39-2-24 | 200 | 10852 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-24.htm |  |  |
| RIS_39_39-2_39-2-25 | 200 | 11313 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-25.htm |  |  |
| RIS_39_39-2_39-2-26 | 200 | 9959 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-26.htm |  |  |
| RIS_39_39-2_39-2-27 | 200 | 5219 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-27.htm |  |  |
| RIS_39_39-2_39-2-28 | 200 | 4301 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-28.htm |  |  |
| RIS_39_39-2_39-2-29 | 200 | 4285 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-29.htm |  |  |
| RIS_39_39-2_39-2-30 | 200 | 4512 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2/39-2-30.htm |  |  |
| RIS_39_39-2.1_39-2.1-1 | 200 | 4876 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2.1/39-2.1-1.htm |  |  |
| RIS_39_39-2.1_39-2.1-2 | 200 | 4883 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2.1/39-2.1-2.htm |  |  |
| RIS_39_39-2.1_39-2.1-3 | 200 | 5218 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2.1/39-2.1-3.htm |  |  |
| RIS_39_39-2.2_39-2.2-1 | 200 | 3969 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2.2/39-2.2-1.htm |  |  |
| RIS_39_39-2.2_39-2.2-2 | 200 | 4708 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2.2/39-2.2-2.htm |  |  |
| RIS_39_39-2.2_39-2.2-3 | 200 | 5472 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2.2/39-2.2-3.htm |  |  |
| RIS_39_39-2.2_39-2.2-4 | 200 | 4040 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2.2/39-2.2-4.htm |  |  |
| RIS_39_39-2.2_39-2.2-5 | 200 | 5215 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-2.2/39-2.2-5.htm |  |  |
| RIS_39_39-3_39-3-1 | 200 | 5851 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-1.htm |  |  |
| RIS_39_39-3_39-3-1.1 | 200 | 5048 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-1.1.htm |  |  |
| RIS_39_39-3_39-3-1.2 | 200 | 13946 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-1.2.htm |  |  |
| RIS_39_39-3_39-3-2 | 200 | 4696 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-2.htm |  |  |
| RIS_39_39-3_39-3-3 | 200 | 6215 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-3.htm |  |  |
| RIS_39_39-3_39-3-3.1 | 200 | 4965 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-3.1.htm |  |  |
| RIS_39_39-3_39-3-4 | 200 | 4787 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-4.htm |  |  |
| RIS_39_39-3_39-3-5 | 200 | 4965 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-5.htm |  |  |
| RIS_39_39-3_39-3-6 | 200 | 4298 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-6.htm |  |  |
| RIS_39_39-3_39-3-7 | 200 | 4602 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-7.htm |  |  |
| RIS_39_39-3_39-3-7.1 | 200 | 4906 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-7.1.htm |  |  |
| RIS_39_39-3_39-3-8 | 200 | 4633 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-8.htm |  |  |
| RIS_39_39-3_39-3-9 | 200 | 4855 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-9.htm |  |  |
| RIS_39_39-3_39-3-10 | 200 | 6850 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-10.htm |  |  |
| RIS_39_39-3_39-3-11 | 200 | 8202 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-11.htm |  |  |
| RIS_39_39-3_39-3-11.1 | 200 | 6024 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-11.1.htm |  |  |
| RIS_39_39-3_39-3-11.2 | 200 | 4555 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-11.2.htm |  |  |
| RIS_39_39-3_39-3-11.3 | 200 | 4464 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-11.3.htm |  |  |
| RIS_39_39-3_39-3-12 | 200 | 4969 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-12.htm |  |  |
| RIS_39_39-3_39-3-12.1 | 200 | 5427 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-12.1.htm |  |  |
| RIS_39_39-3_39-3-12.2 | 200 | 4616 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-12.2.htm |  |  |
| RIS_39_39-3_39-3-13 | 200 | 4382 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-13.htm |  |  |
| RIS_39_39-3_39-3-13.1 | 200 | 4696 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-13.1.htm |  |  |
| RIS_39_39-3_39-3-14 | 200 | 4764 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-14.htm |  |  |
| RIS_39_39-3_39-3-15 | 200 | 4920 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-15.htm |  |  |
| RIS_39_39-3_39-3-16 | 200 | 3885 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-16.htm |  | render-thin 293 |
| RIS_39_39-3_39-3-17 | 200 | 7311 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-17.htm |  |  |
| RIS_39_39-3_39-3-18 | 200 | 4663 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-18.htm |  |  |
| RIS_39_39-3_39-3-19 | 200 | 4279 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-19.htm |  |  |
| RIS_39_39-3_39-3-20 | 200 | 4088 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-20.htm |  |  |
| RIS_39_39-3_39-3-21 | 200 | 4774 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-21.htm |  |  |
| RIS_39_39-3_39-3-22 | 200 | 4200 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-22.htm |  |  |
| RIS_39_39-3_39-3-23 | 200 | 4362 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-23.htm |  |  |
| RIS_39_39-3_39-3-24 | 200 | 6445 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-24.htm |  |  |
| RIS_39_39-3_39-3-25 | 200 | 5183 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-25.htm |  |  |
| RIS_39_39-3_39-3-26 | 200 | 4246 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-26.htm |  |  |
| RIS_39_39-3_39-3-27 | 200 | 5105 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-27.htm |  |  |
| RIS_39_39-3_39-3-28 | 200 | 5015 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-28.htm |  |  |
| RIS_39_39-3_39-3-29 | 200 | 4205 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-29.htm |  |  |
| RIS_39_39-3_39-3-30 | 200 | 5729 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-30.htm |  |  |
| RIS_39_39-3_39-3-31 | 200 | 4601 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-31.htm |  |  |
| RIS_39_39-3_39-3-32 | 200 | 4463 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-32.htm |  |  |
| RIS_39_39-3_39-3-33 | 200 | 4070 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-33.htm |  |  |
| RIS_39_39-3_39-3-34 | 200 | 3967 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-34.htm |  |  |
| RIS_39_39-3_39-3-35 | 200 | 4859 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-35.htm |  |  |
| RIS_39_39-3_39-3-36 | 200 | 4565 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-36.htm |  |  |
| RIS_39_39-3_39-3-37 | 200 | 4138 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-37.htm |  |  |
| RIS_39_39-3_39-3-37.1 | 200 | 4443 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-37.1.htm |  |  |
| RIS_39_39-3_39-3-37.2 | 200 | 5006 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-37.2.htm |  |  |
| RIS_39_39-3_39-3-37.3 | 200 | 5655 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-37.3.htm |  |  |
| RIS_39_39-3_39-3-38 | 200 | 4928 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-38.htm |  |  |
| RIS_39_39-3_39-3-38.1 | 200 | 4494 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-38.1.htm |  |  |
| RIS_39_39-3_39-3-39 | 200 | 5156 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-39.htm |  |  |
| RIS_39_39-3_39-3-40 | 200 | 6529 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-40.htm |  |  |
| RIS_39_39-3_39-3-41 | 200 | 4871 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-41.htm |  |  |
| RIS_39_39-3_39-3-42 | 200 | 3848 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-42.htm |  | render-thin 258 |
| RIS_39_39-3_39-3-43 | 200 | 3789 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-43.htm |  | render-thin 214 |
| RIS_39_39-3_39-3-44 | 200 | 4022 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-3/39-3-44.htm |  |  |
| RIS_39_39-4_39-4-1 | 200 | 5426 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-1.htm |  |  |
| RIS_39_39-4_39-4-2 | 200 | 4624 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-2.htm |  |  |
| RIS_39_39-4_39-4-3 | 200 | 6151 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-3.htm |  |  |
| RIS_39_39-4_39-4-4 | 200 | 4233 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-4.htm |  |  |
| RIS_39_39-4_39-4-5 | 200 | 4372 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-5.htm |  |  |
| RIS_39_39-4_39-4-6 | 200 | 4339 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-6.htm |  |  |
| RIS_39_39-4_39-4-7 | 200 | 4805 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-7.htm |  |  |
| RIS_39_39-4_39-4-8 | 200 | 4568 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-8.htm |  |  |
| RIS_39_39-4_39-4-9 | 200 | 4485 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-9.htm |  |  |
| RIS_39_39-4_39-4-10 | 200 | 4904 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-10.htm |  |  |
| RIS_39_39-4_39-4-11 | 200 | 4770 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-11.htm |  |  |
| RIS_39_39-4_39-4-11.1 | 200 | 4550 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-11.1.htm |  |  |
| RIS_39_39-4_39-4-12 | 200 | 4825 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-12.htm |  |  |
| RIS_39_39-4_39-4-13 | 200 | 5463 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-13.htm |  |  |
| RIS_39_39-4_39-4-14 | 200 | 4403 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-14.htm |  |  |
| RIS_39_39-4_39-4-15 | 200 | 4512 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-15.htm |  |  |
| RIS_39_39-4_39-4-16 | 200 | 4284 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-16.htm |  |  |
| RIS_39_39-4_39-4-17 | 200 | 4411 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-17.htm |  |  |
| RIS_39_39-4_39-4-18 | 200 | 4991 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-18.htm |  |  |
| RIS_39_39-4_39-4-19 | 200 | 3640 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-19.htm |  | render-thin 133 |
| RIS_39_39-4_39-4-21 | 200 | 5136 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-21.htm |  |  |
| RIS_39_39-4_39-4-22 | 200 | 5941 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-22.htm |  |  |
| RIS_39_39-4_39-4-23 | 200 | 5723 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-23.htm |  |  |
| RIS_39_39-4_39-4-24 | 200 | 4492 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-4/39-4-24.htm |  |  |
| RIS_39_39-5_39-5-1 | 200 | 4913 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-5/39-5-1.htm |  |  |
| RIS_39_39-5_39-5-2 | 200 | 4817 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-5/39-5-2.htm |  |  |
| RIS_39_39-5_39-5-3 | 200 | 4256 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-5/39-5-3.htm |  |  |
| RIS_39_39-5_39-5-4 | 200 | 5258 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-5/39-5-4.htm |  |  |
| RIS_39_39-5_39-5-5 | 200 | 5136 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-5/39-5-5.htm |  |  |
| RIS_39_39-6_39-6-1 | 200 | 4147 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-1.htm |  |  |
| RIS_39_39-6_39-6-2 | 200 | 4184 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-2.htm |  |  |
| RIS_39_39-6_39-6-3 | 200 | 4420 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-3.htm |  |  |
| RIS_39_39-6_39-6-4 | 200 | 4144 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-4.htm |  |  |
| RIS_39_39-6_39-6-5 | 200 | 4497 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-5.htm |  |  |
| RIS_39_39-6_39-6-6 | 200 | 4881 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-6.htm |  |  |
| RIS_39_39-6_39-6-7 | 200 | 4928 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-7.htm |  |  |
| RIS_39_39-6_39-6-8 | 200 | 4672 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-8.htm |  |  |
| RIS_39_39-6_39-6-9 | 200 | 4242 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-9.htm |  |  |
| RIS_39_39-6_39-6-10 | 200 | 4193 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-10.htm |  |  |
| RIS_39_39-6_39-6-11 | 200 | 4824 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-11.htm |  |  |
| RIS_39_39-6_39-6-12 | 200 | 4765 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-12.htm |  |  |
| RIS_39_39-6_39-6-13 | 200 | 4239 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-13.htm |  |  |
| RIS_39_39-6_39-6-14 | 200 | 5325 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-14.htm |  |  |
| RIS_39_39-6_39-6-15 | 200 | 4226 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-15.htm |  |  |
| RIS_39_39-6_39-6-16 | 200 | 4284 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-16.htm |  |  |
| RIS_39_39-6_39-6-17 | 200 | 4976 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-17.htm |  |  |
| RIS_39_39-6_39-6-18 | 200 | 4515 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-18.htm |  |  |
| RIS_39_39-6_39-6-19 | 200 | 6234 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-19.htm |  |  |
| RIS_39_39-6_39-6-20 | 200 | 5163 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-20.htm |  |  |
| RIS_39_39-6_39-6-21 | 200 | 4281 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-21.htm |  |  |
| RIS_39_39-6_39-6-22 | 200 | 5352 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-22.htm |  |  |
| RIS_39_39-6_39-6-23 | 200 | 4398 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-23.htm |  |  |
| RIS_39_39-6_39-6-24 | 200 | 4585 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-24.htm |  |  |
| RIS_39_39-6_39-6-25 | 200 | 5031 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-25.htm |  |  |
| RIS_39_39-6_39-6-26 | 200 | 5038 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-26.htm |  |  |
| RIS_39_39-6_39-6-27 | 200 | 4823 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-27.htm |  |  |
| RIS_39_39-6_39-6-27.1 | 200 | 5319 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-27.1.htm |  |  |
| RIS_39_39-6_39-6-27.2 | 200 | 5681 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-27.2.htm |  |  |
| RIS_39_39-6_39-6-28 | 200 | 3622 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-28.htm |  | render-thin 115 |
| RIS_39_39-6_39-6-29 | 200 | 5020 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-29.htm |  |  |
| RIS_39_39-6_39-6-30 | 200 | 5919 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-30.htm |  |  |
| RIS_39_39-6_39-6-31 | 200 | 4898 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-31.htm |  |  |
| RIS_39_39-6_39-6-32 | 200 | 4905 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-32.htm |  |  |
| RIS_39_39-6_39-6-33 | 200 | 5213 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6/39-6-33.htm |  |  |
| RIS_39_39-6.1_39-6.1-1 | 200 | 5006 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6.1/39-6.1-1.htm |  |  |
| RIS_39_39-6.1_39-6.1-2 | 200 | 5960 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6.1/39-6.1-2.htm |  |  |
| RIS_39_39-6.1_39-6.1-3 | 200 | 4390 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6.1/39-6.1-3.htm |  |  |
| RIS_39_39-6.1_39-6.1-4 | 200 | 4293 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6.1/39-6.1-4.htm |  |  |
| RIS_39_39-6.1_39-6.1-5 | 200 | 5350 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6.1/39-6.1-5.htm |  |  |
| RIS_39_39-6.1_39-6.1-6 | 200 | 4678 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6.1/39-6.1-6.htm |  |  |
| RIS_39_39-6.1_39-6.1-7 | 200 | 4281 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6.1/39-6.1-7.htm |  |  |
| RIS_39_39-6.1_39-6.1-8 | 200 | 4385 | https://webserver.rilegislature.gov/Statutes/TITLE39/39-6.1/39-6.1-8.htm |  |  |
